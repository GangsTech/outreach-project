(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))s(o);new MutationObserver(o=>{for(const l of o)if(l.type==="childList")for(const h of l.addedNodes)h.tagName==="LINK"&&h.rel==="modulepreload"&&s(h)}).observe(document,{childList:!0,subtree:!0});function t(o){const l={};return o.integrity&&(l.integrity=o.integrity),o.referrerPolicy&&(l.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?l.credentials="include":o.crossOrigin==="anonymous"?l.credentials="omit":l.credentials="same-origin",l}function s(o){if(o.ep)return;o.ep=!0;const l=t(o);fetch(o.href,l)}})();var nd={exports:{}},Ca={},rd={exports:{}},Se={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Km;function _w(){if(Km)return Se;Km=1;var r=Symbol.for("react.element"),e=Symbol.for("react.portal"),t=Symbol.for("react.fragment"),s=Symbol.for("react.strict_mode"),o=Symbol.for("react.profiler"),l=Symbol.for("react.provider"),h=Symbol.for("react.context"),m=Symbol.for("react.forward_ref"),g=Symbol.for("react.suspense"),_=Symbol.for("react.memo"),E=Symbol.for("react.lazy"),I=Symbol.iterator;function C(L){return L===null||typeof L!="object"?null:(L=I&&L[I]||L["@@iterator"],typeof L=="function"?L:null)}var z={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},G=Object.assign,Q={};function B(L,W,we){this.props=L,this.context=W,this.refs=Q,this.updater=we||z}B.prototype.isReactComponent={},B.prototype.setState=function(L,W){if(typeof L!="object"&&typeof L!="function"&&L!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,L,W,"setState")},B.prototype.forceUpdate=function(L){this.updater.enqueueForceUpdate(this,L,"forceUpdate")};function te(){}te.prototype=B.prototype;function fe(L,W,we){this.props=L,this.context=W,this.refs=Q,this.updater=we||z}var Ee=fe.prototype=new te;Ee.constructor=fe,G(Ee,B.prototype),Ee.isPureReactComponent=!0;var Ae=Array.isArray,De=Object.prototype.hasOwnProperty,Re={current:null},D={key:!0,ref:!0,__self:!0,__source:!0};function T(L,W,we){var Te,Ce={},Pe=null,je=null;if(W!=null)for(Te in W.ref!==void 0&&(je=W.ref),W.key!==void 0&&(Pe=""+W.key),W)De.call(W,Te)&&!D.hasOwnProperty(Te)&&(Ce[Te]=W[Te]);var Le=arguments.length-2;if(Le===1)Ce.children=we;else if(1<Le){for(var We=Array(Le),zt=0;zt<Le;zt++)We[zt]=arguments[zt+2];Ce.children=We}if(L&&L.defaultProps)for(Te in Le=L.defaultProps,Le)Ce[Te]===void 0&&(Ce[Te]=Le[Te]);return{$$typeof:r,type:L,key:Pe,ref:je,props:Ce,_owner:Re.current}}function S(L,W){return{$$typeof:r,type:L.type,key:W,ref:L.ref,props:L.props,_owner:L._owner}}function N(L){return typeof L=="object"&&L!==null&&L.$$typeof===r}function k(L){var W={"=":"=0",":":"=2"};return"$"+L.replace(/[=:]/g,function(we){return W[we]})}var V=/\/+/g;function A(L,W){return typeof L=="object"&&L!==null&&L.key!=null?k(""+L.key):W.toString(36)}function Ie(L,W,we,Te,Ce){var Pe=typeof L;(Pe==="undefined"||Pe==="boolean")&&(L=null);var je=!1;if(L===null)je=!0;else switch(Pe){case"string":case"number":je=!0;break;case"object":switch(L.$$typeof){case r:case e:je=!0}}if(je)return je=L,Ce=Ce(je),L=Te===""?"."+A(je,0):Te,Ae(Ce)?(we="",L!=null&&(we=L.replace(V,"$&/")+"/"),Ie(Ce,W,we,"",function(zt){return zt})):Ce!=null&&(N(Ce)&&(Ce=S(Ce,we+(!Ce.key||je&&je.key===Ce.key?"":(""+Ce.key).replace(V,"$&/")+"/")+L)),W.push(Ce)),1;if(je=0,Te=Te===""?".":Te+":",Ae(L))for(var Le=0;Le<L.length;Le++){Pe=L[Le];var We=Te+A(Pe,Le);je+=Ie(Pe,W,we,We,Ce)}else if(We=C(L),typeof We=="function")for(L=We.call(L),Le=0;!(Pe=L.next()).done;)Pe=Pe.value,We=Te+A(Pe,Le++),je+=Ie(Pe,W,we,We,Ce);else if(Pe==="object")throw W=String(L),Error("Objects are not valid as a React child (found: "+(W==="[object Object]"?"object with keys {"+Object.keys(L).join(", ")+"}":W)+"). If you meant to render a collection of children, use an array instead.");return je}function He(L,W,we){if(L==null)return L;var Te=[],Ce=0;return Ie(L,Te,"","",function(Pe){return W.call(we,Pe,Ce++)}),Te}function ut(L){if(L._status===-1){var W=L._result;W=W(),W.then(function(we){(L._status===0||L._status===-1)&&(L._status=1,L._result=we)},function(we){(L._status===0||L._status===-1)&&(L._status=2,L._result=we)}),L._status===-1&&(L._status=0,L._result=W)}if(L._status===1)return L._result.default;throw L._result}var Be={current:null},Z={transition:null},ae={ReactCurrentDispatcher:Be,ReactCurrentBatchConfig:Z,ReactCurrentOwner:Re};function ee(){throw Error("act(...) is not supported in production builds of React.")}return Se.Children={map:He,forEach:function(L,W,we){He(L,function(){W.apply(this,arguments)},we)},count:function(L){var W=0;return He(L,function(){W++}),W},toArray:function(L){return He(L,function(W){return W})||[]},only:function(L){if(!N(L))throw Error("React.Children.only expected to receive a single React element child.");return L}},Se.Component=B,Se.Fragment=t,Se.Profiler=o,Se.PureComponent=fe,Se.StrictMode=s,Se.Suspense=g,Se.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=ae,Se.act=ee,Se.cloneElement=function(L,W,we){if(L==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+L+".");var Te=G({},L.props),Ce=L.key,Pe=L.ref,je=L._owner;if(W!=null){if(W.ref!==void 0&&(Pe=W.ref,je=Re.current),W.key!==void 0&&(Ce=""+W.key),L.type&&L.type.defaultProps)var Le=L.type.defaultProps;for(We in W)De.call(W,We)&&!D.hasOwnProperty(We)&&(Te[We]=W[We]===void 0&&Le!==void 0?Le[We]:W[We])}var We=arguments.length-2;if(We===1)Te.children=we;else if(1<We){Le=Array(We);for(var zt=0;zt<We;zt++)Le[zt]=arguments[zt+2];Te.children=Le}return{$$typeof:r,type:L.type,key:Ce,ref:Pe,props:Te,_owner:je}},Se.createContext=function(L){return L={$$typeof:h,_currentValue:L,_currentValue2:L,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},L.Provider={$$typeof:l,_context:L},L.Consumer=L},Se.createElement=T,Se.createFactory=function(L){var W=T.bind(null,L);return W.type=L,W},Se.createRef=function(){return{current:null}},Se.forwardRef=function(L){return{$$typeof:m,render:L}},Se.isValidElement=N,Se.lazy=function(L){return{$$typeof:E,_payload:{_status:-1,_result:L},_init:ut}},Se.memo=function(L,W){return{$$typeof:_,type:L,compare:W===void 0?null:W}},Se.startTransition=function(L){var W=Z.transition;Z.transition={};try{L()}finally{Z.transition=W}},Se.unstable_act=ee,Se.useCallback=function(L,W){return Be.current.useCallback(L,W)},Se.useContext=function(L){return Be.current.useContext(L)},Se.useDebugValue=function(){},Se.useDeferredValue=function(L){return Be.current.useDeferredValue(L)},Se.useEffect=function(L,W){return Be.current.useEffect(L,W)},Se.useId=function(){return Be.current.useId()},Se.useImperativeHandle=function(L,W,we){return Be.current.useImperativeHandle(L,W,we)},Se.useInsertionEffect=function(L,W){return Be.current.useInsertionEffect(L,W)},Se.useLayoutEffect=function(L,W){return Be.current.useLayoutEffect(L,W)},Se.useMemo=function(L,W){return Be.current.useMemo(L,W)},Se.useReducer=function(L,W,we){return Be.current.useReducer(L,W,we)},Se.useRef=function(L){return Be.current.useRef(L)},Se.useState=function(L){return Be.current.useState(L)},Se.useSyncExternalStore=function(L,W,we){return Be.current.useSyncExternalStore(L,W,we)},Se.useTransition=function(){return Be.current.useTransition()},Se.version="18.3.1",Se}var Gm;function Wd(){return Gm||(Gm=1,rd.exports=_w()),rd.exports}/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Qm;function vw(){if(Qm)return Ca;Qm=1;var r=Wd(),e=Symbol.for("react.element"),t=Symbol.for("react.fragment"),s=Object.prototype.hasOwnProperty,o=r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,l={key:!0,ref:!0,__self:!0,__source:!0};function h(m,g,_){var E,I={},C=null,z=null;_!==void 0&&(C=""+_),g.key!==void 0&&(C=""+g.key),g.ref!==void 0&&(z=g.ref);for(E in g)s.call(g,E)&&!l.hasOwnProperty(E)&&(I[E]=g[E]);if(m&&m.defaultProps)for(E in g=m.defaultProps,g)I[E]===void 0&&(I[E]=g[E]);return{$$typeof:e,type:m,key:C,ref:z,props:I,_owner:o.current}}return Ca.Fragment=t,Ca.jsx=h,Ca.jsxs=h,Ca}var Ym;function Ew(){return Ym||(Ym=1,nd.exports=vw()),nd.exports}var P=Ew(),Ue=Wd(),Ru={},id={exports:{}},Qt={},sd={exports:{}},od={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Jm;function ww(){return Jm||(Jm=1,(function(r){function e(Z,ae){var ee=Z.length;Z.push(ae);e:for(;0<ee;){var L=ee-1>>>1,W=Z[L];if(0<o(W,ae))Z[L]=ae,Z[ee]=W,ee=L;else break e}}function t(Z){return Z.length===0?null:Z[0]}function s(Z){if(Z.length===0)return null;var ae=Z[0],ee=Z.pop();if(ee!==ae){Z[0]=ee;e:for(var L=0,W=Z.length,we=W>>>1;L<we;){var Te=2*(L+1)-1,Ce=Z[Te],Pe=Te+1,je=Z[Pe];if(0>o(Ce,ee))Pe<W&&0>o(je,Ce)?(Z[L]=je,Z[Pe]=ee,L=Pe):(Z[L]=Ce,Z[Te]=ee,L=Te);else if(Pe<W&&0>o(je,ee))Z[L]=je,Z[Pe]=ee,L=Pe;else break e}}return ae}function o(Z,ae){var ee=Z.sortIndex-ae.sortIndex;return ee!==0?ee:Z.id-ae.id}if(typeof performance=="object"&&typeof performance.now=="function"){var l=performance;r.unstable_now=function(){return l.now()}}else{var h=Date,m=h.now();r.unstable_now=function(){return h.now()-m}}var g=[],_=[],E=1,I=null,C=3,z=!1,G=!1,Q=!1,B=typeof setTimeout=="function"?setTimeout:null,te=typeof clearTimeout=="function"?clearTimeout:null,fe=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function Ee(Z){for(var ae=t(_);ae!==null;){if(ae.callback===null)s(_);else if(ae.startTime<=Z)s(_),ae.sortIndex=ae.expirationTime,e(g,ae);else break;ae=t(_)}}function Ae(Z){if(Q=!1,Ee(Z),!G)if(t(g)!==null)G=!0,ut(De);else{var ae=t(_);ae!==null&&Be(Ae,ae.startTime-Z)}}function De(Z,ae){G=!1,Q&&(Q=!1,te(T),T=-1),z=!0;var ee=C;try{for(Ee(ae),I=t(g);I!==null&&(!(I.expirationTime>ae)||Z&&!k());){var L=I.callback;if(typeof L=="function"){I.callback=null,C=I.priorityLevel;var W=L(I.expirationTime<=ae);ae=r.unstable_now(),typeof W=="function"?I.callback=W:I===t(g)&&s(g),Ee(ae)}else s(g);I=t(g)}if(I!==null)var we=!0;else{var Te=t(_);Te!==null&&Be(Ae,Te.startTime-ae),we=!1}return we}finally{I=null,C=ee,z=!1}}var Re=!1,D=null,T=-1,S=5,N=-1;function k(){return!(r.unstable_now()-N<S)}function V(){if(D!==null){var Z=r.unstable_now();N=Z;var ae=!0;try{ae=D(!0,Z)}finally{ae?A():(Re=!1,D=null)}}else Re=!1}var A;if(typeof fe=="function")A=function(){fe(V)};else if(typeof MessageChannel<"u"){var Ie=new MessageChannel,He=Ie.port2;Ie.port1.onmessage=V,A=function(){He.postMessage(null)}}else A=function(){B(V,0)};function ut(Z){D=Z,Re||(Re=!0,A())}function Be(Z,ae){T=B(function(){Z(r.unstable_now())},ae)}r.unstable_IdlePriority=5,r.unstable_ImmediatePriority=1,r.unstable_LowPriority=4,r.unstable_NormalPriority=3,r.unstable_Profiling=null,r.unstable_UserBlockingPriority=2,r.unstable_cancelCallback=function(Z){Z.callback=null},r.unstable_continueExecution=function(){G||z||(G=!0,ut(De))},r.unstable_forceFrameRate=function(Z){0>Z||125<Z?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):S=0<Z?Math.floor(1e3/Z):5},r.unstable_getCurrentPriorityLevel=function(){return C},r.unstable_getFirstCallbackNode=function(){return t(g)},r.unstable_next=function(Z){switch(C){case 1:case 2:case 3:var ae=3;break;default:ae=C}var ee=C;C=ae;try{return Z()}finally{C=ee}},r.unstable_pauseExecution=function(){},r.unstable_requestPaint=function(){},r.unstable_runWithPriority=function(Z,ae){switch(Z){case 1:case 2:case 3:case 4:case 5:break;default:Z=3}var ee=C;C=Z;try{return ae()}finally{C=ee}},r.unstable_scheduleCallback=function(Z,ae,ee){var L=r.unstable_now();switch(typeof ee=="object"&&ee!==null?(ee=ee.delay,ee=typeof ee=="number"&&0<ee?L+ee:L):ee=L,Z){case 1:var W=-1;break;case 2:W=250;break;case 5:W=1073741823;break;case 4:W=1e4;break;default:W=5e3}return W=ee+W,Z={id:E++,callback:ae,priorityLevel:Z,startTime:ee,expirationTime:W,sortIndex:-1},ee>L?(Z.sortIndex=ee,e(_,Z),t(g)===null&&Z===t(_)&&(Q?(te(T),T=-1):Q=!0,Be(Ae,ee-L))):(Z.sortIndex=W,e(g,Z),G||z||(G=!0,ut(De))),Z},r.unstable_shouldYield=k,r.unstable_wrapCallback=function(Z){var ae=C;return function(){var ee=C;C=ae;try{return Z.apply(this,arguments)}finally{C=ee}}}})(od)),od}var Xm;function Tw(){return Xm||(Xm=1,sd.exports=ww()),sd.exports}/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Zm;function Iw(){if(Zm)return Qt;Zm=1;var r=Wd(),e=Tw();function t(n){for(var i="https://reactjs.org/docs/error-decoder.html?invariant="+n,a=1;a<arguments.length;a++)i+="&args[]="+encodeURIComponent(arguments[a]);return"Minified React error #"+n+"; visit "+i+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var s=new Set,o={};function l(n,i){h(n,i),h(n+"Capture",i)}function h(n,i){for(o[n]=i,n=0;n<i.length;n++)s.add(i[n])}var m=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),g=Object.prototype.hasOwnProperty,_=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,E={},I={};function C(n){return g.call(I,n)?!0:g.call(E,n)?!1:_.test(n)?I[n]=!0:(E[n]=!0,!1)}function z(n,i,a,c){if(a!==null&&a.type===0)return!1;switch(typeof i){case"function":case"symbol":return!0;case"boolean":return c?!1:a!==null?!a.acceptsBooleans:(n=n.toLowerCase().slice(0,5),n!=="data-"&&n!=="aria-");default:return!1}}function G(n,i,a,c){if(i===null||typeof i>"u"||z(n,i,a,c))return!0;if(c)return!1;if(a!==null)switch(a.type){case 3:return!i;case 4:return i===!1;case 5:return isNaN(i);case 6:return isNaN(i)||1>i}return!1}function Q(n,i,a,c,d,f,v){this.acceptsBooleans=i===2||i===3||i===4,this.attributeName=c,this.attributeNamespace=d,this.mustUseProperty=a,this.propertyName=n,this.type=i,this.sanitizeURL=f,this.removeEmptyString=v}var B={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(n){B[n]=new Q(n,0,!1,n,null,!1,!1)}),[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(n){var i=n[0];B[i]=new Q(i,1,!1,n[1],null,!1,!1)}),["contentEditable","draggable","spellCheck","value"].forEach(function(n){B[n]=new Q(n,2,!1,n.toLowerCase(),null,!1,!1)}),["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(n){B[n]=new Q(n,2,!1,n,null,!1,!1)}),"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(n){B[n]=new Q(n,3,!1,n.toLowerCase(),null,!1,!1)}),["checked","multiple","muted","selected"].forEach(function(n){B[n]=new Q(n,3,!0,n,null,!1,!1)}),["capture","download"].forEach(function(n){B[n]=new Q(n,4,!1,n,null,!1,!1)}),["cols","rows","size","span"].forEach(function(n){B[n]=new Q(n,6,!1,n,null,!1,!1)}),["rowSpan","start"].forEach(function(n){B[n]=new Q(n,5,!1,n.toLowerCase(),null,!1,!1)});var te=/[\-:]([a-z])/g;function fe(n){return n[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(n){var i=n.replace(te,fe);B[i]=new Q(i,1,!1,n,null,!1,!1)}),"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(n){var i=n.replace(te,fe);B[i]=new Q(i,1,!1,n,"http://www.w3.org/1999/xlink",!1,!1)}),["xml:base","xml:lang","xml:space"].forEach(function(n){var i=n.replace(te,fe);B[i]=new Q(i,1,!1,n,"http://www.w3.org/XML/1998/namespace",!1,!1)}),["tabIndex","crossOrigin"].forEach(function(n){B[n]=new Q(n,1,!1,n.toLowerCase(),null,!1,!1)}),B.xlinkHref=new Q("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1),["src","href","action","formAction"].forEach(function(n){B[n]=new Q(n,1,!1,n.toLowerCase(),null,!0,!0)});function Ee(n,i,a,c){var d=B.hasOwnProperty(i)?B[i]:null;(d!==null?d.type!==0:c||!(2<i.length)||i[0]!=="o"&&i[0]!=="O"||i[1]!=="n"&&i[1]!=="N")&&(G(i,a,d,c)&&(a=null),c||d===null?C(i)&&(a===null?n.removeAttribute(i):n.setAttribute(i,""+a)):d.mustUseProperty?n[d.propertyName]=a===null?d.type===3?!1:"":a:(i=d.attributeName,c=d.attributeNamespace,a===null?n.removeAttribute(i):(d=d.type,a=d===3||d===4&&a===!0?"":""+a,c?n.setAttributeNS(c,i,a):n.setAttribute(i,a))))}var Ae=r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,De=Symbol.for("react.element"),Re=Symbol.for("react.portal"),D=Symbol.for("react.fragment"),T=Symbol.for("react.strict_mode"),S=Symbol.for("react.profiler"),N=Symbol.for("react.provider"),k=Symbol.for("react.context"),V=Symbol.for("react.forward_ref"),A=Symbol.for("react.suspense"),Ie=Symbol.for("react.suspense_list"),He=Symbol.for("react.memo"),ut=Symbol.for("react.lazy"),Be=Symbol.for("react.offscreen"),Z=Symbol.iterator;function ae(n){return n===null||typeof n!="object"?null:(n=Z&&n[Z]||n["@@iterator"],typeof n=="function"?n:null)}var ee=Object.assign,L;function W(n){if(L===void 0)try{throw Error()}catch(a){var i=a.stack.trim().match(/\n( *(at )?)/);L=i&&i[1]||""}return`
`+L+n}var we=!1;function Te(n,i){if(!n||we)return"";we=!0;var a=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(i)if(i=function(){throw Error()},Object.defineProperty(i.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(i,[])}catch(U){var c=U}Reflect.construct(n,[],i)}else{try{i.call()}catch(U){c=U}n.call(i.prototype)}else{try{throw Error()}catch(U){c=U}n()}}catch(U){if(U&&c&&typeof U.stack=="string"){for(var d=U.stack.split(`
`),f=c.stack.split(`
`),v=d.length-1,R=f.length-1;1<=v&&0<=R&&d[v]!==f[R];)R--;for(;1<=v&&0<=R;v--,R--)if(d[v]!==f[R]){if(v!==1||R!==1)do if(v--,R--,0>R||d[v]!==f[R]){var x=`
`+d[v].replace(" at new "," at ");return n.displayName&&x.includes("<anonymous>")&&(x=x.replace("<anonymous>",n.displayName)),x}while(1<=v&&0<=R);break}}}finally{we=!1,Error.prepareStackTrace=a}return(n=n?n.displayName||n.name:"")?W(n):""}function Ce(n){switch(n.tag){case 5:return W(n.type);case 16:return W("Lazy");case 13:return W("Suspense");case 19:return W("SuspenseList");case 0:case 2:case 15:return n=Te(n.type,!1),n;case 11:return n=Te(n.type.render,!1),n;case 1:return n=Te(n.type,!0),n;default:return""}}function Pe(n){if(n==null)return null;if(typeof n=="function")return n.displayName||n.name||null;if(typeof n=="string")return n;switch(n){case D:return"Fragment";case Re:return"Portal";case S:return"Profiler";case T:return"StrictMode";case A:return"Suspense";case Ie:return"SuspenseList"}if(typeof n=="object")switch(n.$$typeof){case k:return(n.displayName||"Context")+".Consumer";case N:return(n._context.displayName||"Context")+".Provider";case V:var i=n.render;return n=n.displayName,n||(n=i.displayName||i.name||"",n=n!==""?"ForwardRef("+n+")":"ForwardRef"),n;case He:return i=n.displayName||null,i!==null?i:Pe(n.type)||"Memo";case ut:i=n._payload,n=n._init;try{return Pe(n(i))}catch{}}return null}function je(n){var i=n.type;switch(n.tag){case 24:return"Cache";case 9:return(i.displayName||"Context")+".Consumer";case 10:return(i._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return n=i.render,n=n.displayName||n.name||"",i.displayName||(n!==""?"ForwardRef("+n+")":"ForwardRef");case 7:return"Fragment";case 5:return i;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return Pe(i);case 8:return i===T?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof i=="function")return i.displayName||i.name||null;if(typeof i=="string")return i}return null}function Le(n){switch(typeof n){case"boolean":case"number":case"string":case"undefined":return n;case"object":return n;default:return""}}function We(n){var i=n.type;return(n=n.nodeName)&&n.toLowerCase()==="input"&&(i==="checkbox"||i==="radio")}function zt(n){var i=We(n)?"checked":"value",a=Object.getOwnPropertyDescriptor(n.constructor.prototype,i),c=""+n[i];if(!n.hasOwnProperty(i)&&typeof a<"u"&&typeof a.get=="function"&&typeof a.set=="function"){var d=a.get,f=a.set;return Object.defineProperty(n,i,{configurable:!0,get:function(){return d.call(this)},set:function(v){c=""+v,f.call(this,v)}}),Object.defineProperty(n,i,{enumerable:a.enumerable}),{getValue:function(){return c},setValue:function(v){c=""+v},stopTracking:function(){n._valueTracker=null,delete n[i]}}}}function gs(n){n._valueTracker||(n._valueTracker=zt(n))}function Vo(n){if(!n)return!1;var i=n._valueTracker;if(!i)return!0;var a=i.getValue(),c="";return n&&(c=We(n)?n.checked?"true":"false":n.value),n=c,n!==a?(i.setValue(n),!0):!1}function Vr(n){if(n=n||(typeof document<"u"?document:void 0),typeof n>"u")return null;try{return n.activeElement||n.body}catch{return n.body}}function ys(n,i){var a=i.checked;return ee({},i,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:a??n._wrapperState.initialChecked})}function hl(n,i){var a=i.defaultValue==null?"":i.defaultValue,c=i.checked!=null?i.checked:i.defaultChecked;a=Le(i.value!=null?i.value:a),n._wrapperState={initialChecked:c,initialValue:a,controlled:i.type==="checkbox"||i.type==="radio"?i.checked!=null:i.value!=null}}function _s(n,i){i=i.checked,i!=null&&Ee(n,"checked",i,!1)}function Ni(n,i){_s(n,i);var a=Le(i.value),c=i.type;if(a!=null)c==="number"?(a===0&&n.value===""||n.value!=a)&&(n.value=""+a):n.value!==""+a&&(n.value=""+a);else if(c==="submit"||c==="reset"){n.removeAttribute("value");return}i.hasOwnProperty("value")?ct(n,i.type,a):i.hasOwnProperty("defaultValue")&&ct(n,i.type,Le(i.defaultValue)),i.checked==null&&i.defaultChecked!=null&&(n.defaultChecked=!!i.defaultChecked)}function Oo(n,i,a){if(i.hasOwnProperty("value")||i.hasOwnProperty("defaultValue")){var c=i.type;if(!(c!=="submit"&&c!=="reset"||i.value!==void 0&&i.value!==null))return;i=""+n._wrapperState.initialValue,a||i===n.value||(n.value=i),n.defaultValue=i}a=n.name,a!==""&&(n.name=""),n.defaultChecked=!!n._wrapperState.initialChecked,a!==""&&(n.name=a)}function ct(n,i,a){(i!=="number"||Vr(n.ownerDocument)!==n)&&(a==null?n.defaultValue=""+n._wrapperState.initialValue:n.defaultValue!==""+a&&(n.defaultValue=""+a))}var st=Array.isArray;function vn(n,i,a,c){if(n=n.options,i){i={};for(var d=0;d<a.length;d++)i["$"+a[d]]=!0;for(a=0;a<n.length;a++)d=i.hasOwnProperty("$"+n[a].value),n[a].selected!==d&&(n[a].selected=d),d&&c&&(n[a].defaultSelected=!0)}else{for(a=""+Le(a),i=null,d=0;d<n.length;d++){if(n[d].value===a){n[d].selected=!0,c&&(n[d].defaultSelected=!0);return}i!==null||n[d].disabled||(i=n[d])}i!==null&&(i.selected=!0)}}function Lo(n,i){if(i.dangerouslySetInnerHTML!=null)throw Error(t(91));return ee({},i,{value:void 0,defaultValue:void 0,children:""+n._wrapperState.initialValue})}function bo(n,i){var a=i.value;if(a==null){if(a=i.children,i=i.defaultValue,a!=null){if(i!=null)throw Error(t(92));if(st(a)){if(1<a.length)throw Error(t(93));a=a[0]}i=a}i==null&&(i=""),a=i}n._wrapperState={initialValue:Le(a)}}function dl(n,i){var a=Le(i.value),c=Le(i.defaultValue);a!=null&&(a=""+a,a!==n.value&&(n.value=a),i.defaultValue==null&&n.defaultValue!==a&&(n.defaultValue=a)),c!=null&&(n.defaultValue=""+c)}function Or(n){var i=n.textContent;i===n._wrapperState.initialValue&&i!==""&&i!==null&&(n.value=i)}function Mo(n){switch(n){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function vs(n,i){return n==null||n==="http://www.w3.org/1999/xhtml"?Mo(i):n==="http://www.w3.org/2000/svg"&&i==="foreignObject"?"http://www.w3.org/1999/xhtml":n}var Lr,fl=(function(n){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(i,a,c,d){MSApp.execUnsafeLocalFunction(function(){return n(i,a,c,d)})}:n})(function(n,i){if(n.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in n)n.innerHTML=i;else{for(Lr=Lr||document.createElement("div"),Lr.innerHTML="<svg>"+i.valueOf().toString()+"</svg>",i=Lr.firstChild;n.firstChild;)n.removeChild(n.firstChild);for(;i.firstChild;)n.appendChild(i.firstChild)}});function xi(n,i){if(i){var a=n.firstChild;if(a&&a===n.lastChild&&a.nodeType===3){a.nodeValue=i;return}}n.textContent=i}var br={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},pl=["Webkit","ms","Moz","O"];Object.keys(br).forEach(function(n){pl.forEach(function(i){i=i+n.charAt(0).toUpperCase()+n.substring(1),br[i]=br[n]})});function Mr(n,i,a){return i==null||typeof i=="boolean"||i===""?"":a||typeof i!="number"||i===0||br.hasOwnProperty(n)&&br[n]?(""+i).trim():i+"px"}function Es(n,i){n=n.style;for(var a in i)if(i.hasOwnProperty(a)){var c=a.indexOf("--")===0,d=Mr(a,i[a],c);a==="float"&&(a="cssFloat"),c?n.setProperty(a,d):n[a]=d}}var Fo=ee({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function En(n,i){if(i){if(Fo[n]&&(i.children!=null||i.dangerouslySetInnerHTML!=null))throw Error(t(137,n));if(i.dangerouslySetInnerHTML!=null){if(i.children!=null)throw Error(t(60));if(typeof i.dangerouslySetInnerHTML!="object"||!("__html"in i.dangerouslySetInnerHTML))throw Error(t(61))}if(i.style!=null&&typeof i.style!="object")throw Error(t(62))}}function ws(n,i){if(n.indexOf("-")===-1)return typeof i.is=="string";switch(n){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Fr=null;function Ts(n){return n=n.target||n.srcElement||window,n.correspondingUseElement&&(n=n.correspondingUseElement),n.nodeType===3?n.parentNode:n}var sr=null,or=null,rt=null;function Uo(n){if(n=da(n)){if(typeof sr!="function")throw Error(t(280));var i=n.stateNode;i&&(i=zl(i),sr(n.stateNode,n.type,i))}}function Ur(n){or?rt?rt.push(n):rt=[n]:or=n}function jr(){if(or){var n=or,i=rt;if(rt=or=null,Uo(n),i)for(n=0;n<i.length;n++)Uo(i[n])}}function ml(n,i){return n(i)}function gl(){}var On=!1;function yl(n,i,a){if(On)return n(i,a);On=!0;try{return ml(n,i,a)}finally{On=!1,(or!==null||rt!==null)&&(gl(),jr())}}function Di(n,i){var a=n.stateNode;if(a===null)return null;var c=zl(a);if(c===null)return null;a=c[i];e:switch(i){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(c=!c.disabled)||(n=n.type,c=!(n==="button"||n==="input"||n==="select"||n==="textarea")),n=!c;break e;default:n=!1}if(n)return null;if(a&&typeof a!="function")throw Error(t(231,i,typeof a));return a}var zr=!1;if(m)try{var Br={};Object.defineProperty(Br,"passive",{get:function(){zr=!0}}),window.addEventListener("test",Br,Br),window.removeEventListener("test",Br,Br)}catch{zr=!1}function _l(n,i,a,c,d,f,v,R,x){var U=Array.prototype.slice.call(arguments,3);try{i.apply(a,U)}catch(K){this.onError(K)}}var ar=!1,Ln=null,Is=!1,un=null,vl={onError:function(n){ar=!0,Ln=n}};function El(n,i,a,c,d,f,v,R,x){ar=!1,Ln=null,_l.apply(vl,arguments)}function jo(n,i,a,c,d,f,v,R,x){if(El.apply(this,arguments),ar){if(ar){var U=Ln;ar=!1,Ln=null}else throw Error(t(198));Is||(Is=!0,un=U)}}function wn(n){var i=n,a=n;if(n.alternate)for(;i.return;)i=i.return;else{n=i;do i=n,(i.flags&4098)!==0&&(a=i.return),n=i.return;while(n)}return i.tag===3?a:null}function zo(n){if(n.tag===13){var i=n.memoizedState;if(i===null&&(n=n.alternate,n!==null&&(i=n.memoizedState)),i!==null)return i.dehydrated}return null}function wl(n){if(wn(n)!==n)throw Error(t(188))}function Tl(n){var i=n.alternate;if(!i){if(i=wn(n),i===null)throw Error(t(188));return i!==n?null:n}for(var a=n,c=i;;){var d=a.return;if(d===null)break;var f=d.alternate;if(f===null){if(c=d.return,c!==null){a=c;continue}break}if(d.child===f.child){for(f=d.child;f;){if(f===a)return wl(d),n;if(f===c)return wl(d),i;f=f.sibling}throw Error(t(188))}if(a.return!==c.return)a=d,c=f;else{for(var v=!1,R=d.child;R;){if(R===a){v=!0,a=d,c=f;break}if(R===c){v=!0,c=d,a=f;break}R=R.sibling}if(!v){for(R=f.child;R;){if(R===a){v=!0,a=f,c=d;break}if(R===c){v=!0,c=f,a=d;break}R=R.sibling}if(!v)throw Error(t(189))}}if(a.alternate!==c)throw Error(t(190))}if(a.tag!==3)throw Error(t(188));return a.stateNode.current===a?n:i}function Il(n){return n=Tl(n),n!==null?Vi(n):null}function Vi(n){if(n.tag===5||n.tag===6)return n;for(n=n.child;n!==null;){var i=Vi(n);if(i!==null)return i;n=n.sibling}return null}var Bo=e.unstable_scheduleCallback,Ss=e.unstable_cancelCallback,Oi=e.unstable_shouldYield,lr=e.unstable_requestPaint,Qe=e.unstable_now,Vc=e.unstable_getCurrentPriorityLevel,As=e.unstable_ImmediatePriority,$o=e.unstable_UserBlockingPriority,Li=e.unstable_NormalPriority,Ho=e.unstable_LowPriority,Rs=e.unstable_IdlePriority,bi=null,Xt=null;function Sl(n){if(Xt&&typeof Xt.onCommitFiberRoot=="function")try{Xt.onCommitFiberRoot(bi,n,void 0,(n.current.flags&128)===128)}catch{}}var Zt=Math.clz32?Math.clz32:Mi,bn=Math.log,cn=Math.LN2;function Mi(n){return n>>>=0,n===0?32:31-(bn(n)/cn|0)|0}var Mn=64,$r=4194304;function Fe(n){switch(n&-n){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return n&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return n}}function ur(n,i){var a=n.pendingLanes;if(a===0)return 0;var c=0,d=n.suspendedLanes,f=n.pingedLanes,v=a&268435455;if(v!==0){var R=v&~d;R!==0?c=Fe(R):(f&=v,f!==0&&(c=Fe(f)))}else v=a&~d,v!==0?c=Fe(v):f!==0&&(c=Fe(f));if(c===0)return 0;if(i!==0&&i!==c&&(i&d)===0&&(d=c&-c,f=i&-i,d>=f||d===16&&(f&4194240)!==0))return i;if((c&4)!==0&&(c|=a&16),i=n.entangledLanes,i!==0)for(n=n.entanglements,i&=c;0<i;)a=31-Zt(i),d=1<<a,c|=n[a],i&=~d;return c}function Fi(n,i){switch(n){case 1:case 2:case 4:return i+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return i+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Ui(n,i){for(var a=n.suspendedLanes,c=n.pingedLanes,d=n.expirationTimes,f=n.pendingLanes;0<f;){var v=31-Zt(f),R=1<<v,x=d[v];x===-1?((R&a)===0||(R&c)!==0)&&(d[v]=Fi(R,i)):x<=i&&(n.expiredLanes|=R),f&=~R}}function Wo(n){return n=n.pendingLanes&-1073741825,n!==0?n:n&1073741824?1073741824:0}function qo(){var n=Mn;return Mn<<=1,(Mn&4194240)===0&&(Mn=64),n}function Ko(n){for(var i=[],a=0;31>a;a++)i.push(n);return i}function ji(n,i,a){n.pendingLanes|=i,i!==536870912&&(n.suspendedLanes=0,n.pingedLanes=0),n=n.eventTimes,i=31-Zt(i),n[i]=a}function Oc(n,i){var a=n.pendingLanes&~i;n.pendingLanes=i,n.suspendedLanes=0,n.pingedLanes=0,n.expiredLanes&=i,n.mutableReadLanes&=i,n.entangledLanes&=i,i=n.entanglements;var c=n.eventTimes;for(n=n.expirationTimes;0<a;){var d=31-Zt(a),f=1<<d;i[d]=0,c[d]=-1,n[d]=-1,a&=~f}}function Go(n,i){var a=n.entangledLanes|=i;for(n=n.entanglements;a;){var c=31-Zt(a),d=1<<c;d&i|n[c]&i&&(n[c]|=i),a&=~d}}var Ve=0;function Fn(n){return n&=-n,1<n?4<n?(n&268435455)!==0?16:536870912:4:1}var Qo,Cs,Yo,Jo,Xo,Un=!1,Ps=[],jn=null,zn=null,At=null,zi=new Map,cr=new Map,en=[],Al="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function Hr(n,i){switch(n){case"focusin":case"focusout":jn=null;break;case"dragenter":case"dragleave":zn=null;break;case"mouseover":case"mouseout":At=null;break;case"pointerover":case"pointerout":zi.delete(i.pointerId);break;case"gotpointercapture":case"lostpointercapture":cr.delete(i.pointerId)}}function Tn(n,i,a,c,d,f){return n===null||n.nativeEvent!==f?(n={blockedOn:i,domEventName:a,eventSystemFlags:c,nativeEvent:f,targetContainers:[d]},i!==null&&(i=da(i),i!==null&&Cs(i)),n):(n.eventSystemFlags|=c,i=n.targetContainers,d!==null&&i.indexOf(d)===-1&&i.push(d),n)}function Rl(n,i,a,c,d){switch(i){case"focusin":return jn=Tn(jn,n,i,a,c,d),!0;case"dragenter":return zn=Tn(zn,n,i,a,c,d),!0;case"mouseover":return At=Tn(At,n,i,a,c,d),!0;case"pointerover":var f=d.pointerId;return zi.set(f,Tn(zi.get(f)||null,n,i,a,c,d)),!0;case"gotpointercapture":return f=d.pointerId,cr.set(f,Tn(cr.get(f)||null,n,i,a,c,d)),!0}return!1}function ks(n){var i=Wi(n.target);if(i!==null){var a=wn(i);if(a!==null){if(i=a.tag,i===13){if(i=zo(a),i!==null){n.blockedOn=i,Xo(n.priority,function(){Yo(a)});return}}else if(i===3&&a.stateNode.current.memoizedState.isDehydrated){n.blockedOn=a.tag===3?a.stateNode.containerInfo:null;return}}}n.blockedOn=null}function qe(n){if(n.blockedOn!==null)return!1;for(var i=n.targetContainers;0<i.length;){var a=Ns(n.domEventName,n.eventSystemFlags,i[0],n.nativeEvent);if(a===null){a=n.nativeEvent;var c=new a.constructor(a.type,a);Fr=c,a.target.dispatchEvent(c),Fr=null}else return i=da(a),i!==null&&Cs(i),n.blockedOn=a,!1;i.shift()}return!0}function Cl(n,i,a){qe(n)&&a.delete(i)}function Lc(){Un=!1,jn!==null&&qe(jn)&&(jn=null),zn!==null&&qe(zn)&&(zn=null),At!==null&&qe(At)&&(At=null),zi.forEach(Cl),cr.forEach(Cl)}function Wr(n,i){n.blockedOn===i&&(n.blockedOn=null,Un||(Un=!0,e.unstable_scheduleCallback(e.unstable_NormalPriority,Lc)))}function qr(n){function i(d){return Wr(d,n)}if(0<Ps.length){Wr(Ps[0],n);for(var a=1;a<Ps.length;a++){var c=Ps[a];c.blockedOn===n&&(c.blockedOn=null)}}for(jn!==null&&Wr(jn,n),zn!==null&&Wr(zn,n),At!==null&&Wr(At,n),zi.forEach(i),cr.forEach(i),a=0;a<en.length;a++)c=en[a],c.blockedOn===n&&(c.blockedOn=null);for(;0<en.length&&(a=en[0],a.blockedOn===null);)ks(a),a.blockedOn===null&&en.shift()}var hr=Ae.ReactCurrentBatchConfig,dr=!0;function Bn(n,i,a,c){var d=Ve,f=hr.transition;hr.transition=null;try{Ve=1,Zo(n,i,a,c)}finally{Ve=d,hr.transition=f}}function Pl(n,i,a,c){var d=Ve,f=hr.transition;hr.transition=null;try{Ve=4,Zo(n,i,a,c)}finally{Ve=d,hr.transition=f}}function Zo(n,i,a,c){if(dr){var d=Ns(n,i,a,c);if(d===null)qc(n,i,c,$n,a),Hr(n,c);else if(Rl(d,n,i,a,c))c.stopPropagation();else if(Hr(n,c),i&4&&-1<Al.indexOf(n)){for(;d!==null;){var f=da(d);if(f!==null&&Qo(f),f=Ns(n,i,a,c),f===null&&qc(n,i,c,$n,a),f===d)break;d=f}d!==null&&c.stopPropagation()}else qc(n,i,c,null,a)}}var $n=null;function Ns(n,i,a,c){if($n=null,n=Ts(c),n=Wi(n),n!==null)if(i=wn(n),i===null)n=null;else if(a=i.tag,a===13){if(n=zo(i),n!==null)return n;n=null}else if(a===3){if(i.stateNode.current.memoizedState.isDehydrated)return i.tag===3?i.stateNode.containerInfo:null;n=null}else i!==n&&(n=null);return $n=n,null}function xs(n){switch(n){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(Vc()){case As:return 1;case $o:return 4;case Li:case Ho:return 16;case Rs:return 536870912;default:return 16}default:return 16}}var tn=null,Ds=null,fr=null;function kl(){if(fr)return fr;var n,i=Ds,a=i.length,c,d="value"in tn?tn.value:tn.textContent,f=d.length;for(n=0;n<a&&i[n]===d[n];n++);var v=a-n;for(c=1;c<=v&&i[a-c]===d[f-c];c++);return fr=d.slice(n,1<c?1-c:void 0)}function Bi(n){var i=n.keyCode;return"charCode"in n?(n=n.charCode,n===0&&i===13&&(n=13)):n=i,n===10&&(n=13),32<=n||n===13?n:0}function Hn(){return!0}function ea(){return!1}function Dt(n){function i(a,c,d,f,v){this._reactName=a,this._targetInst=d,this.type=c,this.nativeEvent=f,this.target=v,this.currentTarget=null;for(var R in n)n.hasOwnProperty(R)&&(a=n[R],this[R]=a?a(f):f[R]);return this.isDefaultPrevented=(f.defaultPrevented!=null?f.defaultPrevented:f.returnValue===!1)?Hn:ea,this.isPropagationStopped=ea,this}return ee(i.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():typeof a.returnValue!="unknown"&&(a.returnValue=!1),this.isDefaultPrevented=Hn)},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():typeof a.cancelBubble!="unknown"&&(a.cancelBubble=!0),this.isPropagationStopped=Hn)},persist:function(){},isPersistent:Hn}),i}var Wn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(n){return n.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},$i=Dt(Wn),Kr=ee({},Wn,{view:0,detail:0}),Vs=Dt(Kr),Os,Ls,nn,Hi=ee({},Kr,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:_e,button:0,buttons:0,relatedTarget:function(n){return n.relatedTarget===void 0?n.fromElement===n.srcElement?n.toElement:n.fromElement:n.relatedTarget},movementX:function(n){return"movementX"in n?n.movementX:(n!==nn&&(nn&&n.type==="mousemove"?(Os=n.screenX-nn.screenX,Ls=n.screenY-nn.screenY):Ls=Os=0,nn=n),Os)},movementY:function(n){return"movementY"in n?n.movementY:Ls}}),ta=Dt(Hi),Nl=ee({},Hi,{dataTransfer:0}),xl=Dt(Nl),bs=ee({},Kr,{relatedTarget:0}),Rt=Dt(bs),Dl=ee({},Wn,{animationName:0,elapsedTime:0,pseudoElement:0}),Vl=Dt(Dl),Gr=ee({},Wn,{clipboardData:function(n){return"clipboardData"in n?n.clipboardData:window.clipboardData}}),u=Dt(Gr),p=ee({},Wn,{data:0}),y=Dt(p),w={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},M={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},j={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function X(n){var i=this.nativeEvent;return i.getModifierState?i.getModifierState(n):(n=j[n])?!!i[n]:!1}function _e(){return X}var ot=ee({},Kr,{key:function(n){if(n.key){var i=w[n.key]||n.key;if(i!=="Unidentified")return i}return n.type==="keypress"?(n=Bi(n),n===13?"Enter":String.fromCharCode(n)):n.type==="keydown"||n.type==="keyup"?M[n.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:_e,charCode:function(n){return n.type==="keypress"?Bi(n):0},keyCode:function(n){return n.type==="keydown"||n.type==="keyup"?n.keyCode:0},which:function(n){return n.type==="keypress"?Bi(n):n.type==="keydown"||n.type==="keyup"?n.keyCode:0}}),$e=Dt(ot),ht=ee({},Hi,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),rn=Dt(ht),pr=ee({},Kr,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:_e}),qn=Dt(pr),Kn=ee({},Wn,{propertyName:0,elapsedTime:0,pseudoElement:0}),Ms=Dt(Kn),na=ee({},Hi,{deltaX:function(n){return"deltaX"in n?n.deltaX:"wheelDeltaX"in n?-n.wheelDeltaX:0},deltaY:function(n){return"deltaY"in n?n.deltaY:"wheelDeltaY"in n?-n.wheelDeltaY:"wheelDelta"in n?-n.wheelDelta:0},deltaZ:0,deltaMode:0}),dE=Dt(na),fE=[9,13,27,32],bc=m&&"CompositionEvent"in window,ra=null;m&&"documentMode"in document&&(ra=document.documentMode);var pE=m&&"TextEvent"in window&&!ra,Uf=m&&(!bc||ra&&8<ra&&11>=ra),jf=" ",zf=!1;function Bf(n,i){switch(n){case"keyup":return fE.indexOf(i.keyCode)!==-1;case"keydown":return i.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function $f(n){return n=n.detail,typeof n=="object"&&"data"in n?n.data:null}var Fs=!1;function mE(n,i){switch(n){case"compositionend":return $f(i);case"keypress":return i.which!==32?null:(zf=!0,jf);case"textInput":return n=i.data,n===jf&&zf?null:n;default:return null}}function gE(n,i){if(Fs)return n==="compositionend"||!bc&&Bf(n,i)?(n=kl(),fr=Ds=tn=null,Fs=!1,n):null;switch(n){case"paste":return null;case"keypress":if(!(i.ctrlKey||i.altKey||i.metaKey)||i.ctrlKey&&i.altKey){if(i.char&&1<i.char.length)return i.char;if(i.which)return String.fromCharCode(i.which)}return null;case"compositionend":return Uf&&i.locale!=="ko"?null:i.data;default:return null}}var yE={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Hf(n){var i=n&&n.nodeName&&n.nodeName.toLowerCase();return i==="input"?!!yE[n.type]:i==="textarea"}function Wf(n,i,a,c){Ur(c),i=Fl(i,"onChange"),0<i.length&&(a=new $i("onChange","change",null,a,c),n.push({event:a,listeners:i}))}var ia=null,sa=null;function _E(n){up(n,0)}function Ol(n){var i=$s(n);if(Vo(i))return n}function vE(n,i){if(n==="change")return i}var qf=!1;if(m){var Mc;if(m){var Fc="oninput"in document;if(!Fc){var Kf=document.createElement("div");Kf.setAttribute("oninput","return;"),Fc=typeof Kf.oninput=="function"}Mc=Fc}else Mc=!1;qf=Mc&&(!document.documentMode||9<document.documentMode)}function Gf(){ia&&(ia.detachEvent("onpropertychange",Qf),sa=ia=null)}function Qf(n){if(n.propertyName==="value"&&Ol(sa)){var i=[];Wf(i,sa,n,Ts(n)),yl(_E,i)}}function EE(n,i,a){n==="focusin"?(Gf(),ia=i,sa=a,ia.attachEvent("onpropertychange",Qf)):n==="focusout"&&Gf()}function wE(n){if(n==="selectionchange"||n==="keyup"||n==="keydown")return Ol(sa)}function TE(n,i){if(n==="click")return Ol(i)}function IE(n,i){if(n==="input"||n==="change")return Ol(i)}function SE(n,i){return n===i&&(n!==0||1/n===1/i)||n!==n&&i!==i}var In=typeof Object.is=="function"?Object.is:SE;function oa(n,i){if(In(n,i))return!0;if(typeof n!="object"||n===null||typeof i!="object"||i===null)return!1;var a=Object.keys(n),c=Object.keys(i);if(a.length!==c.length)return!1;for(c=0;c<a.length;c++){var d=a[c];if(!g.call(i,d)||!In(n[d],i[d]))return!1}return!0}function Yf(n){for(;n&&n.firstChild;)n=n.firstChild;return n}function Jf(n,i){var a=Yf(n);n=0;for(var c;a;){if(a.nodeType===3){if(c=n+a.textContent.length,n<=i&&c>=i)return{node:a,offset:i-n};n=c}e:{for(;a;){if(a.nextSibling){a=a.nextSibling;break e}a=a.parentNode}a=void 0}a=Yf(a)}}function Xf(n,i){return n&&i?n===i?!0:n&&n.nodeType===3?!1:i&&i.nodeType===3?Xf(n,i.parentNode):"contains"in n?n.contains(i):n.compareDocumentPosition?!!(n.compareDocumentPosition(i)&16):!1:!1}function Zf(){for(var n=window,i=Vr();i instanceof n.HTMLIFrameElement;){try{var a=typeof i.contentWindow.location.href=="string"}catch{a=!1}if(a)n=i.contentWindow;else break;i=Vr(n.document)}return i}function Uc(n){var i=n&&n.nodeName&&n.nodeName.toLowerCase();return i&&(i==="input"&&(n.type==="text"||n.type==="search"||n.type==="tel"||n.type==="url"||n.type==="password")||i==="textarea"||n.contentEditable==="true")}function AE(n){var i=Zf(),a=n.focusedElem,c=n.selectionRange;if(i!==a&&a&&a.ownerDocument&&Xf(a.ownerDocument.documentElement,a)){if(c!==null&&Uc(a)){if(i=c.start,n=c.end,n===void 0&&(n=i),"selectionStart"in a)a.selectionStart=i,a.selectionEnd=Math.min(n,a.value.length);else if(n=(i=a.ownerDocument||document)&&i.defaultView||window,n.getSelection){n=n.getSelection();var d=a.textContent.length,f=Math.min(c.start,d);c=c.end===void 0?f:Math.min(c.end,d),!n.extend&&f>c&&(d=c,c=f,f=d),d=Jf(a,f);var v=Jf(a,c);d&&v&&(n.rangeCount!==1||n.anchorNode!==d.node||n.anchorOffset!==d.offset||n.focusNode!==v.node||n.focusOffset!==v.offset)&&(i=i.createRange(),i.setStart(d.node,d.offset),n.removeAllRanges(),f>c?(n.addRange(i),n.extend(v.node,v.offset)):(i.setEnd(v.node,v.offset),n.addRange(i)))}}for(i=[],n=a;n=n.parentNode;)n.nodeType===1&&i.push({element:n,left:n.scrollLeft,top:n.scrollTop});for(typeof a.focus=="function"&&a.focus(),a=0;a<i.length;a++)n=i[a],n.element.scrollLeft=n.left,n.element.scrollTop=n.top}}var RE=m&&"documentMode"in document&&11>=document.documentMode,Us=null,jc=null,aa=null,zc=!1;function ep(n,i,a){var c=a.window===a?a.document:a.nodeType===9?a:a.ownerDocument;zc||Us==null||Us!==Vr(c)||(c=Us,"selectionStart"in c&&Uc(c)?c={start:c.selectionStart,end:c.selectionEnd}:(c=(c.ownerDocument&&c.ownerDocument.defaultView||window).getSelection(),c={anchorNode:c.anchorNode,anchorOffset:c.anchorOffset,focusNode:c.focusNode,focusOffset:c.focusOffset}),aa&&oa(aa,c)||(aa=c,c=Fl(jc,"onSelect"),0<c.length&&(i=new $i("onSelect","select",null,i,a),n.push({event:i,listeners:c}),i.target=Us)))}function Ll(n,i){var a={};return a[n.toLowerCase()]=i.toLowerCase(),a["Webkit"+n]="webkit"+i,a["Moz"+n]="moz"+i,a}var js={animationend:Ll("Animation","AnimationEnd"),animationiteration:Ll("Animation","AnimationIteration"),animationstart:Ll("Animation","AnimationStart"),transitionend:Ll("Transition","TransitionEnd")},Bc={},tp={};m&&(tp=document.createElement("div").style,"AnimationEvent"in window||(delete js.animationend.animation,delete js.animationiteration.animation,delete js.animationstart.animation),"TransitionEvent"in window||delete js.transitionend.transition);function bl(n){if(Bc[n])return Bc[n];if(!js[n])return n;var i=js[n],a;for(a in i)if(i.hasOwnProperty(a)&&a in tp)return Bc[n]=i[a];return n}var np=bl("animationend"),rp=bl("animationiteration"),ip=bl("animationstart"),sp=bl("transitionend"),op=new Map,ap="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function Qr(n,i){op.set(n,i),l(i,[n])}for(var $c=0;$c<ap.length;$c++){var Hc=ap[$c],CE=Hc.toLowerCase(),PE=Hc[0].toUpperCase()+Hc.slice(1);Qr(CE,"on"+PE)}Qr(np,"onAnimationEnd"),Qr(rp,"onAnimationIteration"),Qr(ip,"onAnimationStart"),Qr("dblclick","onDoubleClick"),Qr("focusin","onFocus"),Qr("focusout","onBlur"),Qr(sp,"onTransitionEnd"),h("onMouseEnter",["mouseout","mouseover"]),h("onMouseLeave",["mouseout","mouseover"]),h("onPointerEnter",["pointerout","pointerover"]),h("onPointerLeave",["pointerout","pointerover"]),l("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),l("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),l("onBeforeInput",["compositionend","keypress","textInput","paste"]),l("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),l("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),l("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var la="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),kE=new Set("cancel close invalid load scroll toggle".split(" ").concat(la));function lp(n,i,a){var c=n.type||"unknown-event";n.currentTarget=a,jo(c,i,void 0,n),n.currentTarget=null}function up(n,i){i=(i&4)!==0;for(var a=0;a<n.length;a++){var c=n[a],d=c.event;c=c.listeners;e:{var f=void 0;if(i)for(var v=c.length-1;0<=v;v--){var R=c[v],x=R.instance,U=R.currentTarget;if(R=R.listener,x!==f&&d.isPropagationStopped())break e;lp(d,R,U),f=x}else for(v=0;v<c.length;v++){if(R=c[v],x=R.instance,U=R.currentTarget,R=R.listener,x!==f&&d.isPropagationStopped())break e;lp(d,R,U),f=x}}}if(Is)throw n=un,Is=!1,un=null,n}function Ye(n,i){var a=i[Xc];a===void 0&&(a=i[Xc]=new Set);var c=n+"__bubble";a.has(c)||(cp(i,n,2,!1),a.add(c))}function Wc(n,i,a){var c=0;i&&(c|=4),cp(a,n,c,i)}var Ml="_reactListening"+Math.random().toString(36).slice(2);function ua(n){if(!n[Ml]){n[Ml]=!0,s.forEach(function(a){a!=="selectionchange"&&(kE.has(a)||Wc(a,!1,n),Wc(a,!0,n))});var i=n.nodeType===9?n:n.ownerDocument;i===null||i[Ml]||(i[Ml]=!0,Wc("selectionchange",!1,i))}}function cp(n,i,a,c){switch(xs(i)){case 1:var d=Bn;break;case 4:d=Pl;break;default:d=Zo}a=d.bind(null,i,a,n),d=void 0,!zr||i!=="touchstart"&&i!=="touchmove"&&i!=="wheel"||(d=!0),c?d!==void 0?n.addEventListener(i,a,{capture:!0,passive:d}):n.addEventListener(i,a,!0):d!==void 0?n.addEventListener(i,a,{passive:d}):n.addEventListener(i,a,!1)}function qc(n,i,a,c,d){var f=c;if((i&1)===0&&(i&2)===0&&c!==null)e:for(;;){if(c===null)return;var v=c.tag;if(v===3||v===4){var R=c.stateNode.containerInfo;if(R===d||R.nodeType===8&&R.parentNode===d)break;if(v===4)for(v=c.return;v!==null;){var x=v.tag;if((x===3||x===4)&&(x=v.stateNode.containerInfo,x===d||x.nodeType===8&&x.parentNode===d))return;v=v.return}for(;R!==null;){if(v=Wi(R),v===null)return;if(x=v.tag,x===5||x===6){c=f=v;continue e}R=R.parentNode}}c=c.return}yl(function(){var U=f,K=Ts(a),Y=[];e:{var q=op.get(n);if(q!==void 0){var ne=$i,oe=n;switch(n){case"keypress":if(Bi(a)===0)break e;case"keydown":case"keyup":ne=$e;break;case"focusin":oe="focus",ne=Rt;break;case"focusout":oe="blur",ne=Rt;break;case"beforeblur":case"afterblur":ne=Rt;break;case"click":if(a.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":ne=ta;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":ne=xl;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":ne=qn;break;case np:case rp:case ip:ne=Vl;break;case sp:ne=Ms;break;case"scroll":ne=Vs;break;case"wheel":ne=dE;break;case"copy":case"cut":case"paste":ne=u;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":ne=rn}var le=(i&4)!==0,at=!le&&n==="scroll",b=le?q!==null?q+"Capture":null:q;le=[];for(var O=U,F;O!==null;){F=O;var J=F.stateNode;if(F.tag===5&&J!==null&&(F=J,b!==null&&(J=Di(O,b),J!=null&&le.push(ca(O,J,F)))),at)break;O=O.return}0<le.length&&(q=new ne(q,oe,null,a,K),Y.push({event:q,listeners:le}))}}if((i&7)===0){e:{if(q=n==="mouseover"||n==="pointerover",ne=n==="mouseout"||n==="pointerout",q&&a!==Fr&&(oe=a.relatedTarget||a.fromElement)&&(Wi(oe)||oe[mr]))break e;if((ne||q)&&(q=K.window===K?K:(q=K.ownerDocument)?q.defaultView||q.parentWindow:window,ne?(oe=a.relatedTarget||a.toElement,ne=U,oe=oe?Wi(oe):null,oe!==null&&(at=wn(oe),oe!==at||oe.tag!==5&&oe.tag!==6)&&(oe=null)):(ne=null,oe=U),ne!==oe)){if(le=ta,J="onMouseLeave",b="onMouseEnter",O="mouse",(n==="pointerout"||n==="pointerover")&&(le=rn,J="onPointerLeave",b="onPointerEnter",O="pointer"),at=ne==null?q:$s(ne),F=oe==null?q:$s(oe),q=new le(J,O+"leave",ne,a,K),q.target=at,q.relatedTarget=F,J=null,Wi(K)===U&&(le=new le(b,O+"enter",oe,a,K),le.target=F,le.relatedTarget=at,J=le),at=J,ne&&oe)t:{for(le=ne,b=oe,O=0,F=le;F;F=zs(F))O++;for(F=0,J=b;J;J=zs(J))F++;for(;0<O-F;)le=zs(le),O--;for(;0<F-O;)b=zs(b),F--;for(;O--;){if(le===b||b!==null&&le===b.alternate)break t;le=zs(le),b=zs(b)}le=null}else le=null;ne!==null&&hp(Y,q,ne,le,!1),oe!==null&&at!==null&&hp(Y,at,oe,le,!0)}}e:{if(q=U?$s(U):window,ne=q.nodeName&&q.nodeName.toLowerCase(),ne==="select"||ne==="input"&&q.type==="file")var ue=vE;else if(Hf(q))if(qf)ue=IE;else{ue=wE;var he=EE}else(ne=q.nodeName)&&ne.toLowerCase()==="input"&&(q.type==="checkbox"||q.type==="radio")&&(ue=TE);if(ue&&(ue=ue(n,U))){Wf(Y,ue,a,K);break e}he&&he(n,q,U),n==="focusout"&&(he=q._wrapperState)&&he.controlled&&q.type==="number"&&ct(q,"number",q.value)}switch(he=U?$s(U):window,n){case"focusin":(Hf(he)||he.contentEditable==="true")&&(Us=he,jc=U,aa=null);break;case"focusout":aa=jc=Us=null;break;case"mousedown":zc=!0;break;case"contextmenu":case"mouseup":case"dragend":zc=!1,ep(Y,a,K);break;case"selectionchange":if(RE)break;case"keydown":case"keyup":ep(Y,a,K)}var de;if(bc)e:{switch(n){case"compositionstart":var ge="onCompositionStart";break e;case"compositionend":ge="onCompositionEnd";break e;case"compositionupdate":ge="onCompositionUpdate";break e}ge=void 0}else Fs?Bf(n,a)&&(ge="onCompositionEnd"):n==="keydown"&&a.keyCode===229&&(ge="onCompositionStart");ge&&(Uf&&a.locale!=="ko"&&(Fs||ge!=="onCompositionStart"?ge==="onCompositionEnd"&&Fs&&(de=kl()):(tn=K,Ds="value"in tn?tn.value:tn.textContent,Fs=!0)),he=Fl(U,ge),0<he.length&&(ge=new y(ge,n,null,a,K),Y.push({event:ge,listeners:he}),de?ge.data=de:(de=$f(a),de!==null&&(ge.data=de)))),(de=pE?mE(n,a):gE(n,a))&&(U=Fl(U,"onBeforeInput"),0<U.length&&(K=new y("onBeforeInput","beforeinput",null,a,K),Y.push({event:K,listeners:U}),K.data=de))}up(Y,i)})}function ca(n,i,a){return{instance:n,listener:i,currentTarget:a}}function Fl(n,i){for(var a=i+"Capture",c=[];n!==null;){var d=n,f=d.stateNode;d.tag===5&&f!==null&&(d=f,f=Di(n,a),f!=null&&c.unshift(ca(n,f,d)),f=Di(n,i),f!=null&&c.push(ca(n,f,d))),n=n.return}return c}function zs(n){if(n===null)return null;do n=n.return;while(n&&n.tag!==5);return n||null}function hp(n,i,a,c,d){for(var f=i._reactName,v=[];a!==null&&a!==c;){var R=a,x=R.alternate,U=R.stateNode;if(x!==null&&x===c)break;R.tag===5&&U!==null&&(R=U,d?(x=Di(a,f),x!=null&&v.unshift(ca(a,x,R))):d||(x=Di(a,f),x!=null&&v.push(ca(a,x,R)))),a=a.return}v.length!==0&&n.push({event:i,listeners:v})}var NE=/\r\n?/g,xE=/\u0000|\uFFFD/g;function dp(n){return(typeof n=="string"?n:""+n).replace(NE,`
`).replace(xE,"")}function Ul(n,i,a){if(i=dp(i),dp(n)!==i&&a)throw Error(t(425))}function jl(){}var Kc=null,Gc=null;function Qc(n,i){return n==="textarea"||n==="noscript"||typeof i.children=="string"||typeof i.children=="number"||typeof i.dangerouslySetInnerHTML=="object"&&i.dangerouslySetInnerHTML!==null&&i.dangerouslySetInnerHTML.__html!=null}var Yc=typeof setTimeout=="function"?setTimeout:void 0,DE=typeof clearTimeout=="function"?clearTimeout:void 0,fp=typeof Promise=="function"?Promise:void 0,VE=typeof queueMicrotask=="function"?queueMicrotask:typeof fp<"u"?function(n){return fp.resolve(null).then(n).catch(OE)}:Yc;function OE(n){setTimeout(function(){throw n})}function Jc(n,i){var a=i,c=0;do{var d=a.nextSibling;if(n.removeChild(a),d&&d.nodeType===8)if(a=d.data,a==="/$"){if(c===0){n.removeChild(d),qr(i);return}c--}else a!=="$"&&a!=="$?"&&a!=="$!"||c++;a=d}while(a);qr(i)}function Yr(n){for(;n!=null;n=n.nextSibling){var i=n.nodeType;if(i===1||i===3)break;if(i===8){if(i=n.data,i==="$"||i==="$!"||i==="$?")break;if(i==="/$")return null}}return n}function pp(n){n=n.previousSibling;for(var i=0;n;){if(n.nodeType===8){var a=n.data;if(a==="$"||a==="$!"||a==="$?"){if(i===0)return n;i--}else a==="/$"&&i++}n=n.previousSibling}return null}var Bs=Math.random().toString(36).slice(2),Gn="__reactFiber$"+Bs,ha="__reactProps$"+Bs,mr="__reactContainer$"+Bs,Xc="__reactEvents$"+Bs,LE="__reactListeners$"+Bs,bE="__reactHandles$"+Bs;function Wi(n){var i=n[Gn];if(i)return i;for(var a=n.parentNode;a;){if(i=a[mr]||a[Gn]){if(a=i.alternate,i.child!==null||a!==null&&a.child!==null)for(n=pp(n);n!==null;){if(a=n[Gn])return a;n=pp(n)}return i}n=a,a=n.parentNode}return null}function da(n){return n=n[Gn]||n[mr],!n||n.tag!==5&&n.tag!==6&&n.tag!==13&&n.tag!==3?null:n}function $s(n){if(n.tag===5||n.tag===6)return n.stateNode;throw Error(t(33))}function zl(n){return n[ha]||null}var Zc=[],Hs=-1;function Jr(n){return{current:n}}function Je(n){0>Hs||(n.current=Zc[Hs],Zc[Hs]=null,Hs--)}function Ke(n,i){Hs++,Zc[Hs]=n.current,n.current=i}var Xr={},Vt=Jr(Xr),Ht=Jr(!1),qi=Xr;function Ws(n,i){var a=n.type.contextTypes;if(!a)return Xr;var c=n.stateNode;if(c&&c.__reactInternalMemoizedUnmaskedChildContext===i)return c.__reactInternalMemoizedMaskedChildContext;var d={},f;for(f in a)d[f]=i[f];return c&&(n=n.stateNode,n.__reactInternalMemoizedUnmaskedChildContext=i,n.__reactInternalMemoizedMaskedChildContext=d),d}function Wt(n){return n=n.childContextTypes,n!=null}function Bl(){Je(Ht),Je(Vt)}function mp(n,i,a){if(Vt.current!==Xr)throw Error(t(168));Ke(Vt,i),Ke(Ht,a)}function gp(n,i,a){var c=n.stateNode;if(i=i.childContextTypes,typeof c.getChildContext!="function")return a;c=c.getChildContext();for(var d in c)if(!(d in i))throw Error(t(108,je(n)||"Unknown",d));return ee({},a,c)}function $l(n){return n=(n=n.stateNode)&&n.__reactInternalMemoizedMergedChildContext||Xr,qi=Vt.current,Ke(Vt,n),Ke(Ht,Ht.current),!0}function yp(n,i,a){var c=n.stateNode;if(!c)throw Error(t(169));a?(n=gp(n,i,qi),c.__reactInternalMemoizedMergedChildContext=n,Je(Ht),Je(Vt),Ke(Vt,n)):Je(Ht),Ke(Ht,a)}var gr=null,Hl=!1,eh=!1;function _p(n){gr===null?gr=[n]:gr.push(n)}function ME(n){Hl=!0,_p(n)}function Zr(){if(!eh&&gr!==null){eh=!0;var n=0,i=Ve;try{var a=gr;for(Ve=1;n<a.length;n++){var c=a[n];do c=c(!0);while(c!==null)}gr=null,Hl=!1}catch(d){throw gr!==null&&(gr=gr.slice(n+1)),Bo(As,Zr),d}finally{Ve=i,eh=!1}}return null}var qs=[],Ks=0,Wl=null,ql=0,hn=[],dn=0,Ki=null,yr=1,_r="";function Gi(n,i){qs[Ks++]=ql,qs[Ks++]=Wl,Wl=n,ql=i}function vp(n,i,a){hn[dn++]=yr,hn[dn++]=_r,hn[dn++]=Ki,Ki=n;var c=yr;n=_r;var d=32-Zt(c)-1;c&=~(1<<d),a+=1;var f=32-Zt(i)+d;if(30<f){var v=d-d%5;f=(c&(1<<v)-1).toString(32),c>>=v,d-=v,yr=1<<32-Zt(i)+d|a<<d|c,_r=f+n}else yr=1<<f|a<<d|c,_r=n}function th(n){n.return!==null&&(Gi(n,1),vp(n,1,0))}function nh(n){for(;n===Wl;)Wl=qs[--Ks],qs[Ks]=null,ql=qs[--Ks],qs[Ks]=null;for(;n===Ki;)Ki=hn[--dn],hn[dn]=null,_r=hn[--dn],hn[dn]=null,yr=hn[--dn],hn[dn]=null}var sn=null,on=null,Ze=!1,Sn=null;function Ep(n,i){var a=gn(5,null,null,0);a.elementType="DELETED",a.stateNode=i,a.return=n,i=n.deletions,i===null?(n.deletions=[a],n.flags|=16):i.push(a)}function wp(n,i){switch(n.tag){case 5:var a=n.type;return i=i.nodeType!==1||a.toLowerCase()!==i.nodeName.toLowerCase()?null:i,i!==null?(n.stateNode=i,sn=n,on=Yr(i.firstChild),!0):!1;case 6:return i=n.pendingProps===""||i.nodeType!==3?null:i,i!==null?(n.stateNode=i,sn=n,on=null,!0):!1;case 13:return i=i.nodeType!==8?null:i,i!==null?(a=Ki!==null?{id:yr,overflow:_r}:null,n.memoizedState={dehydrated:i,treeContext:a,retryLane:1073741824},a=gn(18,null,null,0),a.stateNode=i,a.return=n,n.child=a,sn=n,on=null,!0):!1;default:return!1}}function rh(n){return(n.mode&1)!==0&&(n.flags&128)===0}function ih(n){if(Ze){var i=on;if(i){var a=i;if(!wp(n,i)){if(rh(n))throw Error(t(418));i=Yr(a.nextSibling);var c=sn;i&&wp(n,i)?Ep(c,a):(n.flags=n.flags&-4097|2,Ze=!1,sn=n)}}else{if(rh(n))throw Error(t(418));n.flags=n.flags&-4097|2,Ze=!1,sn=n}}}function Tp(n){for(n=n.return;n!==null&&n.tag!==5&&n.tag!==3&&n.tag!==13;)n=n.return;sn=n}function Kl(n){if(n!==sn)return!1;if(!Ze)return Tp(n),Ze=!0,!1;var i;if((i=n.tag!==3)&&!(i=n.tag!==5)&&(i=n.type,i=i!=="head"&&i!=="body"&&!Qc(n.type,n.memoizedProps)),i&&(i=on)){if(rh(n))throw Ip(),Error(t(418));for(;i;)Ep(n,i),i=Yr(i.nextSibling)}if(Tp(n),n.tag===13){if(n=n.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(t(317));e:{for(n=n.nextSibling,i=0;n;){if(n.nodeType===8){var a=n.data;if(a==="/$"){if(i===0){on=Yr(n.nextSibling);break e}i--}else a!=="$"&&a!=="$!"&&a!=="$?"||i++}n=n.nextSibling}on=null}}else on=sn?Yr(n.stateNode.nextSibling):null;return!0}function Ip(){for(var n=on;n;)n=Yr(n.nextSibling)}function Gs(){on=sn=null,Ze=!1}function sh(n){Sn===null?Sn=[n]:Sn.push(n)}var FE=Ae.ReactCurrentBatchConfig;function fa(n,i,a){if(n=a.ref,n!==null&&typeof n!="function"&&typeof n!="object"){if(a._owner){if(a=a._owner,a){if(a.tag!==1)throw Error(t(309));var c=a.stateNode}if(!c)throw Error(t(147,n));var d=c,f=""+n;return i!==null&&i.ref!==null&&typeof i.ref=="function"&&i.ref._stringRef===f?i.ref:(i=function(v){var R=d.refs;v===null?delete R[f]:R[f]=v},i._stringRef=f,i)}if(typeof n!="string")throw Error(t(284));if(!a._owner)throw Error(t(290,n))}return n}function Gl(n,i){throw n=Object.prototype.toString.call(i),Error(t(31,n==="[object Object]"?"object with keys {"+Object.keys(i).join(", ")+"}":n))}function Sp(n){var i=n._init;return i(n._payload)}function Ap(n){function i(b,O){if(n){var F=b.deletions;F===null?(b.deletions=[O],b.flags|=16):F.push(O)}}function a(b,O){if(!n)return null;for(;O!==null;)i(b,O),O=O.sibling;return null}function c(b,O){for(b=new Map;O!==null;)O.key!==null?b.set(O.key,O):b.set(O.index,O),O=O.sibling;return b}function d(b,O){return b=ai(b,O),b.index=0,b.sibling=null,b}function f(b,O,F){return b.index=F,n?(F=b.alternate,F!==null?(F=F.index,F<O?(b.flags|=2,O):F):(b.flags|=2,O)):(b.flags|=1048576,O)}function v(b){return n&&b.alternate===null&&(b.flags|=2),b}function R(b,O,F,J){return O===null||O.tag!==6?(O=Yh(F,b.mode,J),O.return=b,O):(O=d(O,F),O.return=b,O)}function x(b,O,F,J){var ue=F.type;return ue===D?K(b,O,F.props.children,J,F.key):O!==null&&(O.elementType===ue||typeof ue=="object"&&ue!==null&&ue.$$typeof===ut&&Sp(ue)===O.type)?(J=d(O,F.props),J.ref=fa(b,O,F),J.return=b,J):(J=_u(F.type,F.key,F.props,null,b.mode,J),J.ref=fa(b,O,F),J.return=b,J)}function U(b,O,F,J){return O===null||O.tag!==4||O.stateNode.containerInfo!==F.containerInfo||O.stateNode.implementation!==F.implementation?(O=Jh(F,b.mode,J),O.return=b,O):(O=d(O,F.children||[]),O.return=b,O)}function K(b,O,F,J,ue){return O===null||O.tag!==7?(O=ns(F,b.mode,J,ue),O.return=b,O):(O=d(O,F),O.return=b,O)}function Y(b,O,F){if(typeof O=="string"&&O!==""||typeof O=="number")return O=Yh(""+O,b.mode,F),O.return=b,O;if(typeof O=="object"&&O!==null){switch(O.$$typeof){case De:return F=_u(O.type,O.key,O.props,null,b.mode,F),F.ref=fa(b,null,O),F.return=b,F;case Re:return O=Jh(O,b.mode,F),O.return=b,O;case ut:var J=O._init;return Y(b,J(O._payload),F)}if(st(O)||ae(O))return O=ns(O,b.mode,F,null),O.return=b,O;Gl(b,O)}return null}function q(b,O,F,J){var ue=O!==null?O.key:null;if(typeof F=="string"&&F!==""||typeof F=="number")return ue!==null?null:R(b,O,""+F,J);if(typeof F=="object"&&F!==null){switch(F.$$typeof){case De:return F.key===ue?x(b,O,F,J):null;case Re:return F.key===ue?U(b,O,F,J):null;case ut:return ue=F._init,q(b,O,ue(F._payload),J)}if(st(F)||ae(F))return ue!==null?null:K(b,O,F,J,null);Gl(b,F)}return null}function ne(b,O,F,J,ue){if(typeof J=="string"&&J!==""||typeof J=="number")return b=b.get(F)||null,R(O,b,""+J,ue);if(typeof J=="object"&&J!==null){switch(J.$$typeof){case De:return b=b.get(J.key===null?F:J.key)||null,x(O,b,J,ue);case Re:return b=b.get(J.key===null?F:J.key)||null,U(O,b,J,ue);case ut:var he=J._init;return ne(b,O,F,he(J._payload),ue)}if(st(J)||ae(J))return b=b.get(F)||null,K(O,b,J,ue,null);Gl(O,J)}return null}function oe(b,O,F,J){for(var ue=null,he=null,de=O,ge=O=0,It=null;de!==null&&ge<F.length;ge++){de.index>ge?(It=de,de=null):It=de.sibling;var Me=q(b,de,F[ge],J);if(Me===null){de===null&&(de=It);break}n&&de&&Me.alternate===null&&i(b,de),O=f(Me,O,ge),he===null?ue=Me:he.sibling=Me,he=Me,de=It}if(ge===F.length)return a(b,de),Ze&&Gi(b,ge),ue;if(de===null){for(;ge<F.length;ge++)de=Y(b,F[ge],J),de!==null&&(O=f(de,O,ge),he===null?ue=de:he.sibling=de,he=de);return Ze&&Gi(b,ge),ue}for(de=c(b,de);ge<F.length;ge++)It=ne(de,b,ge,F[ge],J),It!==null&&(n&&It.alternate!==null&&de.delete(It.key===null?ge:It.key),O=f(It,O,ge),he===null?ue=It:he.sibling=It,he=It);return n&&de.forEach(function(li){return i(b,li)}),Ze&&Gi(b,ge),ue}function le(b,O,F,J){var ue=ae(F);if(typeof ue!="function")throw Error(t(150));if(F=ue.call(F),F==null)throw Error(t(151));for(var he=ue=null,de=O,ge=O=0,It=null,Me=F.next();de!==null&&!Me.done;ge++,Me=F.next()){de.index>ge?(It=de,de=null):It=de.sibling;var li=q(b,de,Me.value,J);if(li===null){de===null&&(de=It);break}n&&de&&li.alternate===null&&i(b,de),O=f(li,O,ge),he===null?ue=li:he.sibling=li,he=li,de=It}if(Me.done)return a(b,de),Ze&&Gi(b,ge),ue;if(de===null){for(;!Me.done;ge++,Me=F.next())Me=Y(b,Me.value,J),Me!==null&&(O=f(Me,O,ge),he===null?ue=Me:he.sibling=Me,he=Me);return Ze&&Gi(b,ge),ue}for(de=c(b,de);!Me.done;ge++,Me=F.next())Me=ne(de,b,ge,Me.value,J),Me!==null&&(n&&Me.alternate!==null&&de.delete(Me.key===null?ge:Me.key),O=f(Me,O,ge),he===null?ue=Me:he.sibling=Me,he=Me);return n&&de.forEach(function(yw){return i(b,yw)}),Ze&&Gi(b,ge),ue}function at(b,O,F,J){if(typeof F=="object"&&F!==null&&F.type===D&&F.key===null&&(F=F.props.children),typeof F=="object"&&F!==null){switch(F.$$typeof){case De:e:{for(var ue=F.key,he=O;he!==null;){if(he.key===ue){if(ue=F.type,ue===D){if(he.tag===7){a(b,he.sibling),O=d(he,F.props.children),O.return=b,b=O;break e}}else if(he.elementType===ue||typeof ue=="object"&&ue!==null&&ue.$$typeof===ut&&Sp(ue)===he.type){a(b,he.sibling),O=d(he,F.props),O.ref=fa(b,he,F),O.return=b,b=O;break e}a(b,he);break}else i(b,he);he=he.sibling}F.type===D?(O=ns(F.props.children,b.mode,J,F.key),O.return=b,b=O):(J=_u(F.type,F.key,F.props,null,b.mode,J),J.ref=fa(b,O,F),J.return=b,b=J)}return v(b);case Re:e:{for(he=F.key;O!==null;){if(O.key===he)if(O.tag===4&&O.stateNode.containerInfo===F.containerInfo&&O.stateNode.implementation===F.implementation){a(b,O.sibling),O=d(O,F.children||[]),O.return=b,b=O;break e}else{a(b,O);break}else i(b,O);O=O.sibling}O=Jh(F,b.mode,J),O.return=b,b=O}return v(b);case ut:return he=F._init,at(b,O,he(F._payload),J)}if(st(F))return oe(b,O,F,J);if(ae(F))return le(b,O,F,J);Gl(b,F)}return typeof F=="string"&&F!==""||typeof F=="number"?(F=""+F,O!==null&&O.tag===6?(a(b,O.sibling),O=d(O,F),O.return=b,b=O):(a(b,O),O=Yh(F,b.mode,J),O.return=b,b=O),v(b)):a(b,O)}return at}var Qs=Ap(!0),Rp=Ap(!1),Ql=Jr(null),Yl=null,Ys=null,oh=null;function ah(){oh=Ys=Yl=null}function lh(n){var i=Ql.current;Je(Ql),n._currentValue=i}function uh(n,i,a){for(;n!==null;){var c=n.alternate;if((n.childLanes&i)!==i?(n.childLanes|=i,c!==null&&(c.childLanes|=i)):c!==null&&(c.childLanes&i)!==i&&(c.childLanes|=i),n===a)break;n=n.return}}function Js(n,i){Yl=n,oh=Ys=null,n=n.dependencies,n!==null&&n.firstContext!==null&&((n.lanes&i)!==0&&(qt=!0),n.firstContext=null)}function fn(n){var i=n._currentValue;if(oh!==n)if(n={context:n,memoizedValue:i,next:null},Ys===null){if(Yl===null)throw Error(t(308));Ys=n,Yl.dependencies={lanes:0,firstContext:n}}else Ys=Ys.next=n;return i}var Qi=null;function ch(n){Qi===null?Qi=[n]:Qi.push(n)}function Cp(n,i,a,c){var d=i.interleaved;return d===null?(a.next=a,ch(i)):(a.next=d.next,d.next=a),i.interleaved=a,vr(n,c)}function vr(n,i){n.lanes|=i;var a=n.alternate;for(a!==null&&(a.lanes|=i),a=n,n=n.return;n!==null;)n.childLanes|=i,a=n.alternate,a!==null&&(a.childLanes|=i),a=n,n=n.return;return a.tag===3?a.stateNode:null}var ei=!1;function hh(n){n.updateQueue={baseState:n.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function Pp(n,i){n=n.updateQueue,i.updateQueue===n&&(i.updateQueue={baseState:n.baseState,firstBaseUpdate:n.firstBaseUpdate,lastBaseUpdate:n.lastBaseUpdate,shared:n.shared,effects:n.effects})}function Er(n,i){return{eventTime:n,lane:i,tag:0,payload:null,callback:null,next:null}}function ti(n,i,a){var c=n.updateQueue;if(c===null)return null;if(c=c.shared,(be&2)!==0){var d=c.pending;return d===null?i.next=i:(i.next=d.next,d.next=i),c.pending=i,vr(n,a)}return d=c.interleaved,d===null?(i.next=i,ch(c)):(i.next=d.next,d.next=i),c.interleaved=i,vr(n,a)}function Jl(n,i,a){if(i=i.updateQueue,i!==null&&(i=i.shared,(a&4194240)!==0)){var c=i.lanes;c&=n.pendingLanes,a|=c,i.lanes=a,Go(n,a)}}function kp(n,i){var a=n.updateQueue,c=n.alternate;if(c!==null&&(c=c.updateQueue,a===c)){var d=null,f=null;if(a=a.firstBaseUpdate,a!==null){do{var v={eventTime:a.eventTime,lane:a.lane,tag:a.tag,payload:a.payload,callback:a.callback,next:null};f===null?d=f=v:f=f.next=v,a=a.next}while(a!==null);f===null?d=f=i:f=f.next=i}else d=f=i;a={baseState:c.baseState,firstBaseUpdate:d,lastBaseUpdate:f,shared:c.shared,effects:c.effects},n.updateQueue=a;return}n=a.lastBaseUpdate,n===null?a.firstBaseUpdate=i:n.next=i,a.lastBaseUpdate=i}function Xl(n,i,a,c){var d=n.updateQueue;ei=!1;var f=d.firstBaseUpdate,v=d.lastBaseUpdate,R=d.shared.pending;if(R!==null){d.shared.pending=null;var x=R,U=x.next;x.next=null,v===null?f=U:v.next=U,v=x;var K=n.alternate;K!==null&&(K=K.updateQueue,R=K.lastBaseUpdate,R!==v&&(R===null?K.firstBaseUpdate=U:R.next=U,K.lastBaseUpdate=x))}if(f!==null){var Y=d.baseState;v=0,K=U=x=null,R=f;do{var q=R.lane,ne=R.eventTime;if((c&q)===q){K!==null&&(K=K.next={eventTime:ne,lane:0,tag:R.tag,payload:R.payload,callback:R.callback,next:null});e:{var oe=n,le=R;switch(q=i,ne=a,le.tag){case 1:if(oe=le.payload,typeof oe=="function"){Y=oe.call(ne,Y,q);break e}Y=oe;break e;case 3:oe.flags=oe.flags&-65537|128;case 0:if(oe=le.payload,q=typeof oe=="function"?oe.call(ne,Y,q):oe,q==null)break e;Y=ee({},Y,q);break e;case 2:ei=!0}}R.callback!==null&&R.lane!==0&&(n.flags|=64,q=d.effects,q===null?d.effects=[R]:q.push(R))}else ne={eventTime:ne,lane:q,tag:R.tag,payload:R.payload,callback:R.callback,next:null},K===null?(U=K=ne,x=Y):K=K.next=ne,v|=q;if(R=R.next,R===null){if(R=d.shared.pending,R===null)break;q=R,R=q.next,q.next=null,d.lastBaseUpdate=q,d.shared.pending=null}}while(!0);if(K===null&&(x=Y),d.baseState=x,d.firstBaseUpdate=U,d.lastBaseUpdate=K,i=d.shared.interleaved,i!==null){d=i;do v|=d.lane,d=d.next;while(d!==i)}else f===null&&(d.shared.lanes=0);Xi|=v,n.lanes=v,n.memoizedState=Y}}function Np(n,i,a){if(n=i.effects,i.effects=null,n!==null)for(i=0;i<n.length;i++){var c=n[i],d=c.callback;if(d!==null){if(c.callback=null,c=a,typeof d!="function")throw Error(t(191,d));d.call(c)}}}var pa={},Qn=Jr(pa),ma=Jr(pa),ga=Jr(pa);function Yi(n){if(n===pa)throw Error(t(174));return n}function dh(n,i){switch(Ke(ga,i),Ke(ma,n),Ke(Qn,pa),n=i.nodeType,n){case 9:case 11:i=(i=i.documentElement)?i.namespaceURI:vs(null,"");break;default:n=n===8?i.parentNode:i,i=n.namespaceURI||null,n=n.tagName,i=vs(i,n)}Je(Qn),Ke(Qn,i)}function Xs(){Je(Qn),Je(ma),Je(ga)}function xp(n){Yi(ga.current);var i=Yi(Qn.current),a=vs(i,n.type);i!==a&&(Ke(ma,n),Ke(Qn,a))}function fh(n){ma.current===n&&(Je(Qn),Je(ma))}var et=Jr(0);function Zl(n){for(var i=n;i!==null;){if(i.tag===13){var a=i.memoizedState;if(a!==null&&(a=a.dehydrated,a===null||a.data==="$?"||a.data==="$!"))return i}else if(i.tag===19&&i.memoizedProps.revealOrder!==void 0){if((i.flags&128)!==0)return i}else if(i.child!==null){i.child.return=i,i=i.child;continue}if(i===n)break;for(;i.sibling===null;){if(i.return===null||i.return===n)return null;i=i.return}i.sibling.return=i.return,i=i.sibling}return null}var ph=[];function mh(){for(var n=0;n<ph.length;n++)ph[n]._workInProgressVersionPrimary=null;ph.length=0}var eu=Ae.ReactCurrentDispatcher,gh=Ae.ReactCurrentBatchConfig,Ji=0,tt=null,yt=null,wt=null,tu=!1,ya=!1,_a=0,UE=0;function Ot(){throw Error(t(321))}function yh(n,i){if(i===null)return!1;for(var a=0;a<i.length&&a<n.length;a++)if(!In(n[a],i[a]))return!1;return!0}function _h(n,i,a,c,d,f){if(Ji=f,tt=i,i.memoizedState=null,i.updateQueue=null,i.lanes=0,eu.current=n===null||n.memoizedState===null?$E:HE,n=a(c,d),ya){f=0;do{if(ya=!1,_a=0,25<=f)throw Error(t(301));f+=1,wt=yt=null,i.updateQueue=null,eu.current=WE,n=a(c,d)}while(ya)}if(eu.current=iu,i=yt!==null&&yt.next!==null,Ji=0,wt=yt=tt=null,tu=!1,i)throw Error(t(300));return n}function vh(){var n=_a!==0;return _a=0,n}function Yn(){var n={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return wt===null?tt.memoizedState=wt=n:wt=wt.next=n,wt}function pn(){if(yt===null){var n=tt.alternate;n=n!==null?n.memoizedState:null}else n=yt.next;var i=wt===null?tt.memoizedState:wt.next;if(i!==null)wt=i,yt=n;else{if(n===null)throw Error(t(310));yt=n,n={memoizedState:yt.memoizedState,baseState:yt.baseState,baseQueue:yt.baseQueue,queue:yt.queue,next:null},wt===null?tt.memoizedState=wt=n:wt=wt.next=n}return wt}function va(n,i){return typeof i=="function"?i(n):i}function Eh(n){var i=pn(),a=i.queue;if(a===null)throw Error(t(311));a.lastRenderedReducer=n;var c=yt,d=c.baseQueue,f=a.pending;if(f!==null){if(d!==null){var v=d.next;d.next=f.next,f.next=v}c.baseQueue=d=f,a.pending=null}if(d!==null){f=d.next,c=c.baseState;var R=v=null,x=null,U=f;do{var K=U.lane;if((Ji&K)===K)x!==null&&(x=x.next={lane:0,action:U.action,hasEagerState:U.hasEagerState,eagerState:U.eagerState,next:null}),c=U.hasEagerState?U.eagerState:n(c,U.action);else{var Y={lane:K,action:U.action,hasEagerState:U.hasEagerState,eagerState:U.eagerState,next:null};x===null?(R=x=Y,v=c):x=x.next=Y,tt.lanes|=K,Xi|=K}U=U.next}while(U!==null&&U!==f);x===null?v=c:x.next=R,In(c,i.memoizedState)||(qt=!0),i.memoizedState=c,i.baseState=v,i.baseQueue=x,a.lastRenderedState=c}if(n=a.interleaved,n!==null){d=n;do f=d.lane,tt.lanes|=f,Xi|=f,d=d.next;while(d!==n)}else d===null&&(a.lanes=0);return[i.memoizedState,a.dispatch]}function wh(n){var i=pn(),a=i.queue;if(a===null)throw Error(t(311));a.lastRenderedReducer=n;var c=a.dispatch,d=a.pending,f=i.memoizedState;if(d!==null){a.pending=null;var v=d=d.next;do f=n(f,v.action),v=v.next;while(v!==d);In(f,i.memoizedState)||(qt=!0),i.memoizedState=f,i.baseQueue===null&&(i.baseState=f),a.lastRenderedState=f}return[f,c]}function Dp(){}function Vp(n,i){var a=tt,c=pn(),d=i(),f=!In(c.memoizedState,d);if(f&&(c.memoizedState=d,qt=!0),c=c.queue,Th(bp.bind(null,a,c,n),[n]),c.getSnapshot!==i||f||wt!==null&&wt.memoizedState.tag&1){if(a.flags|=2048,Ea(9,Lp.bind(null,a,c,d,i),void 0,null),Tt===null)throw Error(t(349));(Ji&30)!==0||Op(a,i,d)}return d}function Op(n,i,a){n.flags|=16384,n={getSnapshot:i,value:a},i=tt.updateQueue,i===null?(i={lastEffect:null,stores:null},tt.updateQueue=i,i.stores=[n]):(a=i.stores,a===null?i.stores=[n]:a.push(n))}function Lp(n,i,a,c){i.value=a,i.getSnapshot=c,Mp(i)&&Fp(n)}function bp(n,i,a){return a(function(){Mp(i)&&Fp(n)})}function Mp(n){var i=n.getSnapshot;n=n.value;try{var a=i();return!In(n,a)}catch{return!0}}function Fp(n){var i=vr(n,1);i!==null&&Pn(i,n,1,-1)}function Up(n){var i=Yn();return typeof n=="function"&&(n=n()),i.memoizedState=i.baseState=n,n={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:va,lastRenderedState:n},i.queue=n,n=n.dispatch=BE.bind(null,tt,n),[i.memoizedState,n]}function Ea(n,i,a,c){return n={tag:n,create:i,destroy:a,deps:c,next:null},i=tt.updateQueue,i===null?(i={lastEffect:null,stores:null},tt.updateQueue=i,i.lastEffect=n.next=n):(a=i.lastEffect,a===null?i.lastEffect=n.next=n:(c=a.next,a.next=n,n.next=c,i.lastEffect=n)),n}function jp(){return pn().memoizedState}function nu(n,i,a,c){var d=Yn();tt.flags|=n,d.memoizedState=Ea(1|i,a,void 0,c===void 0?null:c)}function ru(n,i,a,c){var d=pn();c=c===void 0?null:c;var f=void 0;if(yt!==null){var v=yt.memoizedState;if(f=v.destroy,c!==null&&yh(c,v.deps)){d.memoizedState=Ea(i,a,f,c);return}}tt.flags|=n,d.memoizedState=Ea(1|i,a,f,c)}function zp(n,i){return nu(8390656,8,n,i)}function Th(n,i){return ru(2048,8,n,i)}function Bp(n,i){return ru(4,2,n,i)}function $p(n,i){return ru(4,4,n,i)}function Hp(n,i){if(typeof i=="function")return n=n(),i(n),function(){i(null)};if(i!=null)return n=n(),i.current=n,function(){i.current=null}}function Wp(n,i,a){return a=a!=null?a.concat([n]):null,ru(4,4,Hp.bind(null,i,n),a)}function Ih(){}function qp(n,i){var a=pn();i=i===void 0?null:i;var c=a.memoizedState;return c!==null&&i!==null&&yh(i,c[1])?c[0]:(a.memoizedState=[n,i],n)}function Kp(n,i){var a=pn();i=i===void 0?null:i;var c=a.memoizedState;return c!==null&&i!==null&&yh(i,c[1])?c[0]:(n=n(),a.memoizedState=[n,i],n)}function Gp(n,i,a){return(Ji&21)===0?(n.baseState&&(n.baseState=!1,qt=!0),n.memoizedState=a):(In(a,i)||(a=qo(),tt.lanes|=a,Xi|=a,n.baseState=!0),i)}function jE(n,i){var a=Ve;Ve=a!==0&&4>a?a:4,n(!0);var c=gh.transition;gh.transition={};try{n(!1),i()}finally{Ve=a,gh.transition=c}}function Qp(){return pn().memoizedState}function zE(n,i,a){var c=si(n);if(a={lane:c,action:a,hasEagerState:!1,eagerState:null,next:null},Yp(n))Jp(i,a);else if(a=Cp(n,i,a,c),a!==null){var d=$t();Pn(a,n,c,d),Xp(a,i,c)}}function BE(n,i,a){var c=si(n),d={lane:c,action:a,hasEagerState:!1,eagerState:null,next:null};if(Yp(n))Jp(i,d);else{var f=n.alternate;if(n.lanes===0&&(f===null||f.lanes===0)&&(f=i.lastRenderedReducer,f!==null))try{var v=i.lastRenderedState,R=f(v,a);if(d.hasEagerState=!0,d.eagerState=R,In(R,v)){var x=i.interleaved;x===null?(d.next=d,ch(i)):(d.next=x.next,x.next=d),i.interleaved=d;return}}catch{}finally{}a=Cp(n,i,d,c),a!==null&&(d=$t(),Pn(a,n,c,d),Xp(a,i,c))}}function Yp(n){var i=n.alternate;return n===tt||i!==null&&i===tt}function Jp(n,i){ya=tu=!0;var a=n.pending;a===null?i.next=i:(i.next=a.next,a.next=i),n.pending=i}function Xp(n,i,a){if((a&4194240)!==0){var c=i.lanes;c&=n.pendingLanes,a|=c,i.lanes=a,Go(n,a)}}var iu={readContext:fn,useCallback:Ot,useContext:Ot,useEffect:Ot,useImperativeHandle:Ot,useInsertionEffect:Ot,useLayoutEffect:Ot,useMemo:Ot,useReducer:Ot,useRef:Ot,useState:Ot,useDebugValue:Ot,useDeferredValue:Ot,useTransition:Ot,useMutableSource:Ot,useSyncExternalStore:Ot,useId:Ot,unstable_isNewReconciler:!1},$E={readContext:fn,useCallback:function(n,i){return Yn().memoizedState=[n,i===void 0?null:i],n},useContext:fn,useEffect:zp,useImperativeHandle:function(n,i,a){return a=a!=null?a.concat([n]):null,nu(4194308,4,Hp.bind(null,i,n),a)},useLayoutEffect:function(n,i){return nu(4194308,4,n,i)},useInsertionEffect:function(n,i){return nu(4,2,n,i)},useMemo:function(n,i){var a=Yn();return i=i===void 0?null:i,n=n(),a.memoizedState=[n,i],n},useReducer:function(n,i,a){var c=Yn();return i=a!==void 0?a(i):i,c.memoizedState=c.baseState=i,n={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:n,lastRenderedState:i},c.queue=n,n=n.dispatch=zE.bind(null,tt,n),[c.memoizedState,n]},useRef:function(n){var i=Yn();return n={current:n},i.memoizedState=n},useState:Up,useDebugValue:Ih,useDeferredValue:function(n){return Yn().memoizedState=n},useTransition:function(){var n=Up(!1),i=n[0];return n=jE.bind(null,n[1]),Yn().memoizedState=n,[i,n]},useMutableSource:function(){},useSyncExternalStore:function(n,i,a){var c=tt,d=Yn();if(Ze){if(a===void 0)throw Error(t(407));a=a()}else{if(a=i(),Tt===null)throw Error(t(349));(Ji&30)!==0||Op(c,i,a)}d.memoizedState=a;var f={value:a,getSnapshot:i};return d.queue=f,zp(bp.bind(null,c,f,n),[n]),c.flags|=2048,Ea(9,Lp.bind(null,c,f,a,i),void 0,null),a},useId:function(){var n=Yn(),i=Tt.identifierPrefix;if(Ze){var a=_r,c=yr;a=(c&~(1<<32-Zt(c)-1)).toString(32)+a,i=":"+i+"R"+a,a=_a++,0<a&&(i+="H"+a.toString(32)),i+=":"}else a=UE++,i=":"+i+"r"+a.toString(32)+":";return n.memoizedState=i},unstable_isNewReconciler:!1},HE={readContext:fn,useCallback:qp,useContext:fn,useEffect:Th,useImperativeHandle:Wp,useInsertionEffect:Bp,useLayoutEffect:$p,useMemo:Kp,useReducer:Eh,useRef:jp,useState:function(){return Eh(va)},useDebugValue:Ih,useDeferredValue:function(n){var i=pn();return Gp(i,yt.memoizedState,n)},useTransition:function(){var n=Eh(va)[0],i=pn().memoizedState;return[n,i]},useMutableSource:Dp,useSyncExternalStore:Vp,useId:Qp,unstable_isNewReconciler:!1},WE={readContext:fn,useCallback:qp,useContext:fn,useEffect:Th,useImperativeHandle:Wp,useInsertionEffect:Bp,useLayoutEffect:$p,useMemo:Kp,useReducer:wh,useRef:jp,useState:function(){return wh(va)},useDebugValue:Ih,useDeferredValue:function(n){var i=pn();return yt===null?i.memoizedState=n:Gp(i,yt.memoizedState,n)},useTransition:function(){var n=wh(va)[0],i=pn().memoizedState;return[n,i]},useMutableSource:Dp,useSyncExternalStore:Vp,useId:Qp,unstable_isNewReconciler:!1};function An(n,i){if(n&&n.defaultProps){i=ee({},i),n=n.defaultProps;for(var a in n)i[a]===void 0&&(i[a]=n[a]);return i}return i}function Sh(n,i,a,c){i=n.memoizedState,a=a(c,i),a=a==null?i:ee({},i,a),n.memoizedState=a,n.lanes===0&&(n.updateQueue.baseState=a)}var su={isMounted:function(n){return(n=n._reactInternals)?wn(n)===n:!1},enqueueSetState:function(n,i,a){n=n._reactInternals;var c=$t(),d=si(n),f=Er(c,d);f.payload=i,a!=null&&(f.callback=a),i=ti(n,f,d),i!==null&&(Pn(i,n,d,c),Jl(i,n,d))},enqueueReplaceState:function(n,i,a){n=n._reactInternals;var c=$t(),d=si(n),f=Er(c,d);f.tag=1,f.payload=i,a!=null&&(f.callback=a),i=ti(n,f,d),i!==null&&(Pn(i,n,d,c),Jl(i,n,d))},enqueueForceUpdate:function(n,i){n=n._reactInternals;var a=$t(),c=si(n),d=Er(a,c);d.tag=2,i!=null&&(d.callback=i),i=ti(n,d,c),i!==null&&(Pn(i,n,c,a),Jl(i,n,c))}};function Zp(n,i,a,c,d,f,v){return n=n.stateNode,typeof n.shouldComponentUpdate=="function"?n.shouldComponentUpdate(c,f,v):i.prototype&&i.prototype.isPureReactComponent?!oa(a,c)||!oa(d,f):!0}function em(n,i,a){var c=!1,d=Xr,f=i.contextType;return typeof f=="object"&&f!==null?f=fn(f):(d=Wt(i)?qi:Vt.current,c=i.contextTypes,f=(c=c!=null)?Ws(n,d):Xr),i=new i(a,f),n.memoizedState=i.state!==null&&i.state!==void 0?i.state:null,i.updater=su,n.stateNode=i,i._reactInternals=n,c&&(n=n.stateNode,n.__reactInternalMemoizedUnmaskedChildContext=d,n.__reactInternalMemoizedMaskedChildContext=f),i}function tm(n,i,a,c){n=i.state,typeof i.componentWillReceiveProps=="function"&&i.componentWillReceiveProps(a,c),typeof i.UNSAFE_componentWillReceiveProps=="function"&&i.UNSAFE_componentWillReceiveProps(a,c),i.state!==n&&su.enqueueReplaceState(i,i.state,null)}function Ah(n,i,a,c){var d=n.stateNode;d.props=a,d.state=n.memoizedState,d.refs={},hh(n);var f=i.contextType;typeof f=="object"&&f!==null?d.context=fn(f):(f=Wt(i)?qi:Vt.current,d.context=Ws(n,f)),d.state=n.memoizedState,f=i.getDerivedStateFromProps,typeof f=="function"&&(Sh(n,i,f,a),d.state=n.memoizedState),typeof i.getDerivedStateFromProps=="function"||typeof d.getSnapshotBeforeUpdate=="function"||typeof d.UNSAFE_componentWillMount!="function"&&typeof d.componentWillMount!="function"||(i=d.state,typeof d.componentWillMount=="function"&&d.componentWillMount(),typeof d.UNSAFE_componentWillMount=="function"&&d.UNSAFE_componentWillMount(),i!==d.state&&su.enqueueReplaceState(d,d.state,null),Xl(n,a,d,c),d.state=n.memoizedState),typeof d.componentDidMount=="function"&&(n.flags|=4194308)}function Zs(n,i){try{var a="",c=i;do a+=Ce(c),c=c.return;while(c);var d=a}catch(f){d=`
Error generating stack: `+f.message+`
`+f.stack}return{value:n,source:i,stack:d,digest:null}}function Rh(n,i,a){return{value:n,source:null,stack:a??null,digest:i??null}}function Ch(n,i){try{console.error(i.value)}catch(a){setTimeout(function(){throw a})}}var qE=typeof WeakMap=="function"?WeakMap:Map;function nm(n,i,a){a=Er(-1,a),a.tag=3,a.payload={element:null};var c=i.value;return a.callback=function(){du||(du=!0,Bh=c),Ch(n,i)},a}function rm(n,i,a){a=Er(-1,a),a.tag=3;var c=n.type.getDerivedStateFromError;if(typeof c=="function"){var d=i.value;a.payload=function(){return c(d)},a.callback=function(){Ch(n,i)}}var f=n.stateNode;return f!==null&&typeof f.componentDidCatch=="function"&&(a.callback=function(){Ch(n,i),typeof c!="function"&&(ri===null?ri=new Set([this]):ri.add(this));var v=i.stack;this.componentDidCatch(i.value,{componentStack:v!==null?v:""})}),a}function im(n,i,a){var c=n.pingCache;if(c===null){c=n.pingCache=new qE;var d=new Set;c.set(i,d)}else d=c.get(i),d===void 0&&(d=new Set,c.set(i,d));d.has(a)||(d.add(a),n=ow.bind(null,n,i,a),i.then(n,n))}function sm(n){do{var i;if((i=n.tag===13)&&(i=n.memoizedState,i=i!==null?i.dehydrated!==null:!0),i)return n;n=n.return}while(n!==null);return null}function om(n,i,a,c,d){return(n.mode&1)===0?(n===i?n.flags|=65536:(n.flags|=128,a.flags|=131072,a.flags&=-52805,a.tag===1&&(a.alternate===null?a.tag=17:(i=Er(-1,1),i.tag=2,ti(a,i,1))),a.lanes|=1),n):(n.flags|=65536,n.lanes=d,n)}var KE=Ae.ReactCurrentOwner,qt=!1;function Bt(n,i,a,c){i.child=n===null?Rp(i,null,a,c):Qs(i,n.child,a,c)}function am(n,i,a,c,d){a=a.render;var f=i.ref;return Js(i,d),c=_h(n,i,a,c,f,d),a=vh(),n!==null&&!qt?(i.updateQueue=n.updateQueue,i.flags&=-2053,n.lanes&=~d,wr(n,i,d)):(Ze&&a&&th(i),i.flags|=1,Bt(n,i,c,d),i.child)}function lm(n,i,a,c,d){if(n===null){var f=a.type;return typeof f=="function"&&!Qh(f)&&f.defaultProps===void 0&&a.compare===null&&a.defaultProps===void 0?(i.tag=15,i.type=f,um(n,i,f,c,d)):(n=_u(a.type,null,c,i,i.mode,d),n.ref=i.ref,n.return=i,i.child=n)}if(f=n.child,(n.lanes&d)===0){var v=f.memoizedProps;if(a=a.compare,a=a!==null?a:oa,a(v,c)&&n.ref===i.ref)return wr(n,i,d)}return i.flags|=1,n=ai(f,c),n.ref=i.ref,n.return=i,i.child=n}function um(n,i,a,c,d){if(n!==null){var f=n.memoizedProps;if(oa(f,c)&&n.ref===i.ref)if(qt=!1,i.pendingProps=c=f,(n.lanes&d)!==0)(n.flags&131072)!==0&&(qt=!0);else return i.lanes=n.lanes,wr(n,i,d)}return Ph(n,i,a,c,d)}function cm(n,i,a){var c=i.pendingProps,d=c.children,f=n!==null?n.memoizedState:null;if(c.mode==="hidden")if((i.mode&1)===0)i.memoizedState={baseLanes:0,cachePool:null,transitions:null},Ke(to,an),an|=a;else{if((a&1073741824)===0)return n=f!==null?f.baseLanes|a:a,i.lanes=i.childLanes=1073741824,i.memoizedState={baseLanes:n,cachePool:null,transitions:null},i.updateQueue=null,Ke(to,an),an|=n,null;i.memoizedState={baseLanes:0,cachePool:null,transitions:null},c=f!==null?f.baseLanes:a,Ke(to,an),an|=c}else f!==null?(c=f.baseLanes|a,i.memoizedState=null):c=a,Ke(to,an),an|=c;return Bt(n,i,d,a),i.child}function hm(n,i){var a=i.ref;(n===null&&a!==null||n!==null&&n.ref!==a)&&(i.flags|=512,i.flags|=2097152)}function Ph(n,i,a,c,d){var f=Wt(a)?qi:Vt.current;return f=Ws(i,f),Js(i,d),a=_h(n,i,a,c,f,d),c=vh(),n!==null&&!qt?(i.updateQueue=n.updateQueue,i.flags&=-2053,n.lanes&=~d,wr(n,i,d)):(Ze&&c&&th(i),i.flags|=1,Bt(n,i,a,d),i.child)}function dm(n,i,a,c,d){if(Wt(a)){var f=!0;$l(i)}else f=!1;if(Js(i,d),i.stateNode===null)au(n,i),em(i,a,c),Ah(i,a,c,d),c=!0;else if(n===null){var v=i.stateNode,R=i.memoizedProps;v.props=R;var x=v.context,U=a.contextType;typeof U=="object"&&U!==null?U=fn(U):(U=Wt(a)?qi:Vt.current,U=Ws(i,U));var K=a.getDerivedStateFromProps,Y=typeof K=="function"||typeof v.getSnapshotBeforeUpdate=="function";Y||typeof v.UNSAFE_componentWillReceiveProps!="function"&&typeof v.componentWillReceiveProps!="function"||(R!==c||x!==U)&&tm(i,v,c,U),ei=!1;var q=i.memoizedState;v.state=q,Xl(i,c,v,d),x=i.memoizedState,R!==c||q!==x||Ht.current||ei?(typeof K=="function"&&(Sh(i,a,K,c),x=i.memoizedState),(R=ei||Zp(i,a,R,c,q,x,U))?(Y||typeof v.UNSAFE_componentWillMount!="function"&&typeof v.componentWillMount!="function"||(typeof v.componentWillMount=="function"&&v.componentWillMount(),typeof v.UNSAFE_componentWillMount=="function"&&v.UNSAFE_componentWillMount()),typeof v.componentDidMount=="function"&&(i.flags|=4194308)):(typeof v.componentDidMount=="function"&&(i.flags|=4194308),i.memoizedProps=c,i.memoizedState=x),v.props=c,v.state=x,v.context=U,c=R):(typeof v.componentDidMount=="function"&&(i.flags|=4194308),c=!1)}else{v=i.stateNode,Pp(n,i),R=i.memoizedProps,U=i.type===i.elementType?R:An(i.type,R),v.props=U,Y=i.pendingProps,q=v.context,x=a.contextType,typeof x=="object"&&x!==null?x=fn(x):(x=Wt(a)?qi:Vt.current,x=Ws(i,x));var ne=a.getDerivedStateFromProps;(K=typeof ne=="function"||typeof v.getSnapshotBeforeUpdate=="function")||typeof v.UNSAFE_componentWillReceiveProps!="function"&&typeof v.componentWillReceiveProps!="function"||(R!==Y||q!==x)&&tm(i,v,c,x),ei=!1,q=i.memoizedState,v.state=q,Xl(i,c,v,d);var oe=i.memoizedState;R!==Y||q!==oe||Ht.current||ei?(typeof ne=="function"&&(Sh(i,a,ne,c),oe=i.memoizedState),(U=ei||Zp(i,a,U,c,q,oe,x)||!1)?(K||typeof v.UNSAFE_componentWillUpdate!="function"&&typeof v.componentWillUpdate!="function"||(typeof v.componentWillUpdate=="function"&&v.componentWillUpdate(c,oe,x),typeof v.UNSAFE_componentWillUpdate=="function"&&v.UNSAFE_componentWillUpdate(c,oe,x)),typeof v.componentDidUpdate=="function"&&(i.flags|=4),typeof v.getSnapshotBeforeUpdate=="function"&&(i.flags|=1024)):(typeof v.componentDidUpdate!="function"||R===n.memoizedProps&&q===n.memoizedState||(i.flags|=4),typeof v.getSnapshotBeforeUpdate!="function"||R===n.memoizedProps&&q===n.memoizedState||(i.flags|=1024),i.memoizedProps=c,i.memoizedState=oe),v.props=c,v.state=oe,v.context=x,c=U):(typeof v.componentDidUpdate!="function"||R===n.memoizedProps&&q===n.memoizedState||(i.flags|=4),typeof v.getSnapshotBeforeUpdate!="function"||R===n.memoizedProps&&q===n.memoizedState||(i.flags|=1024),c=!1)}return kh(n,i,a,c,f,d)}function kh(n,i,a,c,d,f){hm(n,i);var v=(i.flags&128)!==0;if(!c&&!v)return d&&yp(i,a,!1),wr(n,i,f);c=i.stateNode,KE.current=i;var R=v&&typeof a.getDerivedStateFromError!="function"?null:c.render();return i.flags|=1,n!==null&&v?(i.child=Qs(i,n.child,null,f),i.child=Qs(i,null,R,f)):Bt(n,i,R,f),i.memoizedState=c.state,d&&yp(i,a,!0),i.child}function fm(n){var i=n.stateNode;i.pendingContext?mp(n,i.pendingContext,i.pendingContext!==i.context):i.context&&mp(n,i.context,!1),dh(n,i.containerInfo)}function pm(n,i,a,c,d){return Gs(),sh(d),i.flags|=256,Bt(n,i,a,c),i.child}var Nh={dehydrated:null,treeContext:null,retryLane:0};function xh(n){return{baseLanes:n,cachePool:null,transitions:null}}function mm(n,i,a){var c=i.pendingProps,d=et.current,f=!1,v=(i.flags&128)!==0,R;if((R=v)||(R=n!==null&&n.memoizedState===null?!1:(d&2)!==0),R?(f=!0,i.flags&=-129):(n===null||n.memoizedState!==null)&&(d|=1),Ke(et,d&1),n===null)return ih(i),n=i.memoizedState,n!==null&&(n=n.dehydrated,n!==null)?((i.mode&1)===0?i.lanes=1:n.data==="$!"?i.lanes=8:i.lanes=1073741824,null):(v=c.children,n=c.fallback,f?(c=i.mode,f=i.child,v={mode:"hidden",children:v},(c&1)===0&&f!==null?(f.childLanes=0,f.pendingProps=v):f=vu(v,c,0,null),n=ns(n,c,a,null),f.return=i,n.return=i,f.sibling=n,i.child=f,i.child.memoizedState=xh(a),i.memoizedState=Nh,n):Dh(i,v));if(d=n.memoizedState,d!==null&&(R=d.dehydrated,R!==null))return GE(n,i,v,c,R,d,a);if(f){f=c.fallback,v=i.mode,d=n.child,R=d.sibling;var x={mode:"hidden",children:c.children};return(v&1)===0&&i.child!==d?(c=i.child,c.childLanes=0,c.pendingProps=x,i.deletions=null):(c=ai(d,x),c.subtreeFlags=d.subtreeFlags&14680064),R!==null?f=ai(R,f):(f=ns(f,v,a,null),f.flags|=2),f.return=i,c.return=i,c.sibling=f,i.child=c,c=f,f=i.child,v=n.child.memoizedState,v=v===null?xh(a):{baseLanes:v.baseLanes|a,cachePool:null,transitions:v.transitions},f.memoizedState=v,f.childLanes=n.childLanes&~a,i.memoizedState=Nh,c}return f=n.child,n=f.sibling,c=ai(f,{mode:"visible",children:c.children}),(i.mode&1)===0&&(c.lanes=a),c.return=i,c.sibling=null,n!==null&&(a=i.deletions,a===null?(i.deletions=[n],i.flags|=16):a.push(n)),i.child=c,i.memoizedState=null,c}function Dh(n,i){return i=vu({mode:"visible",children:i},n.mode,0,null),i.return=n,n.child=i}function ou(n,i,a,c){return c!==null&&sh(c),Qs(i,n.child,null,a),n=Dh(i,i.pendingProps.children),n.flags|=2,i.memoizedState=null,n}function GE(n,i,a,c,d,f,v){if(a)return i.flags&256?(i.flags&=-257,c=Rh(Error(t(422))),ou(n,i,v,c)):i.memoizedState!==null?(i.child=n.child,i.flags|=128,null):(f=c.fallback,d=i.mode,c=vu({mode:"visible",children:c.children},d,0,null),f=ns(f,d,v,null),f.flags|=2,c.return=i,f.return=i,c.sibling=f,i.child=c,(i.mode&1)!==0&&Qs(i,n.child,null,v),i.child.memoizedState=xh(v),i.memoizedState=Nh,f);if((i.mode&1)===0)return ou(n,i,v,null);if(d.data==="$!"){if(c=d.nextSibling&&d.nextSibling.dataset,c)var R=c.dgst;return c=R,f=Error(t(419)),c=Rh(f,c,void 0),ou(n,i,v,c)}if(R=(v&n.childLanes)!==0,qt||R){if(c=Tt,c!==null){switch(v&-v){case 4:d=2;break;case 16:d=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:d=32;break;case 536870912:d=268435456;break;default:d=0}d=(d&(c.suspendedLanes|v))!==0?0:d,d!==0&&d!==f.retryLane&&(f.retryLane=d,vr(n,d),Pn(c,n,d,-1))}return Gh(),c=Rh(Error(t(421))),ou(n,i,v,c)}return d.data==="$?"?(i.flags|=128,i.child=n.child,i=aw.bind(null,n),d._reactRetry=i,null):(n=f.treeContext,on=Yr(d.nextSibling),sn=i,Ze=!0,Sn=null,n!==null&&(hn[dn++]=yr,hn[dn++]=_r,hn[dn++]=Ki,yr=n.id,_r=n.overflow,Ki=i),i=Dh(i,c.children),i.flags|=4096,i)}function gm(n,i,a){n.lanes|=i;var c=n.alternate;c!==null&&(c.lanes|=i),uh(n.return,i,a)}function Vh(n,i,a,c,d){var f=n.memoizedState;f===null?n.memoizedState={isBackwards:i,rendering:null,renderingStartTime:0,last:c,tail:a,tailMode:d}:(f.isBackwards=i,f.rendering=null,f.renderingStartTime=0,f.last=c,f.tail=a,f.tailMode=d)}function ym(n,i,a){var c=i.pendingProps,d=c.revealOrder,f=c.tail;if(Bt(n,i,c.children,a),c=et.current,(c&2)!==0)c=c&1|2,i.flags|=128;else{if(n!==null&&(n.flags&128)!==0)e:for(n=i.child;n!==null;){if(n.tag===13)n.memoizedState!==null&&gm(n,a,i);else if(n.tag===19)gm(n,a,i);else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===i)break e;for(;n.sibling===null;){if(n.return===null||n.return===i)break e;n=n.return}n.sibling.return=n.return,n=n.sibling}c&=1}if(Ke(et,c),(i.mode&1)===0)i.memoizedState=null;else switch(d){case"forwards":for(a=i.child,d=null;a!==null;)n=a.alternate,n!==null&&Zl(n)===null&&(d=a),a=a.sibling;a=d,a===null?(d=i.child,i.child=null):(d=a.sibling,a.sibling=null),Vh(i,!1,d,a,f);break;case"backwards":for(a=null,d=i.child,i.child=null;d!==null;){if(n=d.alternate,n!==null&&Zl(n)===null){i.child=d;break}n=d.sibling,d.sibling=a,a=d,d=n}Vh(i,!0,a,null,f);break;case"together":Vh(i,!1,null,null,void 0);break;default:i.memoizedState=null}return i.child}function au(n,i){(i.mode&1)===0&&n!==null&&(n.alternate=null,i.alternate=null,i.flags|=2)}function wr(n,i,a){if(n!==null&&(i.dependencies=n.dependencies),Xi|=i.lanes,(a&i.childLanes)===0)return null;if(n!==null&&i.child!==n.child)throw Error(t(153));if(i.child!==null){for(n=i.child,a=ai(n,n.pendingProps),i.child=a,a.return=i;n.sibling!==null;)n=n.sibling,a=a.sibling=ai(n,n.pendingProps),a.return=i;a.sibling=null}return i.child}function QE(n,i,a){switch(i.tag){case 3:fm(i),Gs();break;case 5:xp(i);break;case 1:Wt(i.type)&&$l(i);break;case 4:dh(i,i.stateNode.containerInfo);break;case 10:var c=i.type._context,d=i.memoizedProps.value;Ke(Ql,c._currentValue),c._currentValue=d;break;case 13:if(c=i.memoizedState,c!==null)return c.dehydrated!==null?(Ke(et,et.current&1),i.flags|=128,null):(a&i.child.childLanes)!==0?mm(n,i,a):(Ke(et,et.current&1),n=wr(n,i,a),n!==null?n.sibling:null);Ke(et,et.current&1);break;case 19:if(c=(a&i.childLanes)!==0,(n.flags&128)!==0){if(c)return ym(n,i,a);i.flags|=128}if(d=i.memoizedState,d!==null&&(d.rendering=null,d.tail=null,d.lastEffect=null),Ke(et,et.current),c)break;return null;case 22:case 23:return i.lanes=0,cm(n,i,a)}return wr(n,i,a)}var _m,Oh,vm,Em;_m=function(n,i){for(var a=i.child;a!==null;){if(a.tag===5||a.tag===6)n.appendChild(a.stateNode);else if(a.tag!==4&&a.child!==null){a.child.return=a,a=a.child;continue}if(a===i)break;for(;a.sibling===null;){if(a.return===null||a.return===i)return;a=a.return}a.sibling.return=a.return,a=a.sibling}},Oh=function(){},vm=function(n,i,a,c){var d=n.memoizedProps;if(d!==c){n=i.stateNode,Yi(Qn.current);var f=null;switch(a){case"input":d=ys(n,d),c=ys(n,c),f=[];break;case"select":d=ee({},d,{value:void 0}),c=ee({},c,{value:void 0}),f=[];break;case"textarea":d=Lo(n,d),c=Lo(n,c),f=[];break;default:typeof d.onClick!="function"&&typeof c.onClick=="function"&&(n.onclick=jl)}En(a,c);var v;a=null;for(U in d)if(!c.hasOwnProperty(U)&&d.hasOwnProperty(U)&&d[U]!=null)if(U==="style"){var R=d[U];for(v in R)R.hasOwnProperty(v)&&(a||(a={}),a[v]="")}else U!=="dangerouslySetInnerHTML"&&U!=="children"&&U!=="suppressContentEditableWarning"&&U!=="suppressHydrationWarning"&&U!=="autoFocus"&&(o.hasOwnProperty(U)?f||(f=[]):(f=f||[]).push(U,null));for(U in c){var x=c[U];if(R=d!=null?d[U]:void 0,c.hasOwnProperty(U)&&x!==R&&(x!=null||R!=null))if(U==="style")if(R){for(v in R)!R.hasOwnProperty(v)||x&&x.hasOwnProperty(v)||(a||(a={}),a[v]="");for(v in x)x.hasOwnProperty(v)&&R[v]!==x[v]&&(a||(a={}),a[v]=x[v])}else a||(f||(f=[]),f.push(U,a)),a=x;else U==="dangerouslySetInnerHTML"?(x=x?x.__html:void 0,R=R?R.__html:void 0,x!=null&&R!==x&&(f=f||[]).push(U,x)):U==="children"?typeof x!="string"&&typeof x!="number"||(f=f||[]).push(U,""+x):U!=="suppressContentEditableWarning"&&U!=="suppressHydrationWarning"&&(o.hasOwnProperty(U)?(x!=null&&U==="onScroll"&&Ye("scroll",n),f||R===x||(f=[])):(f=f||[]).push(U,x))}a&&(f=f||[]).push("style",a);var U=f;(i.updateQueue=U)&&(i.flags|=4)}},Em=function(n,i,a,c){a!==c&&(i.flags|=4)};function wa(n,i){if(!Ze)switch(n.tailMode){case"hidden":i=n.tail;for(var a=null;i!==null;)i.alternate!==null&&(a=i),i=i.sibling;a===null?n.tail=null:a.sibling=null;break;case"collapsed":a=n.tail;for(var c=null;a!==null;)a.alternate!==null&&(c=a),a=a.sibling;c===null?i||n.tail===null?n.tail=null:n.tail.sibling=null:c.sibling=null}}function Lt(n){var i=n.alternate!==null&&n.alternate.child===n.child,a=0,c=0;if(i)for(var d=n.child;d!==null;)a|=d.lanes|d.childLanes,c|=d.subtreeFlags&14680064,c|=d.flags&14680064,d.return=n,d=d.sibling;else for(d=n.child;d!==null;)a|=d.lanes|d.childLanes,c|=d.subtreeFlags,c|=d.flags,d.return=n,d=d.sibling;return n.subtreeFlags|=c,n.childLanes=a,i}function YE(n,i,a){var c=i.pendingProps;switch(nh(i),i.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Lt(i),null;case 1:return Wt(i.type)&&Bl(),Lt(i),null;case 3:return c=i.stateNode,Xs(),Je(Ht),Je(Vt),mh(),c.pendingContext&&(c.context=c.pendingContext,c.pendingContext=null),(n===null||n.child===null)&&(Kl(i)?i.flags|=4:n===null||n.memoizedState.isDehydrated&&(i.flags&256)===0||(i.flags|=1024,Sn!==null&&(Wh(Sn),Sn=null))),Oh(n,i),Lt(i),null;case 5:fh(i);var d=Yi(ga.current);if(a=i.type,n!==null&&i.stateNode!=null)vm(n,i,a,c,d),n.ref!==i.ref&&(i.flags|=512,i.flags|=2097152);else{if(!c){if(i.stateNode===null)throw Error(t(166));return Lt(i),null}if(n=Yi(Qn.current),Kl(i)){c=i.stateNode,a=i.type;var f=i.memoizedProps;switch(c[Gn]=i,c[ha]=f,n=(i.mode&1)!==0,a){case"dialog":Ye("cancel",c),Ye("close",c);break;case"iframe":case"object":case"embed":Ye("load",c);break;case"video":case"audio":for(d=0;d<la.length;d++)Ye(la[d],c);break;case"source":Ye("error",c);break;case"img":case"image":case"link":Ye("error",c),Ye("load",c);break;case"details":Ye("toggle",c);break;case"input":hl(c,f),Ye("invalid",c);break;case"select":c._wrapperState={wasMultiple:!!f.multiple},Ye("invalid",c);break;case"textarea":bo(c,f),Ye("invalid",c)}En(a,f),d=null;for(var v in f)if(f.hasOwnProperty(v)){var R=f[v];v==="children"?typeof R=="string"?c.textContent!==R&&(f.suppressHydrationWarning!==!0&&Ul(c.textContent,R,n),d=["children",R]):typeof R=="number"&&c.textContent!==""+R&&(f.suppressHydrationWarning!==!0&&Ul(c.textContent,R,n),d=["children",""+R]):o.hasOwnProperty(v)&&R!=null&&v==="onScroll"&&Ye("scroll",c)}switch(a){case"input":gs(c),Oo(c,f,!0);break;case"textarea":gs(c),Or(c);break;case"select":case"option":break;default:typeof f.onClick=="function"&&(c.onclick=jl)}c=d,i.updateQueue=c,c!==null&&(i.flags|=4)}else{v=d.nodeType===9?d:d.ownerDocument,n==="http://www.w3.org/1999/xhtml"&&(n=Mo(a)),n==="http://www.w3.org/1999/xhtml"?a==="script"?(n=v.createElement("div"),n.innerHTML="<script><\/script>",n=n.removeChild(n.firstChild)):typeof c.is=="string"?n=v.createElement(a,{is:c.is}):(n=v.createElement(a),a==="select"&&(v=n,c.multiple?v.multiple=!0:c.size&&(v.size=c.size))):n=v.createElementNS(n,a),n[Gn]=i,n[ha]=c,_m(n,i,!1,!1),i.stateNode=n;e:{switch(v=ws(a,c),a){case"dialog":Ye("cancel",n),Ye("close",n),d=c;break;case"iframe":case"object":case"embed":Ye("load",n),d=c;break;case"video":case"audio":for(d=0;d<la.length;d++)Ye(la[d],n);d=c;break;case"source":Ye("error",n),d=c;break;case"img":case"image":case"link":Ye("error",n),Ye("load",n),d=c;break;case"details":Ye("toggle",n),d=c;break;case"input":hl(n,c),d=ys(n,c),Ye("invalid",n);break;case"option":d=c;break;case"select":n._wrapperState={wasMultiple:!!c.multiple},d=ee({},c,{value:void 0}),Ye("invalid",n);break;case"textarea":bo(n,c),d=Lo(n,c),Ye("invalid",n);break;default:d=c}En(a,d),R=d;for(f in R)if(R.hasOwnProperty(f)){var x=R[f];f==="style"?Es(n,x):f==="dangerouslySetInnerHTML"?(x=x?x.__html:void 0,x!=null&&fl(n,x)):f==="children"?typeof x=="string"?(a!=="textarea"||x!=="")&&xi(n,x):typeof x=="number"&&xi(n,""+x):f!=="suppressContentEditableWarning"&&f!=="suppressHydrationWarning"&&f!=="autoFocus"&&(o.hasOwnProperty(f)?x!=null&&f==="onScroll"&&Ye("scroll",n):x!=null&&Ee(n,f,x,v))}switch(a){case"input":gs(n),Oo(n,c,!1);break;case"textarea":gs(n),Or(n);break;case"option":c.value!=null&&n.setAttribute("value",""+Le(c.value));break;case"select":n.multiple=!!c.multiple,f=c.value,f!=null?vn(n,!!c.multiple,f,!1):c.defaultValue!=null&&vn(n,!!c.multiple,c.defaultValue,!0);break;default:typeof d.onClick=="function"&&(n.onclick=jl)}switch(a){case"button":case"input":case"select":case"textarea":c=!!c.autoFocus;break e;case"img":c=!0;break e;default:c=!1}}c&&(i.flags|=4)}i.ref!==null&&(i.flags|=512,i.flags|=2097152)}return Lt(i),null;case 6:if(n&&i.stateNode!=null)Em(n,i,n.memoizedProps,c);else{if(typeof c!="string"&&i.stateNode===null)throw Error(t(166));if(a=Yi(ga.current),Yi(Qn.current),Kl(i)){if(c=i.stateNode,a=i.memoizedProps,c[Gn]=i,(f=c.nodeValue!==a)&&(n=sn,n!==null))switch(n.tag){case 3:Ul(c.nodeValue,a,(n.mode&1)!==0);break;case 5:n.memoizedProps.suppressHydrationWarning!==!0&&Ul(c.nodeValue,a,(n.mode&1)!==0)}f&&(i.flags|=4)}else c=(a.nodeType===9?a:a.ownerDocument).createTextNode(c),c[Gn]=i,i.stateNode=c}return Lt(i),null;case 13:if(Je(et),c=i.memoizedState,n===null||n.memoizedState!==null&&n.memoizedState.dehydrated!==null){if(Ze&&on!==null&&(i.mode&1)!==0&&(i.flags&128)===0)Ip(),Gs(),i.flags|=98560,f=!1;else if(f=Kl(i),c!==null&&c.dehydrated!==null){if(n===null){if(!f)throw Error(t(318));if(f=i.memoizedState,f=f!==null?f.dehydrated:null,!f)throw Error(t(317));f[Gn]=i}else Gs(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;Lt(i),f=!1}else Sn!==null&&(Wh(Sn),Sn=null),f=!0;if(!f)return i.flags&65536?i:null}return(i.flags&128)!==0?(i.lanes=a,i):(c=c!==null,c!==(n!==null&&n.memoizedState!==null)&&c&&(i.child.flags|=8192,(i.mode&1)!==0&&(n===null||(et.current&1)!==0?_t===0&&(_t=3):Gh())),i.updateQueue!==null&&(i.flags|=4),Lt(i),null);case 4:return Xs(),Oh(n,i),n===null&&ua(i.stateNode.containerInfo),Lt(i),null;case 10:return lh(i.type._context),Lt(i),null;case 17:return Wt(i.type)&&Bl(),Lt(i),null;case 19:if(Je(et),f=i.memoizedState,f===null)return Lt(i),null;if(c=(i.flags&128)!==0,v=f.rendering,v===null)if(c)wa(f,!1);else{if(_t!==0||n!==null&&(n.flags&128)!==0)for(n=i.child;n!==null;){if(v=Zl(n),v!==null){for(i.flags|=128,wa(f,!1),c=v.updateQueue,c!==null&&(i.updateQueue=c,i.flags|=4),i.subtreeFlags=0,c=a,a=i.child;a!==null;)f=a,n=c,f.flags&=14680066,v=f.alternate,v===null?(f.childLanes=0,f.lanes=n,f.child=null,f.subtreeFlags=0,f.memoizedProps=null,f.memoizedState=null,f.updateQueue=null,f.dependencies=null,f.stateNode=null):(f.childLanes=v.childLanes,f.lanes=v.lanes,f.child=v.child,f.subtreeFlags=0,f.deletions=null,f.memoizedProps=v.memoizedProps,f.memoizedState=v.memoizedState,f.updateQueue=v.updateQueue,f.type=v.type,n=v.dependencies,f.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),a=a.sibling;return Ke(et,et.current&1|2),i.child}n=n.sibling}f.tail!==null&&Qe()>no&&(i.flags|=128,c=!0,wa(f,!1),i.lanes=4194304)}else{if(!c)if(n=Zl(v),n!==null){if(i.flags|=128,c=!0,a=n.updateQueue,a!==null&&(i.updateQueue=a,i.flags|=4),wa(f,!0),f.tail===null&&f.tailMode==="hidden"&&!v.alternate&&!Ze)return Lt(i),null}else 2*Qe()-f.renderingStartTime>no&&a!==1073741824&&(i.flags|=128,c=!0,wa(f,!1),i.lanes=4194304);f.isBackwards?(v.sibling=i.child,i.child=v):(a=f.last,a!==null?a.sibling=v:i.child=v,f.last=v)}return f.tail!==null?(i=f.tail,f.rendering=i,f.tail=i.sibling,f.renderingStartTime=Qe(),i.sibling=null,a=et.current,Ke(et,c?a&1|2:a&1),i):(Lt(i),null);case 22:case 23:return Kh(),c=i.memoizedState!==null,n!==null&&n.memoizedState!==null!==c&&(i.flags|=8192),c&&(i.mode&1)!==0?(an&1073741824)!==0&&(Lt(i),i.subtreeFlags&6&&(i.flags|=8192)):Lt(i),null;case 24:return null;case 25:return null}throw Error(t(156,i.tag))}function JE(n,i){switch(nh(i),i.tag){case 1:return Wt(i.type)&&Bl(),n=i.flags,n&65536?(i.flags=n&-65537|128,i):null;case 3:return Xs(),Je(Ht),Je(Vt),mh(),n=i.flags,(n&65536)!==0&&(n&128)===0?(i.flags=n&-65537|128,i):null;case 5:return fh(i),null;case 13:if(Je(et),n=i.memoizedState,n!==null&&n.dehydrated!==null){if(i.alternate===null)throw Error(t(340));Gs()}return n=i.flags,n&65536?(i.flags=n&-65537|128,i):null;case 19:return Je(et),null;case 4:return Xs(),null;case 10:return lh(i.type._context),null;case 22:case 23:return Kh(),null;case 24:return null;default:return null}}var lu=!1,bt=!1,XE=typeof WeakSet=="function"?WeakSet:Set,se=null;function eo(n,i){var a=n.ref;if(a!==null)if(typeof a=="function")try{a(null)}catch(c){it(n,i,c)}else a.current=null}function Lh(n,i,a){try{a()}catch(c){it(n,i,c)}}var wm=!1;function ZE(n,i){if(Kc=dr,n=Zf(),Uc(n)){if("selectionStart"in n)var a={start:n.selectionStart,end:n.selectionEnd};else e:{a=(a=n.ownerDocument)&&a.defaultView||window;var c=a.getSelection&&a.getSelection();if(c&&c.rangeCount!==0){a=c.anchorNode;var d=c.anchorOffset,f=c.focusNode;c=c.focusOffset;try{a.nodeType,f.nodeType}catch{a=null;break e}var v=0,R=-1,x=-1,U=0,K=0,Y=n,q=null;t:for(;;){for(var ne;Y!==a||d!==0&&Y.nodeType!==3||(R=v+d),Y!==f||c!==0&&Y.nodeType!==3||(x=v+c),Y.nodeType===3&&(v+=Y.nodeValue.length),(ne=Y.firstChild)!==null;)q=Y,Y=ne;for(;;){if(Y===n)break t;if(q===a&&++U===d&&(R=v),q===f&&++K===c&&(x=v),(ne=Y.nextSibling)!==null)break;Y=q,q=Y.parentNode}Y=ne}a=R===-1||x===-1?null:{start:R,end:x}}else a=null}a=a||{start:0,end:0}}else a=null;for(Gc={focusedElem:n,selectionRange:a},dr=!1,se=i;se!==null;)if(i=se,n=i.child,(i.subtreeFlags&1028)!==0&&n!==null)n.return=i,se=n;else for(;se!==null;){i=se;try{var oe=i.alternate;if((i.flags&1024)!==0)switch(i.tag){case 0:case 11:case 15:break;case 1:if(oe!==null){var le=oe.memoizedProps,at=oe.memoizedState,b=i.stateNode,O=b.getSnapshotBeforeUpdate(i.elementType===i.type?le:An(i.type,le),at);b.__reactInternalSnapshotBeforeUpdate=O}break;case 3:var F=i.stateNode.containerInfo;F.nodeType===1?F.textContent="":F.nodeType===9&&F.documentElement&&F.removeChild(F.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(t(163))}}catch(J){it(i,i.return,J)}if(n=i.sibling,n!==null){n.return=i.return,se=n;break}se=i.return}return oe=wm,wm=!1,oe}function Ta(n,i,a){var c=i.updateQueue;if(c=c!==null?c.lastEffect:null,c!==null){var d=c=c.next;do{if((d.tag&n)===n){var f=d.destroy;d.destroy=void 0,f!==void 0&&Lh(i,a,f)}d=d.next}while(d!==c)}}function uu(n,i){if(i=i.updateQueue,i=i!==null?i.lastEffect:null,i!==null){var a=i=i.next;do{if((a.tag&n)===n){var c=a.create;a.destroy=c()}a=a.next}while(a!==i)}}function bh(n){var i=n.ref;if(i!==null){var a=n.stateNode;switch(n.tag){case 5:n=a;break;default:n=a}typeof i=="function"?i(n):i.current=n}}function Tm(n){var i=n.alternate;i!==null&&(n.alternate=null,Tm(i)),n.child=null,n.deletions=null,n.sibling=null,n.tag===5&&(i=n.stateNode,i!==null&&(delete i[Gn],delete i[ha],delete i[Xc],delete i[LE],delete i[bE])),n.stateNode=null,n.return=null,n.dependencies=null,n.memoizedProps=null,n.memoizedState=null,n.pendingProps=null,n.stateNode=null,n.updateQueue=null}function Im(n){return n.tag===5||n.tag===3||n.tag===4}function Sm(n){e:for(;;){for(;n.sibling===null;){if(n.return===null||Im(n.return))return null;n=n.return}for(n.sibling.return=n.return,n=n.sibling;n.tag!==5&&n.tag!==6&&n.tag!==18;){if(n.flags&2||n.child===null||n.tag===4)continue e;n.child.return=n,n=n.child}if(!(n.flags&2))return n.stateNode}}function Mh(n,i,a){var c=n.tag;if(c===5||c===6)n=n.stateNode,i?a.nodeType===8?a.parentNode.insertBefore(n,i):a.insertBefore(n,i):(a.nodeType===8?(i=a.parentNode,i.insertBefore(n,a)):(i=a,i.appendChild(n)),a=a._reactRootContainer,a!=null||i.onclick!==null||(i.onclick=jl));else if(c!==4&&(n=n.child,n!==null))for(Mh(n,i,a),n=n.sibling;n!==null;)Mh(n,i,a),n=n.sibling}function Fh(n,i,a){var c=n.tag;if(c===5||c===6)n=n.stateNode,i?a.insertBefore(n,i):a.appendChild(n);else if(c!==4&&(n=n.child,n!==null))for(Fh(n,i,a),n=n.sibling;n!==null;)Fh(n,i,a),n=n.sibling}var Ct=null,Rn=!1;function ni(n,i,a){for(a=a.child;a!==null;)Am(n,i,a),a=a.sibling}function Am(n,i,a){if(Xt&&typeof Xt.onCommitFiberUnmount=="function")try{Xt.onCommitFiberUnmount(bi,a)}catch{}switch(a.tag){case 5:bt||eo(a,i);case 6:var c=Ct,d=Rn;Ct=null,ni(n,i,a),Ct=c,Rn=d,Ct!==null&&(Rn?(n=Ct,a=a.stateNode,n.nodeType===8?n.parentNode.removeChild(a):n.removeChild(a)):Ct.removeChild(a.stateNode));break;case 18:Ct!==null&&(Rn?(n=Ct,a=a.stateNode,n.nodeType===8?Jc(n.parentNode,a):n.nodeType===1&&Jc(n,a),qr(n)):Jc(Ct,a.stateNode));break;case 4:c=Ct,d=Rn,Ct=a.stateNode.containerInfo,Rn=!0,ni(n,i,a),Ct=c,Rn=d;break;case 0:case 11:case 14:case 15:if(!bt&&(c=a.updateQueue,c!==null&&(c=c.lastEffect,c!==null))){d=c=c.next;do{var f=d,v=f.destroy;f=f.tag,v!==void 0&&((f&2)!==0||(f&4)!==0)&&Lh(a,i,v),d=d.next}while(d!==c)}ni(n,i,a);break;case 1:if(!bt&&(eo(a,i),c=a.stateNode,typeof c.componentWillUnmount=="function"))try{c.props=a.memoizedProps,c.state=a.memoizedState,c.componentWillUnmount()}catch(R){it(a,i,R)}ni(n,i,a);break;case 21:ni(n,i,a);break;case 22:a.mode&1?(bt=(c=bt)||a.memoizedState!==null,ni(n,i,a),bt=c):ni(n,i,a);break;default:ni(n,i,a)}}function Rm(n){var i=n.updateQueue;if(i!==null){n.updateQueue=null;var a=n.stateNode;a===null&&(a=n.stateNode=new XE),i.forEach(function(c){var d=lw.bind(null,n,c);a.has(c)||(a.add(c),c.then(d,d))})}}function Cn(n,i){var a=i.deletions;if(a!==null)for(var c=0;c<a.length;c++){var d=a[c];try{var f=n,v=i,R=v;e:for(;R!==null;){switch(R.tag){case 5:Ct=R.stateNode,Rn=!1;break e;case 3:Ct=R.stateNode.containerInfo,Rn=!0;break e;case 4:Ct=R.stateNode.containerInfo,Rn=!0;break e}R=R.return}if(Ct===null)throw Error(t(160));Am(f,v,d),Ct=null,Rn=!1;var x=d.alternate;x!==null&&(x.return=null),d.return=null}catch(U){it(d,i,U)}}if(i.subtreeFlags&12854)for(i=i.child;i!==null;)Cm(i,n),i=i.sibling}function Cm(n,i){var a=n.alternate,c=n.flags;switch(n.tag){case 0:case 11:case 14:case 15:if(Cn(i,n),Jn(n),c&4){try{Ta(3,n,n.return),uu(3,n)}catch(le){it(n,n.return,le)}try{Ta(5,n,n.return)}catch(le){it(n,n.return,le)}}break;case 1:Cn(i,n),Jn(n),c&512&&a!==null&&eo(a,a.return);break;case 5:if(Cn(i,n),Jn(n),c&512&&a!==null&&eo(a,a.return),n.flags&32){var d=n.stateNode;try{xi(d,"")}catch(le){it(n,n.return,le)}}if(c&4&&(d=n.stateNode,d!=null)){var f=n.memoizedProps,v=a!==null?a.memoizedProps:f,R=n.type,x=n.updateQueue;if(n.updateQueue=null,x!==null)try{R==="input"&&f.type==="radio"&&f.name!=null&&_s(d,f),ws(R,v);var U=ws(R,f);for(v=0;v<x.length;v+=2){var K=x[v],Y=x[v+1];K==="style"?Es(d,Y):K==="dangerouslySetInnerHTML"?fl(d,Y):K==="children"?xi(d,Y):Ee(d,K,Y,U)}switch(R){case"input":Ni(d,f);break;case"textarea":dl(d,f);break;case"select":var q=d._wrapperState.wasMultiple;d._wrapperState.wasMultiple=!!f.multiple;var ne=f.value;ne!=null?vn(d,!!f.multiple,ne,!1):q!==!!f.multiple&&(f.defaultValue!=null?vn(d,!!f.multiple,f.defaultValue,!0):vn(d,!!f.multiple,f.multiple?[]:"",!1))}d[ha]=f}catch(le){it(n,n.return,le)}}break;case 6:if(Cn(i,n),Jn(n),c&4){if(n.stateNode===null)throw Error(t(162));d=n.stateNode,f=n.memoizedProps;try{d.nodeValue=f}catch(le){it(n,n.return,le)}}break;case 3:if(Cn(i,n),Jn(n),c&4&&a!==null&&a.memoizedState.isDehydrated)try{qr(i.containerInfo)}catch(le){it(n,n.return,le)}break;case 4:Cn(i,n),Jn(n);break;case 13:Cn(i,n),Jn(n),d=n.child,d.flags&8192&&(f=d.memoizedState!==null,d.stateNode.isHidden=f,!f||d.alternate!==null&&d.alternate.memoizedState!==null||(zh=Qe())),c&4&&Rm(n);break;case 22:if(K=a!==null&&a.memoizedState!==null,n.mode&1?(bt=(U=bt)||K,Cn(i,n),bt=U):Cn(i,n),Jn(n),c&8192){if(U=n.memoizedState!==null,(n.stateNode.isHidden=U)&&!K&&(n.mode&1)!==0)for(se=n,K=n.child;K!==null;){for(Y=se=K;se!==null;){switch(q=se,ne=q.child,q.tag){case 0:case 11:case 14:case 15:Ta(4,q,q.return);break;case 1:eo(q,q.return);var oe=q.stateNode;if(typeof oe.componentWillUnmount=="function"){c=q,a=q.return;try{i=c,oe.props=i.memoizedProps,oe.state=i.memoizedState,oe.componentWillUnmount()}catch(le){it(c,a,le)}}break;case 5:eo(q,q.return);break;case 22:if(q.memoizedState!==null){Nm(Y);continue}}ne!==null?(ne.return=q,se=ne):Nm(Y)}K=K.sibling}e:for(K=null,Y=n;;){if(Y.tag===5){if(K===null){K=Y;try{d=Y.stateNode,U?(f=d.style,typeof f.setProperty=="function"?f.setProperty("display","none","important"):f.display="none"):(R=Y.stateNode,x=Y.memoizedProps.style,v=x!=null&&x.hasOwnProperty("display")?x.display:null,R.style.display=Mr("display",v))}catch(le){it(n,n.return,le)}}}else if(Y.tag===6){if(K===null)try{Y.stateNode.nodeValue=U?"":Y.memoizedProps}catch(le){it(n,n.return,le)}}else if((Y.tag!==22&&Y.tag!==23||Y.memoizedState===null||Y===n)&&Y.child!==null){Y.child.return=Y,Y=Y.child;continue}if(Y===n)break e;for(;Y.sibling===null;){if(Y.return===null||Y.return===n)break e;K===Y&&(K=null),Y=Y.return}K===Y&&(K=null),Y.sibling.return=Y.return,Y=Y.sibling}}break;case 19:Cn(i,n),Jn(n),c&4&&Rm(n);break;case 21:break;default:Cn(i,n),Jn(n)}}function Jn(n){var i=n.flags;if(i&2){try{e:{for(var a=n.return;a!==null;){if(Im(a)){var c=a;break e}a=a.return}throw Error(t(160))}switch(c.tag){case 5:var d=c.stateNode;c.flags&32&&(xi(d,""),c.flags&=-33);var f=Sm(n);Fh(n,f,d);break;case 3:case 4:var v=c.stateNode.containerInfo,R=Sm(n);Mh(n,R,v);break;default:throw Error(t(161))}}catch(x){it(n,n.return,x)}n.flags&=-3}i&4096&&(n.flags&=-4097)}function ew(n,i,a){se=n,Pm(n)}function Pm(n,i,a){for(var c=(n.mode&1)!==0;se!==null;){var d=se,f=d.child;if(d.tag===22&&c){var v=d.memoizedState!==null||lu;if(!v){var R=d.alternate,x=R!==null&&R.memoizedState!==null||bt;R=lu;var U=bt;if(lu=v,(bt=x)&&!U)for(se=d;se!==null;)v=se,x=v.child,v.tag===22&&v.memoizedState!==null?xm(d):x!==null?(x.return=v,se=x):xm(d);for(;f!==null;)se=f,Pm(f),f=f.sibling;se=d,lu=R,bt=U}km(n)}else(d.subtreeFlags&8772)!==0&&f!==null?(f.return=d,se=f):km(n)}}function km(n){for(;se!==null;){var i=se;if((i.flags&8772)!==0){var a=i.alternate;try{if((i.flags&8772)!==0)switch(i.tag){case 0:case 11:case 15:bt||uu(5,i);break;case 1:var c=i.stateNode;if(i.flags&4&&!bt)if(a===null)c.componentDidMount();else{var d=i.elementType===i.type?a.memoizedProps:An(i.type,a.memoizedProps);c.componentDidUpdate(d,a.memoizedState,c.__reactInternalSnapshotBeforeUpdate)}var f=i.updateQueue;f!==null&&Np(i,f,c);break;case 3:var v=i.updateQueue;if(v!==null){if(a=null,i.child!==null)switch(i.child.tag){case 5:a=i.child.stateNode;break;case 1:a=i.child.stateNode}Np(i,v,a)}break;case 5:var R=i.stateNode;if(a===null&&i.flags&4){a=R;var x=i.memoizedProps;switch(i.type){case"button":case"input":case"select":case"textarea":x.autoFocus&&a.focus();break;case"img":x.src&&(a.src=x.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(i.memoizedState===null){var U=i.alternate;if(U!==null){var K=U.memoizedState;if(K!==null){var Y=K.dehydrated;Y!==null&&qr(Y)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(t(163))}bt||i.flags&512&&bh(i)}catch(q){it(i,i.return,q)}}if(i===n){se=null;break}if(a=i.sibling,a!==null){a.return=i.return,se=a;break}se=i.return}}function Nm(n){for(;se!==null;){var i=se;if(i===n){se=null;break}var a=i.sibling;if(a!==null){a.return=i.return,se=a;break}se=i.return}}function xm(n){for(;se!==null;){var i=se;try{switch(i.tag){case 0:case 11:case 15:var a=i.return;try{uu(4,i)}catch(x){it(i,a,x)}break;case 1:var c=i.stateNode;if(typeof c.componentDidMount=="function"){var d=i.return;try{c.componentDidMount()}catch(x){it(i,d,x)}}var f=i.return;try{bh(i)}catch(x){it(i,f,x)}break;case 5:var v=i.return;try{bh(i)}catch(x){it(i,v,x)}}}catch(x){it(i,i.return,x)}if(i===n){se=null;break}var R=i.sibling;if(R!==null){R.return=i.return,se=R;break}se=i.return}}var tw=Math.ceil,cu=Ae.ReactCurrentDispatcher,Uh=Ae.ReactCurrentOwner,mn=Ae.ReactCurrentBatchConfig,be=0,Tt=null,dt=null,Pt=0,an=0,to=Jr(0),_t=0,Ia=null,Xi=0,hu=0,jh=0,Sa=null,Kt=null,zh=0,no=1/0,Tr=null,du=!1,Bh=null,ri=null,fu=!1,ii=null,pu=0,Aa=0,$h=null,mu=-1,gu=0;function $t(){return(be&6)!==0?Qe():mu!==-1?mu:mu=Qe()}function si(n){return(n.mode&1)===0?1:(be&2)!==0&&Pt!==0?Pt&-Pt:FE.transition!==null?(gu===0&&(gu=qo()),gu):(n=Ve,n!==0||(n=window.event,n=n===void 0?16:xs(n.type)),n)}function Pn(n,i,a,c){if(50<Aa)throw Aa=0,$h=null,Error(t(185));ji(n,a,c),((be&2)===0||n!==Tt)&&(n===Tt&&((be&2)===0&&(hu|=a),_t===4&&oi(n,Pt)),Gt(n,c),a===1&&be===0&&(i.mode&1)===0&&(no=Qe()+500,Hl&&Zr()))}function Gt(n,i){var a=n.callbackNode;Ui(n,i);var c=ur(n,n===Tt?Pt:0);if(c===0)a!==null&&Ss(a),n.callbackNode=null,n.callbackPriority=0;else if(i=c&-c,n.callbackPriority!==i){if(a!=null&&Ss(a),i===1)n.tag===0?ME(Vm.bind(null,n)):_p(Vm.bind(null,n)),VE(function(){(be&6)===0&&Zr()}),a=null;else{switch(Fn(c)){case 1:a=As;break;case 4:a=$o;break;case 16:a=Li;break;case 536870912:a=Rs;break;default:a=Li}a=zm(a,Dm.bind(null,n))}n.callbackPriority=i,n.callbackNode=a}}function Dm(n,i){if(mu=-1,gu=0,(be&6)!==0)throw Error(t(327));var a=n.callbackNode;if(ro()&&n.callbackNode!==a)return null;var c=ur(n,n===Tt?Pt:0);if(c===0)return null;if((c&30)!==0||(c&n.expiredLanes)!==0||i)i=yu(n,c);else{i=c;var d=be;be|=2;var f=Lm();(Tt!==n||Pt!==i)&&(Tr=null,no=Qe()+500,es(n,i));do try{iw();break}catch(R){Om(n,R)}while(!0);ah(),cu.current=f,be=d,dt!==null?i=0:(Tt=null,Pt=0,i=_t)}if(i!==0){if(i===2&&(d=Wo(n),d!==0&&(c=d,i=Hh(n,d))),i===1)throw a=Ia,es(n,0),oi(n,c),Gt(n,Qe()),a;if(i===6)oi(n,c);else{if(d=n.current.alternate,(c&30)===0&&!nw(d)&&(i=yu(n,c),i===2&&(f=Wo(n),f!==0&&(c=f,i=Hh(n,f))),i===1))throw a=Ia,es(n,0),oi(n,c),Gt(n,Qe()),a;switch(n.finishedWork=d,n.finishedLanes=c,i){case 0:case 1:throw Error(t(345));case 2:ts(n,Kt,Tr);break;case 3:if(oi(n,c),(c&130023424)===c&&(i=zh+500-Qe(),10<i)){if(ur(n,0)!==0)break;if(d=n.suspendedLanes,(d&c)!==c){$t(),n.pingedLanes|=n.suspendedLanes&d;break}n.timeoutHandle=Yc(ts.bind(null,n,Kt,Tr),i);break}ts(n,Kt,Tr);break;case 4:if(oi(n,c),(c&4194240)===c)break;for(i=n.eventTimes,d=-1;0<c;){var v=31-Zt(c);f=1<<v,v=i[v],v>d&&(d=v),c&=~f}if(c=d,c=Qe()-c,c=(120>c?120:480>c?480:1080>c?1080:1920>c?1920:3e3>c?3e3:4320>c?4320:1960*tw(c/1960))-c,10<c){n.timeoutHandle=Yc(ts.bind(null,n,Kt,Tr),c);break}ts(n,Kt,Tr);break;case 5:ts(n,Kt,Tr);break;default:throw Error(t(329))}}}return Gt(n,Qe()),n.callbackNode===a?Dm.bind(null,n):null}function Hh(n,i){var a=Sa;return n.current.memoizedState.isDehydrated&&(es(n,i).flags|=256),n=yu(n,i),n!==2&&(i=Kt,Kt=a,i!==null&&Wh(i)),n}function Wh(n){Kt===null?Kt=n:Kt.push.apply(Kt,n)}function nw(n){for(var i=n;;){if(i.flags&16384){var a=i.updateQueue;if(a!==null&&(a=a.stores,a!==null))for(var c=0;c<a.length;c++){var d=a[c],f=d.getSnapshot;d=d.value;try{if(!In(f(),d))return!1}catch{return!1}}}if(a=i.child,i.subtreeFlags&16384&&a!==null)a.return=i,i=a;else{if(i===n)break;for(;i.sibling===null;){if(i.return===null||i.return===n)return!0;i=i.return}i.sibling.return=i.return,i=i.sibling}}return!0}function oi(n,i){for(i&=~jh,i&=~hu,n.suspendedLanes|=i,n.pingedLanes&=~i,n=n.expirationTimes;0<i;){var a=31-Zt(i),c=1<<a;n[a]=-1,i&=~c}}function Vm(n){if((be&6)!==0)throw Error(t(327));ro();var i=ur(n,0);if((i&1)===0)return Gt(n,Qe()),null;var a=yu(n,i);if(n.tag!==0&&a===2){var c=Wo(n);c!==0&&(i=c,a=Hh(n,c))}if(a===1)throw a=Ia,es(n,0),oi(n,i),Gt(n,Qe()),a;if(a===6)throw Error(t(345));return n.finishedWork=n.current.alternate,n.finishedLanes=i,ts(n,Kt,Tr),Gt(n,Qe()),null}function qh(n,i){var a=be;be|=1;try{return n(i)}finally{be=a,be===0&&(no=Qe()+500,Hl&&Zr())}}function Zi(n){ii!==null&&ii.tag===0&&(be&6)===0&&ro();var i=be;be|=1;var a=mn.transition,c=Ve;try{if(mn.transition=null,Ve=1,n)return n()}finally{Ve=c,mn.transition=a,be=i,(be&6)===0&&Zr()}}function Kh(){an=to.current,Je(to)}function es(n,i){n.finishedWork=null,n.finishedLanes=0;var a=n.timeoutHandle;if(a!==-1&&(n.timeoutHandle=-1,DE(a)),dt!==null)for(a=dt.return;a!==null;){var c=a;switch(nh(c),c.tag){case 1:c=c.type.childContextTypes,c!=null&&Bl();break;case 3:Xs(),Je(Ht),Je(Vt),mh();break;case 5:fh(c);break;case 4:Xs();break;case 13:Je(et);break;case 19:Je(et);break;case 10:lh(c.type._context);break;case 22:case 23:Kh()}a=a.return}if(Tt=n,dt=n=ai(n.current,null),Pt=an=i,_t=0,Ia=null,jh=hu=Xi=0,Kt=Sa=null,Qi!==null){for(i=0;i<Qi.length;i++)if(a=Qi[i],c=a.interleaved,c!==null){a.interleaved=null;var d=c.next,f=a.pending;if(f!==null){var v=f.next;f.next=d,c.next=v}a.pending=c}Qi=null}return n}function Om(n,i){do{var a=dt;try{if(ah(),eu.current=iu,tu){for(var c=tt.memoizedState;c!==null;){var d=c.queue;d!==null&&(d.pending=null),c=c.next}tu=!1}if(Ji=0,wt=yt=tt=null,ya=!1,_a=0,Uh.current=null,a===null||a.return===null){_t=1,Ia=i,dt=null;break}e:{var f=n,v=a.return,R=a,x=i;if(i=Pt,R.flags|=32768,x!==null&&typeof x=="object"&&typeof x.then=="function"){var U=x,K=R,Y=K.tag;if((K.mode&1)===0&&(Y===0||Y===11||Y===15)){var q=K.alternate;q?(K.updateQueue=q.updateQueue,K.memoizedState=q.memoizedState,K.lanes=q.lanes):(K.updateQueue=null,K.memoizedState=null)}var ne=sm(v);if(ne!==null){ne.flags&=-257,om(ne,v,R,f,i),ne.mode&1&&im(f,U,i),i=ne,x=U;var oe=i.updateQueue;if(oe===null){var le=new Set;le.add(x),i.updateQueue=le}else oe.add(x);break e}else{if((i&1)===0){im(f,U,i),Gh();break e}x=Error(t(426))}}else if(Ze&&R.mode&1){var at=sm(v);if(at!==null){(at.flags&65536)===0&&(at.flags|=256),om(at,v,R,f,i),sh(Zs(x,R));break e}}f=x=Zs(x,R),_t!==4&&(_t=2),Sa===null?Sa=[f]:Sa.push(f),f=v;do{switch(f.tag){case 3:f.flags|=65536,i&=-i,f.lanes|=i;var b=nm(f,x,i);kp(f,b);break e;case 1:R=x;var O=f.type,F=f.stateNode;if((f.flags&128)===0&&(typeof O.getDerivedStateFromError=="function"||F!==null&&typeof F.componentDidCatch=="function"&&(ri===null||!ri.has(F)))){f.flags|=65536,i&=-i,f.lanes|=i;var J=rm(f,R,i);kp(f,J);break e}}f=f.return}while(f!==null)}Mm(a)}catch(ue){i=ue,dt===a&&a!==null&&(dt=a=a.return);continue}break}while(!0)}function Lm(){var n=cu.current;return cu.current=iu,n===null?iu:n}function Gh(){(_t===0||_t===3||_t===2)&&(_t=4),Tt===null||(Xi&268435455)===0&&(hu&268435455)===0||oi(Tt,Pt)}function yu(n,i){var a=be;be|=2;var c=Lm();(Tt!==n||Pt!==i)&&(Tr=null,es(n,i));do try{rw();break}catch(d){Om(n,d)}while(!0);if(ah(),be=a,cu.current=c,dt!==null)throw Error(t(261));return Tt=null,Pt=0,_t}function rw(){for(;dt!==null;)bm(dt)}function iw(){for(;dt!==null&&!Oi();)bm(dt)}function bm(n){var i=jm(n.alternate,n,an);n.memoizedProps=n.pendingProps,i===null?Mm(n):dt=i,Uh.current=null}function Mm(n){var i=n;do{var a=i.alternate;if(n=i.return,(i.flags&32768)===0){if(a=YE(a,i,an),a!==null){dt=a;return}}else{if(a=JE(a,i),a!==null){a.flags&=32767,dt=a;return}if(n!==null)n.flags|=32768,n.subtreeFlags=0,n.deletions=null;else{_t=6,dt=null;return}}if(i=i.sibling,i!==null){dt=i;return}dt=i=n}while(i!==null);_t===0&&(_t=5)}function ts(n,i,a){var c=Ve,d=mn.transition;try{mn.transition=null,Ve=1,sw(n,i,a,c)}finally{mn.transition=d,Ve=c}return null}function sw(n,i,a,c){do ro();while(ii!==null);if((be&6)!==0)throw Error(t(327));a=n.finishedWork;var d=n.finishedLanes;if(a===null)return null;if(n.finishedWork=null,n.finishedLanes=0,a===n.current)throw Error(t(177));n.callbackNode=null,n.callbackPriority=0;var f=a.lanes|a.childLanes;if(Oc(n,f),n===Tt&&(dt=Tt=null,Pt=0),(a.subtreeFlags&2064)===0&&(a.flags&2064)===0||fu||(fu=!0,zm(Li,function(){return ro(),null})),f=(a.flags&15990)!==0,(a.subtreeFlags&15990)!==0||f){f=mn.transition,mn.transition=null;var v=Ve;Ve=1;var R=be;be|=4,Uh.current=null,ZE(n,a),Cm(a,n),AE(Gc),dr=!!Kc,Gc=Kc=null,n.current=a,ew(a),lr(),be=R,Ve=v,mn.transition=f}else n.current=a;if(fu&&(fu=!1,ii=n,pu=d),f=n.pendingLanes,f===0&&(ri=null),Sl(a.stateNode),Gt(n,Qe()),i!==null)for(c=n.onRecoverableError,a=0;a<i.length;a++)d=i[a],c(d.value,{componentStack:d.stack,digest:d.digest});if(du)throw du=!1,n=Bh,Bh=null,n;return(pu&1)!==0&&n.tag!==0&&ro(),f=n.pendingLanes,(f&1)!==0?n===$h?Aa++:(Aa=0,$h=n):Aa=0,Zr(),null}function ro(){if(ii!==null){var n=Fn(pu),i=mn.transition,a=Ve;try{if(mn.transition=null,Ve=16>n?16:n,ii===null)var c=!1;else{if(n=ii,ii=null,pu=0,(be&6)!==0)throw Error(t(331));var d=be;for(be|=4,se=n.current;se!==null;){var f=se,v=f.child;if((se.flags&16)!==0){var R=f.deletions;if(R!==null){for(var x=0;x<R.length;x++){var U=R[x];for(se=U;se!==null;){var K=se;switch(K.tag){case 0:case 11:case 15:Ta(8,K,f)}var Y=K.child;if(Y!==null)Y.return=K,se=Y;else for(;se!==null;){K=se;var q=K.sibling,ne=K.return;if(Tm(K),K===U){se=null;break}if(q!==null){q.return=ne,se=q;break}se=ne}}}var oe=f.alternate;if(oe!==null){var le=oe.child;if(le!==null){oe.child=null;do{var at=le.sibling;le.sibling=null,le=at}while(le!==null)}}se=f}}if((f.subtreeFlags&2064)!==0&&v!==null)v.return=f,se=v;else e:for(;se!==null;){if(f=se,(f.flags&2048)!==0)switch(f.tag){case 0:case 11:case 15:Ta(9,f,f.return)}var b=f.sibling;if(b!==null){b.return=f.return,se=b;break e}se=f.return}}var O=n.current;for(se=O;se!==null;){v=se;var F=v.child;if((v.subtreeFlags&2064)!==0&&F!==null)F.return=v,se=F;else e:for(v=O;se!==null;){if(R=se,(R.flags&2048)!==0)try{switch(R.tag){case 0:case 11:case 15:uu(9,R)}}catch(ue){it(R,R.return,ue)}if(R===v){se=null;break e}var J=R.sibling;if(J!==null){J.return=R.return,se=J;break e}se=R.return}}if(be=d,Zr(),Xt&&typeof Xt.onPostCommitFiberRoot=="function")try{Xt.onPostCommitFiberRoot(bi,n)}catch{}c=!0}return c}finally{Ve=a,mn.transition=i}}return!1}function Fm(n,i,a){i=Zs(a,i),i=nm(n,i,1),n=ti(n,i,1),i=$t(),n!==null&&(ji(n,1,i),Gt(n,i))}function it(n,i,a){if(n.tag===3)Fm(n,n,a);else for(;i!==null;){if(i.tag===3){Fm(i,n,a);break}else if(i.tag===1){var c=i.stateNode;if(typeof i.type.getDerivedStateFromError=="function"||typeof c.componentDidCatch=="function"&&(ri===null||!ri.has(c))){n=Zs(a,n),n=rm(i,n,1),i=ti(i,n,1),n=$t(),i!==null&&(ji(i,1,n),Gt(i,n));break}}i=i.return}}function ow(n,i,a){var c=n.pingCache;c!==null&&c.delete(i),i=$t(),n.pingedLanes|=n.suspendedLanes&a,Tt===n&&(Pt&a)===a&&(_t===4||_t===3&&(Pt&130023424)===Pt&&500>Qe()-zh?es(n,0):jh|=a),Gt(n,i)}function Um(n,i){i===0&&((n.mode&1)===0?i=1:(i=$r,$r<<=1,($r&130023424)===0&&($r=4194304)));var a=$t();n=vr(n,i),n!==null&&(ji(n,i,a),Gt(n,a))}function aw(n){var i=n.memoizedState,a=0;i!==null&&(a=i.retryLane),Um(n,a)}function lw(n,i){var a=0;switch(n.tag){case 13:var c=n.stateNode,d=n.memoizedState;d!==null&&(a=d.retryLane);break;case 19:c=n.stateNode;break;default:throw Error(t(314))}c!==null&&c.delete(i),Um(n,a)}var jm;jm=function(n,i,a){if(n!==null)if(n.memoizedProps!==i.pendingProps||Ht.current)qt=!0;else{if((n.lanes&a)===0&&(i.flags&128)===0)return qt=!1,QE(n,i,a);qt=(n.flags&131072)!==0}else qt=!1,Ze&&(i.flags&1048576)!==0&&vp(i,ql,i.index);switch(i.lanes=0,i.tag){case 2:var c=i.type;au(n,i),n=i.pendingProps;var d=Ws(i,Vt.current);Js(i,a),d=_h(null,i,c,n,d,a);var f=vh();return i.flags|=1,typeof d=="object"&&d!==null&&typeof d.render=="function"&&d.$$typeof===void 0?(i.tag=1,i.memoizedState=null,i.updateQueue=null,Wt(c)?(f=!0,$l(i)):f=!1,i.memoizedState=d.state!==null&&d.state!==void 0?d.state:null,hh(i),d.updater=su,i.stateNode=d,d._reactInternals=i,Ah(i,c,n,a),i=kh(null,i,c,!0,f,a)):(i.tag=0,Ze&&f&&th(i),Bt(null,i,d,a),i=i.child),i;case 16:c=i.elementType;e:{switch(au(n,i),n=i.pendingProps,d=c._init,c=d(c._payload),i.type=c,d=i.tag=cw(c),n=An(c,n),d){case 0:i=Ph(null,i,c,n,a);break e;case 1:i=dm(null,i,c,n,a);break e;case 11:i=am(null,i,c,n,a);break e;case 14:i=lm(null,i,c,An(c.type,n),a);break e}throw Error(t(306,c,""))}return i;case 0:return c=i.type,d=i.pendingProps,d=i.elementType===c?d:An(c,d),Ph(n,i,c,d,a);case 1:return c=i.type,d=i.pendingProps,d=i.elementType===c?d:An(c,d),dm(n,i,c,d,a);case 3:e:{if(fm(i),n===null)throw Error(t(387));c=i.pendingProps,f=i.memoizedState,d=f.element,Pp(n,i),Xl(i,c,null,a);var v=i.memoizedState;if(c=v.element,f.isDehydrated)if(f={element:c,isDehydrated:!1,cache:v.cache,pendingSuspenseBoundaries:v.pendingSuspenseBoundaries,transitions:v.transitions},i.updateQueue.baseState=f,i.memoizedState=f,i.flags&256){d=Zs(Error(t(423)),i),i=pm(n,i,c,a,d);break e}else if(c!==d){d=Zs(Error(t(424)),i),i=pm(n,i,c,a,d);break e}else for(on=Yr(i.stateNode.containerInfo.firstChild),sn=i,Ze=!0,Sn=null,a=Rp(i,null,c,a),i.child=a;a;)a.flags=a.flags&-3|4096,a=a.sibling;else{if(Gs(),c===d){i=wr(n,i,a);break e}Bt(n,i,c,a)}i=i.child}return i;case 5:return xp(i),n===null&&ih(i),c=i.type,d=i.pendingProps,f=n!==null?n.memoizedProps:null,v=d.children,Qc(c,d)?v=null:f!==null&&Qc(c,f)&&(i.flags|=32),hm(n,i),Bt(n,i,v,a),i.child;case 6:return n===null&&ih(i),null;case 13:return mm(n,i,a);case 4:return dh(i,i.stateNode.containerInfo),c=i.pendingProps,n===null?i.child=Qs(i,null,c,a):Bt(n,i,c,a),i.child;case 11:return c=i.type,d=i.pendingProps,d=i.elementType===c?d:An(c,d),am(n,i,c,d,a);case 7:return Bt(n,i,i.pendingProps,a),i.child;case 8:return Bt(n,i,i.pendingProps.children,a),i.child;case 12:return Bt(n,i,i.pendingProps.children,a),i.child;case 10:e:{if(c=i.type._context,d=i.pendingProps,f=i.memoizedProps,v=d.value,Ke(Ql,c._currentValue),c._currentValue=v,f!==null)if(In(f.value,v)){if(f.children===d.children&&!Ht.current){i=wr(n,i,a);break e}}else for(f=i.child,f!==null&&(f.return=i);f!==null;){var R=f.dependencies;if(R!==null){v=f.child;for(var x=R.firstContext;x!==null;){if(x.context===c){if(f.tag===1){x=Er(-1,a&-a),x.tag=2;var U=f.updateQueue;if(U!==null){U=U.shared;var K=U.pending;K===null?x.next=x:(x.next=K.next,K.next=x),U.pending=x}}f.lanes|=a,x=f.alternate,x!==null&&(x.lanes|=a),uh(f.return,a,i),R.lanes|=a;break}x=x.next}}else if(f.tag===10)v=f.type===i.type?null:f.child;else if(f.tag===18){if(v=f.return,v===null)throw Error(t(341));v.lanes|=a,R=v.alternate,R!==null&&(R.lanes|=a),uh(v,a,i),v=f.sibling}else v=f.child;if(v!==null)v.return=f;else for(v=f;v!==null;){if(v===i){v=null;break}if(f=v.sibling,f!==null){f.return=v.return,v=f;break}v=v.return}f=v}Bt(n,i,d.children,a),i=i.child}return i;case 9:return d=i.type,c=i.pendingProps.children,Js(i,a),d=fn(d),c=c(d),i.flags|=1,Bt(n,i,c,a),i.child;case 14:return c=i.type,d=An(c,i.pendingProps),d=An(c.type,d),lm(n,i,c,d,a);case 15:return um(n,i,i.type,i.pendingProps,a);case 17:return c=i.type,d=i.pendingProps,d=i.elementType===c?d:An(c,d),au(n,i),i.tag=1,Wt(c)?(n=!0,$l(i)):n=!1,Js(i,a),em(i,c,d),Ah(i,c,d,a),kh(null,i,c,!0,n,a);case 19:return ym(n,i,a);case 22:return cm(n,i,a)}throw Error(t(156,i.tag))};function zm(n,i){return Bo(n,i)}function uw(n,i,a,c){this.tag=n,this.key=a,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=i,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=c,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function gn(n,i,a,c){return new uw(n,i,a,c)}function Qh(n){return n=n.prototype,!(!n||!n.isReactComponent)}function cw(n){if(typeof n=="function")return Qh(n)?1:0;if(n!=null){if(n=n.$$typeof,n===V)return 11;if(n===He)return 14}return 2}function ai(n,i){var a=n.alternate;return a===null?(a=gn(n.tag,i,n.key,n.mode),a.elementType=n.elementType,a.type=n.type,a.stateNode=n.stateNode,a.alternate=n,n.alternate=a):(a.pendingProps=i,a.type=n.type,a.flags=0,a.subtreeFlags=0,a.deletions=null),a.flags=n.flags&14680064,a.childLanes=n.childLanes,a.lanes=n.lanes,a.child=n.child,a.memoizedProps=n.memoizedProps,a.memoizedState=n.memoizedState,a.updateQueue=n.updateQueue,i=n.dependencies,a.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext},a.sibling=n.sibling,a.index=n.index,a.ref=n.ref,a}function _u(n,i,a,c,d,f){var v=2;if(c=n,typeof n=="function")Qh(n)&&(v=1);else if(typeof n=="string")v=5;else e:switch(n){case D:return ns(a.children,d,f,i);case T:v=8,d|=8;break;case S:return n=gn(12,a,i,d|2),n.elementType=S,n.lanes=f,n;case A:return n=gn(13,a,i,d),n.elementType=A,n.lanes=f,n;case Ie:return n=gn(19,a,i,d),n.elementType=Ie,n.lanes=f,n;case Be:return vu(a,d,f,i);default:if(typeof n=="object"&&n!==null)switch(n.$$typeof){case N:v=10;break e;case k:v=9;break e;case V:v=11;break e;case He:v=14;break e;case ut:v=16,c=null;break e}throw Error(t(130,n==null?n:typeof n,""))}return i=gn(v,a,i,d),i.elementType=n,i.type=c,i.lanes=f,i}function ns(n,i,a,c){return n=gn(7,n,c,i),n.lanes=a,n}function vu(n,i,a,c){return n=gn(22,n,c,i),n.elementType=Be,n.lanes=a,n.stateNode={isHidden:!1},n}function Yh(n,i,a){return n=gn(6,n,null,i),n.lanes=a,n}function Jh(n,i,a){return i=gn(4,n.children!==null?n.children:[],n.key,i),i.lanes=a,i.stateNode={containerInfo:n.containerInfo,pendingChildren:null,implementation:n.implementation},i}function hw(n,i,a,c,d){this.tag=i,this.containerInfo=n,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=Ko(0),this.expirationTimes=Ko(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Ko(0),this.identifierPrefix=c,this.onRecoverableError=d,this.mutableSourceEagerHydrationData=null}function Xh(n,i,a,c,d,f,v,R,x){return n=new hw(n,i,a,R,x),i===1?(i=1,f===!0&&(i|=8)):i=0,f=gn(3,null,null,i),n.current=f,f.stateNode=n,f.memoizedState={element:c,isDehydrated:a,cache:null,transitions:null,pendingSuspenseBoundaries:null},hh(f),n}function dw(n,i,a){var c=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:Re,key:c==null?null:""+c,children:n,containerInfo:i,implementation:a}}function Bm(n){if(!n)return Xr;n=n._reactInternals;e:{if(wn(n)!==n||n.tag!==1)throw Error(t(170));var i=n;do{switch(i.tag){case 3:i=i.stateNode.context;break e;case 1:if(Wt(i.type)){i=i.stateNode.__reactInternalMemoizedMergedChildContext;break e}}i=i.return}while(i!==null);throw Error(t(171))}if(n.tag===1){var a=n.type;if(Wt(a))return gp(n,a,i)}return i}function $m(n,i,a,c,d,f,v,R,x){return n=Xh(a,c,!0,n,d,f,v,R,x),n.context=Bm(null),a=n.current,c=$t(),d=si(a),f=Er(c,d),f.callback=i??null,ti(a,f,d),n.current.lanes=d,ji(n,d,c),Gt(n,c),n}function Eu(n,i,a,c){var d=i.current,f=$t(),v=si(d);return a=Bm(a),i.context===null?i.context=a:i.pendingContext=a,i=Er(f,v),i.payload={element:n},c=c===void 0?null:c,c!==null&&(i.callback=c),n=ti(d,i,v),n!==null&&(Pn(n,d,v,f),Jl(n,d,v)),v}function wu(n){if(n=n.current,!n.child)return null;switch(n.child.tag){case 5:return n.child.stateNode;default:return n.child.stateNode}}function Hm(n,i){if(n=n.memoizedState,n!==null&&n.dehydrated!==null){var a=n.retryLane;n.retryLane=a!==0&&a<i?a:i}}function Zh(n,i){Hm(n,i),(n=n.alternate)&&Hm(n,i)}function fw(){return null}var Wm=typeof reportError=="function"?reportError:function(n){console.error(n)};function ed(n){this._internalRoot=n}Tu.prototype.render=ed.prototype.render=function(n){var i=this._internalRoot;if(i===null)throw Error(t(409));Eu(n,i,null,null)},Tu.prototype.unmount=ed.prototype.unmount=function(){var n=this._internalRoot;if(n!==null){this._internalRoot=null;var i=n.containerInfo;Zi(function(){Eu(null,n,null,null)}),i[mr]=null}};function Tu(n){this._internalRoot=n}Tu.prototype.unstable_scheduleHydration=function(n){if(n){var i=Jo();n={blockedOn:null,target:n,priority:i};for(var a=0;a<en.length&&i!==0&&i<en[a].priority;a++);en.splice(a,0,n),a===0&&ks(n)}};function td(n){return!(!n||n.nodeType!==1&&n.nodeType!==9&&n.nodeType!==11)}function Iu(n){return!(!n||n.nodeType!==1&&n.nodeType!==9&&n.nodeType!==11&&(n.nodeType!==8||n.nodeValue!==" react-mount-point-unstable "))}function qm(){}function pw(n,i,a,c,d){if(d){if(typeof c=="function"){var f=c;c=function(){var U=wu(v);f.call(U)}}var v=$m(i,c,n,0,null,!1,!1,"",qm);return n._reactRootContainer=v,n[mr]=v.current,ua(n.nodeType===8?n.parentNode:n),Zi(),v}for(;d=n.lastChild;)n.removeChild(d);if(typeof c=="function"){var R=c;c=function(){var U=wu(x);R.call(U)}}var x=Xh(n,0,!1,null,null,!1,!1,"",qm);return n._reactRootContainer=x,n[mr]=x.current,ua(n.nodeType===8?n.parentNode:n),Zi(function(){Eu(i,x,a,c)}),x}function Su(n,i,a,c,d){var f=a._reactRootContainer;if(f){var v=f;if(typeof d=="function"){var R=d;d=function(){var x=wu(v);R.call(x)}}Eu(i,v,n,d)}else v=pw(a,i,n,d,c);return wu(v)}Qo=function(n){switch(n.tag){case 3:var i=n.stateNode;if(i.current.memoizedState.isDehydrated){var a=Fe(i.pendingLanes);a!==0&&(Go(i,a|1),Gt(i,Qe()),(be&6)===0&&(no=Qe()+500,Zr()))}break;case 13:Zi(function(){var c=vr(n,1);if(c!==null){var d=$t();Pn(c,n,1,d)}}),Zh(n,1)}},Cs=function(n){if(n.tag===13){var i=vr(n,134217728);if(i!==null){var a=$t();Pn(i,n,134217728,a)}Zh(n,134217728)}},Yo=function(n){if(n.tag===13){var i=si(n),a=vr(n,i);if(a!==null){var c=$t();Pn(a,n,i,c)}Zh(n,i)}},Jo=function(){return Ve},Xo=function(n,i){var a=Ve;try{return Ve=n,i()}finally{Ve=a}},sr=function(n,i,a){switch(i){case"input":if(Ni(n,a),i=a.name,a.type==="radio"&&i!=null){for(a=n;a.parentNode;)a=a.parentNode;for(a=a.querySelectorAll("input[name="+JSON.stringify(""+i)+'][type="radio"]'),i=0;i<a.length;i++){var c=a[i];if(c!==n&&c.form===n.form){var d=zl(c);if(!d)throw Error(t(90));Vo(c),Ni(c,d)}}}break;case"textarea":dl(n,a);break;case"select":i=a.value,i!=null&&vn(n,!!a.multiple,i,!1)}},ml=qh,gl=Zi;var mw={usingClientEntryPoint:!1,Events:[da,$s,zl,Ur,jr,qh]},Ra={findFiberByHostInstance:Wi,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},gw={bundleType:Ra.bundleType,version:Ra.version,rendererPackageName:Ra.rendererPackageName,rendererConfig:Ra.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:Ae.ReactCurrentDispatcher,findHostInstanceByFiber:function(n){return n=Il(n),n===null?null:n.stateNode},findFiberByHostInstance:Ra.findFiberByHostInstance||fw,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Au=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Au.isDisabled&&Au.supportsFiber)try{bi=Au.inject(gw),Xt=Au}catch{}}return Qt.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=mw,Qt.createPortal=function(n,i){var a=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!td(i))throw Error(t(200));return dw(n,i,null,a)},Qt.createRoot=function(n,i){if(!td(n))throw Error(t(299));var a=!1,c="",d=Wm;return i!=null&&(i.unstable_strictMode===!0&&(a=!0),i.identifierPrefix!==void 0&&(c=i.identifierPrefix),i.onRecoverableError!==void 0&&(d=i.onRecoverableError)),i=Xh(n,1,!1,null,null,a,!1,c,d),n[mr]=i.current,ua(n.nodeType===8?n.parentNode:n),new ed(i)},Qt.findDOMNode=function(n){if(n==null)return null;if(n.nodeType===1)return n;var i=n._reactInternals;if(i===void 0)throw typeof n.render=="function"?Error(t(188)):(n=Object.keys(n).join(","),Error(t(268,n)));return n=Il(i),n=n===null?null:n.stateNode,n},Qt.flushSync=function(n){return Zi(n)},Qt.hydrate=function(n,i,a){if(!Iu(i))throw Error(t(200));return Su(null,n,i,!0,a)},Qt.hydrateRoot=function(n,i,a){if(!td(n))throw Error(t(405));var c=a!=null&&a.hydratedSources||null,d=!1,f="",v=Wm;if(a!=null&&(a.unstable_strictMode===!0&&(d=!0),a.identifierPrefix!==void 0&&(f=a.identifierPrefix),a.onRecoverableError!==void 0&&(v=a.onRecoverableError)),i=$m(i,null,n,1,a??null,d,!1,f,v),n[mr]=i.current,ua(n),c)for(n=0;n<c.length;n++)a=c[n],d=a._getVersion,d=d(a._source),i.mutableSourceEagerHydrationData==null?i.mutableSourceEagerHydrationData=[a,d]:i.mutableSourceEagerHydrationData.push(a,d);return new Tu(i)},Qt.render=function(n,i,a){if(!Iu(i))throw Error(t(200));return Su(null,n,i,!1,a)},Qt.unmountComponentAtNode=function(n){if(!Iu(n))throw Error(t(40));return n._reactRootContainer?(Zi(function(){Su(null,null,n,!1,function(){n._reactRootContainer=null,n[mr]=null})}),!0):!1},Qt.unstable_batchedUpdates=qh,Qt.unstable_renderSubtreeIntoContainer=function(n,i,a,c){if(!Iu(a))throw Error(t(200));if(n==null||n._reactInternals===void 0)throw Error(t(38));return Su(n,i,a,!1,c)},Qt.version="18.3.1-next-f1338f8080-20240426",Qt}var eg;function Sw(){if(eg)return id.exports;eg=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(e){console.error(e)}}return r(),id.exports=Iw(),id.exports}var tg;function Aw(){if(tg)return Ru;tg=1;var r=Sw();return Ru.createRoot=r.createRoot,Ru.hydrateRoot=r.hydrateRoot,Ru}var Rw=Aw();/*! Capacitor: https://capacitorjs.com/ - MIT License */var yo;(function(r){r.Unimplemented="UNIMPLEMENTED",r.Unavailable="UNAVAILABLE"})(yo||(yo={}));class ad extends Error{constructor(e,t,s){super(e),this.message=e,this.code=t,this.data=s}}const Cw=r=>{var e,t;return r!=null&&r.androidBridge?"android":!((t=(e=r==null?void 0:r.webkit)===null||e===void 0?void 0:e.messageHandlers)===null||t===void 0)&&t.bridge?"ios":"web"},Pw=r=>{const e=r.CapacitorCustomPlatform||null,t=r.Capacitor||{},s=t.Plugins=t.Plugins||{},o=()=>e!==null?e.name:Cw(r),l=()=>o()!=="web",h=I=>{const C=_.get(I);return!!(C!=null&&C.platforms.has(o())||m(I))},m=I=>{var C;return(C=t.PluginHeaders)===null||C===void 0?void 0:C.find(z=>z.name===I)},g=I=>r.console.error(I),_=new Map,E=(I,C={})=>{const z=_.get(I);if(z)return console.warn(`Capacitor plugin "${I}" already registered. Cannot register plugins twice.`),z.proxy;const G=o(),Q=m(I);let B;const te=async()=>(!B&&G in C?B=typeof C[G]=="function"?B=await C[G]():B=C[G]:e!==null&&!B&&"web"in C&&(B=typeof C.web=="function"?B=await C.web():B=C.web),B),fe=(T,S)=>{var N,k;if(Q){const V=Q==null?void 0:Q.methods.find(A=>S===A.name);if(V)return V.rtype==="promise"?A=>t.nativePromise(I,S.toString(),A):(A,Ie)=>t.nativeCallback(I,S.toString(),A,Ie);if(T)return(N=T[S])===null||N===void 0?void 0:N.bind(T)}else{if(T)return(k=T[S])===null||k===void 0?void 0:k.bind(T);throw new ad(`"${I}" plugin is not implemented on ${G}`,yo.Unimplemented)}},Ee=T=>{let S;const N=(...k)=>{const V=te().then(A=>{const Ie=fe(A,T);if(Ie){const He=Ie(...k);return S=He==null?void 0:He.remove,He}else throw new ad(`"${I}.${T}()" is not implemented on ${G}`,yo.Unimplemented)});return T==="addListener"&&(V.remove=async()=>S()),V};return N.toString=()=>`${T.toString()}() { [capacitor code] }`,Object.defineProperty(N,"name",{value:T,writable:!1,configurable:!1}),N},Ae=Ee("addListener"),De=Ee("removeListener"),Re=(T,S)=>{const N=Ae({eventName:T},S),k=async()=>{const A=await N;De({eventName:T,callbackId:A},S)},V=new Promise(A=>N.then(()=>A({remove:k})));return V.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await k()},V},D=new Proxy({},{get(T,S){switch(S){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return Q?Re:Ae;case"removeListener":return De;default:return Ee(S)}}});return s[I]=D,_.set(I,{name:I,proxy:D,platforms:new Set([...Object.keys(C),...Q?[G]:[]])}),D};return t.convertFileSrc||(t.convertFileSrc=I=>I),t.getPlatform=o,t.handleError=g,t.isNativePlatform=l,t.isPluginAvailable=h,t.registerPlugin=E,t.Exception=ad,t.DEBUG=!!t.DEBUG,t.isLoggingEnabled=!!t.isLoggingEnabled,t},kw=r=>r.Capacitor=Pw(r),Hu=kw(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),dc=Hu.registerPlugin;class qd{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(e,t){let s=!1;this.listeners[e]||(this.listeners[e]=[],s=!0),this.listeners[e].push(t);const l=this.windowListeners[e];l&&!l.registered&&this.addWindowListener(l),s&&this.sendRetainedArgumentsForEvent(e);const h=async()=>this.removeListener(e,t);return Promise.resolve({remove:h})}async removeAllListeners(){this.listeners={};for(const e in this.windowListeners)this.removeWindowListener(this.windowListeners[e]);this.windowListeners={}}notifyListeners(e,t,s){const o=this.listeners[e];if(!o){if(s){let l=this.retainedEventArguments[e];l||(l=[]),l.push(t),this.retainedEventArguments[e]=l}return}o.forEach(l=>l(t))}hasListeners(e){var t;return!!(!((t=this.listeners[e])===null||t===void 0)&&t.length)}registerWindowListener(e,t){this.windowListeners[t]={registered:!1,windowEventName:e,pluginEventName:t,handler:s=>{this.notifyListeners(t,s)}}}unimplemented(e="not implemented"){return new Hu.Exception(e,yo.Unimplemented)}unavailable(e="not available"){return new Hu.Exception(e,yo.Unavailable)}async removeListener(e,t){const s=this.listeners[e];if(!s)return;const o=s.indexOf(t);this.listeners[e].splice(o,1),this.listeners[e].length||this.removeWindowListener(this.windowListeners[e])}addWindowListener(e){window.addEventListener(e.windowEventName,e.handler),e.registered=!0}removeWindowListener(e){e&&(window.removeEventListener(e.windowEventName,e.handler),e.registered=!1)}sendRetainedArgumentsForEvent(e){const t=this.retainedEventArguments[e];t&&(delete this.retainedEventArguments[e],t.forEach(s=>{this.notifyListeners(e,s)}))}}const ng=r=>encodeURIComponent(r).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),rg=r=>r.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class Nw extends qd{async getCookies(){const e=document.cookie,t={};return e.split(";").forEach(s=>{if(s.length<=0)return;let[o,l]=s.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");o=rg(o).trim(),l=rg(l).trim(),t[o]=l}),t}async setCookie(e){try{const t=ng(e.key),s=ng(e.value),o=e.expires?`; expires=${e.expires.replace("expires=","")}`:"",l=(e.path||"/").replace("path=",""),h=e.url!=null&&e.url.length>0?`domain=${e.url}`:"";document.cookie=`${t}=${s||""}${o}; path=${l}; ${h};`}catch(t){return Promise.reject(t)}}async deleteCookie(e){try{document.cookie=`${e.key}=; Max-Age=0`}catch(t){return Promise.reject(t)}}async clearCookies(){try{const e=document.cookie.split(";")||[];for(const t of e)document.cookie=t.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(e){return Promise.reject(e)}}async clearAllCookies(){try{await this.clearCookies()}catch(e){return Promise.reject(e)}}}dc("CapacitorCookies",{web:()=>new Nw});const xw=async r=>new Promise((e,t)=>{const s=new FileReader;s.onload=()=>{const o=s.result;e(o.indexOf(",")>=0?o.split(",")[1]:o)},s.onerror=o=>t(o),s.readAsDataURL(r)}),Dw=(r={})=>{const e=Object.keys(r);return Object.keys(r).map(o=>o.toLocaleLowerCase()).reduce((o,l,h)=>(o[l]=r[e[h]],o),{})},Vw=(r,e=!0)=>r?Object.entries(r).reduce((s,o)=>{const[l,h]=o;let m,g;return Array.isArray(h)?(g="",h.forEach(_=>{m=e?encodeURIComponent(_):_,g+=`${l}=${m}&`}),g.slice(0,-1)):(m=e?encodeURIComponent(h):h,g=`${l}=${m}`),`${s}&${g}`},"").substr(1):null,Ow=(r,e={})=>{const t=Object.assign({method:r.method||"GET",headers:r.headers},e),o=Dw(r.headers)["content-type"]||"";if(typeof r.data=="string")t.body=r.data;else if(o.includes("application/x-www-form-urlencoded")){const l=new URLSearchParams;for(const[h,m]of Object.entries(r.data||{}))l.set(h,m);t.body=l.toString()}else if(o.includes("multipart/form-data")||r.data instanceof FormData){const l=new FormData;if(r.data instanceof FormData)r.data.forEach((m,g)=>{l.append(g,m)});else for(const m of Object.keys(r.data))l.append(m,r.data[m]);t.body=l;const h=new Headers(t.headers);h.delete("content-type"),t.headers=h}else(o.includes("application/json")||typeof r.data=="object")&&(t.body=JSON.stringify(r.data));return t};class Lw extends qd{async request(e){const t=Ow(e,e.webFetchExtra),s=Vw(e.params,e.shouldEncodeUrlParams),o=s?`${e.url}?${s}`:e.url,l=await fetch(o,t),h=l.headers.get("content-type")||"";let{responseType:m="text"}=l.ok?e:{};h.includes("application/json")&&(m="json");let g,_;switch(m){case"arraybuffer":case"blob":_=await l.blob(),g=await xw(_);break;case"json":g=await l.json();break;case"document":case"text":default:g=await l.text()}const E={};return l.headers.forEach((I,C)=>{E[C]=I}),{data:g,headers:E,status:l.status,url:l.url}}async get(e){return this.request(Object.assign(Object.assign({},e),{method:"GET"}))}async post(e){return this.request(Object.assign(Object.assign({},e),{method:"POST"}))}async put(e){return this.request(Object.assign(Object.assign({},e),{method:"PUT"}))}async patch(e){return this.request(Object.assign(Object.assign({},e),{method:"PATCH"}))}async delete(e){return this.request(Object.assign(Object.assign({},e),{method:"DELETE"}))}}dc("CapacitorHttp",{web:()=>new Lw});var ig;(function(r){r.Dark="DARK",r.Light="LIGHT",r.Default="DEFAULT"})(ig||(ig={}));var sg;(function(r){r.StatusBar="StatusBar",r.NavigationBar="NavigationBar"})(sg||(sg={}));class bw extends qd{async setStyle(){this.unavailable("not available for web")}async setAnimation(){this.unavailable("not available for web")}async show(){this.unavailable("not available for web")}async hide(){this.unavailable("not available for web")}}dc("SystemBars",{web:()=>new bw});const Mw="modulepreload",Fw=function(r){return"/"+r},og={},Uw=function(e,t,s){let o=Promise.resolve();if(t&&t.length>0){let h=function(_){return Promise.all(_.map(E=>Promise.resolve(E).then(I=>({status:"fulfilled",value:I}),I=>({status:"rejected",reason:I}))))};document.getElementsByTagName("link");const m=document.querySelector("meta[property=csp-nonce]"),g=(m==null?void 0:m.nonce)||(m==null?void 0:m.getAttribute("nonce"));o=h(t.map(_=>{if(_=Fw(_),_ in og)return;og[_]=!0;const E=_.endsWith(".css"),I=E?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${_}"]${I}`))return;const C=document.createElement("link");if(C.rel=E?"stylesheet":Mw,E||(C.as="script"),C.crossOrigin="",C.href=_,g&&C.setAttribute("nonce",g),document.head.appendChild(C),E)return new Promise((z,G)=>{C.addEventListener("load",z),C.addEventListener("error",()=>G(new Error(`Unable to preload CSS for ${_}`)))})}))}function l(h){const m=new Event("vite:preloadError",{cancelable:!0});if(m.payload=h,window.dispatchEvent(m),!m.defaultPrevented)throw h}return o.then(h=>{for(const m of h||[])m.status==="rejected"&&l(m.reason);return e().catch(l)})};var ag;(function(r){r[r.Sunday=1]="Sunday",r[r.Monday=2]="Monday",r[r.Tuesday=3]="Tuesday",r[r.Wednesday=4]="Wednesday",r[r.Thursday=5]="Thursday",r[r.Friday=6]="Friday",r[r.Saturday=7]="Saturday"})(ag||(ag={}));const Cu=dc("LocalNotifications",{web:()=>Uw(()=>import("./web-DzYIuV8u.js"),[]).then(r=>new r.LocalNotificationsWeb)}),jw=()=>{};var lg={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const jy=function(r){const e=[];let t=0;for(let s=0;s<r.length;s++){let o=r.charCodeAt(s);o<128?e[t++]=o:o<2048?(e[t++]=o>>6|192,e[t++]=o&63|128):(o&64512)===55296&&s+1<r.length&&(r.charCodeAt(s+1)&64512)===56320?(o=65536+((o&1023)<<10)+(r.charCodeAt(++s)&1023),e[t++]=o>>18|240,e[t++]=o>>12&63|128,e[t++]=o>>6&63|128,e[t++]=o&63|128):(e[t++]=o>>12|224,e[t++]=o>>6&63|128,e[t++]=o&63|128)}return e},zw=function(r){const e=[];let t=0,s=0;for(;t<r.length;){const o=r[t++];if(o<128)e[s++]=String.fromCharCode(o);else if(o>191&&o<224){const l=r[t++];e[s++]=String.fromCharCode((o&31)<<6|l&63)}else if(o>239&&o<365){const l=r[t++],h=r[t++],m=r[t++],g=((o&7)<<18|(l&63)<<12|(h&63)<<6|m&63)-65536;e[s++]=String.fromCharCode(55296+(g>>10)),e[s++]=String.fromCharCode(56320+(g&1023))}else{const l=r[t++],h=r[t++];e[s++]=String.fromCharCode((o&15)<<12|(l&63)<<6|h&63)}}return e.join("")},zy={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(r,e){if(!Array.isArray(r))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,s=[];for(let o=0;o<r.length;o+=3){const l=r[o],h=o+1<r.length,m=h?r[o+1]:0,g=o+2<r.length,_=g?r[o+2]:0,E=l>>2,I=(l&3)<<4|m>>4;let C=(m&15)<<2|_>>6,z=_&63;g||(z=64,h||(C=64)),s.push(t[E],t[I],t[C],t[z])}return s.join("")},encodeString(r,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(r):this.encodeByteArray(jy(r),e)},decodeString(r,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(r):zw(this.decodeStringToByteArray(r,e))},decodeStringToByteArray(r,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,s=[];for(let o=0;o<r.length;){const l=t[r.charAt(o++)],m=o<r.length?t[r.charAt(o)]:0;++o;const _=o<r.length?t[r.charAt(o)]:64;++o;const I=o<r.length?t[r.charAt(o)]:64;if(++o,l==null||m==null||_==null||I==null)throw new Bw;const C=l<<2|m>>4;if(s.push(C),_!==64){const z=m<<4&240|_>>2;if(s.push(z),I!==64){const G=_<<6&192|I;s.push(G)}}}return s},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let r=0;r<this.ENCODED_VALS.length;r++)this.byteToCharMap_[r]=this.ENCODED_VALS.charAt(r),this.charToByteMap_[this.byteToCharMap_[r]]=r,this.byteToCharMapWebSafe_[r]=this.ENCODED_VALS_WEBSAFE.charAt(r),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[r]]=r,r>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(r)]=r,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(r)]=r)}}};class Bw extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const $w=function(r){const e=jy(r);return zy.encodeByteArray(e,!0)},Wu=function(r){return $w(r).replace(/\./g,"")},By=function(r){try{return zy.decodeString(r,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Hw(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ww=()=>Hw().__FIREBASE_DEFAULTS__,qw=()=>{if(typeof process>"u"||typeof lg>"u")return;const r=lg.__FIREBASE_DEFAULTS__;if(r)return JSON.parse(r)},Kw=()=>{if(typeof document>"u")return;let r;try{r=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=r&&By(r[1]);return e&&JSON.parse(e)},fc=()=>{try{return jw()||Ww()||qw()||Kw()}catch(r){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${r}`);return}},$y=r=>{var e,t;return(t=(e=fc())==null?void 0:e.emulatorHosts)==null?void 0:t[r]},Gw=r=>{const e=$y(r);if(!e)return;const t=e.lastIndexOf(":");if(t<=0||t+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const s=parseInt(e.substring(t+1),10);return e[0]==="["?[e.substring(1,t-1),s]:[e.substring(0,t),s]},Hy=()=>{var r;return(r=fc())==null?void 0:r.config},Wy=r=>{var e;return(e=fc())==null?void 0:e[`_${r}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qw{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,s)=>{t?this.reject(t):this.resolve(s),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,s))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Yw(r,e){if(r.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const t={alg:"none",type:"JWT"},s=e||"demo-project",o=r.iat||0,l=r.sub||r.user_id;if(!l)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const h={iss:`https://securetoken.google.com/${s}`,aud:s,iat:o,exp:o+3600,auth_time:o,sub:l,user_id:l,firebase:{sign_in_provider:"custom",identities:{}},...r};return[Wu(JSON.stringify(t)),Wu(JSON.stringify(h)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jt(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function Jw(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(jt())}function Xw(){var e;const r=(e=fc())==null?void 0:e.forceEnvironment;if(r==="node")return!0;if(r==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function Zw(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function eT(){const r=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof r=="object"&&r.id!==void 0}function tT(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function nT(){const r=jt();return r.indexOf("MSIE ")>=0||r.indexOf("Trident/")>=0}function rT(){return!Xw()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function iT(){try{return typeof indexedDB=="object"}catch{return!1}}function sT(){return new Promise((r,e)=>{try{let t=!0;const s="validate-browser-context-for-indexeddb-analytics-module",o=self.indexedDB.open(s);o.onsuccess=()=>{o.result.close(),t||self.indexedDB.deleteDatabase(s),r(!0)},o.onupgradeneeded=()=>{t=!1},o.onerror=()=>{var l;e(((l=o.error)==null?void 0:l.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oT="FirebaseError";class Nr extends Error{constructor(e,t,s){super(t),this.code=e,this.customData=s,this.name=oT,Object.setPrototypeOf(this,Nr.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Ja.prototype.create)}}class Ja{constructor(e,t,s){this.service=e,this.serviceName=t,this.errors=s}create(e,...t){const s=t[0]||{},o=`${this.service}/${e}`,l=this.errors[e],h=l?aT(l,s):"Error",m=`${this.serviceName}: ${h} (${o}).`;return new Nr(o,m,s)}}function aT(r,e){return r.replace(lT,(t,s)=>{const o=e[s];return o!=null?String(o):`<${s}?>`})}const lT=/\{\$([^}]+)}/g;function uT(r){for(const e in r)if(Object.prototype.hasOwnProperty.call(r,e))return!1;return!0}function as(r,e){if(r===e)return!0;const t=Object.keys(r),s=Object.keys(e);for(const o of t){if(!s.includes(o))return!1;const l=r[o],h=e[o];if(ug(l)&&ug(h)){if(!as(l,h))return!1}else if(l!==h)return!1}for(const o of s)if(!t.includes(o))return!1;return!0}function ug(r){return r!==null&&typeof r=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xa(r){const e=[];for(const[t,s]of Object.entries(r))Array.isArray(s)?s.forEach(o=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(o))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(s));return e.length?"&"+e.join("&"):""}function ka(r){const e={};return r.replace(/^\?/,"").split("&").forEach(s=>{if(s){const[o,l]=s.split("=");e[decodeURIComponent(o)]=decodeURIComponent(l)}}),e}function Na(r){const e=r.indexOf("?");if(!e)return"";const t=r.indexOf("#",e);return r.substring(e,t>0?t:void 0)}function cT(r,e){const t=new hT(r,e);return t.subscribe.bind(t)}class hT{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(s=>{this.error(s)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,s){let o;if(e===void 0&&t===void 0&&s===void 0)throw new Error("Missing Observer.");dT(e,["next","error","complete"])?o=e:o={next:e,error:t,complete:s},o.next===void 0&&(o.next=ld),o.error===void 0&&(o.error=ld),o.complete===void 0&&(o.complete=ld);const l=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?o.error(this.finalError):o.complete()}catch{}}),this.observers.push(o),l}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(s){typeof console<"u"&&console.error&&console.error(s)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function dT(r,e){if(typeof r!="object"||r===null)return!1;for(const t of e)if(t in r&&typeof r[t]=="function")return!0;return!1}function ld(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Et(r){return r&&r._delegate?r._delegate:r}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Za(r){try{return(r.startsWith("http://")||r.startsWith("https://")?new URL(r).hostname:r).endsWith(".cloudworkstations.dev")}catch{return!1}}async function qy(r){return(await fetch(r,{credentials:"include"})).ok}class ls{constructor(e,t,s){this.name=e,this.instanceFactory=t,this.type=s,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rs="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fT{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const s=new Qw;if(this.instancesDeferred.set(t,s),this.isInitialized(t)||this.shouldAutoInitialize())try{const o=this.getOrInitializeService({instanceIdentifier:t});o&&s.resolve(o)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){const t=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),s=(e==null?void 0:e.optional)??!1;if(this.isInitialized(t)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:t})}catch(o){if(s)return null;throw o}else{if(s)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(mT(e))try{this.getOrInitializeService({instanceIdentifier:rs})}catch{}for(const[t,s]of this.instancesDeferred.entries()){const o=this.normalizeInstanceIdentifier(t);try{const l=this.getOrInitializeService({instanceIdentifier:o});s.resolve(l)}catch{}}}}clearInstance(e=rs){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=rs){return this.instances.has(e)}getOptions(e=rs){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,s=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(s))throw Error(`${this.name}(${s}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const o=this.getOrInitializeService({instanceIdentifier:s,options:t});for(const[l,h]of this.instancesDeferred.entries()){const m=this.normalizeInstanceIdentifier(l);s===m&&h.resolve(o)}return o}onInit(e,t){const s=this.normalizeInstanceIdentifier(t),o=this.onInitCallbacks.get(s)??new Set;o.add(e),this.onInitCallbacks.set(s,o);const l=this.instances.get(s);return l&&e(l,s),()=>{o.delete(e)}}invokeOnInitCallbacks(e,t){const s=this.onInitCallbacks.get(t);if(s)for(const o of s)try{o(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let s=this.instances.get(e);if(!s&&this.component&&(s=this.component.instanceFactory(this.container,{instanceIdentifier:pT(e),options:t}),this.instances.set(e,s),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(s,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,s)}catch{}return s||null}normalizeInstanceIdentifier(e=rs){return this.component?this.component.multipleInstances?e:rs:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function pT(r){return r===rs?void 0:r}function mT(r){return r.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gT{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new fT(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ke;(function(r){r[r.DEBUG=0]="DEBUG",r[r.VERBOSE=1]="VERBOSE",r[r.INFO=2]="INFO",r[r.WARN=3]="WARN",r[r.ERROR=4]="ERROR",r[r.SILENT=5]="SILENT"})(ke||(ke={}));const yT={debug:ke.DEBUG,verbose:ke.VERBOSE,info:ke.INFO,warn:ke.WARN,error:ke.ERROR,silent:ke.SILENT},_T=ke.INFO,vT={[ke.DEBUG]:"log",[ke.VERBOSE]:"log",[ke.INFO]:"info",[ke.WARN]:"warn",[ke.ERROR]:"error"},ET=(r,e,...t)=>{if(e<r.logLevel)return;const s=new Date().toISOString(),o=vT[e];if(o)console[o](`[${s}]  ${r.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Kd{constructor(e){this.name=e,this._logLevel=_T,this._logHandler=ET,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in ke))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?yT[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,ke.DEBUG,...e),this._logHandler(this,ke.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,ke.VERBOSE,...e),this._logHandler(this,ke.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,ke.INFO,...e),this._logHandler(this,ke.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,ke.WARN,...e),this._logHandler(this,ke.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,ke.ERROR,...e),this._logHandler(this,ke.ERROR,...e)}}const wT=(r,e)=>e.some(t=>r instanceof t);let cg,hg;function TT(){return cg||(cg=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function IT(){return hg||(hg=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Ky=new WeakMap,Ed=new WeakMap,Gy=new WeakMap,ud=new WeakMap,Gd=new WeakMap;function ST(r){const e=new Promise((t,s)=>{const o=()=>{r.removeEventListener("success",l),r.removeEventListener("error",h)},l=()=>{t(mi(r.result)),o()},h=()=>{s(r.error),o()};r.addEventListener("success",l),r.addEventListener("error",h)});return e.then(t=>{t instanceof IDBCursor&&Ky.set(t,r)}).catch(()=>{}),Gd.set(e,r),e}function AT(r){if(Ed.has(r))return;const e=new Promise((t,s)=>{const o=()=>{r.removeEventListener("complete",l),r.removeEventListener("error",h),r.removeEventListener("abort",h)},l=()=>{t(),o()},h=()=>{s(r.error||new DOMException("AbortError","AbortError")),o()};r.addEventListener("complete",l),r.addEventListener("error",h),r.addEventListener("abort",h)});Ed.set(r,e)}let wd={get(r,e,t){if(r instanceof IDBTransaction){if(e==="done")return Ed.get(r);if(e==="objectStoreNames")return r.objectStoreNames||Gy.get(r);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return mi(r[e])},set(r,e,t){return r[e]=t,!0},has(r,e){return r instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in r}};function RT(r){wd=r(wd)}function CT(r){return r===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const s=r.call(cd(this),e,...t);return Gy.set(s,e.sort?e.sort():[e]),mi(s)}:IT().includes(r)?function(...e){return r.apply(cd(this),e),mi(Ky.get(this))}:function(...e){return mi(r.apply(cd(this),e))}}function PT(r){return typeof r=="function"?CT(r):(r instanceof IDBTransaction&&AT(r),wT(r,TT())?new Proxy(r,wd):r)}function mi(r){if(r instanceof IDBRequest)return ST(r);if(ud.has(r))return ud.get(r);const e=PT(r);return e!==r&&(ud.set(r,e),Gd.set(e,r)),e}const cd=r=>Gd.get(r);function kT(r,e,{blocked:t,upgrade:s,blocking:o,terminated:l}={}){const h=indexedDB.open(r,e),m=mi(h);return s&&h.addEventListener("upgradeneeded",g=>{s(mi(h.result),g.oldVersion,g.newVersion,mi(h.transaction),g)}),t&&h.addEventListener("blocked",g=>t(g.oldVersion,g.newVersion,g)),m.then(g=>{l&&g.addEventListener("close",()=>l()),o&&g.addEventListener("versionchange",_=>o(_.oldVersion,_.newVersion,_))}).catch(()=>{}),m}const NT=["get","getKey","getAll","getAllKeys","count"],xT=["put","add","delete","clear"],hd=new Map;function dg(r,e){if(!(r instanceof IDBDatabase&&!(e in r)&&typeof e=="string"))return;if(hd.get(e))return hd.get(e);const t=e.replace(/FromIndex$/,""),s=e!==t,o=xT.includes(t);if(!(t in(s?IDBIndex:IDBObjectStore).prototype)||!(o||NT.includes(t)))return;const l=async function(h,...m){const g=this.transaction(h,o?"readwrite":"readonly");let _=g.store;return s&&(_=_.index(m.shift())),(await Promise.all([_[t](...m),o&&g.done]))[0]};return hd.set(e,l),l}RT(r=>({...r,get:(e,t,s)=>dg(e,t)||r.get(e,t,s),has:(e,t)=>!!dg(e,t)||r.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class DT{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(VT(t)){const s=t.getImmediate();return`${s.library}/${s.version}`}else return null}).filter(t=>t).join(" ")}}function VT(r){const e=r.getComponent();return(e==null?void 0:e.type)==="VERSION"}const Td="@firebase/app",fg="0.14.10";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rr=new Kd("@firebase/app"),OT="@firebase/app-compat",LT="@firebase/analytics-compat",bT="@firebase/analytics",MT="@firebase/app-check-compat",FT="@firebase/app-check",UT="@firebase/auth",jT="@firebase/auth-compat",zT="@firebase/database",BT="@firebase/data-connect",$T="@firebase/database-compat",HT="@firebase/functions",WT="@firebase/functions-compat",qT="@firebase/installations",KT="@firebase/installations-compat",GT="@firebase/messaging",QT="@firebase/messaging-compat",YT="@firebase/performance",JT="@firebase/performance-compat",XT="@firebase/remote-config",ZT="@firebase/remote-config-compat",eI="@firebase/storage",tI="@firebase/storage-compat",nI="@firebase/firestore",rI="@firebase/ai",iI="@firebase/firestore-compat",sI="firebase",oI="12.11.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Id="[DEFAULT]",aI={[Td]:"fire-core",[OT]:"fire-core-compat",[bT]:"fire-analytics",[LT]:"fire-analytics-compat",[FT]:"fire-app-check",[MT]:"fire-app-check-compat",[UT]:"fire-auth",[jT]:"fire-auth-compat",[zT]:"fire-rtdb",[BT]:"fire-data-connect",[$T]:"fire-rtdb-compat",[HT]:"fire-fn",[WT]:"fire-fn-compat",[qT]:"fire-iid",[KT]:"fire-iid-compat",[GT]:"fire-fcm",[QT]:"fire-fcm-compat",[YT]:"fire-perf",[JT]:"fire-perf-compat",[XT]:"fire-rc",[ZT]:"fire-rc-compat",[eI]:"fire-gcs",[tI]:"fire-gcs-compat",[nI]:"fire-fst",[iI]:"fire-fst-compat",[rI]:"fire-vertex","fire-js":"fire-js",[sI]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qu=new Map,lI=new Map,Sd=new Map;function pg(r,e){try{r.container.addComponent(e)}catch(t){Rr.debug(`Component ${e.name} failed to register with FirebaseApp ${r.name}`,t)}}function _o(r){const e=r.name;if(Sd.has(e))return Rr.debug(`There were multiple attempts to register component ${e}.`),!1;Sd.set(e,r);for(const t of qu.values())pg(t,r);for(const t of lI.values())pg(t,r);return!0}function Qd(r,e){const t=r.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),r.container.getProvider(e)}function yn(r){return r==null?!1:r.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uI={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},gi=new Ja("app","Firebase",uI);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cI{constructor(e,t,s){this._isDeleted=!1,this._options={...e},this._config={...t},this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=s,this.container.addComponent(new ls("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw gi.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ro=oI;function Qy(r,e={}){let t=r;typeof e!="object"&&(e={name:e});const s={name:Id,automaticDataCollectionEnabled:!0,...e},o=s.name;if(typeof o!="string"||!o)throw gi.create("bad-app-name",{appName:String(o)});if(t||(t=Hy()),!t)throw gi.create("no-options");const l=qu.get(o);if(l){if(as(t,l.options)&&as(s,l.config))return l;throw gi.create("duplicate-app",{appName:o})}const h=new gT(o);for(const g of Sd.values())h.addComponent(g);const m=new cI(t,s,h);return qu.set(o,m),m}function Yy(r=Id){const e=qu.get(r);if(!e&&r===Id&&Hy())return Qy();if(!e)throw gi.create("no-app",{appName:r});return e}function yi(r,e,t){let s=aI[r]??r;t&&(s+=`-${t}`);const o=s.match(/\s|\//),l=e.match(/\s|\//);if(o||l){const h=[`Unable to register library "${s}" with version "${e}":`];o&&h.push(`library name "${s}" contains illegal characters (whitespace or "/")`),o&&l&&h.push("and"),l&&h.push(`version name "${e}" contains illegal characters (whitespace or "/")`),Rr.warn(h.join(" "));return}_o(new ls(`${s}-version`,()=>({library:s,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hI="firebase-heartbeat-database",dI=1,za="firebase-heartbeat-store";let dd=null;function Jy(){return dd||(dd=kT(hI,dI,{upgrade:(r,e)=>{switch(e){case 0:try{r.createObjectStore(za)}catch(t){console.warn(t)}}}}).catch(r=>{throw gi.create("idb-open",{originalErrorMessage:r.message})})),dd}async function fI(r){try{const t=(await Jy()).transaction(za),s=await t.objectStore(za).get(Xy(r));return await t.done,s}catch(e){if(e instanceof Nr)Rr.warn(e.message);else{const t=gi.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});Rr.warn(t.message)}}}async function mg(r,e){try{const s=(await Jy()).transaction(za,"readwrite");await s.objectStore(za).put(e,Xy(r)),await s.done}catch(t){if(t instanceof Nr)Rr.warn(t.message);else{const s=gi.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});Rr.warn(s.message)}}}function Xy(r){return`${r.name}!${r.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pI=1024,mI=30;class gI{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new _I(t),this._heartbeatsCachePromise=this._storage.read().then(s=>(this._heartbeatsCache=s,s))}async triggerHeartbeat(){var e,t;try{const o=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),l=gg();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===l||this._heartbeatsCache.heartbeats.some(h=>h.date===l))return;if(this._heartbeatsCache.heartbeats.push({date:l,agent:o}),this._heartbeatsCache.heartbeats.length>mI){const h=vI(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(h,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(s){Rr.warn(s)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=gg(),{heartbeatsToSend:s,unsentEntries:o}=yI(this._heartbeatsCache.heartbeats),l=Wu(JSON.stringify({version:2,heartbeats:s}));return this._heartbeatsCache.lastSentHeartbeatDate=t,o.length>0?(this._heartbeatsCache.heartbeats=o,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),l}catch(t){return Rr.warn(t),""}}}function gg(){return new Date().toISOString().substring(0,10)}function yI(r,e=pI){const t=[];let s=r.slice();for(const o of r){const l=t.find(h=>h.agent===o.agent);if(l){if(l.dates.push(o.date),yg(t)>e){l.dates.pop();break}}else if(t.push({agent:o.agent,dates:[o.date]}),yg(t)>e){t.pop();break}s=s.slice(1)}return{heartbeatsToSend:t,unsentEntries:s}}class _I{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return iT()?sT().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await fI(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const s=await this.read();return mg(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??s.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const s=await this.read();return mg(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??s.lastSentHeartbeatDate,heartbeats:[...s.heartbeats,...e.heartbeats]})}else return}}function yg(r){return Wu(JSON.stringify({version:2,heartbeats:r})).length}function vI(r){if(r.length===0)return-1;let e=0,t=r[0].date;for(let s=1;s<r.length;s++)r[s].date<t&&(t=r[s].date,e=s);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function EI(r){_o(new ls("platform-logger",e=>new DT(e),"PRIVATE")),_o(new ls("heartbeat",e=>new gI(e),"PRIVATE")),yi(Td,fg,r),yi(Td,fg,"esm2020"),yi("fire-js","")}EI("");var wI="firebase",TI="12.11.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */yi(wI,TI,"app");function Zy(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const II=Zy,e_=new Ja("auth","Firebase",Zy());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ku=new Kd("@firebase/auth");function SI(r,...e){Ku.logLevel<=ke.WARN&&Ku.warn(`Auth (${Ro}): ${r}`,...e)}function Ou(r,...e){Ku.logLevel<=ke.ERROR&&Ku.error(`Auth (${Ro}): ${r}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Dn(r,...e){throw Yd(r,...e)}function Zn(r,...e){return Yd(r,...e)}function t_(r,e,t){const s={...II(),[e]:t};return new Ja("auth","Firebase",s).create(e,{appName:r.name})}function Ar(r){return t_(r,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function Yd(r,...e){if(typeof r!="string"){const t=e[0],s=[...e.slice(1)];return s[0]&&(s[0].appName=r.name),r._errorFactory.create(t,...s)}return e_.create(r,...e)}function pe(r,e,...t){if(!r)throw Yd(e,...t)}function Ir(r){const e="INTERNAL ASSERTION FAILED: "+r;throw Ou(e),new Error(e)}function Cr(r,e){r||Ir(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ad(){var r;return typeof self<"u"&&((r=self.location)==null?void 0:r.href)||""}function AI(){return _g()==="http:"||_g()==="https:"}function _g(){var r;return typeof self<"u"&&((r=self.location)==null?void 0:r.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function RI(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(AI()||eT()||"connection"in navigator)?navigator.onLine:!0}function CI(){if(typeof navigator>"u")return null;const r=navigator;return r.languages&&r.languages[0]||r.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class el{constructor(e,t){this.shortDelay=e,this.longDelay=t,Cr(t>e,"Short delay should be less than long delay!"),this.isMobile=Jw()||tT()}get(){return RI()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Jd(r,e){Cr(r.emulator,"Emulator should always be set here");const{url:t}=r.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class n_{static initialize(e,t,s){this.fetchImpl=e,t&&(this.headersImpl=t),s&&(this.responseImpl=s)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;Ir("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;Ir("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;Ir("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const PI={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const kI=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],NI=new el(3e4,6e4);function xr(r,e){return r.tenantId&&!e.tenantId?{...e,tenantId:r.tenantId}:e}async function Dr(r,e,t,s,o={}){return r_(r,o,async()=>{let l={},h={};s&&(e==="GET"?h=s:l={body:JSON.stringify(s)});const m=Xa({key:r.config.apiKey,...h}).slice(1),g=await r._getAdditionalHeaders();g["Content-Type"]="application/json",r.languageCode&&(g["X-Firebase-Locale"]=r.languageCode);const _={method:e,headers:g,...l};return Zw()||(_.referrerPolicy="no-referrer"),r.emulatorConfig&&Za(r.emulatorConfig.host)&&(_.credentials="include"),n_.fetch()(await i_(r,r.config.apiHost,t,m),_)})}async function r_(r,e,t){r._canInitEmulator=!1;const s={...PI,...e};try{const o=new DI(r),l=await Promise.race([t(),o.promise]);o.clearNetworkTimeout();const h=await l.json();if("needConfirmation"in h)throw Pu(r,"account-exists-with-different-credential",h);if(l.ok&&!("errorMessage"in h))return h;{const m=l.ok?h.errorMessage:h.error.message,[g,_]=m.split(" : ");if(g==="FEDERATED_USER_ID_ALREADY_LINKED")throw Pu(r,"credential-already-in-use",h);if(g==="EMAIL_EXISTS")throw Pu(r,"email-already-in-use",h);if(g==="USER_DISABLED")throw Pu(r,"user-disabled",h);const E=s[g]||g.toLowerCase().replace(/[_\s]+/g,"-");if(_)throw t_(r,E,_);Dn(r,E)}}catch(o){if(o instanceof Nr)throw o;Dn(r,"network-request-failed",{message:String(o)})}}async function tl(r,e,t,s,o={}){const l=await Dr(r,e,t,s,o);return"mfaPendingCredential"in l&&Dn(r,"multi-factor-auth-required",{_serverResponse:l}),l}async function i_(r,e,t,s){const o=`${e}${t}?${s}`,l=r,h=l.config.emulator?Jd(r.config,o):`${r.config.apiScheme}://${o}`;return kI.includes(t)&&(await l._persistenceManagerAvailable,l._getPersistenceType()==="COOKIE")?l._getPersistence()._getFinalTarget(h).toString():h}function xI(r){switch(r){case"ENFORCE":return"ENFORCE";case"AUDIT":return"AUDIT";case"OFF":return"OFF";default:return"ENFORCEMENT_STATE_UNSPECIFIED"}}class DI{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,s)=>{this.timer=setTimeout(()=>s(Zn(this.auth,"network-request-failed")),NI.get())})}}function Pu(r,e,t){const s={appName:r.name};t.email&&(s.email=t.email),t.phoneNumber&&(s.phoneNumber=t.phoneNumber);const o=Zn(r,e,s);return o.customData._tokenResponse=t,o}function vg(r){return r!==void 0&&r.enterprise!==void 0}class VI{constructor(e){if(this.siteKey="",this.recaptchaEnforcementState=[],e.recaptchaKey===void 0)throw new Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.recaptchaEnforcementState=e.recaptchaEnforcementState}getProviderEnforcementState(e){if(!this.recaptchaEnforcementState||this.recaptchaEnforcementState.length===0)return null;for(const t of this.recaptchaEnforcementState)if(t.provider&&t.provider===e)return xI(t.enforcementState);return null}isProviderEnabled(e){return this.getProviderEnforcementState(e)==="ENFORCE"||this.getProviderEnforcementState(e)==="AUDIT"}isAnyProviderEnabled(){return this.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")||this.isProviderEnabled("PHONE_PROVIDER")}}async function OI(r,e){return Dr(r,"GET","/v2/recaptchaConfig",xr(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function LI(r,e){return Dr(r,"POST","/v1/accounts:delete",e)}async function Gu(r,e){return Dr(r,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function La(r){if(r)try{const e=new Date(Number(r));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function bI(r,e=!1){const t=Et(r),s=await t.getIdToken(e),o=Xd(s);pe(o&&o.exp&&o.auth_time&&o.iat,t.auth,"internal-error");const l=typeof o.firebase=="object"?o.firebase:void 0,h=l==null?void 0:l.sign_in_provider;return{claims:o,token:s,authTime:La(fd(o.auth_time)),issuedAtTime:La(fd(o.iat)),expirationTime:La(fd(o.exp)),signInProvider:h||null,signInSecondFactor:(l==null?void 0:l.sign_in_second_factor)||null}}function fd(r){return Number(r)*1e3}function Xd(r){const[e,t,s]=r.split(".");if(e===void 0||t===void 0||s===void 0)return Ou("JWT malformed, contained fewer than 3 sections"),null;try{const o=By(t);return o?JSON.parse(o):(Ou("Failed to decode base64 JWT payload"),null)}catch(o){return Ou("Caught error parsing JWT payload as JSON",o==null?void 0:o.toString()),null}}function Eg(r){const e=Xd(r);return pe(e,"internal-error"),pe(typeof e.exp<"u","internal-error"),pe(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ba(r,e,t=!1){if(t)return e;try{return await e}catch(s){throw s instanceof Nr&&MI(s)&&r.auth.currentUser===r&&await r.auth.signOut(),s}}function MI({code:r}){return r==="auth/user-disabled"||r==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class FI{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){if(e){const t=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),t}else{this.errorBackoff=3e4;const s=(this.user.stsTokenManager.expirationTime??0)-Date.now()-3e5;return Math.max(0,s)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rd{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=La(this.lastLoginAt),this.creationTime=La(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Qu(r){var I;const e=r.auth,t=await r.getIdToken(),s=await Ba(r,Gu(e,{idToken:t}));pe(s==null?void 0:s.users.length,e,"internal-error");const o=s.users[0];r._notifyReloadListener(o);const l=(I=o.providerUserInfo)!=null&&I.length?s_(o.providerUserInfo):[],h=jI(r.providerData,l),m=r.isAnonymous,g=!(r.email&&o.passwordHash)&&!(h!=null&&h.length),_=m?g:!1,E={uid:o.localId,displayName:o.displayName||null,photoURL:o.photoUrl||null,email:o.email||null,emailVerified:o.emailVerified||!1,phoneNumber:o.phoneNumber||null,tenantId:o.tenantId||null,providerData:h,metadata:new Rd(o.createdAt,o.lastLoginAt),isAnonymous:_};Object.assign(r,E)}async function UI(r){const e=Et(r);await Qu(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function jI(r,e){return[...r.filter(s=>!e.some(o=>o.providerId===s.providerId)),...e]}function s_(r){return r.map(({providerId:e,...t})=>({providerId:e,uid:t.rawId||"",displayName:t.displayName||null,email:t.email||null,phoneNumber:t.phoneNumber||null,photoURL:t.photoUrl||null}))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function zI(r,e){const t=await r_(r,{},async()=>{const s=Xa({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:o,apiKey:l}=r.config,h=await i_(r,o,"/v1/token",`key=${l}`),m=await r._getAdditionalHeaders();m["Content-Type"]="application/x-www-form-urlencoded";const g={method:"POST",headers:m,body:s};return r.emulatorConfig&&Za(r.emulatorConfig.host)&&(g.credentials="include"),n_.fetch()(h,g)});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function BI(r,e){return Dr(r,"POST","/v2/accounts:revokeToken",xr(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uo{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){pe(e.idToken,"internal-error"),pe(typeof e.idToken<"u","internal-error"),pe(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):Eg(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){pe(e.length!==0,"internal-error");const t=Eg(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(pe(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:s,refreshToken:o,expiresIn:l}=await zI(e,t);this.updateTokensAndExpiration(s,o,Number(l))}updateTokensAndExpiration(e,t,s){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+s*1e3}static fromJSON(e,t){const{refreshToken:s,accessToken:o,expirationTime:l}=t,h=new uo;return s&&(pe(typeof s=="string","internal-error",{appName:e}),h.refreshToken=s),o&&(pe(typeof o=="string","internal-error",{appName:e}),h.accessToken=o),l&&(pe(typeof l=="number","internal-error",{appName:e}),h.expirationTime=l),h}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new uo,this.toJSON())}_performRefresh(){return Ir("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ui(r,e){pe(typeof r=="string"||typeof r>"u","internal-error",{appName:e})}class kn{constructor({uid:e,auth:t,stsTokenManager:s,...o}){this.providerId="firebase",this.proactiveRefresh=new FI(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=e,this.auth=t,this.stsTokenManager=s,this.accessToken=s.accessToken,this.displayName=o.displayName||null,this.email=o.email||null,this.emailVerified=o.emailVerified||!1,this.phoneNumber=o.phoneNumber||null,this.photoURL=o.photoURL||null,this.isAnonymous=o.isAnonymous||!1,this.tenantId=o.tenantId||null,this.providerData=o.providerData?[...o.providerData]:[],this.metadata=new Rd(o.createdAt||void 0,o.lastLoginAt||void 0)}async getIdToken(e){const t=await Ba(this,this.stsTokenManager.getToken(this.auth,e));return pe(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return bI(this,e)}reload(){return UI(this)}_assign(e){this!==e&&(pe(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>({...t})),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new kn({...this,auth:e,stsTokenManager:this.stsTokenManager._clone()});return t.metadata._copy(this.metadata),t}_onReload(e){pe(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let s=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),s=!0),t&&await Qu(this),await this.auth._persistUserIfCurrent(this),s&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(yn(this.auth.app))return Promise.reject(Ar(this.auth));const e=await this.getIdToken();return await Ba(this,LI(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return{uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>({...e})),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId,...this.metadata.toJSON(),apiKey:this.auth.config.apiKey,appName:this.auth.name}}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){const s=t.displayName??void 0,o=t.email??void 0,l=t.phoneNumber??void 0,h=t.photoURL??void 0,m=t.tenantId??void 0,g=t._redirectEventId??void 0,_=t.createdAt??void 0,E=t.lastLoginAt??void 0,{uid:I,emailVerified:C,isAnonymous:z,providerData:G,stsTokenManager:Q}=t;pe(I&&Q,e,"internal-error");const B=uo.fromJSON(this.name,Q);pe(typeof I=="string",e,"internal-error"),ui(s,e.name),ui(o,e.name),pe(typeof C=="boolean",e,"internal-error"),pe(typeof z=="boolean",e,"internal-error"),ui(l,e.name),ui(h,e.name),ui(m,e.name),ui(g,e.name),ui(_,e.name),ui(E,e.name);const te=new kn({uid:I,auth:e,email:o,emailVerified:C,displayName:s,isAnonymous:z,photoURL:h,phoneNumber:l,tenantId:m,stsTokenManager:B,createdAt:_,lastLoginAt:E});return G&&Array.isArray(G)&&(te.providerData=G.map(fe=>({...fe}))),g&&(te._redirectEventId=g),te}static async _fromIdTokenResponse(e,t,s=!1){const o=new uo;o.updateFromServerResponse(t);const l=new kn({uid:t.localId,auth:e,stsTokenManager:o,isAnonymous:s});return await Qu(l),l}static async _fromGetAccountInfoResponse(e,t,s){const o=t.users[0];pe(o.localId!==void 0,"internal-error");const l=o.providerUserInfo!==void 0?s_(o.providerUserInfo):[],h=!(o.email&&o.passwordHash)&&!(l!=null&&l.length),m=new uo;m.updateFromIdToken(s);const g=new kn({uid:o.localId,auth:e,stsTokenManager:m,isAnonymous:h}),_={uid:o.localId,displayName:o.displayName||null,photoURL:o.photoUrl||null,email:o.email||null,emailVerified:o.emailVerified||!1,phoneNumber:o.phoneNumber||null,tenantId:o.tenantId||null,providerData:l,metadata:new Rd(o.createdAt,o.lastLoginAt),isAnonymous:!(o.email&&o.passwordHash)&&!(l!=null&&l.length)};return Object.assign(g,_),g}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wg=new Map;function Sr(r){Cr(r instanceof Function,"Expected a class definition");let e=wg.get(r);return e?(Cr(e instanceof r,"Instance stored in cache mismatched with class"),e):(e=new r,wg.set(r,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class o_{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}o_.type="NONE";const Tg=o_;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Lu(r,e,t){return`firebase:${r}:${e}:${t}`}class co{constructor(e,t,s){this.persistence=e,this.auth=t,this.userKey=s;const{config:o,name:l}=this.auth;this.fullUserKey=Lu(this.userKey,o.apiKey,l),this.fullPersistenceKey=Lu("persistence",o.apiKey,l),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const t=await Gu(this.auth,{idToken:e}).catch(()=>{});return t?kn._fromGetAccountInfoResponse(this.auth,t,e):null}return kn._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,s="authUser"){if(!t.length)return new co(Sr(Tg),e,s);const o=(await Promise.all(t.map(async _=>{if(await _._isAvailable())return _}))).filter(_=>_);let l=o[0]||Sr(Tg);const h=Lu(s,e.config.apiKey,e.name);let m=null;for(const _ of t)try{const E=await _._get(h);if(E){let I;if(typeof E=="string"){const C=await Gu(e,{idToken:E}).catch(()=>{});if(!C)break;I=await kn._fromGetAccountInfoResponse(e,C,E)}else I=kn._fromJSON(e,E);_!==l&&(m=I),l=_;break}}catch{}const g=o.filter(_=>_._shouldAllowMigration);return!l._shouldAllowMigration||!g.length?new co(l,e,s):(l=g[0],m&&await l._set(h,m.toJSON()),await Promise.all(t.map(async _=>{if(_!==l)try{await _._remove(h)}catch{}})),new co(l,e,s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ig(r){const e=r.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(c_(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(a_(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(d_(e))return"Blackberry";if(f_(e))return"Webos";if(l_(e))return"Safari";if((e.includes("chrome/")||u_(e))&&!e.includes("edge/"))return"Chrome";if(h_(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,s=r.match(t);if((s==null?void 0:s.length)===2)return s[1]}return"Other"}function a_(r=jt()){return/firefox\//i.test(r)}function l_(r=jt()){const e=r.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function u_(r=jt()){return/crios\//i.test(r)}function c_(r=jt()){return/iemobile/i.test(r)}function h_(r=jt()){return/android/i.test(r)}function d_(r=jt()){return/blackberry/i.test(r)}function f_(r=jt()){return/webos/i.test(r)}function Zd(r=jt()){return/iphone|ipad|ipod/i.test(r)||/macintosh/i.test(r)&&/mobile/i.test(r)}function $I(r=jt()){var e;return Zd(r)&&!!((e=window.navigator)!=null&&e.standalone)}function HI(){return nT()&&document.documentMode===10}function p_(r=jt()){return Zd(r)||h_(r)||f_(r)||d_(r)||/windows phone/i.test(r)||c_(r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function m_(r,e=[]){let t;switch(r){case"Browser":t=Ig(jt());break;case"Worker":t=`${Ig(jt())}-${r}`;break;default:t=r}const s=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${Ro}/${s}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class WI{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const s=l=>new Promise((h,m)=>{try{const g=e(l);h(g)}catch(g){m(g)}});s.onAbort=t,this.queue.push(s);const o=this.queue.length-1;return()=>{this.queue[o]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const s of this.queue)await s(e),s.onAbort&&t.push(s.onAbort)}catch(s){t.reverse();for(const o of t)try{o()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:s==null?void 0:s.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function qI(r,e={}){return Dr(r,"GET","/v2/passwordPolicy",xr(r,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const KI=6;class GI{constructor(e){var s;const t=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=t.minPasswordLength??KI,t.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=t.maxPasswordLength),t.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=t.containsLowercaseCharacter),t.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=t.containsUppercaseCharacter),t.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=t.containsNumericCharacter),t.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=t.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=((s=e.allowedNonAlphanumericCharacters)==null?void 0:s.join(""))??"",this.forceUpgradeOnSignin=e.forceUpgradeOnSignin??!1,this.schemaVersion=e.schemaVersion}validatePassword(e){const t={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,t),this.validatePasswordCharacterOptions(e,t),t.isValid&&(t.isValid=t.meetsMinPasswordLength??!0),t.isValid&&(t.isValid=t.meetsMaxPasswordLength??!0),t.isValid&&(t.isValid=t.containsLowercaseLetter??!0),t.isValid&&(t.isValid=t.containsUppercaseLetter??!0),t.isValid&&(t.isValid=t.containsNumericCharacter??!0),t.isValid&&(t.isValid=t.containsNonAlphanumericCharacter??!0),t}validatePasswordLengthOptions(e,t){const s=this.customStrengthOptions.minPasswordLength,o=this.customStrengthOptions.maxPasswordLength;s&&(t.meetsMinPasswordLength=e.length>=s),o&&(t.meetsMaxPasswordLength=e.length<=o)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let s;for(let o=0;o<e.length;o++)s=e.charAt(o),this.updatePasswordCharacterOptionsStatuses(t,s>="a"&&s<="z",s>="A"&&s<="Z",s>="0"&&s<="9",this.allowedNonAlphanumericCharacters.includes(s))}updatePasswordCharacterOptionsStatuses(e,t,s,o,l){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=s)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=o)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=l))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class QI{constructor(e,t,s,o){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=s,this.config=o,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new Sg(this),this.idTokenSubscription=new Sg(this),this.beforeStateQueue=new WI(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=e_,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=o.sdkClientVersion,this._persistenceManagerAvailable=new Promise(l=>this._resolvePersistenceManagerAvailable=l)}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=Sr(t)),this._initializationPromise=this.queue(async()=>{var s,o,l;if(!this._deleted&&(this.persistenceManager=await co.create(this,e),(s=this._resolvePersistenceManagerAvailable)==null||s.call(this),!this._deleted)){if((o=this._popupRedirectResolver)!=null&&o._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((l=this.currentUser)==null?void 0:l.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await Gu(this,{idToken:e}),s=await kn._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(s)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var l;if(yn(this.app)){const h=this.app.settings.authIdToken;return h?new Promise(m=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(h).then(m,m))}):this.directlySetCurrentUser(null)}const t=await this.assertedPersistence.getCurrentUser();let s=t,o=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const h=(l=this.redirectUser)==null?void 0:l._redirectEventId,m=s==null?void 0:s._redirectEventId,g=await this.tryRedirectSignIn(e);(!h||h===m)&&(g!=null&&g.user)&&(s=g.user,o=!0)}if(!s)return this.directlySetCurrentUser(null);if(!s._redirectEventId){if(o)try{await this.beforeStateQueue.runMiddleware(s)}catch(h){s=t,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(h))}return s?this.reloadAndSetCurrentUserOrClear(s):this.directlySetCurrentUser(null)}return pe(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===s._redirectEventId?this.directlySetCurrentUser(s):this.reloadAndSetCurrentUserOrClear(s)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await Qu(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=CI()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(yn(this.app))return Promise.reject(Ar(this));const t=e?Et(e):null;return t&&pe(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&pe(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return yn(this.app)?Promise.reject(Ar(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return yn(this.app)?Promise.reject(Ar(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(Sr(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await qI(this),t=new GI(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new Ja("auth","Firebase",e())}onAuthStateChanged(e,t,s){return this.registerStateListener(this.authStateSubscription,e,t,s)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,s){return this.registerStateListener(this.idTokenSubscription,e,t,s)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const s=this.onAuthStateChanged(()=>{s(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),s={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(s.tenantId=this.tenantId),await BI(this,s)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)==null?void 0:e.toJSON()}}async _setRedirectUser(e,t){const s=await this.getOrInitRedirectPersistenceManager(t);return e===null?s.removeCurrentUser():s.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&Sr(e)||this._popupRedirectResolver;pe(t,this,"argument-error"),this.redirectPersistenceManager=await co.create(this,[Sr(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,s;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)==null?void 0:t._redirectEventId)===e?this._currentUser:((s=this.redirectUser)==null?void 0:s._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const e=((t=this.currentUser)==null?void 0:t.uid)??null;this.lastNotifiedUid!==e&&(this.lastNotifiedUid=e,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,s,o){if(this._deleted)return()=>{};const l=typeof t=="function"?t:t.next.bind(t);let h=!1;const m=this._isInitialized?Promise.resolve():this._initializationPromise;if(pe(m,this,"internal-error"),m.then(()=>{h||l(this.currentUser)}),typeof t=="function"){const g=e.addObserver(t,s,o);return()=>{h=!0,g()}}else{const g=e.addObserver(t);return()=>{h=!0,g()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return pe(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=m_(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var o;const e={"X-Client-Version":this.clientVersion};this.app.options.appId&&(e["X-Firebase-gmpid"]=this.app.options.appId);const t=await((o=this.heartbeatServiceProvider.getImmediate({optional:!0}))==null?void 0:o.getHeartbeatsHeader());t&&(e["X-Firebase-Client"]=t);const s=await this._getAppCheckToken();return s&&(e["X-Firebase-AppCheck"]=s),e}async _getAppCheckToken(){var t;if(yn(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const e=await((t=this.appCheckServiceProvider.getImmediate({optional:!0}))==null?void 0:t.getToken());return e!=null&&e.error&&SI(`Error while retrieving App Check token: ${e.error}`),e==null?void 0:e.token}}function Ci(r){return Et(r)}class Sg{constructor(e){this.auth=e,this.observer=null,this.addObserver=cT(t=>this.observer=t)}get next(){return pe(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let pc={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function YI(r){pc=r}function g_(r){return pc.loadJS(r)}function JI(){return pc.recaptchaEnterpriseScript}function XI(){return pc.gapiScript}function ZI(r){return`__${r}${Math.floor(Math.random()*1e6)}`}class e0{constructor(){this.enterprise=new t0}ready(e){e()}execute(e,t){return Promise.resolve("token")}render(e,t){return""}}class t0{ready(e){e()}execute(e,t){return Promise.resolve("token")}render(e,t){return""}}const n0="recaptcha-enterprise",y_="NO_RECAPTCHA";class r0{constructor(e){this.type=n0,this.auth=Ci(e)}async verify(e="verify",t=!1){async function s(l){if(!t){if(l.tenantId==null&&l._agentRecaptchaConfig!=null)return l._agentRecaptchaConfig.siteKey;if(l.tenantId!=null&&l._tenantRecaptchaConfigs[l.tenantId]!==void 0)return l._tenantRecaptchaConfigs[l.tenantId].siteKey}return new Promise(async(h,m)=>{OI(l,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(g=>{if(g.recaptchaKey===void 0)m(new Error("recaptcha Enterprise site key undefined"));else{const _=new VI(g);return l.tenantId==null?l._agentRecaptchaConfig=_:l._tenantRecaptchaConfigs[l.tenantId]=_,h(_.siteKey)}}).catch(g=>{m(g)})})}function o(l,h,m){const g=window.grecaptcha;vg(g)?g.enterprise.ready(()=>{g.enterprise.execute(l,{action:e}).then(_=>{h(_)}).catch(()=>{h(y_)})}):m(Error("No reCAPTCHA enterprise script loaded."))}return this.auth.settings.appVerificationDisabledForTesting?new e0().execute("siteKey",{action:"verify"}):new Promise((l,h)=>{s(this.auth).then(m=>{if(!t&&vg(window.grecaptcha))o(m,l,h);else{if(typeof window>"u"){h(new Error("RecaptchaVerifier is only supported in browser"));return}let g=JI();g.length!==0&&(g+=m),g_(g).then(()=>{o(m,l,h)}).catch(_=>{h(_)})}}).catch(m=>{h(m)})})}}async function Ag(r,e,t,s=!1,o=!1){const l=new r0(r);let h;if(o)h=y_;else try{h=await l.verify(t)}catch{h=await l.verify(t,!0)}const m={...e};if(t==="mfaSmsEnrollment"||t==="mfaSmsSignIn"){if("phoneEnrollmentInfo"in m){const g=m.phoneEnrollmentInfo.phoneNumber,_=m.phoneEnrollmentInfo.recaptchaToken;Object.assign(m,{phoneEnrollmentInfo:{phoneNumber:g,recaptchaToken:_,captchaResponse:h,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}else if("phoneSignInInfo"in m){const g=m.phoneSignInInfo.recaptchaToken;Object.assign(m,{phoneSignInInfo:{recaptchaToken:g,captchaResponse:h,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}return m}return s?Object.assign(m,{captchaResp:h}):Object.assign(m,{captchaResponse:h}),Object.assign(m,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(m,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),m}async function Yu(r,e,t,s,o){var l;if((l=r._getRecaptchaConfig())!=null&&l.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")){const h=await Ag(r,e,t,t==="getOobCode");return s(r,h)}else return s(r,e).catch(async h=>{if(h.code==="auth/missing-recaptcha-token"){console.log(`${t} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);const m=await Ag(r,e,t,t==="getOobCode");return s(r,m)}else return Promise.reject(h)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function i0(r,e){const t=Qd(r,"auth");if(t.isInitialized()){const o=t.getImmediate(),l=t.getOptions();if(as(l,e??{}))return o;Dn(o,"already-initialized")}return t.initialize({options:e})}function s0(r,e){const t=(e==null?void 0:e.persistence)||[],s=(Array.isArray(t)?t:[t]).map(Sr);e!=null&&e.errorMap&&r._updateErrorMap(e.errorMap),r._initializeWithPersistence(s,e==null?void 0:e.popupRedirectResolver)}function o0(r,e,t){const s=Ci(r);pe(/^https?:\/\//.test(e),s,"invalid-emulator-scheme");const o=!1,l=__(e),{host:h,port:m}=a0(e),g=m===null?"":`:${m}`,_={url:`${l}//${h}${g}/`},E=Object.freeze({host:h,port:m,protocol:l.replace(":",""),options:Object.freeze({disableWarnings:o})});if(!s._canInitEmulator){pe(s.config.emulator&&s.emulatorConfig,s,"emulator-config-failed"),pe(as(_,s.config.emulator)&&as(E,s.emulatorConfig),s,"emulator-config-failed");return}s.config.emulator=_,s.emulatorConfig=E,s.settings.appVerificationDisabledForTesting=!0,Za(h)?qy(`${l}//${h}${g}`):l0()}function __(r){const e=r.indexOf(":");return e<0?"":r.substr(0,e+1)}function a0(r){const e=__(r),t=/(\/\/)?([^?#/]+)/.exec(r.substr(e.length));if(!t)return{host:"",port:null};const s=t[2].split("@").pop()||"",o=/^(\[[^\]]+\])(:|$)/.exec(s);if(o){const l=o[1];return{host:l,port:Rg(s.substr(l.length+1))}}else{const[l,h]=s.split(":");return{host:l,port:Rg(h)}}}function Rg(r){if(!r)return null;const e=Number(r);return isNaN(e)?null:e}function l0(){function r(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",r):r())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ef{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return Ir("not implemented")}_getIdTokenResponse(e){return Ir("not implemented")}_linkToIdToken(e,t){return Ir("not implemented")}_getReauthenticationResolver(e){return Ir("not implemented")}}async function u0(r,e){return Dr(r,"POST","/v1/accounts:signUp",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function c0(r,e){return tl(r,"POST","/v1/accounts:signInWithPassword",xr(r,e))}async function h0(r,e){return Dr(r,"POST","/v1/accounts:sendOobCode",xr(r,e))}async function d0(r,e){return h0(r,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function f0(r,e){return tl(r,"POST","/v1/accounts:signInWithEmailLink",xr(r,e))}async function p0(r,e){return tl(r,"POST","/v1/accounts:signInWithEmailLink",xr(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $a extends ef{constructor(e,t,s,o=null){super("password",s),this._email=e,this._password=t,this._tenantId=o}static _fromEmailAndPassword(e,t){return new $a(e,t,"password")}static _fromEmailAndCode(e,t,s=null){return new $a(e,t,"emailLink",s)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e;if(t!=null&&t.email&&(t!=null&&t.password)){if(t.signInMethod==="password")return this._fromEmailAndPassword(t.email,t.password);if(t.signInMethod==="emailLink")return this._fromEmailAndCode(t.email,t.password,t.tenantId)}return null}async _getIdTokenResponse(e){switch(this.signInMethod){case"password":const t={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Yu(e,t,"signInWithPassword",c0);case"emailLink":return f0(e,{email:this._email,oobCode:this._password});default:Dn(e,"internal-error")}}async _linkToIdToken(e,t){switch(this.signInMethod){case"password":const s={idToken:t,returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Yu(e,s,"signUpPassword",u0);case"emailLink":return p0(e,{idToken:t,email:this._email,oobCode:this._password});default:Dn(e,"internal-error")}}_getReauthenticationResolver(e){return this._getIdTokenResponse(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ho(r,e){return tl(r,"POST","/v1/accounts:signInWithIdp",xr(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const m0="http://localhost";class us extends ef{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new us(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):Dn("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:s,signInMethod:o,...l}=t;if(!s||!o)return null;const h=new us(s,o);return h.idToken=l.idToken||void 0,h.accessToken=l.accessToken||void 0,h.secret=l.secret,h.nonce=l.nonce,h.pendingToken=l.pendingToken||null,h}_getIdTokenResponse(e){const t=this.buildRequest();return ho(e,t)}_linkToIdToken(e,t){const s=this.buildRequest();return s.idToken=t,ho(e,s)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,ho(e,t)}buildRequest(){const e={requestUri:m0,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=Xa(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function g0(r){switch(r){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function y0(r){const e=ka(Na(r)).link,t=e?ka(Na(e)).deep_link_id:null,s=ka(Na(r)).deep_link_id;return(s?ka(Na(s)).link:null)||s||t||e||r}class tf{constructor(e){const t=ka(Na(e)),s=t.apiKey??null,o=t.oobCode??null,l=g0(t.mode??null);pe(s&&o&&l,"argument-error"),this.apiKey=s,this.operation=l,this.code=o,this.continueUrl=t.continueUrl??null,this.languageCode=t.lang??null,this.tenantId=t.tenantId??null}static parseLink(e){const t=y0(e);try{return new tf(t)}catch{return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Co{constructor(){this.providerId=Co.PROVIDER_ID}static credential(e,t){return $a._fromEmailAndPassword(e,t)}static credentialWithLink(e,t){const s=tf.parseLink(t);return pe(s,"argument-error"),$a._fromEmailAndCode(e,s.code,s.tenantId)}}Co.PROVIDER_ID="password";Co.EMAIL_PASSWORD_SIGN_IN_METHOD="password";Co.EMAIL_LINK_SIGN_IN_METHOD="emailLink";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class v_{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nl extends v_{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ci extends nl{constructor(){super("facebook.com")}static credential(e){return us._fromParams({providerId:ci.PROVIDER_ID,signInMethod:ci.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return ci.credentialFromTaggedObject(e)}static credentialFromError(e){return ci.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return ci.credential(e.oauthAccessToken)}catch{return null}}}ci.FACEBOOK_SIGN_IN_METHOD="facebook.com";ci.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hi extends nl{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return us._fromParams({providerId:hi.PROVIDER_ID,signInMethod:hi.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return hi.credentialFromTaggedObject(e)}static credentialFromError(e){return hi.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:s}=e;if(!t&&!s)return null;try{return hi.credential(t,s)}catch{return null}}}hi.GOOGLE_SIGN_IN_METHOD="google.com";hi.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class di extends nl{constructor(){super("github.com")}static credential(e){return us._fromParams({providerId:di.PROVIDER_ID,signInMethod:di.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return di.credentialFromTaggedObject(e)}static credentialFromError(e){return di.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return di.credential(e.oauthAccessToken)}catch{return null}}}di.GITHUB_SIGN_IN_METHOD="github.com";di.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fi extends nl{constructor(){super("twitter.com")}static credential(e,t){return us._fromParams({providerId:fi.PROVIDER_ID,signInMethod:fi.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return fi.credentialFromTaggedObject(e)}static credentialFromError(e){return fi.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:s}=e;if(!t||!s)return null;try{return fi.credential(t,s)}catch{return null}}}fi.TWITTER_SIGN_IN_METHOD="twitter.com";fi.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function _0(r,e){return tl(r,"POST","/v1/accounts:signUp",xr(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cs{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,s,o=!1){const l=await kn._fromIdTokenResponse(e,s,o),h=Cg(s);return new cs({user:l,providerId:h,_tokenResponse:s,operationType:t})}static async _forOperation(e,t,s){await e._updateTokensIfNecessary(s,!0);const o=Cg(s);return new cs({user:e,providerId:o,_tokenResponse:s,operationType:t})}}function Cg(r){return r.providerId?r.providerId:"phoneNumber"in r?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ju extends Nr{constructor(e,t,s,o){super(t.code,t.message),this.operationType=s,this.user=o,Object.setPrototypeOf(this,Ju.prototype),this.customData={appName:e.name,tenantId:e.tenantId??void 0,_serverResponse:t.customData._serverResponse,operationType:s}}static _fromErrorAndOperation(e,t,s,o){return new Ju(e,t,s,o)}}function E_(r,e,t,s){return(e==="reauthenticate"?t._getReauthenticationResolver(r):t._getIdTokenResponse(r)).catch(l=>{throw l.code==="auth/multi-factor-auth-required"?Ju._fromErrorAndOperation(r,l,e,s):l})}async function v0(r,e,t=!1){const s=await Ba(r,e._linkToIdToken(r.auth,await r.getIdToken()),t);return cs._forOperation(r,"link",s)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function E0(r,e,t=!1){const{auth:s}=r;if(yn(s.app))return Promise.reject(Ar(s));const o="reauthenticate";try{const l=await Ba(r,E_(s,o,e,r),t);pe(l.idToken,s,"internal-error");const h=Xd(l.idToken);pe(h,s,"internal-error");const{sub:m}=h;return pe(r.uid===m,s,"user-mismatch"),cs._forOperation(r,o,l)}catch(l){throw(l==null?void 0:l.code)==="auth/user-not-found"&&Dn(s,"user-mismatch"),l}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function w_(r,e,t=!1){if(yn(r.app))return Promise.reject(Ar(r));const s="signIn",o=await E_(r,s,e),l=await cs._fromIdTokenResponse(r,s,o);return t||await r._updateCurrentUser(l.user),l}async function w0(r,e){return w_(Ci(r),e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function T_(r){const e=Ci(r);e._getPasswordPolicyInternal()&&await e._updatePasswordPolicy()}async function T0(r,e,t){const s=Ci(r);await Yu(s,{requestType:"PASSWORD_RESET",email:e,clientType:"CLIENT_TYPE_WEB"},"getOobCode",d0)}async function I0(r,e,t){if(yn(r.app))return Promise.reject(Ar(r));const s=Ci(r),h=await Yu(s,{returnSecureToken:!0,email:e,password:t,clientType:"CLIENT_TYPE_WEB"},"signUpPassword",_0).catch(g=>{throw g.code==="auth/password-does-not-meet-requirements"&&T_(r),g}),m=await cs._fromIdTokenResponse(s,"signIn",h);return await s._updateCurrentUser(m.user),m}function S0(r,e,t){return yn(r.app)?Promise.reject(Ar(r)):w0(Et(r),Co.credential(e,t)).catch(async s=>{throw s.code==="auth/password-does-not-meet-requirements"&&T_(r),s})}function A0(r,e,t,s){return Et(r).onIdTokenChanged(e,t,s)}function R0(r,e,t){return Et(r).beforeAuthStateChanged(e,t)}function C0(r,e,t,s){return Et(r).onAuthStateChanged(e,t,s)}function P0(r){return Et(r).signOut()}const Xu="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class I_{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(Xu,"1"),this.storage.removeItem(Xu),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const k0=1e3,N0=10;class S_ extends I_{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.fallbackToPolling=p_(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const s=this.storage.getItem(t),o=this.localCache[t];s!==o&&e(t,o,s)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((h,m,g)=>{this.notifyListeners(h,g)});return}const s=e.key;t?this.detachListener():this.stopPolling();const o=()=>{const h=this.storage.getItem(s);!t&&this.localCache[s]===h||this.notifyListeners(s,h)},l=this.storage.getItem(s);HI()&&l!==e.newValue&&e.newValue!==e.oldValue?setTimeout(o,N0):o()}notifyListeners(e,t){this.localCache[e]=t;const s=this.listeners[e];if(s)for(const o of Array.from(s))o(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,s)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:s}),!0)})},k0)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}S_.type="LOCAL";const x0=S_;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class A_ extends I_{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}A_.type="SESSION";const R_=A_;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function D0(r){return Promise.all(r.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mc{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(o=>o.isListeningto(e));if(t)return t;const s=new mc(e);return this.receivers.push(s),s}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:s,eventType:o,data:l}=t.data,h=this.handlersMap[o];if(!(h!=null&&h.size))return;t.ports[0].postMessage({status:"ack",eventId:s,eventType:o});const m=Array.from(h).map(async _=>_(t.origin,l)),g=await D0(m);t.ports[0].postMessage({status:"done",eventId:s,eventType:o,response:g})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}mc.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function nf(r="",e=10){let t="";for(let s=0;s<e;s++)t+=Math.floor(Math.random()*10);return r+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class V0{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,s=50){const o=typeof MessageChannel<"u"?new MessageChannel:null;if(!o)throw new Error("connection_unavailable");let l,h;return new Promise((m,g)=>{const _=nf("",20);o.port1.start();const E=setTimeout(()=>{g(new Error("unsupported_event"))},s);h={messageChannel:o,onMessage(I){const C=I;if(C.data.eventId===_)switch(C.data.status){case"ack":clearTimeout(E),l=setTimeout(()=>{g(new Error("timeout"))},3e3);break;case"done":clearTimeout(l),m(C.data.response);break;default:clearTimeout(E),clearTimeout(l),g(new Error("invalid_response"));break}}},this.handlers.add(h),o.port1.addEventListener("message",h.onMessage),this.target.postMessage({eventType:e,eventId:_,data:t},[o.port2])}).finally(()=>{h&&this.removeMessageHandler(h)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function er(){return window}function O0(r){er().location.href=r}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function C_(){return typeof er().WorkerGlobalScope<"u"&&typeof er().importScripts=="function"}async function L0(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function b0(){var r;return((r=navigator==null?void 0:navigator.serviceWorker)==null?void 0:r.controller)||null}function M0(){return C_()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const P_="firebaseLocalStorageDb",F0=1,Zu="firebaseLocalStorage",k_="fbase_key";class rl{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function gc(r,e){return r.transaction([Zu],e?"readwrite":"readonly").objectStore(Zu)}function U0(){const r=indexedDB.deleteDatabase(P_);return new rl(r).toPromise()}function Cd(){const r=indexedDB.open(P_,F0);return new Promise((e,t)=>{r.addEventListener("error",()=>{t(r.error)}),r.addEventListener("upgradeneeded",()=>{const s=r.result;try{s.createObjectStore(Zu,{keyPath:k_})}catch(o){t(o)}}),r.addEventListener("success",async()=>{const s=r.result;s.objectStoreNames.contains(Zu)?e(s):(s.close(),await U0(),e(await Cd()))})})}async function Pg(r,e,t){const s=gc(r,!0).put({[k_]:e,value:t});return new rl(s).toPromise()}async function j0(r,e){const t=gc(r,!1).get(e),s=await new rl(t).toPromise();return s===void 0?null:s.value}function kg(r,e){const t=gc(r,!0).delete(e);return new rl(t).toPromise()}const z0=800,B0=3;class N_{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await Cd(),this.db)}async _withRetries(e){let t=0;for(;;)try{const s=await this._openDb();return await e(s)}catch(s){if(t++>B0)throw s;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return C_()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=mc._getInstance(M0()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var t,s;if(this.activeServiceWorker=await L0(),!this.activeServiceWorker)return;this.sender=new V0(this.activeServiceWorker);const e=await this.sender._send("ping",{},800);e&&(t=e[0])!=null&&t.fulfilled&&(s=e[0])!=null&&s.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||b0()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await Cd();return await Pg(e,Xu,"1"),await kg(e,Xu),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(s=>Pg(s,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(s=>j0(s,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>kg(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(o=>{const l=gc(o,!1).getAll();return new rl(l).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],s=new Set;if(e.length!==0)for(const{fbase_key:o,value:l}of e)s.add(o),JSON.stringify(this.localCache[o])!==JSON.stringify(l)&&(this.notifyListeners(o,l),t.push(o));for(const o of Object.keys(this.localCache))this.localCache[o]&&!s.has(o)&&(this.notifyListeners(o,null),t.push(o));return t}notifyListeners(e,t){this.localCache[e]=t;const s=this.listeners[e];if(s)for(const o of Array.from(s))o(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),z0)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}N_.type="LOCAL";const $0=N_;new el(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function H0(r,e){return e?Sr(e):(pe(r._popupRedirectResolver,r,"argument-error"),r._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rf extends ef{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return ho(e,this._buildIdpRequest())}_linkToIdToken(e,t){return ho(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return ho(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function W0(r){return w_(r.auth,new rf(r),r.bypassAuthState)}function q0(r){const{auth:e,user:t}=r;return pe(t,e,"internal-error"),E0(t,new rf(r),r.bypassAuthState)}async function K0(r){const{auth:e,user:t}=r;return pe(t,e,"internal-error"),v0(t,new rf(r),r.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class x_{constructor(e,t,s,o,l=!1){this.auth=e,this.resolver=s,this.user=o,this.bypassAuthState=l,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(s){this.reject(s)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:s,postBody:o,tenantId:l,error:h,type:m}=e;if(h){this.reject(h);return}const g={auth:this.auth,requestUri:t,sessionId:s,tenantId:l||void 0,postBody:o||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(m)(g))}catch(_){this.reject(_)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return W0;case"linkViaPopup":case"linkViaRedirect":return K0;case"reauthViaPopup":case"reauthViaRedirect":return q0;default:Dn(this.auth,"internal-error")}}resolve(e){Cr(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){Cr(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const G0=new el(2e3,1e4);class lo extends x_{constructor(e,t,s,o,l){super(e,t,o,l),this.provider=s,this.authWindow=null,this.pollId=null,lo.currentPopupAction&&lo.currentPopupAction.cancel(),lo.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return pe(e,this.auth,"internal-error"),e}async onExecution(){Cr(this.filter.length===1,"Popup operations only handle one event");const e=nf();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(Zn(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)==null?void 0:e.associatedEvent)||null}cancel(){this.reject(Zn(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,lo.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,s;if((s=(t=this.authWindow)==null?void 0:t.window)!=null&&s.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(Zn(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,G0.get())};e()}}lo.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Q0="pendingRedirect",bu=new Map;class Y0 extends x_{constructor(e,t,s=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,s),this.eventId=null}async execute(){let e=bu.get(this.auth._key());if(!e){try{const s=await J0(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(s)}catch(t){e=()=>Promise.reject(t)}bu.set(this.auth._key(),e)}return this.bypassAuthState||bu.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function J0(r,e){const t=eS(e),s=Z0(r);if(!await s._isAvailable())return!1;const o=await s._get(t)==="true";return await s._remove(t),o}function X0(r,e){bu.set(r._key(),e)}function Z0(r){return Sr(r._redirectPersistence)}function eS(r){return Lu(Q0,r.config.apiKey,r.name)}async function tS(r,e,t=!1){if(yn(r.app))return Promise.reject(Ar(r));const s=Ci(r),o=H0(s,e),h=await new Y0(s,o,t).execute();return h&&!t&&(delete h.user._redirectEventId,await s._persistUserIfCurrent(h.user),await s._setRedirectUser(null,e)),h}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nS=600*1e3;class rS{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(s=>{this.isEventForConsumer(e,s)&&(t=!0,this.sendToConsumer(e,s),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!iS(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var s;if(e.error&&!D_(e)){const o=((s=e.error.code)==null?void 0:s.split("auth/")[1])||"internal-error";t.onError(Zn(this.auth,o))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const s=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&s}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=nS&&this.cachedEventUids.clear(),this.cachedEventUids.has(Ng(e))}saveEventToCache(e){this.cachedEventUids.add(Ng(e)),this.lastProcessedEventTime=Date.now()}}function Ng(r){return[r.type,r.eventId,r.sessionId,r.tenantId].filter(e=>e).join("-")}function D_({type:r,error:e}){return r==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function iS(r){switch(r.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return D_(r);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function sS(r,e={}){return Dr(r,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oS=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,aS=/^https?/;async function lS(r){if(r.config.emulator)return;const{authorizedDomains:e}=await sS(r);for(const t of e)try{if(uS(t))return}catch{}Dn(r,"unauthorized-domain")}function uS(r){const e=Ad(),{protocol:t,hostname:s}=new URL(e);if(r.startsWith("chrome-extension://")){const h=new URL(r);return h.hostname===""&&s===""?t==="chrome-extension:"&&r.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&h.hostname===s}if(!aS.test(t))return!1;if(oS.test(r))return s===r;const o=r.replace(/\./g,"\\.");return new RegExp("^(.+\\."+o+"|"+o+")$","i").test(s)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cS=new el(3e4,6e4);function xg(){const r=er().___jsl;if(r!=null&&r.H){for(const e of Object.keys(r.H))if(r.H[e].r=r.H[e].r||[],r.H[e].L=r.H[e].L||[],r.H[e].r=[...r.H[e].L],r.CP)for(let t=0;t<r.CP.length;t++)r.CP[t]=null}}function hS(r){return new Promise((e,t)=>{var o,l,h;function s(){xg(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{xg(),t(Zn(r,"network-request-failed"))},timeout:cS.get()})}if((l=(o=er().gapi)==null?void 0:o.iframes)!=null&&l.Iframe)e(gapi.iframes.getContext());else if((h=er().gapi)!=null&&h.load)s();else{const m=ZI("iframefcb");return er()[m]=()=>{gapi.load?s():t(Zn(r,"network-request-failed"))},g_(`${XI()}?onload=${m}`).catch(g=>t(g))}}).catch(e=>{throw Mu=null,e})}let Mu=null;function dS(r){return Mu=Mu||hS(r),Mu}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fS=new el(5e3,15e3),pS="__/auth/iframe",mS="emulator/auth/iframe",gS={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},yS=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function _S(r){const e=r.config;pe(e.authDomain,r,"auth-domain-config-required");const t=e.emulator?Jd(e,mS):`https://${r.config.authDomain}/${pS}`,s={apiKey:e.apiKey,appName:r.name,v:Ro},o=yS.get(r.config.apiHost);o&&(s.eid=o);const l=r._getFrameworks();return l.length&&(s.fw=l.join(",")),`${t}?${Xa(s).slice(1)}`}async function vS(r){const e=await dS(r),t=er().gapi;return pe(t,r,"internal-error"),e.open({where:document.body,url:_S(r),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:gS,dontclear:!0},s=>new Promise(async(o,l)=>{await s.restyle({setHideOnLeave:!1});const h=Zn(r,"network-request-failed"),m=er().setTimeout(()=>{l(h)},fS.get());function g(){er().clearTimeout(m),o(s)}s.ping(g).then(g,()=>{l(h)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ES={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},wS=500,TS=600,IS="_blank",SS="http://localhost";class Dg{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function AS(r,e,t,s=wS,o=TS){const l=Math.max((window.screen.availHeight-o)/2,0).toString(),h=Math.max((window.screen.availWidth-s)/2,0).toString();let m="";const g={...ES,width:s.toString(),height:o.toString(),top:l,left:h},_=jt().toLowerCase();t&&(m=u_(_)?IS:t),a_(_)&&(e=e||SS,g.scrollbars="yes");const E=Object.entries(g).reduce((C,[z,G])=>`${C}${z}=${G},`,"");if($I(_)&&m!=="_self")return RS(e||"",m),new Dg(null);const I=window.open(e||"",m,E);pe(I,r,"popup-blocked");try{I.focus()}catch{}return new Dg(I)}function RS(r,e){const t=document.createElement("a");t.href=r,t.target=e;const s=document.createEvent("MouseEvent");s.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(s)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const CS="__/auth/handler",PS="emulator/auth/handler",kS=encodeURIComponent("fac");async function Vg(r,e,t,s,o,l){pe(r.config.authDomain,r,"auth-domain-config-required"),pe(r.config.apiKey,r,"invalid-api-key");const h={apiKey:r.config.apiKey,appName:r.name,authType:t,redirectUrl:s,v:Ro,eventId:o};if(e instanceof v_){e.setDefaultLanguage(r.languageCode),h.providerId=e.providerId||"",uT(e.getCustomParameters())||(h.customParameters=JSON.stringify(e.getCustomParameters()));for(const[E,I]of Object.entries({}))h[E]=I}if(e instanceof nl){const E=e.getScopes().filter(I=>I!=="");E.length>0&&(h.scopes=E.join(","))}r.tenantId&&(h.tid=r.tenantId);const m=h;for(const E of Object.keys(m))m[E]===void 0&&delete m[E];const g=await r._getAppCheckToken(),_=g?`#${kS}=${encodeURIComponent(g)}`:"";return`${NS(r)}?${Xa(m).slice(1)}${_}`}function NS({config:r}){return r.emulator?Jd(r,PS):`https://${r.authDomain}/${CS}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pd="webStorageSupport";class xS{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=R_,this._completeRedirectFn=tS,this._overrideRedirectResult=X0}async _openPopup(e,t,s,o){var h;Cr((h=this.eventManagers[e._key()])==null?void 0:h.manager,"_initialize() not called before _openPopup()");const l=await Vg(e,t,s,Ad(),o);return AS(e,l,nf())}async _openRedirect(e,t,s,o){await this._originValidation(e);const l=await Vg(e,t,s,Ad(),o);return O0(l),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:o,promise:l}=this.eventManagers[t];return o?Promise.resolve(o):(Cr(l,"If manager is not set, promise should be"),l)}const s=this.initAndGetManager(e);return this.eventManagers[t]={promise:s},s.catch(()=>{delete this.eventManagers[t]}),s}async initAndGetManager(e){const t=await vS(e),s=new rS(e);return t.register("authEvent",o=>(pe(o==null?void 0:o.authEvent,e,"invalid-auth-event"),{status:s.onEvent(o.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:s},this.iframes[e._key()]=t,s}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(pd,{type:pd},o=>{var h;const l=(h=o==null?void 0:o[0])==null?void 0:h[pd];l!==void 0&&t(!!l),Dn(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=lS(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return p_()||l_()||Zd()}}const DS=xS;var Og="@firebase/auth",Lg="1.12.2";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class VS{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)==null?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(s=>{e((s==null?void 0:s.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){pe(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function OS(r){switch(r){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function LS(r){_o(new ls("auth",(e,{options:t})=>{const s=e.getProvider("app").getImmediate(),o=e.getProvider("heartbeat"),l=e.getProvider("app-check-internal"),{apiKey:h,authDomain:m}=s.options;pe(h&&!h.includes(":"),"invalid-api-key",{appName:s.name});const g={apiKey:h,authDomain:m,clientPlatform:r,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:m_(r)},_=new QI(s,o,l,g);return s0(_,t),_},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,s)=>{e.getProvider("auth-internal").initialize()})),_o(new ls("auth-internal",e=>{const t=Ci(e.getProvider("auth").getImmediate());return(s=>new VS(s))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),yi(Og,Lg,OS(r)),yi(Og,Lg,"esm2020")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bS=300,MS=Wy("authIdTokenMaxAge")||bS;let bg=null;const FS=r=>async e=>{const t=e&&await e.getIdTokenResult(),s=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(s&&s>MS)return;const o=t==null?void 0:t.token;bg!==o&&(bg=o,await fetch(r,{method:o?"POST":"DELETE",headers:o?{Authorization:`Bearer ${o}`}:{}}))};function US(r=Yy()){const e=Qd(r,"auth");if(e.isInitialized())return e.getImmediate();const t=i0(r,{popupRedirectResolver:DS,persistence:[$0,x0,R_]}),s=Wy("authTokenSyncURL");if(s&&typeof isSecureContext=="boolean"&&isSecureContext){const l=new URL(s,location.origin);if(location.origin===l.origin){const h=FS(l.toString());R0(t,h,()=>h(t.currentUser)),A0(t,m=>h(m))}}const o=$y("auth");return o&&o0(t,`http://${o}`),t}function jS(){var r;return((r=document.getElementsByTagName("head"))==null?void 0:r[0])??document}YI({loadJS(r){return new Promise((e,t)=>{const s=document.createElement("script");s.setAttribute("src",r),s.onload=e,s.onerror=o=>{const l=Zn("internal-error");l.customData=o,t(l)},s.type="text/javascript",s.charset="UTF-8",jS().appendChild(s)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});LS("Browser");var Mg=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var _i,V_;(function(){var r;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(D,T){function S(){}S.prototype=T.prototype,D.F=T.prototype,D.prototype=new S,D.prototype.constructor=D,D.D=function(N,k,V){for(var A=Array(arguments.length-2),Ie=2;Ie<arguments.length;Ie++)A[Ie-2]=arguments[Ie];return T.prototype[k].apply(N,A)}}function t(){this.blockSize=-1}function s(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}e(s,t),s.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function o(D,T,S){S||(S=0);const N=Array(16);if(typeof T=="string")for(var k=0;k<16;++k)N[k]=T.charCodeAt(S++)|T.charCodeAt(S++)<<8|T.charCodeAt(S++)<<16|T.charCodeAt(S++)<<24;else for(k=0;k<16;++k)N[k]=T[S++]|T[S++]<<8|T[S++]<<16|T[S++]<<24;T=D.g[0],S=D.g[1],k=D.g[2];let V=D.g[3],A;A=T+(V^S&(k^V))+N[0]+3614090360&4294967295,T=S+(A<<7&4294967295|A>>>25),A=V+(k^T&(S^k))+N[1]+3905402710&4294967295,V=T+(A<<12&4294967295|A>>>20),A=k+(S^V&(T^S))+N[2]+606105819&4294967295,k=V+(A<<17&4294967295|A>>>15),A=S+(T^k&(V^T))+N[3]+3250441966&4294967295,S=k+(A<<22&4294967295|A>>>10),A=T+(V^S&(k^V))+N[4]+4118548399&4294967295,T=S+(A<<7&4294967295|A>>>25),A=V+(k^T&(S^k))+N[5]+1200080426&4294967295,V=T+(A<<12&4294967295|A>>>20),A=k+(S^V&(T^S))+N[6]+2821735955&4294967295,k=V+(A<<17&4294967295|A>>>15),A=S+(T^k&(V^T))+N[7]+4249261313&4294967295,S=k+(A<<22&4294967295|A>>>10),A=T+(V^S&(k^V))+N[8]+1770035416&4294967295,T=S+(A<<7&4294967295|A>>>25),A=V+(k^T&(S^k))+N[9]+2336552879&4294967295,V=T+(A<<12&4294967295|A>>>20),A=k+(S^V&(T^S))+N[10]+4294925233&4294967295,k=V+(A<<17&4294967295|A>>>15),A=S+(T^k&(V^T))+N[11]+2304563134&4294967295,S=k+(A<<22&4294967295|A>>>10),A=T+(V^S&(k^V))+N[12]+1804603682&4294967295,T=S+(A<<7&4294967295|A>>>25),A=V+(k^T&(S^k))+N[13]+4254626195&4294967295,V=T+(A<<12&4294967295|A>>>20),A=k+(S^V&(T^S))+N[14]+2792965006&4294967295,k=V+(A<<17&4294967295|A>>>15),A=S+(T^k&(V^T))+N[15]+1236535329&4294967295,S=k+(A<<22&4294967295|A>>>10),A=T+(k^V&(S^k))+N[1]+4129170786&4294967295,T=S+(A<<5&4294967295|A>>>27),A=V+(S^k&(T^S))+N[6]+3225465664&4294967295,V=T+(A<<9&4294967295|A>>>23),A=k+(T^S&(V^T))+N[11]+643717713&4294967295,k=V+(A<<14&4294967295|A>>>18),A=S+(V^T&(k^V))+N[0]+3921069994&4294967295,S=k+(A<<20&4294967295|A>>>12),A=T+(k^V&(S^k))+N[5]+3593408605&4294967295,T=S+(A<<5&4294967295|A>>>27),A=V+(S^k&(T^S))+N[10]+38016083&4294967295,V=T+(A<<9&4294967295|A>>>23),A=k+(T^S&(V^T))+N[15]+3634488961&4294967295,k=V+(A<<14&4294967295|A>>>18),A=S+(V^T&(k^V))+N[4]+3889429448&4294967295,S=k+(A<<20&4294967295|A>>>12),A=T+(k^V&(S^k))+N[9]+568446438&4294967295,T=S+(A<<5&4294967295|A>>>27),A=V+(S^k&(T^S))+N[14]+3275163606&4294967295,V=T+(A<<9&4294967295|A>>>23),A=k+(T^S&(V^T))+N[3]+4107603335&4294967295,k=V+(A<<14&4294967295|A>>>18),A=S+(V^T&(k^V))+N[8]+1163531501&4294967295,S=k+(A<<20&4294967295|A>>>12),A=T+(k^V&(S^k))+N[13]+2850285829&4294967295,T=S+(A<<5&4294967295|A>>>27),A=V+(S^k&(T^S))+N[2]+4243563512&4294967295,V=T+(A<<9&4294967295|A>>>23),A=k+(T^S&(V^T))+N[7]+1735328473&4294967295,k=V+(A<<14&4294967295|A>>>18),A=S+(V^T&(k^V))+N[12]+2368359562&4294967295,S=k+(A<<20&4294967295|A>>>12),A=T+(S^k^V)+N[5]+4294588738&4294967295,T=S+(A<<4&4294967295|A>>>28),A=V+(T^S^k)+N[8]+2272392833&4294967295,V=T+(A<<11&4294967295|A>>>21),A=k+(V^T^S)+N[11]+1839030562&4294967295,k=V+(A<<16&4294967295|A>>>16),A=S+(k^V^T)+N[14]+4259657740&4294967295,S=k+(A<<23&4294967295|A>>>9),A=T+(S^k^V)+N[1]+2763975236&4294967295,T=S+(A<<4&4294967295|A>>>28),A=V+(T^S^k)+N[4]+1272893353&4294967295,V=T+(A<<11&4294967295|A>>>21),A=k+(V^T^S)+N[7]+4139469664&4294967295,k=V+(A<<16&4294967295|A>>>16),A=S+(k^V^T)+N[10]+3200236656&4294967295,S=k+(A<<23&4294967295|A>>>9),A=T+(S^k^V)+N[13]+681279174&4294967295,T=S+(A<<4&4294967295|A>>>28),A=V+(T^S^k)+N[0]+3936430074&4294967295,V=T+(A<<11&4294967295|A>>>21),A=k+(V^T^S)+N[3]+3572445317&4294967295,k=V+(A<<16&4294967295|A>>>16),A=S+(k^V^T)+N[6]+76029189&4294967295,S=k+(A<<23&4294967295|A>>>9),A=T+(S^k^V)+N[9]+3654602809&4294967295,T=S+(A<<4&4294967295|A>>>28),A=V+(T^S^k)+N[12]+3873151461&4294967295,V=T+(A<<11&4294967295|A>>>21),A=k+(V^T^S)+N[15]+530742520&4294967295,k=V+(A<<16&4294967295|A>>>16),A=S+(k^V^T)+N[2]+3299628645&4294967295,S=k+(A<<23&4294967295|A>>>9),A=T+(k^(S|~V))+N[0]+4096336452&4294967295,T=S+(A<<6&4294967295|A>>>26),A=V+(S^(T|~k))+N[7]+1126891415&4294967295,V=T+(A<<10&4294967295|A>>>22),A=k+(T^(V|~S))+N[14]+2878612391&4294967295,k=V+(A<<15&4294967295|A>>>17),A=S+(V^(k|~T))+N[5]+4237533241&4294967295,S=k+(A<<21&4294967295|A>>>11),A=T+(k^(S|~V))+N[12]+1700485571&4294967295,T=S+(A<<6&4294967295|A>>>26),A=V+(S^(T|~k))+N[3]+2399980690&4294967295,V=T+(A<<10&4294967295|A>>>22),A=k+(T^(V|~S))+N[10]+4293915773&4294967295,k=V+(A<<15&4294967295|A>>>17),A=S+(V^(k|~T))+N[1]+2240044497&4294967295,S=k+(A<<21&4294967295|A>>>11),A=T+(k^(S|~V))+N[8]+1873313359&4294967295,T=S+(A<<6&4294967295|A>>>26),A=V+(S^(T|~k))+N[15]+4264355552&4294967295,V=T+(A<<10&4294967295|A>>>22),A=k+(T^(V|~S))+N[6]+2734768916&4294967295,k=V+(A<<15&4294967295|A>>>17),A=S+(V^(k|~T))+N[13]+1309151649&4294967295,S=k+(A<<21&4294967295|A>>>11),A=T+(k^(S|~V))+N[4]+4149444226&4294967295,T=S+(A<<6&4294967295|A>>>26),A=V+(S^(T|~k))+N[11]+3174756917&4294967295,V=T+(A<<10&4294967295|A>>>22),A=k+(T^(V|~S))+N[2]+718787259&4294967295,k=V+(A<<15&4294967295|A>>>17),A=S+(V^(k|~T))+N[9]+3951481745&4294967295,D.g[0]=D.g[0]+T&4294967295,D.g[1]=D.g[1]+(k+(A<<21&4294967295|A>>>11))&4294967295,D.g[2]=D.g[2]+k&4294967295,D.g[3]=D.g[3]+V&4294967295}s.prototype.v=function(D,T){T===void 0&&(T=D.length);const S=T-this.blockSize,N=this.C;let k=this.h,V=0;for(;V<T;){if(k==0)for(;V<=S;)o(this,D,V),V+=this.blockSize;if(typeof D=="string"){for(;V<T;)if(N[k++]=D.charCodeAt(V++),k==this.blockSize){o(this,N),k=0;break}}else for(;V<T;)if(N[k++]=D[V++],k==this.blockSize){o(this,N),k=0;break}}this.h=k,this.o+=T},s.prototype.A=function(){var D=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);D[0]=128;for(var T=1;T<D.length-8;++T)D[T]=0;T=this.o*8;for(var S=D.length-8;S<D.length;++S)D[S]=T&255,T/=256;for(this.v(D),D=Array(16),T=0,S=0;S<4;++S)for(let N=0;N<32;N+=8)D[T++]=this.g[S]>>>N&255;return D};function l(D,T){var S=m;return Object.prototype.hasOwnProperty.call(S,D)?S[D]:S[D]=T(D)}function h(D,T){this.h=T;const S=[];let N=!0;for(let k=D.length-1;k>=0;k--){const V=D[k]|0;N&&V==T||(S[k]=V,N=!1)}this.g=S}var m={};function g(D){return-128<=D&&D<128?l(D,function(T){return new h([T|0],T<0?-1:0)}):new h([D|0],D<0?-1:0)}function _(D){if(isNaN(D)||!isFinite(D))return I;if(D<0)return B(_(-D));const T=[];let S=1;for(let N=0;D>=S;N++)T[N]=D/S|0,S*=4294967296;return new h(T,0)}function E(D,T){if(D.length==0)throw Error("number format error: empty string");if(T=T||10,T<2||36<T)throw Error("radix out of range: "+T);if(D.charAt(0)=="-")return B(E(D.substring(1),T));if(D.indexOf("-")>=0)throw Error('number format error: interior "-" character');const S=_(Math.pow(T,8));let N=I;for(let V=0;V<D.length;V+=8){var k=Math.min(8,D.length-V);const A=parseInt(D.substring(V,V+k),T);k<8?(k=_(Math.pow(T,k)),N=N.j(k).add(_(A))):(N=N.j(S),N=N.add(_(A)))}return N}var I=g(0),C=g(1),z=g(16777216);r=h.prototype,r.m=function(){if(Q(this))return-B(this).m();let D=0,T=1;for(let S=0;S<this.g.length;S++){const N=this.i(S);D+=(N>=0?N:4294967296+N)*T,T*=4294967296}return D},r.toString=function(D){if(D=D||10,D<2||36<D)throw Error("radix out of range: "+D);if(G(this))return"0";if(Q(this))return"-"+B(this).toString(D);const T=_(Math.pow(D,6));var S=this;let N="";for(;;){const k=Ae(S,T).g;S=te(S,k.j(T));let V=((S.g.length>0?S.g[0]:S.h)>>>0).toString(D);if(S=k,G(S))return V+N;for(;V.length<6;)V="0"+V;N=V+N}},r.i=function(D){return D<0?0:D<this.g.length?this.g[D]:this.h};function G(D){if(D.h!=0)return!1;for(let T=0;T<D.g.length;T++)if(D.g[T]!=0)return!1;return!0}function Q(D){return D.h==-1}r.l=function(D){return D=te(this,D),Q(D)?-1:G(D)?0:1};function B(D){const T=D.g.length,S=[];for(let N=0;N<T;N++)S[N]=~D.g[N];return new h(S,~D.h).add(C)}r.abs=function(){return Q(this)?B(this):this},r.add=function(D){const T=Math.max(this.g.length,D.g.length),S=[];let N=0;for(let k=0;k<=T;k++){let V=N+(this.i(k)&65535)+(D.i(k)&65535),A=(V>>>16)+(this.i(k)>>>16)+(D.i(k)>>>16);N=A>>>16,V&=65535,A&=65535,S[k]=A<<16|V}return new h(S,S[S.length-1]&-2147483648?-1:0)};function te(D,T){return D.add(B(T))}r.j=function(D){if(G(this)||G(D))return I;if(Q(this))return Q(D)?B(this).j(B(D)):B(B(this).j(D));if(Q(D))return B(this.j(B(D)));if(this.l(z)<0&&D.l(z)<0)return _(this.m()*D.m());const T=this.g.length+D.g.length,S=[];for(var N=0;N<2*T;N++)S[N]=0;for(N=0;N<this.g.length;N++)for(let k=0;k<D.g.length;k++){const V=this.i(N)>>>16,A=this.i(N)&65535,Ie=D.i(k)>>>16,He=D.i(k)&65535;S[2*N+2*k]+=A*He,fe(S,2*N+2*k),S[2*N+2*k+1]+=V*He,fe(S,2*N+2*k+1),S[2*N+2*k+1]+=A*Ie,fe(S,2*N+2*k+1),S[2*N+2*k+2]+=V*Ie,fe(S,2*N+2*k+2)}for(D=0;D<T;D++)S[D]=S[2*D+1]<<16|S[2*D];for(D=T;D<2*T;D++)S[D]=0;return new h(S,0)};function fe(D,T){for(;(D[T]&65535)!=D[T];)D[T+1]+=D[T]>>>16,D[T]&=65535,T++}function Ee(D,T){this.g=D,this.h=T}function Ae(D,T){if(G(T))throw Error("division by zero");if(G(D))return new Ee(I,I);if(Q(D))return T=Ae(B(D),T),new Ee(B(T.g),B(T.h));if(Q(T))return T=Ae(D,B(T)),new Ee(B(T.g),T.h);if(D.g.length>30){if(Q(D)||Q(T))throw Error("slowDivide_ only works with positive integers.");for(var S=C,N=T;N.l(D)<=0;)S=De(S),N=De(N);var k=Re(S,1),V=Re(N,1);for(N=Re(N,2),S=Re(S,2);!G(N);){var A=V.add(N);A.l(D)<=0&&(k=k.add(S),V=A),N=Re(N,1),S=Re(S,1)}return T=te(D,k.j(T)),new Ee(k,T)}for(k=I;D.l(T)>=0;){for(S=Math.max(1,Math.floor(D.m()/T.m())),N=Math.ceil(Math.log(S)/Math.LN2),N=N<=48?1:Math.pow(2,N-48),V=_(S),A=V.j(T);Q(A)||A.l(D)>0;)S-=N,V=_(S),A=V.j(T);G(V)&&(V=C),k=k.add(V),D=te(D,A)}return new Ee(k,D)}r.B=function(D){return Ae(this,D).h},r.and=function(D){const T=Math.max(this.g.length,D.g.length),S=[];for(let N=0;N<T;N++)S[N]=this.i(N)&D.i(N);return new h(S,this.h&D.h)},r.or=function(D){const T=Math.max(this.g.length,D.g.length),S=[];for(let N=0;N<T;N++)S[N]=this.i(N)|D.i(N);return new h(S,this.h|D.h)},r.xor=function(D){const T=Math.max(this.g.length,D.g.length),S=[];for(let N=0;N<T;N++)S[N]=this.i(N)^D.i(N);return new h(S,this.h^D.h)};function De(D){const T=D.g.length+1,S=[];for(let N=0;N<T;N++)S[N]=D.i(N)<<1|D.i(N-1)>>>31;return new h(S,D.h)}function Re(D,T){const S=T>>5;T%=32;const N=D.g.length-S,k=[];for(let V=0;V<N;V++)k[V]=T>0?D.i(V+S)>>>T|D.i(V+S+1)<<32-T:D.i(V+S);return new h(k,D.h)}s.prototype.digest=s.prototype.A,s.prototype.reset=s.prototype.u,s.prototype.update=s.prototype.v,V_=s,h.prototype.add=h.prototype.add,h.prototype.multiply=h.prototype.j,h.prototype.modulo=h.prototype.B,h.prototype.compare=h.prototype.l,h.prototype.toNumber=h.prototype.m,h.prototype.toString=h.prototype.toString,h.prototype.getBits=h.prototype.i,h.fromNumber=_,h.fromString=E,_i=h}).apply(typeof Mg<"u"?Mg:typeof self<"u"?self:typeof window<"u"?window:{});var ku=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var O_,xa,L_,Fu,Pd,b_,M_,F_;(function(){var r,e=Object.defineProperty;function t(u){u=[typeof globalThis=="object"&&globalThis,u,typeof window=="object"&&window,typeof self=="object"&&self,typeof ku=="object"&&ku];for(var p=0;p<u.length;++p){var y=u[p];if(y&&y.Math==Math)return y}throw Error("Cannot find global object")}var s=t(this);function o(u,p){if(p)e:{var y=s;u=u.split(".");for(var w=0;w<u.length-1;w++){var M=u[w];if(!(M in y))break e;y=y[M]}u=u[u.length-1],w=y[u],p=p(w),p!=w&&p!=null&&e(y,u,{configurable:!0,writable:!0,value:p})}}o("Symbol.dispose",function(u){return u||Symbol("Symbol.dispose")}),o("Array.prototype.values",function(u){return u||function(){return this[Symbol.iterator]()}}),o("Object.entries",function(u){return u||function(p){var y=[],w;for(w in p)Object.prototype.hasOwnProperty.call(p,w)&&y.push([w,p[w]]);return y}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var l=l||{},h=this||self;function m(u){var p=typeof u;return p=="object"&&u!=null||p=="function"}function g(u,p,y){return u.call.apply(u.bind,arguments)}function _(u,p,y){return _=g,_.apply(null,arguments)}function E(u,p){var y=Array.prototype.slice.call(arguments,1);return function(){var w=y.slice();return w.push.apply(w,arguments),u.apply(this,w)}}function I(u,p){function y(){}y.prototype=p.prototype,u.Z=p.prototype,u.prototype=new y,u.prototype.constructor=u,u.Ob=function(w,M,j){for(var X=Array(arguments.length-2),_e=2;_e<arguments.length;_e++)X[_e-2]=arguments[_e];return p.prototype[M].apply(w,X)}}var C=typeof AsyncContext<"u"&&typeof AsyncContext.Snapshot=="function"?u=>u&&AsyncContext.Snapshot.wrap(u):u=>u;function z(u){const p=u.length;if(p>0){const y=Array(p);for(let w=0;w<p;w++)y[w]=u[w];return y}return[]}function G(u,p){for(let w=1;w<arguments.length;w++){const M=arguments[w];var y=typeof M;if(y=y!="object"?y:M?Array.isArray(M)?"array":y:"null",y=="array"||y=="object"&&typeof M.length=="number"){y=u.length||0;const j=M.length||0;u.length=y+j;for(let X=0;X<j;X++)u[y+X]=M[X]}else u.push(M)}}class Q{constructor(p,y){this.i=p,this.j=y,this.h=0,this.g=null}get(){let p;return this.h>0?(this.h--,p=this.g,this.g=p.next,p.next=null):p=this.i(),p}}function B(u){h.setTimeout(()=>{throw u},0)}function te(){var u=D;let p=null;return u.g&&(p=u.g,u.g=u.g.next,u.g||(u.h=null),p.next=null),p}class fe{constructor(){this.h=this.g=null}add(p,y){const w=Ee.get();w.set(p,y),this.h?this.h.next=w:this.g=w,this.h=w}}var Ee=new Q(()=>new Ae,u=>u.reset());class Ae{constructor(){this.next=this.g=this.h=null}set(p,y){this.h=p,this.g=y,this.next=null}reset(){this.next=this.g=this.h=null}}let De,Re=!1,D=new fe,T=()=>{const u=Promise.resolve(void 0);De=()=>{u.then(S)}};function S(){for(var u;u=te();){try{u.h.call(u.g)}catch(y){B(y)}var p=Ee;p.j(u),p.h<100&&(p.h++,u.next=p.g,p.g=u)}Re=!1}function N(){this.u=this.u,this.C=this.C}N.prototype.u=!1,N.prototype.dispose=function(){this.u||(this.u=!0,this.N())},N.prototype[Symbol.dispose]=function(){this.dispose()},N.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function k(u,p){this.type=u,this.g=this.target=p,this.defaultPrevented=!1}k.prototype.h=function(){this.defaultPrevented=!0};var V=(function(){if(!h.addEventListener||!Object.defineProperty)return!1;var u=!1,p=Object.defineProperty({},"passive",{get:function(){u=!0}});try{const y=()=>{};h.addEventListener("test",y,p),h.removeEventListener("test",y,p)}catch{}return u})();function A(u){return/^[\s\xa0]*$/.test(u)}function Ie(u,p){k.call(this,u?u.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,u&&this.init(u,p)}I(Ie,k),Ie.prototype.init=function(u,p){const y=this.type=u.type,w=u.changedTouches&&u.changedTouches.length?u.changedTouches[0]:null;this.target=u.target||u.srcElement,this.g=p,p=u.relatedTarget,p||(y=="mouseover"?p=u.fromElement:y=="mouseout"&&(p=u.toElement)),this.relatedTarget=p,w?(this.clientX=w.clientX!==void 0?w.clientX:w.pageX,this.clientY=w.clientY!==void 0?w.clientY:w.pageY,this.screenX=w.screenX||0,this.screenY=w.screenY||0):(this.clientX=u.clientX!==void 0?u.clientX:u.pageX,this.clientY=u.clientY!==void 0?u.clientY:u.pageY,this.screenX=u.screenX||0,this.screenY=u.screenY||0),this.button=u.button,this.key=u.key||"",this.ctrlKey=u.ctrlKey,this.altKey=u.altKey,this.shiftKey=u.shiftKey,this.metaKey=u.metaKey,this.pointerId=u.pointerId||0,this.pointerType=u.pointerType,this.state=u.state,this.i=u,u.defaultPrevented&&Ie.Z.h.call(this)},Ie.prototype.h=function(){Ie.Z.h.call(this);const u=this.i;u.preventDefault?u.preventDefault():u.returnValue=!1};var He="closure_listenable_"+(Math.random()*1e6|0),ut=0;function Be(u,p,y,w,M){this.listener=u,this.proxy=null,this.src=p,this.type=y,this.capture=!!w,this.ha=M,this.key=++ut,this.da=this.fa=!1}function Z(u){u.da=!0,u.listener=null,u.proxy=null,u.src=null,u.ha=null}function ae(u,p,y){for(const w in u)p.call(y,u[w],w,u)}function ee(u,p){for(const y in u)p.call(void 0,u[y],y,u)}function L(u){const p={};for(const y in u)p[y]=u[y];return p}const W="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function we(u,p){let y,w;for(let M=1;M<arguments.length;M++){w=arguments[M];for(y in w)u[y]=w[y];for(let j=0;j<W.length;j++)y=W[j],Object.prototype.hasOwnProperty.call(w,y)&&(u[y]=w[y])}}function Te(u){this.src=u,this.g={},this.h=0}Te.prototype.add=function(u,p,y,w,M){const j=u.toString();u=this.g[j],u||(u=this.g[j]=[],this.h++);const X=Pe(u,p,w,M);return X>-1?(p=u[X],y||(p.fa=!1)):(p=new Be(p,this.src,j,!!w,M),p.fa=y,u.push(p)),p};function Ce(u,p){const y=p.type;if(y in u.g){var w=u.g[y],M=Array.prototype.indexOf.call(w,p,void 0),j;(j=M>=0)&&Array.prototype.splice.call(w,M,1),j&&(Z(p),u.g[y].length==0&&(delete u.g[y],u.h--))}}function Pe(u,p,y,w){for(let M=0;M<u.length;++M){const j=u[M];if(!j.da&&j.listener==p&&j.capture==!!y&&j.ha==w)return M}return-1}var je="closure_lm_"+(Math.random()*1e6|0),Le={};function We(u,p,y,w,M){if(Array.isArray(p)){for(let j=0;j<p.length;j++)We(u,p[j],y,w,M);return null}return y=Oo(y),u&&u[He]?u.J(p,y,m(w)?!!w.capture:!1,M):zt(u,p,y,!1,w,M)}function zt(u,p,y,w,M,j){if(!p)throw Error("Invalid event type");const X=m(M)?!!M.capture:!!M;let _e=_s(u);if(_e||(u[je]=_e=new Te(u)),y=_e.add(p,y,w,X,j),y.proxy)return y;if(w=gs(),y.proxy=w,w.src=u,w.listener=y,u.addEventListener)V||(M=X),M===void 0&&(M=!1),u.addEventListener(p.toString(),w,M);else if(u.attachEvent)u.attachEvent(ys(p.toString()),w);else if(u.addListener&&u.removeListener)u.addListener(w);else throw Error("addEventListener and attachEvent are unavailable.");return y}function gs(){function u(y){return p.call(u.src,u.listener,y)}const p=hl;return u}function Vo(u,p,y,w,M){if(Array.isArray(p))for(var j=0;j<p.length;j++)Vo(u,p[j],y,w,M);else w=m(w)?!!w.capture:!!w,y=Oo(y),u&&u[He]?(u=u.i,j=String(p).toString(),j in u.g&&(p=u.g[j],y=Pe(p,y,w,M),y>-1&&(Z(p[y]),Array.prototype.splice.call(p,y,1),p.length==0&&(delete u.g[j],u.h--)))):u&&(u=_s(u))&&(p=u.g[p.toString()],u=-1,p&&(u=Pe(p,y,w,M)),(y=u>-1?p[u]:null)&&Vr(y))}function Vr(u){if(typeof u!="number"&&u&&!u.da){var p=u.src;if(p&&p[He])Ce(p.i,u);else{var y=u.type,w=u.proxy;p.removeEventListener?p.removeEventListener(y,w,u.capture):p.detachEvent?p.detachEvent(ys(y),w):p.addListener&&p.removeListener&&p.removeListener(w),(y=_s(p))?(Ce(y,u),y.h==0&&(y.src=null,p[je]=null)):Z(u)}}}function ys(u){return u in Le?Le[u]:Le[u]="on"+u}function hl(u,p){if(u.da)u=!0;else{p=new Ie(p,this);const y=u.listener,w=u.ha||u.src;u.fa&&Vr(u),u=y.call(w,p)}return u}function _s(u){return u=u[je],u instanceof Te?u:null}var Ni="__closure_events_fn_"+(Math.random()*1e9>>>0);function Oo(u){return typeof u=="function"?u:(u[Ni]||(u[Ni]=function(p){return u.handleEvent(p)}),u[Ni])}function ct(){N.call(this),this.i=new Te(this),this.M=this,this.G=null}I(ct,N),ct.prototype[He]=!0,ct.prototype.removeEventListener=function(u,p,y,w){Vo(this,u,p,y,w)};function st(u,p){var y,w=u.G;if(w)for(y=[];w;w=w.G)y.push(w);if(u=u.M,w=p.type||p,typeof p=="string")p=new k(p,u);else if(p instanceof k)p.target=p.target||u;else{var M=p;p=new k(w,u),we(p,M)}M=!0;let j,X;if(y)for(X=y.length-1;X>=0;X--)j=p.g=y[X],M=vn(j,w,!0,p)&&M;if(j=p.g=u,M=vn(j,w,!0,p)&&M,M=vn(j,w,!1,p)&&M,y)for(X=0;X<y.length;X++)j=p.g=y[X],M=vn(j,w,!1,p)&&M}ct.prototype.N=function(){if(ct.Z.N.call(this),this.i){var u=this.i;for(const p in u.g){const y=u.g[p];for(let w=0;w<y.length;w++)Z(y[w]);delete u.g[p],u.h--}}this.G=null},ct.prototype.J=function(u,p,y,w){return this.i.add(String(u),p,!1,y,w)},ct.prototype.K=function(u,p,y,w){return this.i.add(String(u),p,!0,y,w)};function vn(u,p,y,w){if(p=u.i.g[String(p)],!p)return!0;p=p.concat();let M=!0;for(let j=0;j<p.length;++j){const X=p[j];if(X&&!X.da&&X.capture==y){const _e=X.listener,ot=X.ha||X.src;X.fa&&Ce(u.i,X),M=_e.call(ot,w)!==!1&&M}}return M&&!w.defaultPrevented}function Lo(u,p){if(typeof u!="function")if(u&&typeof u.handleEvent=="function")u=_(u.handleEvent,u);else throw Error("Invalid listener argument");return Number(p)>2147483647?-1:h.setTimeout(u,p||0)}function bo(u){u.g=Lo(()=>{u.g=null,u.i&&(u.i=!1,bo(u))},u.l);const p=u.h;u.h=null,u.m.apply(null,p)}class dl extends N{constructor(p,y){super(),this.m=p,this.l=y,this.h=null,this.i=!1,this.g=null}j(p){this.h=arguments,this.g?this.i=!0:bo(this)}N(){super.N(),this.g&&(h.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function Or(u){N.call(this),this.h=u,this.g={}}I(Or,N);var Mo=[];function vs(u){ae(u.g,function(p,y){this.g.hasOwnProperty(y)&&Vr(p)},u),u.g={}}Or.prototype.N=function(){Or.Z.N.call(this),vs(this)},Or.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var Lr=h.JSON.stringify,fl=h.JSON.parse,xi=class{stringify(u){return h.JSON.stringify(u,void 0)}parse(u){return h.JSON.parse(u,void 0)}};function br(){}function pl(){}var Mr={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function Es(){k.call(this,"d")}I(Es,k);function Fo(){k.call(this,"c")}I(Fo,k);var En={},ws=null;function Fr(){return ws=ws||new ct}En.Ia="serverreachability";function Ts(u){k.call(this,En.Ia,u)}I(Ts,k);function sr(u){const p=Fr();st(p,new Ts(p))}En.STAT_EVENT="statevent";function or(u,p){k.call(this,En.STAT_EVENT,u),this.stat=p}I(or,k);function rt(u){const p=Fr();st(p,new or(p,u))}En.Ja="timingevent";function Uo(u,p){k.call(this,En.Ja,u),this.size=p}I(Uo,k);function Ur(u,p){if(typeof u!="function")throw Error("Fn must not be null and must be a function");return h.setTimeout(function(){u()},p)}function jr(){this.g=!0}jr.prototype.ua=function(){this.g=!1};function ml(u,p,y,w,M,j){u.info(function(){if(u.g)if(j){var X="",_e=j.split("&");for(let $e=0;$e<_e.length;$e++){var ot=_e[$e].split("=");if(ot.length>1){const ht=ot[0];ot=ot[1];const rn=ht.split("_");X=rn.length>=2&&rn[1]=="type"?X+(ht+"="+ot+"&"):X+(ht+"=redacted&")}}}else X=null;else X=j;return"XMLHTTP REQ ("+w+") [attempt "+M+"]: "+p+`
`+y+`
`+X})}function gl(u,p,y,w,M,j,X){u.info(function(){return"XMLHTTP RESP ("+w+") [ attempt "+M+"]: "+p+`
`+y+`
`+j+" "+X})}function On(u,p,y,w){u.info(function(){return"XMLHTTP TEXT ("+p+"): "+Di(u,y)+(w?" "+w:"")})}function yl(u,p){u.info(function(){return"TIMEOUT: "+p})}jr.prototype.info=function(){};function Di(u,p){if(!u.g)return p;if(!p)return null;try{const j=JSON.parse(p);if(j){for(u=0;u<j.length;u++)if(Array.isArray(j[u])){var y=j[u];if(!(y.length<2)){var w=y[1];if(Array.isArray(w)&&!(w.length<1)){var M=w[0];if(M!="noop"&&M!="stop"&&M!="close")for(let X=1;X<w.length;X++)w[X]=""}}}}return Lr(j)}catch{return p}}var zr={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},Br={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"},_l;function ar(){}I(ar,br),ar.prototype.g=function(){return new XMLHttpRequest},_l=new ar;function Ln(u){return encodeURIComponent(String(u))}function Is(u){var p=1;u=u.split(":");const y=[];for(;p>0&&u.length;)y.push(u.shift()),p--;return u.length&&y.push(u.join(":")),y}function un(u,p,y,w){this.j=u,this.i=p,this.l=y,this.S=w||1,this.V=new Or(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new vl}function vl(){this.i=null,this.g="",this.h=!1}var El={},jo={};function wn(u,p,y){u.M=1,u.A=ur(cn(p)),u.u=y,u.R=!0,zo(u,null)}function zo(u,p){u.F=Date.now(),Vi(u),u.B=cn(u.A);var y=u.B,w=u.S;Array.isArray(w)||(w=[String(w)]),Jo(y.i,"t",w),u.C=0,y=u.j.L,u.h=new vl,u.g=Nl(u.j,y?p:null,!u.u),u.P>0&&(u.O=new dl(_(u.Y,u,u.g),u.P)),p=u.V,y=u.g,w=u.ba;var M="readystatechange";Array.isArray(M)||(M&&(Mo[0]=M.toString()),M=Mo);for(let j=0;j<M.length;j++){const X=We(y,M[j],w||p.handleEvent,!1,p.h||p);if(!X)break;p.g[X.key]=X}p=u.J?L(u.J):{},u.u?(u.v||(u.v="POST"),p["Content-Type"]="application/x-www-form-urlencoded",u.g.ea(u.B,u.v,u.u,p)):(u.v="GET",u.g.ea(u.B,u.v,null,p)),sr(),ml(u.i,u.v,u.B,u.l,u.S,u.u)}un.prototype.ba=function(u){u=u.target;const p=this.O;p&&Bn(u)==3?p.j():this.Y(u)},un.prototype.Y=function(u){try{if(u==this.g)e:{const _e=Bn(this.g),ot=this.g.ya(),$e=this.g.ca();if(!(_e<3)&&(_e!=3||this.g&&(this.h.h||this.g.la()||Pl(this.g)))){this.K||_e!=4||ot==7||(ot==8||$e<=0?sr(3):sr(2)),Ss(this);var p=this.g.ca();this.X=p;var y=wl(this);if(this.o=p==200,gl(this.i,this.v,this.B,this.l,this.S,_e,p),this.o){if(this.U&&!this.L){t:{if(this.g){var w,M=this.g;if((w=M.g?M.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!A(w)){var j=w;break t}}j=null}if(u=j)On(this.i,this.l,u,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,Qe(this,u);else{this.o=!1,this.m=3,rt(12),lr(this),Oi(this);break e}}if(this.R){u=!0;let ht;for(;!this.K&&this.C<y.length;)if(ht=Il(this,y),ht==jo){_e==4&&(this.m=4,rt(14),u=!1),On(this.i,this.l,null,"[Incomplete Response]");break}else if(ht==El){this.m=4,rt(15),On(this.i,this.l,y,"[Invalid Chunk]"),u=!1;break}else On(this.i,this.l,ht,null),Qe(this,ht);if(Tl(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),_e!=4||y.length!=0||this.h.h||(this.m=1,rt(16),u=!1),this.o=this.o&&u,!u)On(this.i,this.l,y,"[Invalid Chunked Response]"),lr(this),Oi(this);else if(y.length>0&&!this.W){this.W=!0;var X=this.j;X.g==this&&X.aa&&!X.P&&(X.j.info("Great, no buffering proxy detected. Bytes received: "+y.length),$i(X),X.P=!0,rt(11))}}else On(this.i,this.l,y,null),Qe(this,y);_e==4&&lr(this),this.o&&!this.K&&(_e==4?Os(this.j,this):(this.o=!1,Vi(this)))}else Zo(this.g),p==400&&y.indexOf("Unknown SID")>0?(this.m=3,rt(12)):(this.m=0,rt(13)),lr(this),Oi(this)}}}catch{}finally{}};function wl(u){if(!Tl(u))return u.g.la();const p=Pl(u.g);if(p==="")return"";let y="";const w=p.length,M=Bn(u.g)==4;if(!u.h.i){if(typeof TextDecoder>"u")return lr(u),Oi(u),"";u.h.i=new h.TextDecoder}for(let j=0;j<w;j++)u.h.h=!0,y+=u.h.i.decode(p[j],{stream:!(M&&j==w-1)});return p.length=0,u.h.g+=y,u.C=0,u.h.g}function Tl(u){return u.g?u.v=="GET"&&u.M!=2&&u.j.Aa:!1}function Il(u,p){var y=u.C,w=p.indexOf(`
`,y);return w==-1?jo:(y=Number(p.substring(y,w)),isNaN(y)?El:(w+=1,w+y>p.length?jo:(p=p.slice(w,w+y),u.C=w+y,p)))}un.prototype.cancel=function(){this.K=!0,lr(this)};function Vi(u){u.T=Date.now()+u.H,Bo(u,u.H)}function Bo(u,p){if(u.D!=null)throw Error("WatchDog timer not null");u.D=Ur(_(u.aa,u),p)}function Ss(u){u.D&&(h.clearTimeout(u.D),u.D=null)}un.prototype.aa=function(){this.D=null;const u=Date.now();u-this.T>=0?(yl(this.i,this.B),this.M!=2&&(sr(),rt(17)),lr(this),this.m=2,Oi(this)):Bo(this,this.T-u)};function Oi(u){u.j.I==0||u.K||Os(u.j,u)}function lr(u){Ss(u);var p=u.O;p&&typeof p.dispose=="function"&&p.dispose(),u.O=null,vs(u.V),u.g&&(p=u.g,u.g=null,p.abort(),p.dispose())}function Qe(u,p){try{var y=u.j;if(y.I!=0&&(y.g==u||Ho(y.h,u))){if(!u.L&&Ho(y.h,u)&&y.I==3){try{var w=y.Ba.g.parse(p)}catch{w=null}if(Array.isArray(w)&&w.length==3){var M=w;if(M[0]==0){e:if(!y.v){if(y.g)if(y.g.F+3e3<u.F)Vs(y),tn(y);else break e;Wn(y),rt(18)}}else y.xa=M[1],0<y.xa-y.K&&M[2]<37500&&y.F&&y.A==0&&!y.C&&(y.C=Ur(_(y.Va,y),6e3));Li(y.h)<=1&&y.ta&&(y.ta=void 0)}else nn(y,11)}else if((u.L||y.g==u)&&Vs(y),!A(p))for(M=y.Ba.g.parse(p),p=0;p<M.length;p++){let $e=M[p];const ht=$e[0];if(!(ht<=y.K))if(y.K=ht,$e=$e[1],y.I==2)if($e[0]=="c"){y.M=$e[1],y.ba=$e[2];const rn=$e[3];rn!=null&&(y.ka=rn,y.j.info("VER="+y.ka));const pr=$e[4];pr!=null&&(y.za=pr,y.j.info("SVER="+y.za));const qn=$e[5];qn!=null&&typeof qn=="number"&&qn>0&&(w=1.5*qn,y.O=w,y.j.info("backChannelRequestTimeoutMs_="+w)),w=y;const Kn=u.g;if(Kn){const Ms=Kn.g?Kn.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(Ms){var j=w.h;j.g||Ms.indexOf("spdy")==-1&&Ms.indexOf("quic")==-1&&Ms.indexOf("h2")==-1||(j.j=j.l,j.g=new Set,j.h&&(Rs(j,j.h),j.h=null))}if(w.G){const na=Kn.g?Kn.g.getResponseHeader("X-HTTP-Session-Id"):null;na&&(w.wa=na,Fe(w.J,w.G,na))}}y.I=3,y.l&&y.l.ra(),y.aa&&(y.T=Date.now()-u.F,y.j.info("Handshake RTT: "+y.T+"ms")),w=y;var X=u;if(w.na=ta(w,w.L?w.ba:null,w.W),X.L){bi(w.h,X);var _e=X,ot=w.O;ot&&(_e.H=ot),_e.D&&(Ss(_e),Vi(_e)),w.g=X}else Dt(w);y.i.length>0&&fr(y)}else $e[0]!="stop"&&$e[0]!="close"||nn(y,7);else y.I==3&&($e[0]=="stop"||$e[0]=="close"?$e[0]=="stop"?nn(y,7):xs(y):$e[0]!="noop"&&y.l&&y.l.qa($e),y.A=0)}}sr(4)}catch{}}var Vc=class{constructor(u,p){this.g=u,this.map=p}};function As(u){this.l=u||10,h.PerformanceNavigationTiming?(u=h.performance.getEntriesByType("navigation"),u=u.length>0&&(u[0].nextHopProtocol=="hq"||u[0].nextHopProtocol=="h2")):u=!!(h.chrome&&h.chrome.loadTimes&&h.chrome.loadTimes()&&h.chrome.loadTimes().wasFetchedViaSpdy),this.j=u?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function $o(u){return u.h?!0:u.g?u.g.size>=u.j:!1}function Li(u){return u.h?1:u.g?u.g.size:0}function Ho(u,p){return u.h?u.h==p:u.g?u.g.has(p):!1}function Rs(u,p){u.g?u.g.add(p):u.h=p}function bi(u,p){u.h&&u.h==p?u.h=null:u.g&&u.g.has(p)&&u.g.delete(p)}As.prototype.cancel=function(){if(this.i=Xt(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const u of this.g.values())u.cancel();this.g.clear()}};function Xt(u){if(u.h!=null)return u.i.concat(u.h.G);if(u.g!=null&&u.g.size!==0){let p=u.i;for(const y of u.g.values())p=p.concat(y.G);return p}return z(u.i)}var Sl=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function Zt(u,p){if(u){u=u.split("&");for(let y=0;y<u.length;y++){const w=u[y].indexOf("=");let M,j=null;w>=0?(M=u[y].substring(0,w),j=u[y].substring(w+1)):M=u[y],p(M,j?decodeURIComponent(j.replace(/\+/g," ")):"")}}}function bn(u){this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1;let p;u instanceof bn?(this.l=u.l,Mi(this,u.j),this.o=u.o,this.g=u.g,Mn(this,u.u),this.h=u.h,$r(this,Xo(u.i)),this.m=u.m):u&&(p=String(u).match(Sl))?(this.l=!1,Mi(this,p[1]||"",!0),this.o=Fi(p[2]||""),this.g=Fi(p[3]||"",!0),Mn(this,p[4]),this.h=Fi(p[5]||"",!0),$r(this,p[6]||"",!0),this.m=Fi(p[7]||"")):(this.l=!1,this.i=new Ve(null,this.l))}bn.prototype.toString=function(){const u=[];var p=this.j;p&&u.push(Ui(p,qo,!0),":");var y=this.g;return(y||p=="file")&&(u.push("//"),(p=this.o)&&u.push(Ui(p,qo,!0),"@"),u.push(Ln(y).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),y=this.u,y!=null&&u.push(":",String(y))),(y=this.h)&&(this.g&&y.charAt(0)!="/"&&u.push("/"),u.push(Ui(y,y.charAt(0)=="/"?ji:Ko,!0))),(y=this.i.toString())&&u.push("?",y),(y=this.m)&&u.push("#",Ui(y,Go)),u.join("")},bn.prototype.resolve=function(u){const p=cn(this);let y=!!u.j;y?Mi(p,u.j):y=!!u.o,y?p.o=u.o:y=!!u.g,y?p.g=u.g:y=u.u!=null;var w=u.h;if(y)Mn(p,u.u);else if(y=!!u.h){if(w.charAt(0)!="/")if(this.g&&!this.h)w="/"+w;else{var M=p.h.lastIndexOf("/");M!=-1&&(w=p.h.slice(0,M+1)+w)}if(M=w,M==".."||M==".")w="";else if(M.indexOf("./")!=-1||M.indexOf("/.")!=-1){w=M.lastIndexOf("/",0)==0,M=M.split("/");const j=[];for(let X=0;X<M.length;){const _e=M[X++];_e=="."?w&&X==M.length&&j.push(""):_e==".."?((j.length>1||j.length==1&&j[0]!="")&&j.pop(),w&&X==M.length&&j.push("")):(j.push(_e),w=!0)}w=j.join("/")}else w=M}return y?p.h=w:y=u.i.toString()!=="",y?$r(p,Xo(u.i)):y=!!u.m,y&&(p.m=u.m),p};function cn(u){return new bn(u)}function Mi(u,p,y){u.j=y?Fi(p,!0):p,u.j&&(u.j=u.j.replace(/:$/,""))}function Mn(u,p){if(p){if(p=Number(p),isNaN(p)||p<0)throw Error("Bad port number "+p);u.u=p}else u.u=null}function $r(u,p,y){p instanceof Ve?(u.i=p,Ps(u.i,u.l)):(y||(p=Ui(p,Oc)),u.i=new Ve(p,u.l))}function Fe(u,p,y){u.i.set(p,y)}function ur(u){return Fe(u,"zx",Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)),u}function Fi(u,p){return u?p?decodeURI(u.replace(/%25/g,"%2525")):decodeURIComponent(u):""}function Ui(u,p,y){return typeof u=="string"?(u=encodeURI(u).replace(p,Wo),y&&(u=u.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),u):null}function Wo(u){return u=u.charCodeAt(0),"%"+(u>>4&15).toString(16)+(u&15).toString(16)}var qo=/[#\/\?@]/g,Ko=/[#\?:]/g,ji=/[#\?]/g,Oc=/[#\?@]/g,Go=/#/g;function Ve(u,p){this.h=this.g=null,this.i=u||null,this.j=!!p}function Fn(u){u.g||(u.g=new Map,u.h=0,u.i&&Zt(u.i,function(p,y){u.add(decodeURIComponent(p.replace(/\+/g," ")),y)}))}r=Ve.prototype,r.add=function(u,p){Fn(this),this.i=null,u=Un(this,u);let y=this.g.get(u);return y||this.g.set(u,y=[]),y.push(p),this.h+=1,this};function Qo(u,p){Fn(u),p=Un(u,p),u.g.has(p)&&(u.i=null,u.h-=u.g.get(p).length,u.g.delete(p))}function Cs(u,p){return Fn(u),p=Un(u,p),u.g.has(p)}r.forEach=function(u,p){Fn(this),this.g.forEach(function(y,w){y.forEach(function(M){u.call(p,M,w,this)},this)},this)};function Yo(u,p){Fn(u);let y=[];if(typeof p=="string")Cs(u,p)&&(y=y.concat(u.g.get(Un(u,p))));else for(u=Array.from(u.g.values()),p=0;p<u.length;p++)y=y.concat(u[p]);return y}r.set=function(u,p){return Fn(this),this.i=null,u=Un(this,u),Cs(this,u)&&(this.h-=this.g.get(u).length),this.g.set(u,[p]),this.h+=1,this},r.get=function(u,p){return u?(u=Yo(this,u),u.length>0?String(u[0]):p):p};function Jo(u,p,y){Qo(u,p),y.length>0&&(u.i=null,u.g.set(Un(u,p),z(y)),u.h+=y.length)}r.toString=function(){if(this.i)return this.i;if(!this.g)return"";const u=[],p=Array.from(this.g.keys());for(let w=0;w<p.length;w++){var y=p[w];const M=Ln(y);y=Yo(this,y);for(let j=0;j<y.length;j++){let X=M;y[j]!==""&&(X+="="+Ln(y[j])),u.push(X)}}return this.i=u.join("&")};function Xo(u){const p=new Ve;return p.i=u.i,u.g&&(p.g=new Map(u.g),p.h=u.h),p}function Un(u,p){return p=String(p),u.j&&(p=p.toLowerCase()),p}function Ps(u,p){p&&!u.j&&(Fn(u),u.i=null,u.g.forEach(function(y,w){const M=w.toLowerCase();w!=M&&(Qo(this,w),Jo(this,M,y))},u)),u.j=p}function jn(u,p){const y=new jr;if(h.Image){const w=new Image;w.onload=E(At,y,"TestLoadImage: loaded",!0,p,w),w.onerror=E(At,y,"TestLoadImage: error",!1,p,w),w.onabort=E(At,y,"TestLoadImage: abort",!1,p,w),w.ontimeout=E(At,y,"TestLoadImage: timeout",!1,p,w),h.setTimeout(function(){w.ontimeout&&w.ontimeout()},1e4),w.src=u}else p(!1)}function zn(u,p){const y=new jr,w=new AbortController,M=setTimeout(()=>{w.abort(),At(y,"TestPingServer: timeout",!1,p)},1e4);fetch(u,{signal:w.signal}).then(j=>{clearTimeout(M),j.ok?At(y,"TestPingServer: ok",!0,p):At(y,"TestPingServer: server error",!1,p)}).catch(()=>{clearTimeout(M),At(y,"TestPingServer: error",!1,p)})}function At(u,p,y,w,M){try{M&&(M.onload=null,M.onerror=null,M.onabort=null,M.ontimeout=null),w(y)}catch{}}function zi(){this.g=new xi}function cr(u){this.i=u.Sb||null,this.h=u.ab||!1}I(cr,br),cr.prototype.g=function(){return new en(this.i,this.h)};function en(u,p){ct.call(this),this.H=u,this.o=p,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}I(en,ct),r=en.prototype,r.open=function(u,p){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.F=u,this.D=p,this.readyState=1,Tn(this)},r.send=function(u){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const p={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};u&&(p.body=u),(this.H||h).fetch(new Request(this.D,p)).then(this.Pa.bind(this),this.ga.bind(this))},r.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&this.readyState!=4&&(this.g=!1,Hr(this)),this.readyState=0},r.Pa=function(u){if(this.g&&(this.l=u,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=u.headers,this.readyState=2,Tn(this)),this.g&&(this.readyState=3,Tn(this),this.g)))if(this.responseType==="arraybuffer")u.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(typeof h.ReadableStream<"u"&&"body"in u){if(this.j=u.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;Al(this)}else u.text().then(this.Oa.bind(this),this.ga.bind(this))};function Al(u){u.j.read().then(u.Ma.bind(u)).catch(u.ga.bind(u))}r.Ma=function(u){if(this.g){if(this.o&&u.value)this.response.push(u.value);else if(!this.o){var p=u.value?u.value:new Uint8Array(0);(p=this.B.decode(p,{stream:!u.done}))&&(this.response=this.responseText+=p)}u.done?Hr(this):Tn(this),this.readyState==3&&Al(this)}},r.Oa=function(u){this.g&&(this.response=this.responseText=u,Hr(this))},r.Na=function(u){this.g&&(this.response=u,Hr(this))},r.ga=function(){this.g&&Hr(this)};function Hr(u){u.readyState=4,u.l=null,u.j=null,u.B=null,Tn(u)}r.setRequestHeader=function(u,p){this.A.append(u,p)},r.getResponseHeader=function(u){return this.h&&this.h.get(u.toLowerCase())||""},r.getAllResponseHeaders=function(){if(!this.h)return"";const u=[],p=this.h.entries();for(var y=p.next();!y.done;)y=y.value,u.push(y[0]+": "+y[1]),y=p.next();return u.join(`\r
`)};function Tn(u){u.onreadystatechange&&u.onreadystatechange.call(u)}Object.defineProperty(en.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(u){this.m=u?"include":"same-origin"}});function Rl(u){let p="";return ae(u,function(y,w){p+=w,p+=":",p+=y,p+=`\r
`}),p}function ks(u,p,y){e:{for(w in y){var w=!1;break e}w=!0}w||(y=Rl(y),typeof u=="string"?y!=null&&Ln(y):Fe(u,p,y))}function qe(u){ct.call(this),this.headers=new Map,this.L=u||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}I(qe,ct);var Cl=/^https?$/i,Lc=["POST","PUT"];r=qe.prototype,r.Fa=function(u){this.H=u},r.ea=function(u,p,y,w){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+u);p=p?p.toUpperCase():"GET",this.D=u,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():_l.g(),this.g.onreadystatechange=C(_(this.Ca,this));try{this.B=!0,this.g.open(p,String(u),!0),this.B=!1}catch(j){Wr(this,j);return}if(u=y||"",y=new Map(this.headers),w)if(Object.getPrototypeOf(w)===Object.prototype)for(var M in w)y.set(M,w[M]);else if(typeof w.keys=="function"&&typeof w.get=="function")for(const j of w.keys())y.set(j,w.get(j));else throw Error("Unknown input type for opt_headers: "+String(w));w=Array.from(y.keys()).find(j=>j.toLowerCase()=="content-type"),M=h.FormData&&u instanceof h.FormData,!(Array.prototype.indexOf.call(Lc,p,void 0)>=0)||w||M||y.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[j,X]of y)this.g.setRequestHeader(j,X);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(u),this.v=!1}catch(j){Wr(this,j)}};function Wr(u,p){u.h=!1,u.g&&(u.j=!0,u.g.abort(),u.j=!1),u.l=p,u.o=5,qr(u),dr(u)}function qr(u){u.A||(u.A=!0,st(u,"complete"),st(u,"error"))}r.abort=function(u){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=u||7,st(this,"complete"),st(this,"abort"),dr(this))},r.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),dr(this,!0)),qe.Z.N.call(this)},r.Ca=function(){this.u||(this.B||this.v||this.j?hr(this):this.Xa())},r.Xa=function(){hr(this)};function hr(u){if(u.h&&typeof l<"u"){if(u.v&&Bn(u)==4)setTimeout(u.Ca.bind(u),0);else if(st(u,"readystatechange"),Bn(u)==4){u.h=!1;try{const j=u.ca();e:switch(j){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var p=!0;break e;default:p=!1}var y;if(!(y=p)){var w;if(w=j===0){let X=String(u.D).match(Sl)[1]||null;!X&&h.self&&h.self.location&&(X=h.self.location.protocol.slice(0,-1)),w=!Cl.test(X?X.toLowerCase():"")}y=w}if(y)st(u,"complete"),st(u,"success");else{u.o=6;try{var M=Bn(u)>2?u.g.statusText:""}catch{M=""}u.l=M+" ["+u.ca()+"]",qr(u)}}finally{dr(u)}}}}function dr(u,p){if(u.g){u.m&&(clearTimeout(u.m),u.m=null);const y=u.g;u.g=null,p||st(u,"ready");try{y.onreadystatechange=null}catch{}}}r.isActive=function(){return!!this.g};function Bn(u){return u.g?u.g.readyState:0}r.ca=function(){try{return Bn(this)>2?this.g.status:-1}catch{return-1}},r.la=function(){try{return this.g?this.g.responseText:""}catch{return""}},r.La=function(u){if(this.g){var p=this.g.responseText;return u&&p.indexOf(u)==0&&(p=p.substring(u.length)),fl(p)}};function Pl(u){try{if(!u.g)return null;if("response"in u.g)return u.g.response;switch(u.F){case"":case"text":return u.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in u.g)return u.g.mozResponseArrayBuffer}return null}catch{return null}}function Zo(u){const p={};u=(u.g&&Bn(u)>=2&&u.g.getAllResponseHeaders()||"").split(`\r
`);for(let w=0;w<u.length;w++){if(A(u[w]))continue;var y=Is(u[w]);const M=y[0];if(y=y[1],typeof y!="string")continue;y=y.trim();const j=p[M]||[];p[M]=j,j.push(y)}ee(p,function(w){return w.join(", ")})}r.ya=function(){return this.o},r.Ha=function(){return typeof this.l=="string"?this.l:String(this.l)};function $n(u,p,y){return y&&y.internalChannelParams&&y.internalChannelParams[u]||p}function Ns(u){this.za=0,this.i=[],this.j=new jr,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=$n("failFast",!1,u),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=$n("baseRetryDelayMs",5e3,u),this.Za=$n("retryDelaySeedMs",1e4,u),this.Ta=$n("forwardChannelMaxRetries",2,u),this.va=$n("forwardChannelRequestTimeoutMs",2e4,u),this.ma=u&&u.xmlHttpFactory||void 0,this.Ua=u&&u.Rb||void 0,this.Aa=u&&u.useFetchStreams||!1,this.O=void 0,this.L=u&&u.supportsCrossDomainXhr||!1,this.M="",this.h=new As(u&&u.concurrentRequestLimit),this.Ba=new zi,this.S=u&&u.fastHandshake||!1,this.R=u&&u.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=u&&u.Pb||!1,u&&u.ua&&this.j.ua(),u&&u.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&u&&u.detectBufferingProxy||!1,this.ia=void 0,u&&u.longPollingTimeout&&u.longPollingTimeout>0&&(this.ia=u.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}r=Ns.prototype,r.ka=8,r.I=1,r.connect=function(u,p,y,w){rt(0),this.W=u,this.H=p||{},y&&w!==void 0&&(this.H.OSID=y,this.H.OAID=w),this.F=this.X,this.J=ta(this,null,this.W),fr(this)};function xs(u){if(Ds(u),u.I==3){var p=u.V++,y=cn(u.J);if(Fe(y,"SID",u.M),Fe(y,"RID",p),Fe(y,"TYPE","terminate"),Hn(u,y),p=new un(u,u.j,p),p.M=2,p.A=ur(cn(y)),y=!1,h.navigator&&h.navigator.sendBeacon)try{y=h.navigator.sendBeacon(p.A.toString(),"")}catch{}!y&&h.Image&&(new Image().src=p.A,y=!0),y||(p.g=Nl(p.j,null),p.g.ea(p.A)),p.F=Date.now(),Vi(p)}Hi(u)}function tn(u){u.g&&($i(u),u.g.cancel(),u.g=null)}function Ds(u){tn(u),u.v&&(h.clearTimeout(u.v),u.v=null),Vs(u),u.h.cancel(),u.m&&(typeof u.m=="number"&&h.clearTimeout(u.m),u.m=null)}function fr(u){if(!$o(u.h)&&!u.m){u.m=!0;var p=u.Ea;De||T(),Re||(De(),Re=!0),D.add(p,u),u.D=0}}function kl(u,p){return Li(u.h)>=u.h.j-(u.m?1:0)?!1:u.m?(u.i=p.G.concat(u.i),!0):u.I==1||u.I==2||u.D>=(u.Sa?0:u.Ta)?!1:(u.m=Ur(_(u.Ea,u,p),Ls(u,u.D)),u.D++,!0)}r.Ea=function(u){if(this.m)if(this.m=null,this.I==1){if(!u){this.V=Math.floor(Math.random()*1e5),u=this.V++;const M=new un(this,this.j,u);let j=this.o;if(this.U&&(j?(j=L(j),we(j,this.U)):j=this.U),this.u!==null||this.R||(M.J=j,j=null),this.S)e:{for(var p=0,y=0;y<this.i.length;y++){t:{var w=this.i[y];if("__data__"in w.map&&(w=w.map.__data__,typeof w=="string")){w=w.length;break t}w=void 0}if(w===void 0)break;if(p+=w,p>4096){p=y;break e}if(p===4096||y===this.i.length-1){p=y+1;break e}}p=1e3}else p=1e3;p=ea(this,M,p),y=cn(this.J),Fe(y,"RID",u),Fe(y,"CVER",22),this.G&&Fe(y,"X-HTTP-Session-Id",this.G),Hn(this,y),j&&(this.R?p="headers="+Ln(Rl(j))+"&"+p:this.u&&ks(y,this.u,j)),Rs(this.h,M),this.Ra&&Fe(y,"TYPE","init"),this.S?(Fe(y,"$req",p),Fe(y,"SID","null"),M.U=!0,wn(M,y,null)):wn(M,y,p),this.I=2}}else this.I==3&&(u?Bi(this,u):this.i.length==0||$o(this.h)||Bi(this))};function Bi(u,p){var y;p?y=p.l:y=u.V++;const w=cn(u.J);Fe(w,"SID",u.M),Fe(w,"RID",y),Fe(w,"AID",u.K),Hn(u,w),u.u&&u.o&&ks(w,u.u,u.o),y=new un(u,u.j,y,u.D+1),u.u===null&&(y.J=u.o),p&&(u.i=p.G.concat(u.i)),p=ea(u,y,1e3),y.H=Math.round(u.va*.5)+Math.round(u.va*.5*Math.random()),Rs(u.h,y),wn(y,w,p)}function Hn(u,p){u.H&&ae(u.H,function(y,w){Fe(p,w,y)}),u.l&&ae({},function(y,w){Fe(p,w,y)})}function ea(u,p,y){y=Math.min(u.i.length,y);const w=u.l?_(u.l.Ka,u.l,u):null;e:{var M=u.i;let _e=-1;for(;;){const ot=["count="+y];_e==-1?y>0?(_e=M[0].g,ot.push("ofs="+_e)):_e=0:ot.push("ofs="+_e);let $e=!0;for(let ht=0;ht<y;ht++){var j=M[ht].g;const rn=M[ht].map;if(j-=_e,j<0)_e=Math.max(0,M[ht].g-100),$e=!1;else try{j="req"+j+"_"||"";try{var X=rn instanceof Map?rn:Object.entries(rn);for(const[pr,qn]of X){let Kn=qn;m(qn)&&(Kn=Lr(qn)),ot.push(j+pr+"="+encodeURIComponent(Kn))}}catch(pr){throw ot.push(j+"type="+encodeURIComponent("_badmap")),pr}}catch{w&&w(rn)}}if($e){X=ot.join("&");break e}}X=void 0}return u=u.i.splice(0,y),p.G=u,X}function Dt(u){if(!u.g&&!u.v){u.Y=1;var p=u.Da;De||T(),Re||(De(),Re=!0),D.add(p,u),u.A=0}}function Wn(u){return u.g||u.v||u.A>=3?!1:(u.Y++,u.v=Ur(_(u.Da,u),Ls(u,u.A)),u.A++,!0)}r.Da=function(){if(this.v=null,Kr(this),this.aa&&!(this.P||this.g==null||this.T<=0)){var u=4*this.T;this.j.info("BP detection timer enabled: "+u),this.B=Ur(_(this.Wa,this),u)}},r.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,rt(10),tn(this),Kr(this))};function $i(u){u.B!=null&&(h.clearTimeout(u.B),u.B=null)}function Kr(u){u.g=new un(u,u.j,"rpc",u.Y),u.u===null&&(u.g.J=u.o),u.g.P=0;var p=cn(u.na);Fe(p,"RID","rpc"),Fe(p,"SID",u.M),Fe(p,"AID",u.K),Fe(p,"CI",u.F?"0":"1"),!u.F&&u.ia&&Fe(p,"TO",u.ia),Fe(p,"TYPE","xmlhttp"),Hn(u,p),u.u&&u.o&&ks(p,u.u,u.o),u.O&&(u.g.H=u.O);var y=u.g;u=u.ba,y.M=1,y.A=ur(cn(p)),y.u=null,y.R=!0,zo(y,u)}r.Va=function(){this.C!=null&&(this.C=null,tn(this),Wn(this),rt(19))};function Vs(u){u.C!=null&&(h.clearTimeout(u.C),u.C=null)}function Os(u,p){var y=null;if(u.g==p){Vs(u),$i(u),u.g=null;var w=2}else if(Ho(u.h,p))y=p.G,bi(u.h,p),w=1;else return;if(u.I!=0){if(p.o)if(w==1){y=p.u?p.u.length:0,p=Date.now()-p.F;var M=u.D;w=Fr(),st(w,new Uo(w,y)),fr(u)}else Dt(u);else if(M=p.m,M==3||M==0&&p.X>0||!(w==1&&kl(u,p)||w==2&&Wn(u)))switch(y&&y.length>0&&(p=u.h,p.i=p.i.concat(y)),M){case 1:nn(u,5);break;case 4:nn(u,10);break;case 3:nn(u,6);break;default:nn(u,2)}}}function Ls(u,p){let y=u.Qa+Math.floor(Math.random()*u.Za);return u.isActive()||(y*=2),y*p}function nn(u,p){if(u.j.info("Error code "+p),p==2){var y=_(u.bb,u),w=u.Ua;const M=!w;w=new bn(w||"//www.google.com/images/cleardot.gif"),h.location&&h.location.protocol=="http"||Mi(w,"https"),ur(w),M?jn(w.toString(),y):zn(w.toString(),y)}else rt(2);u.I=0,u.l&&u.l.pa(p),Hi(u),Ds(u)}r.bb=function(u){u?(this.j.info("Successfully pinged google.com"),rt(2)):(this.j.info("Failed to ping google.com"),rt(1))};function Hi(u){if(u.I=0,u.ja=[],u.l){const p=Xt(u.h);(p.length!=0||u.i.length!=0)&&(G(u.ja,p),G(u.ja,u.i),u.h.i.length=0,z(u.i),u.i.length=0),u.l.oa()}}function ta(u,p,y){var w=y instanceof bn?cn(y):new bn(y);if(w.g!="")p&&(w.g=p+"."+w.g),Mn(w,w.u);else{var M=h.location;w=M.protocol,p=p?p+"."+M.hostname:M.hostname,M=+M.port;const j=new bn(null);w&&Mi(j,w),p&&(j.g=p),M&&Mn(j,M),y&&(j.h=y),w=j}return y=u.G,p=u.wa,y&&p&&Fe(w,y,p),Fe(w,"VER",u.ka),Hn(u,w),w}function Nl(u,p,y){if(p&&!u.L)throw Error("Can't create secondary domain capable XhrIo object.");return p=u.Aa&&!u.ma?new qe(new cr({ab:y})):new qe(u.ma),p.Fa(u.L),p}r.isActive=function(){return!!this.l&&this.l.isActive(this)};function xl(){}r=xl.prototype,r.ra=function(){},r.qa=function(){},r.pa=function(){},r.oa=function(){},r.isActive=function(){return!0},r.Ka=function(){};function bs(){}bs.prototype.g=function(u,p){return new Rt(u,p)};function Rt(u,p){ct.call(this),this.g=new Ns(p),this.l=u,this.h=p&&p.messageUrlParams||null,u=p&&p.messageHeaders||null,p&&p.clientProtocolHeaderRequired&&(u?u["X-Client-Protocol"]="webchannel":u={"X-Client-Protocol":"webchannel"}),this.g.o=u,u=p&&p.initMessageHeaders||null,p&&p.messageContentType&&(u?u["X-WebChannel-Content-Type"]=p.messageContentType:u={"X-WebChannel-Content-Type":p.messageContentType}),p&&p.sa&&(u?u["X-WebChannel-Client-Profile"]=p.sa:u={"X-WebChannel-Client-Profile":p.sa}),this.g.U=u,(u=p&&p.Qb)&&!A(u)&&(this.g.u=u),this.A=p&&p.supportsCrossDomainXhr||!1,this.v=p&&p.sendRawJson||!1,(p=p&&p.httpSessionIdParam)&&!A(p)&&(this.g.G=p,u=this.h,u!==null&&p in u&&(u=this.h,p in u&&delete u[p])),this.j=new Gr(this)}I(Rt,ct),Rt.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},Rt.prototype.close=function(){xs(this.g)},Rt.prototype.o=function(u){var p=this.g;if(typeof u=="string"){var y={};y.__data__=u,u=y}else this.v&&(y={},y.__data__=Lr(u),u=y);p.i.push(new Vc(p.Ya++,u)),p.I==3&&fr(p)},Rt.prototype.N=function(){this.g.l=null,delete this.j,xs(this.g),delete this.g,Rt.Z.N.call(this)};function Dl(u){Es.call(this),u.__headers__&&(this.headers=u.__headers__,this.statusCode=u.__status__,delete u.__headers__,delete u.__status__);var p=u.__sm__;if(p){e:{for(const y in p){u=y;break e}u=void 0}(this.i=u)&&(u=this.i,p=p!==null&&u in p?p[u]:void 0),this.data=p}else this.data=u}I(Dl,Es);function Vl(){Fo.call(this),this.status=1}I(Vl,Fo);function Gr(u){this.g=u}I(Gr,xl),Gr.prototype.ra=function(){st(this.g,"a")},Gr.prototype.qa=function(u){st(this.g,new Dl(u))},Gr.prototype.pa=function(u){st(this.g,new Vl)},Gr.prototype.oa=function(){st(this.g,"b")},bs.prototype.createWebChannel=bs.prototype.g,Rt.prototype.send=Rt.prototype.o,Rt.prototype.open=Rt.prototype.m,Rt.prototype.close=Rt.prototype.close,F_=function(){return new bs},M_=function(){return Fr()},b_=En,Pd={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},zr.NO_ERROR=0,zr.TIMEOUT=8,zr.HTTP_ERROR=6,Fu=zr,Br.COMPLETE="complete",L_=Br,pl.EventType=Mr,Mr.OPEN="a",Mr.CLOSE="b",Mr.ERROR="c",Mr.MESSAGE="d",ct.prototype.listen=ct.prototype.J,xa=pl,qe.prototype.listenOnce=qe.prototype.K,qe.prototype.getLastError=qe.prototype.Ha,qe.prototype.getLastErrorCode=qe.prototype.ya,qe.prototype.getStatus=qe.prototype.ca,qe.prototype.getResponseJson=qe.prototype.La,qe.prototype.getResponseText=qe.prototype.la,qe.prototype.send=qe.prototype.ea,qe.prototype.setWithCredentials=qe.prototype.Fa,O_=qe}).apply(typeof ku<"u"?ku:typeof self<"u"?self:typeof window<"u"?window:{});/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ft{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}Ft.UNAUTHENTICATED=new Ft(null),Ft.GOOGLE_CREDENTIALS=new Ft("google-credentials-uid"),Ft.FIRST_PARTY=new Ft("first-party-uid"),Ft.MOCK_USER=new Ft("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Po="12.11.0";function zS(r){Po=r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hs=new Kd("@firebase/firestore");function io(){return hs.logLevel}function re(r,...e){if(hs.logLevel<=ke.DEBUG){const t=e.map(sf);hs.debug(`Firestore (${Po}): ${r}`,...t)}}function Pr(r,...e){if(hs.logLevel<=ke.ERROR){const t=e.map(sf);hs.error(`Firestore (${Po}): ${r}`,...t)}}function ds(r,...e){if(hs.logLevel<=ke.WARN){const t=e.map(sf);hs.warn(`Firestore (${Po}): ${r}`,...t)}}function sf(r){if(typeof r=="string")return r;try{return(function(t){return JSON.stringify(t)})(r)}catch{return r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function me(r,e,t){let s="Unexpected state";typeof e=="string"?s=e:t=e,U_(r,s,t)}function U_(r,e,t){let s=`FIRESTORE (${Po}) INTERNAL ASSERTION FAILED: ${e} (ID: ${r.toString(16)})`;if(t!==void 0)try{s+=" CONTEXT: "+JSON.stringify(t)}catch{s+=" CONTEXT: "+t}throw Pr(s),new Error(s)}function ze(r,e,t,s){let o="Unexpected state";typeof t=="string"?o=t:s=t,r||U_(e,o,s)}function ve(r,e){return r}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class ie extends Nr{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ss{constructor(){this.promise=new Promise(((e,t)=>{this.resolve=e,this.reject=t}))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class j_{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class BS{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable((()=>t(Ft.UNAUTHENTICATED)))}shutdown(){}}class $S{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable((()=>t(this.token.user)))}shutdown(){this.changeListener=null}}class HS{constructor(e){this.t=e,this.currentUser=Ft.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){ze(this.o===void 0,42304);let s=this.i;const o=g=>this.i!==s?(s=this.i,t(g)):Promise.resolve();let l=new ss;this.o=()=>{this.i++,this.currentUser=this.u(),l.resolve(),l=new ss,e.enqueueRetryable((()=>o(this.currentUser)))};const h=()=>{const g=l;e.enqueueRetryable((async()=>{await g.promise,await o(this.currentUser)}))},m=g=>{re("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=g,this.o&&(this.auth.addAuthTokenListener(this.o),h())};this.t.onInit((g=>m(g))),setTimeout((()=>{if(!this.auth){const g=this.t.getImmediate({optional:!0});g?m(g):(re("FirebaseAuthCredentialsProvider","Auth not yet detected"),l.resolve(),l=new ss)}}),0),h()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then((s=>this.i!==e?(re("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):s?(ze(typeof s.accessToken=="string",31837,{l:s}),new j_(s.accessToken,this.currentUser)):null)):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.o&&this.auth.removeAuthTokenListener(this.o),this.o=void 0}u(){const e=this.auth&&this.auth.getUid();return ze(e===null||typeof e=="string",2055,{h:e}),new Ft(e)}}class WS{constructor(e,t,s){this.P=e,this.T=t,this.I=s,this.type="FirstParty",this.user=Ft.FIRST_PARTY,this.R=new Map}A(){return this.I?this.I():null}get headers(){this.R.set("X-Goog-AuthUser",this.P);const e=this.A();return e&&this.R.set("Authorization",e),this.T&&this.R.set("X-Goog-Iam-Authorization-Token",this.T),this.R}}class qS{constructor(e,t,s){this.P=e,this.T=t,this.I=s}getToken(){return Promise.resolve(new WS(this.P,this.T,this.I))}start(e,t){e.enqueueRetryable((()=>t(Ft.FIRST_PARTY)))}shutdown(){}invalidateToken(){}}class Fg{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class KS{constructor(e,t){this.V=t,this.forceRefresh=!1,this.appCheck=null,this.m=null,this.p=null,yn(e)&&e.settings.appCheckToken&&(this.p=e.settings.appCheckToken)}start(e,t){ze(this.o===void 0,3512);const s=l=>{l.error!=null&&re("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${l.error.message}`);const h=l.token!==this.m;return this.m=l.token,re("FirebaseAppCheckTokenProvider",`Received ${h?"new":"existing"} token.`),h?t(l.token):Promise.resolve()};this.o=l=>{e.enqueueRetryable((()=>s(l)))};const o=l=>{re("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=l,this.o&&this.appCheck.addTokenListener(this.o)};this.V.onInit((l=>o(l))),setTimeout((()=>{if(!this.appCheck){const l=this.V.getImmediate({optional:!0});l?o(l):re("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}}),0)}getToken(){if(this.p)return Promise.resolve(new Fg(this.p));const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then((t=>t?(ze(typeof t.token=="string",44558,{tokenResult:t}),this.m=t.token,new Fg(t.token)):null)):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.o&&this.appCheck.removeTokenListener(this.o),this.o=void 0}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function GS(r){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(r);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let s=0;s<r;s++)t[s]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class of{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=62*Math.floor(4.129032258064516);let s="";for(;s.length<20;){const o=GS(40);for(let l=0;l<o.length;++l)s.length<20&&o[l]<t&&(s+=e.charAt(o[l]%62))}return s}}function Ne(r,e){return r<e?-1:r>e?1:0}function kd(r,e){const t=Math.min(r.length,e.length);for(let s=0;s<t;s++){const o=r.charAt(s),l=e.charAt(s);if(o!==l)return md(o)===md(l)?Ne(o,l):md(o)?1:-1}return Ne(r.length,e.length)}const QS=55296,YS=57343;function md(r){const e=r.charCodeAt(0);return e>=QS&&e<=YS}function vo(r,e,t){return r.length===e.length&&r.every(((s,o)=>t(s,e[o])))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ug="__name__";class Xn{constructor(e,t,s){t===void 0?t=0:t>e.length&&me(637,{offset:t,range:e.length}),s===void 0?s=e.length-t:s>e.length-t&&me(1746,{length:s,range:e.length-t}),this.segments=e,this.offset=t,this.len=s}get length(){return this.len}isEqual(e){return Xn.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof Xn?e.forEach((s=>{t.push(s)})):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,s=this.limit();t<s;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const s=Math.min(e.length,t.length);for(let o=0;o<s;o++){const l=Xn.compareSegments(e.get(o),t.get(o));if(l!==0)return l}return Ne(e.length,t.length)}static compareSegments(e,t){const s=Xn.isNumericId(e),o=Xn.isNumericId(t);return s&&!o?-1:!s&&o?1:s&&o?Xn.extractNumericId(e).compare(Xn.extractNumericId(t)):kd(e,t)}static isNumericId(e){return e.startsWith("__id")&&e.endsWith("__")}static extractNumericId(e){return _i.fromString(e.substring(4,e.length-2))}}class Ge extends Xn{construct(e,t,s){return new Ge(e,t,s)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const s of e){if(s.indexOf("//")>=0)throw new ie($.INVALID_ARGUMENT,`Invalid segment (${s}). Paths must not contain // in them.`);t.push(...s.split("/").filter((o=>o.length>0)))}return new Ge(t)}static emptyPath(){return new Ge([])}}const JS=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class Nt extends Xn{construct(e,t,s){return new Nt(e,t,s)}static isValidIdentifier(e){return JS.test(e)}canonicalString(){return this.toArray().map((e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),Nt.isValidIdentifier(e)||(e="`"+e+"`"),e))).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===Ug}static keyField(){return new Nt([Ug])}static fromServerFormat(e){const t=[];let s="",o=0;const l=()=>{if(s.length===0)throw new ie($.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(s),s=""};let h=!1;for(;o<e.length;){const m=e[o];if(m==="\\"){if(o+1===e.length)throw new ie($.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const g=e[o+1];if(g!=="\\"&&g!=="."&&g!=="`")throw new ie($.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);s+=g,o+=2}else m==="`"?(h=!h,o++):m!=="."||h?(s+=m,o++):(l(),o++)}if(l(),h)throw new ie($.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new Nt(t)}static emptyPath(){return new Nt([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ce{constructor(e){this.path=e}static fromPath(e){return new ce(Ge.fromString(e))}static fromName(e){return new ce(Ge.fromString(e).popFirst(5))}static empty(){return new ce(Ge.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&Ge.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return Ge.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new ce(new Ge(e.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function z_(r,e,t){if(!t)throw new ie($.INVALID_ARGUMENT,`Function ${r}() cannot be called with an empty ${e}.`)}function XS(r,e,t,s){if(e===!0&&s===!0)throw new ie($.INVALID_ARGUMENT,`${r} and ${t} cannot be used together.`)}function jg(r){if(!ce.isDocumentKey(r))throw new ie($.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${r} has ${r.length}.`)}function zg(r){if(ce.isDocumentKey(r))throw new ie($.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${r} has ${r.length}.`)}function B_(r){return typeof r=="object"&&r!==null&&(Object.getPrototypeOf(r)===Object.prototype||Object.getPrototypeOf(r)===null)}function yc(r){if(r===void 0)return"undefined";if(r===null)return"null";if(typeof r=="string")return r.length>20&&(r=`${r.substring(0,20)}...`),JSON.stringify(r);if(typeof r=="number"||typeof r=="boolean")return""+r;if(typeof r=="object"){if(r instanceof Array)return"an array";{const e=(function(s){return s.constructor?s.constructor.name:null})(r);return e?`a custom ${e} object`:"an object"}}return typeof r=="function"?"a function":me(12329,{type:typeof r})}function vi(r,e){if("_delegate"in r&&(r=r._delegate),!(r instanceof e)){if(e.name===r.constructor.name)throw new ie($.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=yc(r);throw new ie($.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return r}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mt(r,e){const t={typeString:r};return e&&(t.value=e),t}function il(r,e){if(!B_(r))throw new ie($.INVALID_ARGUMENT,"JSON must be an object");let t;for(const s in e)if(e[s]){const o=e[s].typeString,l="value"in e[s]?{value:e[s].value}:void 0;if(!(s in r)){t=`JSON missing required field: '${s}'`;break}const h=r[s];if(o&&typeof h!==o){t=`JSON field '${s}' must be a ${o}.`;break}if(l!==void 0&&h!==l.value){t=`Expected '${s}' field to equal '${l.value}'`;break}}if(t)throw new ie($.INVALID_ARGUMENT,t);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Bg=-62135596800,$g=1e6;class Xe{static now(){return Xe.fromMillis(Date.now())}static fromDate(e){return Xe.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),s=Math.floor((e-1e3*t)*$g);return new Xe(t,s)}constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new ie($.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new ie($.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<Bg)throw new ie($.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new ie($.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/$g}_compareTo(e){return this.seconds===e.seconds?Ne(this.nanoseconds,e.nanoseconds):Ne(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:Xe._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(e){if(il(e,Xe._jsonSchema))return new Xe(e.seconds,e.nanoseconds)}valueOf(){const e=this.seconds-Bg;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}Xe._jsonSchemaVersion="firestore/timestamp/1.0",Xe._jsonSchema={type:mt("string",Xe._jsonSchemaVersion),seconds:mt("number"),nanoseconds:mt("number")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ye{static fromTimestamp(e){return new ye(e)}static min(){return new ye(new Xe(0,0))}static max(){return new ye(new Xe(253402300799,999999999))}constructor(e){this.timestamp=e}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ha=-1;function ZS(r,e){const t=r.toTimestamp().seconds,s=r.toTimestamp().nanoseconds+1,o=ye.fromTimestamp(s===1e9?new Xe(t+1,0):new Xe(t,s));return new wi(o,ce.empty(),e)}function eA(r){return new wi(r.readTime,r.key,Ha)}class wi{constructor(e,t,s){this.readTime=e,this.documentKey=t,this.largestBatchId=s}static min(){return new wi(ye.min(),ce.empty(),Ha)}static max(){return new wi(ye.max(),ce.empty(),Ha)}}function tA(r,e){let t=r.readTime.compareTo(e.readTime);return t!==0?t:(t=ce.comparator(r.documentKey,e.documentKey),t!==0?t:Ne(r.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nA="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class rA{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach((e=>e()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ko(r){if(r.code!==$.FAILED_PRECONDITION||r.message!==nA)throw r;re("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class H{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e((t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)}),(t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)}))}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&me(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new H(((s,o)=>{this.nextCallback=l=>{this.wrapSuccess(e,l).next(s,o)},this.catchCallback=l=>{this.wrapFailure(t,l).next(s,o)}}))}toPromise(){return new Promise(((e,t)=>{this.next(e,t)}))}wrapUserFunction(e){try{const t=e();return t instanceof H?t:H.resolve(t)}catch(t){return H.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction((()=>e(t))):H.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction((()=>e(t))):H.reject(t)}static resolve(e){return new H(((t,s)=>{t(e)}))}static reject(e){return new H(((t,s)=>{s(e)}))}static waitFor(e){return new H(((t,s)=>{let o=0,l=0,h=!1;e.forEach((m=>{++o,m.next((()=>{++l,h&&l===o&&t()}),(g=>s(g)))})),h=!0,l===o&&t()}))}static or(e){let t=H.resolve(!1);for(const s of e)t=t.next((o=>o?H.resolve(o):s()));return t}static forEach(e,t){const s=[];return e.forEach(((o,l)=>{s.push(t.call(this,o,l))})),this.waitFor(s)}static mapArray(e,t){return new H(((s,o)=>{const l=e.length,h=new Array(l);let m=0;for(let g=0;g<l;g++){const _=g;t(e[_]).next((E=>{h[_]=E,++m,m===l&&s(h)}),(E=>o(E)))}}))}static doWhile(e,t){return new H(((s,o)=>{const l=()=>{e()===!0?t().next((()=>{l()}),o):s()};l()}))}}function iA(r){const e=r.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}function No(r){return r.name==="IndexedDbTransactionError"}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _c{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=s=>this.ae(s),this.ue=s=>t.writeSequenceNumber(s))}ae(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.ue&&this.ue(e),e}}_c.ce=-1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const af=-1;function vc(r){return r==null}function ec(r){return r===0&&1/r==-1/0}function sA(r){return typeof r=="number"&&Number.isInteger(r)&&!ec(r)&&r<=Number.MAX_SAFE_INTEGER&&r>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $_="";function oA(r){let e="";for(let t=0;t<r.length;t++)e.length>0&&(e=Hg(e)),e=aA(r.get(t),e);return Hg(e)}function aA(r,e){let t=e;const s=r.length;for(let o=0;o<s;o++){const l=r.charAt(o);switch(l){case"\0":t+="";break;case $_:t+="";break;default:t+=l}}return t}function Hg(r){return r+$_+""}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wg(r){let e=0;for(const t in r)Object.prototype.hasOwnProperty.call(r,t)&&e++;return e}function Pi(r,e){for(const t in r)Object.prototype.hasOwnProperty.call(r,t)&&e(t,r[t])}function H_(r){for(const e in r)if(Object.prototype.hasOwnProperty.call(r,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nt{constructor(e,t){this.comparator=e,this.root=t||kt.EMPTY}insert(e,t){return new nt(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,kt.BLACK,null,null))}remove(e){return new nt(this.comparator,this.root.remove(e,this.comparator).copy(null,null,kt.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const s=this.comparator(e,t.key);if(s===0)return t.value;s<0?t=t.left:s>0&&(t=t.right)}return null}indexOf(e){let t=0,s=this.root;for(;!s.isEmpty();){const o=this.comparator(e,s.key);if(o===0)return t+s.left.size;o<0?s=s.left:(t+=s.left.size+1,s=s.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal(((t,s)=>(e(t,s),!1)))}toString(){const e=[];return this.inorderTraversal(((t,s)=>(e.push(`${t}:${s}`),!1))),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new Nu(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new Nu(this.root,e,this.comparator,!1)}getReverseIterator(){return new Nu(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new Nu(this.root,e,this.comparator,!0)}}class Nu{constructor(e,t,s,o){this.isReverse=o,this.nodeStack=[];let l=1;for(;!e.isEmpty();)if(l=t?s(e.key,t):1,t&&o&&(l*=-1),l<0)e=this.isReverse?e.left:e.right;else{if(l===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class kt{constructor(e,t,s,o,l){this.key=e,this.value=t,this.color=s??kt.RED,this.left=o??kt.EMPTY,this.right=l??kt.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,s,o,l){return new kt(e??this.key,t??this.value,s??this.color,o??this.left,l??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,s){let o=this;const l=s(e,o.key);return o=l<0?o.copy(null,null,null,o.left.insert(e,t,s),null):l===0?o.copy(null,t,null,null,null):o.copy(null,null,null,null,o.right.insert(e,t,s)),o.fixUp()}removeMin(){if(this.left.isEmpty())return kt.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let s,o=this;if(t(e,o.key)<0)o.left.isEmpty()||o.left.isRed()||o.left.left.isRed()||(o=o.moveRedLeft()),o=o.copy(null,null,null,o.left.remove(e,t),null);else{if(o.left.isRed()&&(o=o.rotateRight()),o.right.isEmpty()||o.right.isRed()||o.right.left.isRed()||(o=o.moveRedRight()),t(e,o.key)===0){if(o.right.isEmpty())return kt.EMPTY;s=o.right.min(),o=o.copy(s.key,s.value,null,null,o.right.removeMin())}o=o.copy(null,null,null,null,o.right.remove(e,t))}return o.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,kt.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,kt.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw me(43730,{key:this.key,value:this.value});if(this.right.isRed())throw me(14113,{key:this.key,value:this.value});const e=this.left.check();if(e!==this.right.check())throw me(27949);return e+(this.isRed()?0:1)}}kt.EMPTY=null,kt.RED=!0,kt.BLACK=!1;kt.EMPTY=new class{constructor(){this.size=0}get key(){throw me(57766)}get value(){throw me(16141)}get color(){throw me(16727)}get left(){throw me(29726)}get right(){throw me(36894)}copy(e,t,s,o,l){return this}insert(e,t,s){return new kt(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vt{constructor(e){this.comparator=e,this.data=new nt(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal(((t,s)=>(e(t),!1)))}forEachInRange(e,t){const s=this.data.getIteratorFrom(e[0]);for(;s.hasNext();){const o=s.getNext();if(this.comparator(o.key,e[1])>=0)return;t(o.key)}}forEachWhile(e,t){let s;for(s=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();s.hasNext();)if(!e(s.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new qg(this.data.getIterator())}getIteratorFrom(e){return new qg(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach((s=>{t=t.add(s)})),t}isEqual(e){if(!(e instanceof vt)||this.size!==e.size)return!1;const t=this.data.getIterator(),s=e.data.getIterator();for(;t.hasNext();){const o=t.getNext().key,l=s.getNext().key;if(this.comparator(o,l)!==0)return!1}return!0}toArray(){const e=[];return this.forEach((t=>{e.push(t)})),e}toString(){const e=[];return this.forEach((t=>e.push(t))),"SortedSet("+e.toString()+")"}copy(e){const t=new vt(this.comparator);return t.data=e,t}}class qg{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ln{constructor(e){this.fields=e,e.sort(Nt.comparator)}static empty(){return new ln([])}unionWith(e){let t=new vt(Nt.comparator);for(const s of this.fields)t=t.add(s);for(const s of e)t=t.add(s);return new ln(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return vo(this.fields,e.fields,((t,s)=>t.isEqual(s)))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class W_ extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xt{constructor(e){this.binaryString=e}static fromBase64String(e){const t=(function(o){try{return atob(o)}catch(l){throw typeof DOMException<"u"&&l instanceof DOMException?new W_("Invalid base64 string: "+l):l}})(e);return new xt(t)}static fromUint8Array(e){const t=(function(o){let l="";for(let h=0;h<o.length;++h)l+=String.fromCharCode(o[h]);return l})(e);return new xt(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return(function(t){return btoa(t)})(this.binaryString)}toUint8Array(){return(function(t){const s=new Uint8Array(t.length);for(let o=0;o<t.length;o++)s[o]=t.charCodeAt(o);return s})(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return Ne(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}xt.EMPTY_BYTE_STRING=new xt("");const lA=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function Ti(r){if(ze(!!r,39018),typeof r=="string"){let e=0;const t=lA.exec(r);if(ze(!!t,46558,{timestamp:r}),t[1]){let o=t[1];o=(o+"000000000").substr(0,9),e=Number(o)}const s=new Date(r);return{seconds:Math.floor(s.getTime()/1e3),nanos:e}}return{seconds:lt(r.seconds),nanos:lt(r.nanos)}}function lt(r){return typeof r=="number"?r:typeof r=="string"?Number(r):0}function Ii(r){return typeof r=="string"?xt.fromBase64String(r):xt.fromUint8Array(r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const q_="server_timestamp",K_="__type__",G_="__previous_value__",Q_="__local_write_time__";function lf(r){var t,s;return((s=(((t=r==null?void 0:r.mapValue)==null?void 0:t.fields)||{})[K_])==null?void 0:s.stringValue)===q_}function Ec(r){const e=r.mapValue.fields[G_];return lf(e)?Ec(e):e}function Wa(r){const e=Ti(r.mapValue.fields[Q_].timestampValue);return new Xe(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uA{constructor(e,t,s,o,l,h,m,g,_,E,I){this.databaseId=e,this.appId=t,this.persistenceKey=s,this.host=o,this.ssl=l,this.forceLongPolling=h,this.autoDetectLongPolling=m,this.longPollingOptions=g,this.useFetchStreams=_,this.isUsingEmulator=E,this.apiKey=I}}const tc="(default)";class qa{constructor(e,t){this.projectId=e,this.database=t||tc}static empty(){return new qa("","")}get isDefaultDatabase(){return this.database===tc}isEqual(e){return e instanceof qa&&e.projectId===this.projectId&&e.database===this.database}}function cA(r,e){if(!Object.prototype.hasOwnProperty.apply(r.options,["projectId"]))throw new ie($.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new qa(r.options.projectId,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Y_="__type__",hA="__max__",xu={mapValue:{}},J_="__vector__",nc="value";function Si(r){return"nullValue"in r?0:"booleanValue"in r?1:"integerValue"in r||"doubleValue"in r?2:"timestampValue"in r?3:"stringValue"in r?5:"bytesValue"in r?6:"referenceValue"in r?7:"geoPointValue"in r?8:"arrayValue"in r?9:"mapValue"in r?lf(r)?4:fA(r)?9007199254740991:dA(r)?10:11:me(28295,{value:r})}function ir(r,e){if(r===e)return!0;const t=Si(r);if(t!==Si(e))return!1;switch(t){case 0:case 9007199254740991:return!0;case 1:return r.booleanValue===e.booleanValue;case 4:return Wa(r).isEqual(Wa(e));case 3:return(function(o,l){if(typeof o.timestampValue=="string"&&typeof l.timestampValue=="string"&&o.timestampValue.length===l.timestampValue.length)return o.timestampValue===l.timestampValue;const h=Ti(o.timestampValue),m=Ti(l.timestampValue);return h.seconds===m.seconds&&h.nanos===m.nanos})(r,e);case 5:return r.stringValue===e.stringValue;case 6:return(function(o,l){return Ii(o.bytesValue).isEqual(Ii(l.bytesValue))})(r,e);case 7:return r.referenceValue===e.referenceValue;case 8:return(function(o,l){return lt(o.geoPointValue.latitude)===lt(l.geoPointValue.latitude)&&lt(o.geoPointValue.longitude)===lt(l.geoPointValue.longitude)})(r,e);case 2:return(function(o,l){if("integerValue"in o&&"integerValue"in l)return lt(o.integerValue)===lt(l.integerValue);if("doubleValue"in o&&"doubleValue"in l){const h=lt(o.doubleValue),m=lt(l.doubleValue);return h===m?ec(h)===ec(m):isNaN(h)&&isNaN(m)}return!1})(r,e);case 9:return vo(r.arrayValue.values||[],e.arrayValue.values||[],ir);case 10:case 11:return(function(o,l){const h=o.mapValue.fields||{},m=l.mapValue.fields||{};if(Wg(h)!==Wg(m))return!1;for(const g in h)if(h.hasOwnProperty(g)&&(m[g]===void 0||!ir(h[g],m[g])))return!1;return!0})(r,e);default:return me(52216,{left:r})}}function Ka(r,e){return(r.values||[]).find((t=>ir(t,e)))!==void 0}function Eo(r,e){if(r===e)return 0;const t=Si(r),s=Si(e);if(t!==s)return Ne(t,s);switch(t){case 0:case 9007199254740991:return 0;case 1:return Ne(r.booleanValue,e.booleanValue);case 2:return(function(l,h){const m=lt(l.integerValue||l.doubleValue),g=lt(h.integerValue||h.doubleValue);return m<g?-1:m>g?1:m===g?0:isNaN(m)?isNaN(g)?0:-1:1})(r,e);case 3:return Kg(r.timestampValue,e.timestampValue);case 4:return Kg(Wa(r),Wa(e));case 5:return kd(r.stringValue,e.stringValue);case 6:return(function(l,h){const m=Ii(l),g=Ii(h);return m.compareTo(g)})(r.bytesValue,e.bytesValue);case 7:return(function(l,h){const m=l.split("/"),g=h.split("/");for(let _=0;_<m.length&&_<g.length;_++){const E=Ne(m[_],g[_]);if(E!==0)return E}return Ne(m.length,g.length)})(r.referenceValue,e.referenceValue);case 8:return(function(l,h){const m=Ne(lt(l.latitude),lt(h.latitude));return m!==0?m:Ne(lt(l.longitude),lt(h.longitude))})(r.geoPointValue,e.geoPointValue);case 9:return Gg(r.arrayValue,e.arrayValue);case 10:return(function(l,h){var C,z,G,Q;const m=l.fields||{},g=h.fields||{},_=(C=m[nc])==null?void 0:C.arrayValue,E=(z=g[nc])==null?void 0:z.arrayValue,I=Ne(((G=_==null?void 0:_.values)==null?void 0:G.length)||0,((Q=E==null?void 0:E.values)==null?void 0:Q.length)||0);return I!==0?I:Gg(_,E)})(r.mapValue,e.mapValue);case 11:return(function(l,h){if(l===xu.mapValue&&h===xu.mapValue)return 0;if(l===xu.mapValue)return 1;if(h===xu.mapValue)return-1;const m=l.fields||{},g=Object.keys(m),_=h.fields||{},E=Object.keys(_);g.sort(),E.sort();for(let I=0;I<g.length&&I<E.length;++I){const C=kd(g[I],E[I]);if(C!==0)return C;const z=Eo(m[g[I]],_[E[I]]);if(z!==0)return z}return Ne(g.length,E.length)})(r.mapValue,e.mapValue);default:throw me(23264,{he:t})}}function Kg(r,e){if(typeof r=="string"&&typeof e=="string"&&r.length===e.length)return Ne(r,e);const t=Ti(r),s=Ti(e),o=Ne(t.seconds,s.seconds);return o!==0?o:Ne(t.nanos,s.nanos)}function Gg(r,e){const t=r.values||[],s=e.values||[];for(let o=0;o<t.length&&o<s.length;++o){const l=Eo(t[o],s[o]);if(l)return l}return Ne(t.length,s.length)}function wo(r){return Nd(r)}function Nd(r){return"nullValue"in r?"null":"booleanValue"in r?""+r.booleanValue:"integerValue"in r?""+r.integerValue:"doubleValue"in r?""+r.doubleValue:"timestampValue"in r?(function(t){const s=Ti(t);return`time(${s.seconds},${s.nanos})`})(r.timestampValue):"stringValue"in r?r.stringValue:"bytesValue"in r?(function(t){return Ii(t).toBase64()})(r.bytesValue):"referenceValue"in r?(function(t){return ce.fromName(t).toString()})(r.referenceValue):"geoPointValue"in r?(function(t){return`geo(${t.latitude},${t.longitude})`})(r.geoPointValue):"arrayValue"in r?(function(t){let s="[",o=!0;for(const l of t.values||[])o?o=!1:s+=",",s+=Nd(l);return s+"]"})(r.arrayValue):"mapValue"in r?(function(t){const s=Object.keys(t.fields||{}).sort();let o="{",l=!0;for(const h of s)l?l=!1:o+=",",o+=`${h}:${Nd(t.fields[h])}`;return o+"}"})(r.mapValue):me(61005,{value:r})}function Uu(r){switch(Si(r)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const e=Ec(r);return e?16+Uu(e):16;case 5:return 2*r.stringValue.length;case 6:return Ii(r.bytesValue).approximateByteSize();case 7:return r.referenceValue.length;case 9:return(function(s){return(s.values||[]).reduce(((o,l)=>o+Uu(l)),0)})(r.arrayValue);case 10:case 11:return(function(s){let o=0;return Pi(s.fields,((l,h)=>{o+=l.length+Uu(h)})),o})(r.mapValue);default:throw me(13486,{value:r})}}function Qg(r,e){return{referenceValue:`projects/${r.projectId}/databases/${r.database}/documents/${e.path.canonicalString()}`}}function xd(r){return!!r&&"integerValue"in r}function uf(r){return!!r&&"arrayValue"in r}function Yg(r){return!!r&&"nullValue"in r}function Jg(r){return!!r&&"doubleValue"in r&&isNaN(Number(r.doubleValue))}function ju(r){return!!r&&"mapValue"in r}function dA(r){var t,s;return((s=(((t=r==null?void 0:r.mapValue)==null?void 0:t.fields)||{})[Y_])==null?void 0:s.stringValue)===J_}function ba(r){if(r.geoPointValue)return{geoPointValue:{...r.geoPointValue}};if(r.timestampValue&&typeof r.timestampValue=="object")return{timestampValue:{...r.timestampValue}};if(r.mapValue){const e={mapValue:{fields:{}}};return Pi(r.mapValue.fields,((t,s)=>e.mapValue.fields[t]=ba(s))),e}if(r.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(r.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=ba(r.arrayValue.values[t]);return e}return{...r}}function fA(r){return(((r.mapValue||{}).fields||{}).__type__||{}).stringValue===hA}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jt{constructor(e){this.value=e}static empty(){return new Jt({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let s=0;s<e.length-1;++s)if(t=(t.mapValue.fields||{})[e.get(s)],!ju(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=ba(t)}setAll(e){let t=Nt.emptyPath(),s={},o=[];e.forEach(((h,m)=>{if(!t.isImmediateParentOf(m)){const g=this.getFieldsMap(t);this.applyChanges(g,s,o),s={},o=[],t=m.popLast()}h?s[m.lastSegment()]=ba(h):o.push(m.lastSegment())}));const l=this.getFieldsMap(t);this.applyChanges(l,s,o)}delete(e){const t=this.field(e.popLast());ju(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return ir(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let s=0;s<e.length;++s){let o=t.mapValue.fields[e.get(s)];ju(o)&&o.mapValue.fields||(o={mapValue:{fields:{}}},t.mapValue.fields[e.get(s)]=o),t=o}return t.mapValue.fields}applyChanges(e,t,s){Pi(t,((o,l)=>e[o]=l));for(const o of s)delete e[o]}clone(){return new Jt(ba(this.value))}}function X_(r){const e=[];return Pi(r.fields,((t,s)=>{const o=new Nt([t]);if(ju(s)){const l=X_(s.mapValue).fields;if(l.length===0)e.push(o);else for(const h of l)e.push(o.child(h))}else e.push(o)})),new ln(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ut{constructor(e,t,s,o,l,h,m){this.key=e,this.documentType=t,this.version=s,this.readTime=o,this.createTime=l,this.data=h,this.documentState=m}static newInvalidDocument(e){return new Ut(e,0,ye.min(),ye.min(),ye.min(),Jt.empty(),0)}static newFoundDocument(e,t,s,o){return new Ut(e,1,t,ye.min(),s,o,0)}static newNoDocument(e,t){return new Ut(e,2,t,ye.min(),ye.min(),Jt.empty(),0)}static newUnknownDocument(e,t){return new Ut(e,3,t,ye.min(),ye.min(),Jt.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(ye.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=Jt.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=Jt.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=ye.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof Ut&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new Ut(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rc{constructor(e,t){this.position=e,this.inclusive=t}}function Xg(r,e,t){let s=0;for(let o=0;o<r.position.length;o++){const l=e[o],h=r.position[o];if(l.field.isKeyField()?s=ce.comparator(ce.fromName(h.referenceValue),t.key):s=Eo(h,t.data.field(l.field)),l.dir==="desc"&&(s*=-1),s!==0)break}return s}function Zg(r,e){if(r===null)return e===null;if(e===null||r.inclusive!==e.inclusive||r.position.length!==e.position.length)return!1;for(let t=0;t<r.position.length;t++)if(!ir(r.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ic{constructor(e,t="asc"){this.field=e,this.dir=t}}function pA(r,e){return r.dir===e.dir&&r.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Z_{}class pt extends Z_{constructor(e,t,s){super(),this.field=e,this.op=t,this.value=s}static create(e,t,s){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,s):new gA(e,t,s):t==="array-contains"?new vA(e,s):t==="in"?new EA(e,s):t==="not-in"?new wA(e,s):t==="array-contains-any"?new TA(e,s):new pt(e,t,s)}static createKeyFieldInFilter(e,t,s){return t==="in"?new yA(e,s):new _A(e,s)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&t.nullValue===void 0&&this.matchesComparison(Eo(t,this.value)):t!==null&&Si(this.value)===Si(t)&&this.matchesComparison(Eo(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return me(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class Vn extends Z_{constructor(e,t){super(),this.filters=e,this.op=t,this.Pe=null}static create(e,t){return new Vn(e,t)}matches(e){return ev(this)?this.filters.find((t=>!t.matches(e)))===void 0:this.filters.find((t=>t.matches(e)))!==void 0}getFlattenedFilters(){return this.Pe!==null||(this.Pe=this.filters.reduce(((e,t)=>e.concat(t.getFlattenedFilters())),[])),this.Pe}getFilters(){return Object.assign([],this.filters)}}function ev(r){return r.op==="and"}function tv(r){return mA(r)&&ev(r)}function mA(r){for(const e of r.filters)if(e instanceof Vn)return!1;return!0}function Dd(r){if(r instanceof pt)return r.field.canonicalString()+r.op.toString()+wo(r.value);if(tv(r))return r.filters.map((e=>Dd(e))).join(",");{const e=r.filters.map((t=>Dd(t))).join(",");return`${r.op}(${e})`}}function nv(r,e){return r instanceof pt?(function(s,o){return o instanceof pt&&s.op===o.op&&s.field.isEqual(o.field)&&ir(s.value,o.value)})(r,e):r instanceof Vn?(function(s,o){return o instanceof Vn&&s.op===o.op&&s.filters.length===o.filters.length?s.filters.reduce(((l,h,m)=>l&&nv(h,o.filters[m])),!0):!1})(r,e):void me(19439)}function rv(r){return r instanceof pt?(function(t){return`${t.field.canonicalString()} ${t.op} ${wo(t.value)}`})(r):r instanceof Vn?(function(t){return t.op.toString()+" {"+t.getFilters().map(rv).join(" ,")+"}"})(r):"Filter"}class gA extends pt{constructor(e,t,s){super(e,t,s),this.key=ce.fromName(s.referenceValue)}matches(e){const t=ce.comparator(e.key,this.key);return this.matchesComparison(t)}}class yA extends pt{constructor(e,t){super(e,"in",t),this.keys=iv("in",t)}matches(e){return this.keys.some((t=>t.isEqual(e.key)))}}class _A extends pt{constructor(e,t){super(e,"not-in",t),this.keys=iv("not-in",t)}matches(e){return!this.keys.some((t=>t.isEqual(e.key)))}}function iv(r,e){var t;return(((t=e.arrayValue)==null?void 0:t.values)||[]).map((s=>ce.fromName(s.referenceValue)))}class vA extends pt{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return uf(t)&&Ka(t.arrayValue,this.value)}}class EA extends pt{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&Ka(this.value.arrayValue,t)}}class wA extends pt{constructor(e,t){super(e,"not-in",t)}matches(e){if(Ka(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&t.nullValue===void 0&&!Ka(this.value.arrayValue,t)}}class TA extends pt{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!uf(t)||!t.arrayValue.values)&&t.arrayValue.values.some((s=>Ka(this.value.arrayValue,s)))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class IA{constructor(e,t=null,s=[],o=[],l=null,h=null,m=null){this.path=e,this.collectionGroup=t,this.orderBy=s,this.filters=o,this.limit=l,this.startAt=h,this.endAt=m,this.Te=null}}function ey(r,e=null,t=[],s=[],o=null,l=null,h=null){return new IA(r,e,t,s,o,l,h)}function cf(r){const e=ve(r);if(e.Te===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map((s=>Dd(s))).join(","),t+="|ob:",t+=e.orderBy.map((s=>(function(l){return l.field.canonicalString()+l.dir})(s))).join(","),vc(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map((s=>wo(s))).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map((s=>wo(s))).join(",")),e.Te=t}return e.Te}function hf(r,e){if(r.limit!==e.limit||r.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<r.orderBy.length;t++)if(!pA(r.orderBy[t],e.orderBy[t]))return!1;if(r.filters.length!==e.filters.length)return!1;for(let t=0;t<r.filters.length;t++)if(!nv(r.filters[t],e.filters[t]))return!1;return r.collectionGroup===e.collectionGroup&&!!r.path.isEqual(e.path)&&!!Zg(r.startAt,e.startAt)&&Zg(r.endAt,e.endAt)}function Vd(r){return ce.isDocumentKey(r.path)&&r.collectionGroup===null&&r.filters.length===0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sl{constructor(e,t=null,s=[],o=[],l=null,h="F",m=null,g=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=s,this.filters=o,this.limit=l,this.limitType=h,this.startAt=m,this.endAt=g,this.Ee=null,this.Ie=null,this.Re=null,this.startAt,this.endAt}}function SA(r,e,t,s,o,l,h,m){return new sl(r,e,t,s,o,l,h,m)}function df(r){return new sl(r)}function ty(r){return r.filters.length===0&&r.limit===null&&r.startAt==null&&r.endAt==null&&(r.explicitOrderBy.length===0||r.explicitOrderBy.length===1&&r.explicitOrderBy[0].field.isKeyField())}function AA(r){return ce.isDocumentKey(r.path)&&r.collectionGroup===null&&r.filters.length===0}function sv(r){return r.collectionGroup!==null}function Ma(r){const e=ve(r);if(e.Ee===null){e.Ee=[];const t=new Set;for(const l of e.explicitOrderBy)e.Ee.push(l),t.add(l.field.canonicalString());const s=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(h){let m=new vt(Nt.comparator);return h.filters.forEach((g=>{g.getFlattenedFilters().forEach((_=>{_.isInequality()&&(m=m.add(_.field))}))})),m})(e).forEach((l=>{t.has(l.canonicalString())||l.isKeyField()||e.Ee.push(new ic(l,s))})),t.has(Nt.keyField().canonicalString())||e.Ee.push(new ic(Nt.keyField(),s))}return e.Ee}function tr(r){const e=ve(r);return e.Ie||(e.Ie=RA(e,Ma(r))),e.Ie}function RA(r,e){if(r.limitType==="F")return ey(r.path,r.collectionGroup,e,r.filters,r.limit,r.startAt,r.endAt);{e=e.map((o=>{const l=o.dir==="desc"?"asc":"desc";return new ic(o.field,l)}));const t=r.endAt?new rc(r.endAt.position,r.endAt.inclusive):null,s=r.startAt?new rc(r.startAt.position,r.startAt.inclusive):null;return ey(r.path,r.collectionGroup,e,r.filters,r.limit,t,s)}}function Od(r,e){const t=r.filters.concat([e]);return new sl(r.path,r.collectionGroup,r.explicitOrderBy.slice(),t,r.limit,r.limitType,r.startAt,r.endAt)}function Ld(r,e,t){return new sl(r.path,r.collectionGroup,r.explicitOrderBy.slice(),r.filters.slice(),e,t,r.startAt,r.endAt)}function wc(r,e){return hf(tr(r),tr(e))&&r.limitType===e.limitType}function ov(r){return`${cf(tr(r))}|lt:${r.limitType}`}function so(r){return`Query(target=${(function(t){let s=t.path.canonicalString();return t.collectionGroup!==null&&(s+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(s+=`, filters: [${t.filters.map((o=>rv(o))).join(", ")}]`),vc(t.limit)||(s+=", limit: "+t.limit),t.orderBy.length>0&&(s+=`, orderBy: [${t.orderBy.map((o=>(function(h){return`${h.field.canonicalString()} (${h.dir})`})(o))).join(", ")}]`),t.startAt&&(s+=", startAt: ",s+=t.startAt.inclusive?"b:":"a:",s+=t.startAt.position.map((o=>wo(o))).join(",")),t.endAt&&(s+=", endAt: ",s+=t.endAt.inclusive?"a:":"b:",s+=t.endAt.position.map((o=>wo(o))).join(",")),`Target(${s})`})(tr(r))}; limitType=${r.limitType})`}function Tc(r,e){return e.isFoundDocument()&&(function(s,o){const l=o.key.path;return s.collectionGroup!==null?o.key.hasCollectionId(s.collectionGroup)&&s.path.isPrefixOf(l):ce.isDocumentKey(s.path)?s.path.isEqual(l):s.path.isImmediateParentOf(l)})(r,e)&&(function(s,o){for(const l of Ma(s))if(!l.field.isKeyField()&&o.data.field(l.field)===null)return!1;return!0})(r,e)&&(function(s,o){for(const l of s.filters)if(!l.matches(o))return!1;return!0})(r,e)&&(function(s,o){return!(s.startAt&&!(function(h,m,g){const _=Xg(h,m,g);return h.inclusive?_<=0:_<0})(s.startAt,Ma(s),o)||s.endAt&&!(function(h,m,g){const _=Xg(h,m,g);return h.inclusive?_>=0:_>0})(s.endAt,Ma(s),o))})(r,e)}function CA(r){return r.collectionGroup||(r.path.length%2==1?r.path.lastSegment():r.path.get(r.path.length-2))}function av(r){return(e,t)=>{let s=!1;for(const o of Ma(r)){const l=PA(o,e,t);if(l!==0)return l;s=s||o.field.isKeyField()}return 0}}function PA(r,e,t){const s=r.field.isKeyField()?ce.comparator(e.key,t.key):(function(l,h,m){const g=h.data.field(l),_=m.data.field(l);return g!==null&&_!==null?Eo(g,_):me(42886)})(r.field,e,t);switch(r.dir){case"asc":return s;case"desc":return-1*s;default:return me(19790,{direction:r.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ps{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),s=this.inner[t];if(s!==void 0){for(const[o,l]of s)if(this.equalsFn(o,e))return l}}has(e){return this.get(e)!==void 0}set(e,t){const s=this.mapKeyFn(e),o=this.inner[s];if(o===void 0)return this.inner[s]=[[e,t]],void this.innerSize++;for(let l=0;l<o.length;l++)if(this.equalsFn(o[l][0],e))return void(o[l]=[e,t]);o.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),s=this.inner[t];if(s===void 0)return!1;for(let o=0;o<s.length;o++)if(this.equalsFn(s[o][0],e))return s.length===1?delete this.inner[t]:s.splice(o,1),this.innerSize--,!0;return!1}forEach(e){Pi(this.inner,((t,s)=>{for(const[o,l]of s)e(o,l)}))}isEmpty(){return H_(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const kA=new nt(ce.comparator);function kr(){return kA}const lv=new nt(ce.comparator);function Da(...r){let e=lv;for(const t of r)e=e.insert(t.key,t);return e}function uv(r){let e=lv;return r.forEach(((t,s)=>e=e.insert(t,s.overlayedDocument))),e}function is(){return Fa()}function cv(){return Fa()}function Fa(){return new ps((r=>r.toString()),((r,e)=>r.isEqual(e)))}const NA=new nt(ce.comparator),xA=new vt(ce.comparator);function xe(...r){let e=xA;for(const t of r)e=e.add(t);return e}const DA=new vt(Ne);function VA(){return DA}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ff(r,e){if(r.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:ec(e)?"-0":e}}function hv(r){return{integerValue:""+r}}function OA(r,e){return sA(e)?hv(e):ff(r,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ic{constructor(){this._=void 0}}function LA(r,e,t){return r instanceof Ga?(function(o,l){const h={fields:{[K_]:{stringValue:q_},[Q_]:{timestampValue:{seconds:o.seconds,nanos:o.nanoseconds}}}};return l&&lf(l)&&(l=Ec(l)),l&&(h.fields[G_]=l),{mapValue:h}})(t,e):r instanceof Qa?fv(r,e):r instanceof Ya?pv(r,e):(function(o,l){const h=dv(o,l),m=ny(h)+ny(o.Ae);return xd(h)&&xd(o.Ae)?hv(m):ff(o.serializer,m)})(r,e)}function bA(r,e,t){return r instanceof Qa?fv(r,e):r instanceof Ya?pv(r,e):t}function dv(r,e){return r instanceof sc?(function(s){return xd(s)||(function(l){return!!l&&"doubleValue"in l})(s)})(e)?e:{integerValue:0}:null}class Ga extends Ic{}class Qa extends Ic{constructor(e){super(),this.elements=e}}function fv(r,e){const t=mv(e);for(const s of r.elements)t.some((o=>ir(o,s)))||t.push(s);return{arrayValue:{values:t}}}class Ya extends Ic{constructor(e){super(),this.elements=e}}function pv(r,e){let t=mv(e);for(const s of r.elements)t=t.filter((o=>!ir(o,s)));return{arrayValue:{values:t}}}class sc extends Ic{constructor(e,t){super(),this.serializer=e,this.Ae=t}}function ny(r){return lt(r.integerValue||r.doubleValue)}function mv(r){return uf(r)&&r.arrayValue.values?r.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class MA{constructor(e,t){this.field=e,this.transform=t}}function FA(r,e){return r.field.isEqual(e.field)&&(function(s,o){return s instanceof Qa&&o instanceof Qa||s instanceof Ya&&o instanceof Ya?vo(s.elements,o.elements,ir):s instanceof sc&&o instanceof sc?ir(s.Ae,o.Ae):s instanceof Ga&&o instanceof Ga})(r.transform,e.transform)}class UA{constructor(e,t){this.version=e,this.transformResults=t}}class Nn{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new Nn}static exists(e){return new Nn(void 0,e)}static updateTime(e){return new Nn(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function zu(r,e){return r.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(r.updateTime):r.exists===void 0||r.exists===e.isFoundDocument()}class Sc{}function gv(r,e){if(!r.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return r.isNoDocument()?new pf(r.key,Nn.none()):new ol(r.key,r.data,Nn.none());{const t=r.data,s=Jt.empty();let o=new vt(Nt.comparator);for(let l of e.fields)if(!o.has(l)){let h=t.field(l);h===null&&l.length>1&&(l=l.popLast(),h=t.field(l)),h===null?s.delete(l):s.set(l,h),o=o.add(l)}return new ki(r.key,s,new ln(o.toArray()),Nn.none())}}function jA(r,e,t){r instanceof ol?(function(o,l,h){const m=o.value.clone(),g=iy(o.fieldTransforms,l,h.transformResults);m.setAll(g),l.convertToFoundDocument(h.version,m).setHasCommittedMutations()})(r,e,t):r instanceof ki?(function(o,l,h){if(!zu(o.precondition,l))return void l.convertToUnknownDocument(h.version);const m=iy(o.fieldTransforms,l,h.transformResults),g=l.data;g.setAll(yv(o)),g.setAll(m),l.convertToFoundDocument(h.version,g).setHasCommittedMutations()})(r,e,t):(function(o,l,h){l.convertToNoDocument(h.version).setHasCommittedMutations()})(0,e,t)}function Ua(r,e,t,s){return r instanceof ol?(function(l,h,m,g){if(!zu(l.precondition,h))return m;const _=l.value.clone(),E=sy(l.fieldTransforms,g,h);return _.setAll(E),h.convertToFoundDocument(h.version,_).setHasLocalMutations(),null})(r,e,t,s):r instanceof ki?(function(l,h,m,g){if(!zu(l.precondition,h))return m;const _=sy(l.fieldTransforms,g,h),E=h.data;return E.setAll(yv(l)),E.setAll(_),h.convertToFoundDocument(h.version,E).setHasLocalMutations(),m===null?null:m.unionWith(l.fieldMask.fields).unionWith(l.fieldTransforms.map((I=>I.field)))})(r,e,t,s):(function(l,h,m){return zu(l.precondition,h)?(h.convertToNoDocument(h.version).setHasLocalMutations(),null):m})(r,e,t)}function zA(r,e){let t=null;for(const s of r.fieldTransforms){const o=e.data.field(s.field),l=dv(s.transform,o||null);l!=null&&(t===null&&(t=Jt.empty()),t.set(s.field,l))}return t||null}function ry(r,e){return r.type===e.type&&!!r.key.isEqual(e.key)&&!!r.precondition.isEqual(e.precondition)&&!!(function(s,o){return s===void 0&&o===void 0||!(!s||!o)&&vo(s,o,((l,h)=>FA(l,h)))})(r.fieldTransforms,e.fieldTransforms)&&(r.type===0?r.value.isEqual(e.value):r.type!==1||r.data.isEqual(e.data)&&r.fieldMask.isEqual(e.fieldMask))}class ol extends Sc{constructor(e,t,s,o=[]){super(),this.key=e,this.value=t,this.precondition=s,this.fieldTransforms=o,this.type=0}getFieldMask(){return null}}class ki extends Sc{constructor(e,t,s,o,l=[]){super(),this.key=e,this.data=t,this.fieldMask=s,this.precondition=o,this.fieldTransforms=l,this.type=1}getFieldMask(){return this.fieldMask}}function yv(r){const e=new Map;return r.fieldMask.fields.forEach((t=>{if(!t.isEmpty()){const s=r.data.field(t);e.set(t,s)}})),e}function iy(r,e,t){const s=new Map;ze(r.length===t.length,32656,{Ve:t.length,de:r.length});for(let o=0;o<t.length;o++){const l=r[o],h=l.transform,m=e.data.field(l.field);s.set(l.field,bA(h,m,t[o]))}return s}function sy(r,e,t){const s=new Map;for(const o of r){const l=o.transform,h=t.data.field(o.field);s.set(o.field,LA(l,h,e))}return s}class pf extends Sc{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class BA extends Sc{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $A{constructor(e,t,s,o){this.batchId=e,this.localWriteTime=t,this.baseMutations=s,this.mutations=o}applyToRemoteDocument(e,t){const s=t.mutationResults;for(let o=0;o<this.mutations.length;o++){const l=this.mutations[o];l.key.isEqual(e.key)&&jA(l,e,s[o])}}applyToLocalView(e,t){for(const s of this.baseMutations)s.key.isEqual(e.key)&&(t=Ua(s,e,t,this.localWriteTime));for(const s of this.mutations)s.key.isEqual(e.key)&&(t=Ua(s,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const s=cv();return this.mutations.forEach((o=>{const l=e.get(o.key),h=l.overlayedDocument;let m=this.applyToLocalView(h,l.mutatedFields);m=t.has(o.key)?null:m;const g=gv(h,m);g!==null&&s.set(o.key,g),h.isValidDocument()||h.convertToNoDocument(ye.min())})),s}keys(){return this.mutations.reduce(((e,t)=>e.add(t.key)),xe())}isEqual(e){return this.batchId===e.batchId&&vo(this.mutations,e.mutations,((t,s)=>ry(t,s)))&&vo(this.baseMutations,e.baseMutations,((t,s)=>ry(t,s)))}}class mf{constructor(e,t,s,o){this.batch=e,this.commitVersion=t,this.mutationResults=s,this.docVersions=o}static from(e,t,s){ze(e.mutations.length===s.length,58842,{me:e.mutations.length,fe:s.length});let o=(function(){return NA})();const l=e.mutations;for(let h=0;h<l.length;h++)o=o.insert(l[h].key,s[h].version);return new mf(e,t,s,o)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class HA{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class WA{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ft,Oe;function qA(r){switch(r){case $.OK:return me(64938);case $.CANCELLED:case $.UNKNOWN:case $.DEADLINE_EXCEEDED:case $.RESOURCE_EXHAUSTED:case $.INTERNAL:case $.UNAVAILABLE:case $.UNAUTHENTICATED:return!1;case $.INVALID_ARGUMENT:case $.NOT_FOUND:case $.ALREADY_EXISTS:case $.PERMISSION_DENIED:case $.FAILED_PRECONDITION:case $.ABORTED:case $.OUT_OF_RANGE:case $.UNIMPLEMENTED:case $.DATA_LOSS:return!0;default:return me(15467,{code:r})}}function _v(r){if(r===void 0)return Pr("GRPC error has no .code"),$.UNKNOWN;switch(r){case ft.OK:return $.OK;case ft.CANCELLED:return $.CANCELLED;case ft.UNKNOWN:return $.UNKNOWN;case ft.DEADLINE_EXCEEDED:return $.DEADLINE_EXCEEDED;case ft.RESOURCE_EXHAUSTED:return $.RESOURCE_EXHAUSTED;case ft.INTERNAL:return $.INTERNAL;case ft.UNAVAILABLE:return $.UNAVAILABLE;case ft.UNAUTHENTICATED:return $.UNAUTHENTICATED;case ft.INVALID_ARGUMENT:return $.INVALID_ARGUMENT;case ft.NOT_FOUND:return $.NOT_FOUND;case ft.ALREADY_EXISTS:return $.ALREADY_EXISTS;case ft.PERMISSION_DENIED:return $.PERMISSION_DENIED;case ft.FAILED_PRECONDITION:return $.FAILED_PRECONDITION;case ft.ABORTED:return $.ABORTED;case ft.OUT_OF_RANGE:return $.OUT_OF_RANGE;case ft.UNIMPLEMENTED:return $.UNIMPLEMENTED;case ft.DATA_LOSS:return $.DATA_LOSS;default:return me(39323,{code:r})}}(Oe=ft||(ft={}))[Oe.OK=0]="OK",Oe[Oe.CANCELLED=1]="CANCELLED",Oe[Oe.UNKNOWN=2]="UNKNOWN",Oe[Oe.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",Oe[Oe.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",Oe[Oe.NOT_FOUND=5]="NOT_FOUND",Oe[Oe.ALREADY_EXISTS=6]="ALREADY_EXISTS",Oe[Oe.PERMISSION_DENIED=7]="PERMISSION_DENIED",Oe[Oe.UNAUTHENTICATED=16]="UNAUTHENTICATED",Oe[Oe.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",Oe[Oe.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",Oe[Oe.ABORTED=10]="ABORTED",Oe[Oe.OUT_OF_RANGE=11]="OUT_OF_RANGE",Oe[Oe.UNIMPLEMENTED=12]="UNIMPLEMENTED",Oe[Oe.INTERNAL=13]="INTERNAL",Oe[Oe.UNAVAILABLE=14]="UNAVAILABLE",Oe[Oe.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function KA(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const GA=new _i([4294967295,4294967295],0);function oy(r){const e=KA().encode(r),t=new V_;return t.update(e),new Uint8Array(t.digest())}function ay(r){const e=new DataView(r.buffer),t=e.getUint32(0,!0),s=e.getUint32(4,!0),o=e.getUint32(8,!0),l=e.getUint32(12,!0);return[new _i([t,s],0),new _i([o,l],0)]}class gf{constructor(e,t,s){if(this.bitmap=e,this.padding=t,this.hashCount=s,t<0||t>=8)throw new Va(`Invalid padding: ${t}`);if(s<0)throw new Va(`Invalid hash count: ${s}`);if(e.length>0&&this.hashCount===0)throw new Va(`Invalid hash count: ${s}`);if(e.length===0&&t!==0)throw new Va(`Invalid padding when bitmap length is 0: ${t}`);this.ge=8*e.length-t,this.pe=_i.fromNumber(this.ge)}ye(e,t,s){let o=e.add(t.multiply(_i.fromNumber(s)));return o.compare(GA)===1&&(o=new _i([o.getBits(0),o.getBits(1)],0)),o.modulo(this.pe).toNumber()}we(e){return!!(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(this.ge===0)return!1;const t=oy(e),[s,o]=ay(t);for(let l=0;l<this.hashCount;l++){const h=this.ye(s,o,l);if(!this.we(h))return!1}return!0}static create(e,t,s){const o=e%8==0?0:8-e%8,l=new Uint8Array(Math.ceil(e/8)),h=new gf(l,o,t);return s.forEach((m=>h.insert(m))),h}insert(e){if(this.ge===0)return;const t=oy(e),[s,o]=ay(t);for(let l=0;l<this.hashCount;l++){const h=this.ye(s,o,l);this.Se(h)}}Se(e){const t=Math.floor(e/8),s=e%8;this.bitmap[t]|=1<<s}}class Va extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ac{constructor(e,t,s,o,l){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=s,this.documentUpdates=o,this.resolvedLimboDocuments=l}static createSynthesizedRemoteEventForCurrentChange(e,t,s){const o=new Map;return o.set(e,al.createSynthesizedTargetChangeForCurrentChange(e,t,s)),new Ac(ye.min(),o,new nt(Ne),kr(),xe())}}class al{constructor(e,t,s,o,l){this.resumeToken=e,this.current=t,this.addedDocuments=s,this.modifiedDocuments=o,this.removedDocuments=l}static createSynthesizedTargetChangeForCurrentChange(e,t,s){return new al(s,t,xe(),xe(),xe())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bu{constructor(e,t,s,o){this.be=e,this.removedTargetIds=t,this.key=s,this.De=o}}class vv{constructor(e,t){this.targetId=e,this.Ce=t}}class Ev{constructor(e,t,s=xt.EMPTY_BYTE_STRING,o=null){this.state=e,this.targetIds=t,this.resumeToken=s,this.cause=o}}class ly{constructor(){this.ve=0,this.Fe=uy(),this.Me=xt.EMPTY_BYTE_STRING,this.xe=!1,this.Oe=!0}get current(){return this.xe}get resumeToken(){return this.Me}get Ne(){return this.ve!==0}get Be(){return this.Oe}Le(e){e.approximateByteSize()>0&&(this.Oe=!0,this.Me=e)}ke(){let e=xe(),t=xe(),s=xe();return this.Fe.forEach(((o,l)=>{switch(l){case 0:e=e.add(o);break;case 2:t=t.add(o);break;case 1:s=s.add(o);break;default:me(38017,{changeType:l})}})),new al(this.Me,this.xe,e,t,s)}qe(){this.Oe=!1,this.Fe=uy()}Ke(e,t){this.Oe=!0,this.Fe=this.Fe.insert(e,t)}Ue(e){this.Oe=!0,this.Fe=this.Fe.remove(e)}$e(){this.ve+=1}We(){this.ve-=1,ze(this.ve>=0,3241,{ve:this.ve})}Qe(){this.Oe=!0,this.xe=!0}}class QA{constructor(e){this.Ge=e,this.ze=new Map,this.je=kr(),this.Je=Du(),this.He=Du(),this.Ze=new nt(Ne)}Xe(e){for(const t of e.be)e.De&&e.De.isFoundDocument()?this.Ye(t,e.De):this.et(t,e.key,e.De);for(const t of e.removedTargetIds)this.et(t,e.key,e.De)}tt(e){this.forEachTarget(e,(t=>{const s=this.nt(t);switch(e.state){case 0:this.rt(t)&&s.Le(e.resumeToken);break;case 1:s.We(),s.Ne||s.qe(),s.Le(e.resumeToken);break;case 2:s.We(),s.Ne||this.removeTarget(t);break;case 3:this.rt(t)&&(s.Qe(),s.Le(e.resumeToken));break;case 4:this.rt(t)&&(this.it(t),s.Le(e.resumeToken));break;default:me(56790,{state:e.state})}}))}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.ze.forEach(((s,o)=>{this.rt(o)&&t(o)}))}st(e){const t=e.targetId,s=e.Ce.count,o=this.ot(t);if(o){const l=o.target;if(Vd(l))if(s===0){const h=new ce(l.path);this.et(t,h,Ut.newNoDocument(h,ye.min()))}else ze(s===1,20013,{expectedCount:s});else{const h=this._t(t);if(h!==s){const m=this.ut(e),g=m?this.ct(m,e,h):1;if(g!==0){this.it(t);const _=g===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Ze=this.Ze.insert(t,_)}}}}}ut(e){const t=e.Ce.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:s="",padding:o=0},hashCount:l=0}=t;let h,m;try{h=Ii(s).toUint8Array()}catch(g){if(g instanceof W_)return ds("Decoding the base64 bloom filter in existence filter failed ("+g.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw g}try{m=new gf(h,o,l)}catch(g){return ds(g instanceof Va?"BloomFilter error: ":"Applying bloom filter failed: ",g),null}return m.ge===0?null:m}ct(e,t,s){return t.Ce.count===s-this.Pt(e,t.targetId)?0:2}Pt(e,t){const s=this.Ge.getRemoteKeysForTarget(t);let o=0;return s.forEach((l=>{const h=this.Ge.ht(),m=`projects/${h.projectId}/databases/${h.database}/documents/${l.path.canonicalString()}`;e.mightContain(m)||(this.et(t,l,null),o++)})),o}Tt(e){const t=new Map;this.ze.forEach(((l,h)=>{const m=this.ot(h);if(m){if(l.current&&Vd(m.target)){const g=new ce(m.target.path);this.Et(g).has(h)||this.It(h,g)||this.et(h,g,Ut.newNoDocument(g,e))}l.Be&&(t.set(h,l.ke()),l.qe())}}));let s=xe();this.He.forEach(((l,h)=>{let m=!0;h.forEachWhile((g=>{const _=this.ot(g);return!_||_.purpose==="TargetPurposeLimboResolution"||(m=!1,!1)})),m&&(s=s.add(l))})),this.je.forEach(((l,h)=>h.setReadTime(e)));const o=new Ac(e,t,this.Ze,this.je,s);return this.je=kr(),this.Je=Du(),this.He=Du(),this.Ze=new nt(Ne),o}Ye(e,t){if(!this.rt(e))return;const s=this.It(e,t.key)?2:0;this.nt(e).Ke(t.key,s),this.je=this.je.insert(t.key,t),this.Je=this.Je.insert(t.key,this.Et(t.key).add(e)),this.He=this.He.insert(t.key,this.Rt(t.key).add(e))}et(e,t,s){if(!this.rt(e))return;const o=this.nt(e);this.It(e,t)?o.Ke(t,1):o.Ue(t),this.He=this.He.insert(t,this.Rt(t).delete(e)),this.He=this.He.insert(t,this.Rt(t).add(e)),s&&(this.je=this.je.insert(t,s))}removeTarget(e){this.ze.delete(e)}_t(e){const t=this.nt(e).ke();return this.Ge.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}$e(e){this.nt(e).$e()}nt(e){let t=this.ze.get(e);return t||(t=new ly,this.ze.set(e,t)),t}Rt(e){let t=this.He.get(e);return t||(t=new vt(Ne),this.He=this.He.insert(e,t)),t}Et(e){let t=this.Je.get(e);return t||(t=new vt(Ne),this.Je=this.Je.insert(e,t)),t}rt(e){const t=this.ot(e)!==null;return t||re("WatchChangeAggregator","Detected inactive target",e),t}ot(e){const t=this.ze.get(e);return t&&t.Ne?null:this.Ge.At(e)}it(e){this.ze.set(e,new ly),this.Ge.getRemoteKeysForTarget(e).forEach((t=>{this.et(e,t,null)}))}It(e,t){return this.Ge.getRemoteKeysForTarget(e).has(t)}}function Du(){return new nt(ce.comparator)}function uy(){return new nt(ce.comparator)}const YA={asc:"ASCENDING",desc:"DESCENDING"},JA={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},XA={and:"AND",or:"OR"};class ZA{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function bd(r,e){return r.useProto3Json||vc(e)?e:{value:e}}function oc(r,e){return r.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function wv(r,e){return r.useProto3Json?e.toBase64():e.toUint8Array()}function eR(r,e){return oc(r,e.toTimestamp())}function nr(r){return ze(!!r,49232),ye.fromTimestamp((function(t){const s=Ti(t);return new Xe(s.seconds,s.nanos)})(r))}function yf(r,e){return Md(r,e).canonicalString()}function Md(r,e){const t=(function(o){return new Ge(["projects",o.projectId,"databases",o.database])})(r).child("documents");return e===void 0?t:t.child(e)}function Tv(r){const e=Ge.fromString(r);return ze(Cv(e),10190,{key:e.toString()}),e}function Fd(r,e){return yf(r.databaseId,e.path)}function gd(r,e){const t=Tv(e);if(t.get(1)!==r.databaseId.projectId)throw new ie($.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+r.databaseId.projectId);if(t.get(3)!==r.databaseId.database)throw new ie($.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+r.databaseId.database);return new ce(Sv(t))}function Iv(r,e){return yf(r.databaseId,e)}function tR(r){const e=Tv(r);return e.length===4?Ge.emptyPath():Sv(e)}function Ud(r){return new Ge(["projects",r.databaseId.projectId,"databases",r.databaseId.database]).canonicalString()}function Sv(r){return ze(r.length>4&&r.get(4)==="documents",29091,{key:r.toString()}),r.popFirst(5)}function cy(r,e,t){return{name:Fd(r,e),fields:t.value.mapValue.fields}}function nR(r,e){let t;if("targetChange"in e){e.targetChange;const s=(function(_){return _==="NO_CHANGE"?0:_==="ADD"?1:_==="REMOVE"?2:_==="CURRENT"?3:_==="RESET"?4:me(39313,{state:_})})(e.targetChange.targetChangeType||"NO_CHANGE"),o=e.targetChange.targetIds||[],l=(function(_,E){return _.useProto3Json?(ze(E===void 0||typeof E=="string",58123),xt.fromBase64String(E||"")):(ze(E===void 0||E instanceof Buffer||E instanceof Uint8Array,16193),xt.fromUint8Array(E||new Uint8Array))})(r,e.targetChange.resumeToken),h=e.targetChange.cause,m=h&&(function(_){const E=_.code===void 0?$.UNKNOWN:_v(_.code);return new ie(E,_.message||"")})(h);t=new Ev(s,o,l,m||null)}else if("documentChange"in e){e.documentChange;const s=e.documentChange;s.document,s.document.name,s.document.updateTime;const o=gd(r,s.document.name),l=nr(s.document.updateTime),h=s.document.createTime?nr(s.document.createTime):ye.min(),m=new Jt({mapValue:{fields:s.document.fields}}),g=Ut.newFoundDocument(o,l,h,m),_=s.targetIds||[],E=s.removedTargetIds||[];t=new Bu(_,E,g.key,g)}else if("documentDelete"in e){e.documentDelete;const s=e.documentDelete;s.document;const o=gd(r,s.document),l=s.readTime?nr(s.readTime):ye.min(),h=Ut.newNoDocument(o,l),m=s.removedTargetIds||[];t=new Bu([],m,h.key,h)}else if("documentRemove"in e){e.documentRemove;const s=e.documentRemove;s.document;const o=gd(r,s.document),l=s.removedTargetIds||[];t=new Bu([],l,o,null)}else{if(!("filter"in e))return me(11601,{Vt:e});{e.filter;const s=e.filter;s.targetId;const{count:o=0,unchangedNames:l}=s,h=new WA(o,l),m=s.targetId;t=new vv(m,h)}}return t}function rR(r,e){let t;if(e instanceof ol)t={update:cy(r,e.key,e.value)};else if(e instanceof pf)t={delete:Fd(r,e.key)};else if(e instanceof ki)t={update:cy(r,e.key,e.data),updateMask:dR(e.fieldMask)};else{if(!(e instanceof BA))return me(16599,{dt:e.type});t={verify:Fd(r,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map((s=>(function(l,h){const m=h.transform;if(m instanceof Ga)return{fieldPath:h.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(m instanceof Qa)return{fieldPath:h.field.canonicalString(),appendMissingElements:{values:m.elements}};if(m instanceof Ya)return{fieldPath:h.field.canonicalString(),removeAllFromArray:{values:m.elements}};if(m instanceof sc)return{fieldPath:h.field.canonicalString(),increment:m.Ae};throw me(20930,{transform:h.transform})})(0,s)))),e.precondition.isNone||(t.currentDocument=(function(o,l){return l.updateTime!==void 0?{updateTime:eR(o,l.updateTime)}:l.exists!==void 0?{exists:l.exists}:me(27497)})(r,e.precondition)),t}function iR(r,e){return r&&r.length>0?(ze(e!==void 0,14353),r.map((t=>(function(o,l){let h=o.updateTime?nr(o.updateTime):nr(l);return h.isEqual(ye.min())&&(h=nr(l)),new UA(h,o.transformResults||[])})(t,e)))):[]}function sR(r,e){return{documents:[Iv(r,e.path)]}}function oR(r,e){const t={structuredQuery:{}},s=e.path;let o;e.collectionGroup!==null?(o=s,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(o=s.popLast(),t.structuredQuery.from=[{collectionId:s.lastSegment()}]),t.parent=Iv(r,o);const l=(function(_){if(_.length!==0)return Rv(Vn.create(_,"and"))})(e.filters);l&&(t.structuredQuery.where=l);const h=(function(_){if(_.length!==0)return _.map((E=>(function(C){return{field:oo(C.field),direction:uR(C.dir)}})(E)))})(e.orderBy);h&&(t.structuredQuery.orderBy=h);const m=bd(r,e.limit);return m!==null&&(t.structuredQuery.limit=m),e.startAt&&(t.structuredQuery.startAt=(function(_){return{before:_.inclusive,values:_.position}})(e.startAt)),e.endAt&&(t.structuredQuery.endAt=(function(_){return{before:!_.inclusive,values:_.position}})(e.endAt)),{ft:t,parent:o}}function aR(r){let e=tR(r.parent);const t=r.structuredQuery,s=t.from?t.from.length:0;let o=null;if(s>0){ze(s===1,65062);const E=t.from[0];E.allDescendants?o=E.collectionId:e=e.child(E.collectionId)}let l=[];t.where&&(l=(function(I){const C=Av(I);return C instanceof Vn&&tv(C)?C.getFilters():[C]})(t.where));let h=[];t.orderBy&&(h=(function(I){return I.map((C=>(function(G){return new ic(ao(G.field),(function(B){switch(B){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}})(G.direction))})(C)))})(t.orderBy));let m=null;t.limit&&(m=(function(I){let C;return C=typeof I=="object"?I.value:I,vc(C)?null:C})(t.limit));let g=null;t.startAt&&(g=(function(I){const C=!!I.before,z=I.values||[];return new rc(z,C)})(t.startAt));let _=null;return t.endAt&&(_=(function(I){const C=!I.before,z=I.values||[];return new rc(z,C)})(t.endAt)),SA(e,o,h,l,m,"F",g,_)}function lR(r,e){const t=(function(o){switch(o){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return me(28987,{purpose:o})}})(e.purpose);return t==null?null:{"goog-listen-tags":t}}function Av(r){return r.unaryFilter!==void 0?(function(t){switch(t.unaryFilter.op){case"IS_NAN":const s=ao(t.unaryFilter.field);return pt.create(s,"==",{doubleValue:NaN});case"IS_NULL":const o=ao(t.unaryFilter.field);return pt.create(o,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const l=ao(t.unaryFilter.field);return pt.create(l,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const h=ao(t.unaryFilter.field);return pt.create(h,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return me(61313);default:return me(60726)}})(r):r.fieldFilter!==void 0?(function(t){return pt.create(ao(t.fieldFilter.field),(function(o){switch(o){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return me(58110);default:return me(50506)}})(t.fieldFilter.op),t.fieldFilter.value)})(r):r.compositeFilter!==void 0?(function(t){return Vn.create(t.compositeFilter.filters.map((s=>Av(s))),(function(o){switch(o){case"AND":return"and";case"OR":return"or";default:return me(1026)}})(t.compositeFilter.op))})(r):me(30097,{filter:r})}function uR(r){return YA[r]}function cR(r){return JA[r]}function hR(r){return XA[r]}function oo(r){return{fieldPath:r.canonicalString()}}function ao(r){return Nt.fromServerFormat(r.fieldPath)}function Rv(r){return r instanceof pt?(function(t){if(t.op==="=="){if(Jg(t.value))return{unaryFilter:{field:oo(t.field),op:"IS_NAN"}};if(Yg(t.value))return{unaryFilter:{field:oo(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(Jg(t.value))return{unaryFilter:{field:oo(t.field),op:"IS_NOT_NAN"}};if(Yg(t.value))return{unaryFilter:{field:oo(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:oo(t.field),op:cR(t.op),value:t.value}}})(r):r instanceof Vn?(function(t){const s=t.getFilters().map((o=>Rv(o)));return s.length===1?s[0]:{compositeFilter:{op:hR(t.op),filters:s}}})(r):me(54877,{filter:r})}function dR(r){const e=[];return r.fields.forEach((t=>e.push(t.canonicalString()))),{fieldPaths:e}}function Cv(r){return r.length>=4&&r.get(0)==="projects"&&r.get(2)==="databases"}function Pv(r){return!!r&&typeof r._toProto=="function"&&r._protoValueType==="ProtoValue"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pi{constructor(e,t,s,o,l=ye.min(),h=ye.min(),m=xt.EMPTY_BYTE_STRING,g=null){this.target=e,this.targetId=t,this.purpose=s,this.sequenceNumber=o,this.snapshotVersion=l,this.lastLimboFreeSnapshotVersion=h,this.resumeToken=m,this.expectedCount=g}withSequenceNumber(e){return new pi(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new pi(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new pi(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new pi(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fR{constructor(e){this.yt=e}}function pR(r){const e=aR({parent:r.parent,structuredQuery:r.structuredQuery});return r.limitType==="LAST"?Ld(e,e.limit,"L"):e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mR{constructor(){this.bn=new gR}addToCollectionParentIndex(e,t){return this.bn.add(t),H.resolve()}getCollectionParents(e,t){return H.resolve(this.bn.getEntries(t))}addFieldIndex(e,t){return H.resolve()}deleteFieldIndex(e,t){return H.resolve()}deleteAllFieldIndexes(e){return H.resolve()}createTargetIndexes(e,t){return H.resolve()}getDocumentsMatchingTarget(e,t){return H.resolve(null)}getIndexType(e,t){return H.resolve(0)}getFieldIndexes(e,t){return H.resolve([])}getNextCollectionGroupToUpdate(e){return H.resolve(null)}getMinOffset(e,t){return H.resolve(wi.min())}getMinOffsetFromCollectionGroup(e,t){return H.resolve(wi.min())}updateCollectionGroup(e,t,s){return H.resolve()}updateIndexEntries(e,t){return H.resolve()}}class gR{constructor(){this.index={}}add(e){const t=e.lastSegment(),s=e.popLast(),o=this.index[t]||new vt(Ge.comparator),l=!o.has(s);return this.index[t]=o.add(s),l}has(e){const t=e.lastSegment(),s=e.popLast(),o=this.index[t];return o&&o.has(s)}getEntries(e){return(this.index[e]||new vt(Ge.comparator)).toArray()}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hy={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},kv=41943040;class Yt{static withCacheSize(e){return new Yt(e,Yt.DEFAULT_COLLECTION_PERCENTILE,Yt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(e,t,s){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Yt.DEFAULT_COLLECTION_PERCENTILE=10,Yt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,Yt.DEFAULT=new Yt(kv,Yt.DEFAULT_COLLECTION_PERCENTILE,Yt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),Yt.DISABLED=new Yt(-1,0,0);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class To{constructor(e){this.sr=e}next(){return this.sr+=2,this.sr}static _r(){return new To(0)}static ar(){return new To(-1)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dy="LruGarbageCollector",yR=1048576;function fy([r,e],[t,s]){const o=Ne(r,t);return o===0?Ne(e,s):o}class _R{constructor(e){this.Pr=e,this.buffer=new vt(fy),this.Tr=0}Er(){return++this.Tr}Ir(e){const t=[e,this.Er()];if(this.buffer.size<this.Pr)this.buffer=this.buffer.add(t);else{const s=this.buffer.last();fy(t,s)<0&&(this.buffer=this.buffer.delete(s).add(t))}}get maxValue(){return this.buffer.last()[0]}}class vR{constructor(e,t,s){this.garbageCollector=e,this.asyncQueue=t,this.localStore=s,this.Rr=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.Ar(6e4)}stop(){this.Rr&&(this.Rr.cancel(),this.Rr=null)}get started(){return this.Rr!==null}Ar(e){re(dy,`Garbage collection scheduled in ${e}ms`),this.Rr=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,(async()=>{this.Rr=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){No(t)?re(dy,"Ignoring IndexedDB error during garbage collection: ",t):await ko(t)}await this.Ar(3e5)}))}}class ER{constructor(e,t){this.Vr=e,this.params=t}calculateTargetCount(e,t){return this.Vr.dr(e).next((s=>Math.floor(t/100*s)))}nthSequenceNumber(e,t){if(t===0)return H.resolve(_c.ce);const s=new _R(t);return this.Vr.forEachTarget(e,(o=>s.Ir(o.sequenceNumber))).next((()=>this.Vr.mr(e,(o=>s.Ir(o))))).next((()=>s.maxValue))}removeTargets(e,t,s){return this.Vr.removeTargets(e,t,s)}removeOrphanedDocuments(e,t){return this.Vr.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(re("LruGarbageCollector","Garbage collection skipped; disabled"),H.resolve(hy)):this.getCacheSize(e).next((s=>s<this.params.cacheSizeCollectionThreshold?(re("LruGarbageCollector",`Garbage collection skipped; Cache size ${s} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),hy):this.gr(e,t)))}getCacheSize(e){return this.Vr.getCacheSize(e)}gr(e,t){let s,o,l,h,m,g,_;const E=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next((I=>(I>this.params.maximumSequenceNumbersToCollect?(re("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${I}`),o=this.params.maximumSequenceNumbersToCollect):o=I,h=Date.now(),this.nthSequenceNumber(e,o)))).next((I=>(s=I,m=Date.now(),this.removeTargets(e,s,t)))).next((I=>(l=I,g=Date.now(),this.removeOrphanedDocuments(e,s)))).next((I=>(_=Date.now(),io()<=ke.DEBUG&&re("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${h-E}ms
	Determined least recently used ${o} in `+(m-h)+`ms
	Removed ${l} targets in `+(g-m)+`ms
	Removed ${I} documents in `+(_-g)+`ms
Total Duration: ${_-E}ms`),H.resolve({didRun:!0,sequenceNumbersCollected:o,targetsRemoved:l,documentsRemoved:I}))))}}function wR(r,e){return new ER(r,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class TR{constructor(){this.changes=new ps((e=>e.toString()),((e,t)=>e.isEqual(t))),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,Ut.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const s=this.changes.get(t);return s!==void 0?H.resolve(s):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class IR{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class SR{constructor(e,t,s,o){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=s,this.indexManager=o}getDocument(e,t){let s=null;return this.documentOverlayCache.getOverlay(e,t).next((o=>(s=o,this.remoteDocumentCache.getEntry(e,t)))).next((o=>(s!==null&&Ua(s.mutation,o,ln.empty(),Xe.now()),o)))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next((s=>this.getLocalViewOfDocuments(e,s,xe()).next((()=>s))))}getLocalViewOfDocuments(e,t,s=xe()){const o=is();return this.populateOverlays(e,o,t).next((()=>this.computeViews(e,t,o,s).next((l=>{let h=Da();return l.forEach(((m,g)=>{h=h.insert(m,g.overlayedDocument)})),h}))))}getOverlayedDocuments(e,t){const s=is();return this.populateOverlays(e,s,t).next((()=>this.computeViews(e,t,s,xe())))}populateOverlays(e,t,s){const o=[];return s.forEach((l=>{t.has(l)||o.push(l)})),this.documentOverlayCache.getOverlays(e,o).next((l=>{l.forEach(((h,m)=>{t.set(h,m)}))}))}computeViews(e,t,s,o){let l=kr();const h=Fa(),m=(function(){return Fa()})();return t.forEach(((g,_)=>{const E=s.get(_.key);o.has(_.key)&&(E===void 0||E.mutation instanceof ki)?l=l.insert(_.key,_):E!==void 0?(h.set(_.key,E.mutation.getFieldMask()),Ua(E.mutation,_,E.mutation.getFieldMask(),Xe.now())):h.set(_.key,ln.empty())})),this.recalculateAndSaveOverlays(e,l).next((g=>(g.forEach(((_,E)=>h.set(_,E))),t.forEach(((_,E)=>m.set(_,new IR(E,h.get(_)??null)))),m)))}recalculateAndSaveOverlays(e,t){const s=Fa();let o=new nt(((h,m)=>h-m)),l=xe();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next((h=>{for(const m of h)m.keys().forEach((g=>{const _=t.get(g);if(_===null)return;let E=s.get(g)||ln.empty();E=m.applyToLocalView(_,E),s.set(g,E);const I=(o.get(m.batchId)||xe()).add(g);o=o.insert(m.batchId,I)}))})).next((()=>{const h=[],m=o.getReverseIterator();for(;m.hasNext();){const g=m.getNext(),_=g.key,E=g.value,I=cv();E.forEach((C=>{if(!l.has(C)){const z=gv(t.get(C),s.get(C));z!==null&&I.set(C,z),l=l.add(C)}})),h.push(this.documentOverlayCache.saveOverlays(e,_,I))}return H.waitFor(h)})).next((()=>s))}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next((s=>this.recalculateAndSaveOverlays(e,s)))}getDocumentsMatchingQuery(e,t,s,o){return AA(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):sv(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,s,o):this.getDocumentsMatchingCollectionQuery(e,t,s,o)}getNextDocuments(e,t,s,o){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,s,o).next((l=>{const h=o-l.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,s.largestBatchId,o-l.size):H.resolve(is());let m=Ha,g=l;return h.next((_=>H.forEach(_,((E,I)=>(m<I.largestBatchId&&(m=I.largestBatchId),l.get(E)?H.resolve():this.remoteDocumentCache.getEntry(e,E).next((C=>{g=g.insert(E,C)}))))).next((()=>this.populateOverlays(e,_,l))).next((()=>this.computeViews(e,g,_,xe()))).next((E=>({batchId:m,changes:uv(E)})))))}))}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new ce(t)).next((s=>{let o=Da();return s.isFoundDocument()&&(o=o.insert(s.key,s)),o}))}getDocumentsMatchingCollectionGroupQuery(e,t,s,o){const l=t.collectionGroup;let h=Da();return this.indexManager.getCollectionParents(e,l).next((m=>H.forEach(m,(g=>{const _=(function(I,C){return new sl(C,null,I.explicitOrderBy.slice(),I.filters.slice(),I.limit,I.limitType,I.startAt,I.endAt)})(t,g.child(l));return this.getDocumentsMatchingCollectionQuery(e,_,s,o).next((E=>{E.forEach(((I,C)=>{h=h.insert(I,C)}))}))})).next((()=>h))))}getDocumentsMatchingCollectionQuery(e,t,s,o){let l;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,s.largestBatchId).next((h=>(l=h,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,s,l,o)))).next((h=>{l.forEach(((g,_)=>{const E=_.getKey();h.get(E)===null&&(h=h.insert(E,Ut.newInvalidDocument(E)))}));let m=Da();return h.forEach(((g,_)=>{const E=l.get(g);E!==void 0&&Ua(E.mutation,_,ln.empty(),Xe.now()),Tc(t,_)&&(m=m.insert(g,_))})),m}))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class AR{constructor(e){this.serializer=e,this.Nr=new Map,this.Br=new Map}getBundleMetadata(e,t){return H.resolve(this.Nr.get(t))}saveBundleMetadata(e,t){return this.Nr.set(t.id,(function(o){return{id:o.id,version:o.version,createTime:nr(o.createTime)}})(t)),H.resolve()}getNamedQuery(e,t){return H.resolve(this.Br.get(t))}saveNamedQuery(e,t){return this.Br.set(t.name,(function(o){return{name:o.name,query:pR(o.bundledQuery),readTime:nr(o.readTime)}})(t)),H.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class RR{constructor(){this.overlays=new nt(ce.comparator),this.Lr=new Map}getOverlay(e,t){return H.resolve(this.overlays.get(t))}getOverlays(e,t){const s=is();return H.forEach(t,(o=>this.getOverlay(e,o).next((l=>{l!==null&&s.set(o,l)})))).next((()=>s))}saveOverlays(e,t,s){return s.forEach(((o,l)=>{this.St(e,t,l)})),H.resolve()}removeOverlaysForBatchId(e,t,s){const o=this.Lr.get(s);return o!==void 0&&(o.forEach((l=>this.overlays=this.overlays.remove(l))),this.Lr.delete(s)),H.resolve()}getOverlaysForCollection(e,t,s){const o=is(),l=t.length+1,h=new ce(t.child("")),m=this.overlays.getIteratorFrom(h);for(;m.hasNext();){const g=m.getNext().value,_=g.getKey();if(!t.isPrefixOf(_.path))break;_.path.length===l&&g.largestBatchId>s&&o.set(g.getKey(),g)}return H.resolve(o)}getOverlaysForCollectionGroup(e,t,s,o){let l=new nt(((_,E)=>_-E));const h=this.overlays.getIterator();for(;h.hasNext();){const _=h.getNext().value;if(_.getKey().getCollectionGroup()===t&&_.largestBatchId>s){let E=l.get(_.largestBatchId);E===null&&(E=is(),l=l.insert(_.largestBatchId,E)),E.set(_.getKey(),_)}}const m=is(),g=l.getIterator();for(;g.hasNext()&&(g.getNext().value.forEach(((_,E)=>m.set(_,E))),!(m.size()>=o)););return H.resolve(m)}St(e,t,s){const o=this.overlays.get(s.key);if(o!==null){const h=this.Lr.get(o.largestBatchId).delete(s.key);this.Lr.set(o.largestBatchId,h)}this.overlays=this.overlays.insert(s.key,new HA(t,s));let l=this.Lr.get(t);l===void 0&&(l=xe(),this.Lr.set(t,l)),this.Lr.set(t,l.add(s.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class CR{constructor(){this.sessionToken=xt.EMPTY_BYTE_STRING}getSessionToken(e){return H.resolve(this.sessionToken)}setSessionToken(e,t){return this.sessionToken=t,H.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _f{constructor(){this.kr=new vt(St.qr),this.Kr=new vt(St.Ur)}isEmpty(){return this.kr.isEmpty()}addReference(e,t){const s=new St(e,t);this.kr=this.kr.add(s),this.Kr=this.Kr.add(s)}$r(e,t){e.forEach((s=>this.addReference(s,t)))}removeReference(e,t){this.Wr(new St(e,t))}Qr(e,t){e.forEach((s=>this.removeReference(s,t)))}Gr(e){const t=new ce(new Ge([])),s=new St(t,e),o=new St(t,e+1),l=[];return this.Kr.forEachInRange([s,o],(h=>{this.Wr(h),l.push(h.key)})),l}zr(){this.kr.forEach((e=>this.Wr(e)))}Wr(e){this.kr=this.kr.delete(e),this.Kr=this.Kr.delete(e)}jr(e){const t=new ce(new Ge([])),s=new St(t,e),o=new St(t,e+1);let l=xe();return this.Kr.forEachInRange([s,o],(h=>{l=l.add(h.key)})),l}containsKey(e){const t=new St(e,0),s=this.kr.firstAfterOrEqual(t);return s!==null&&e.isEqual(s.key)}}class St{constructor(e,t){this.key=e,this.Jr=t}static qr(e,t){return ce.comparator(e.key,t.key)||Ne(e.Jr,t.Jr)}static Ur(e,t){return Ne(e.Jr,t.Jr)||ce.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class PR{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.Yn=1,this.Hr=new vt(St.qr)}checkEmpty(e){return H.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,s,o){const l=this.Yn;this.Yn++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const h=new $A(l,t,s,o);this.mutationQueue.push(h);for(const m of o)this.Hr=this.Hr.add(new St(m.key,l)),this.indexManager.addToCollectionParentIndex(e,m.key.path.popLast());return H.resolve(h)}lookupMutationBatch(e,t){return H.resolve(this.Zr(t))}getNextMutationBatchAfterBatchId(e,t){const s=t+1,o=this.Xr(s),l=o<0?0:o;return H.resolve(this.mutationQueue.length>l?this.mutationQueue[l]:null)}getHighestUnacknowledgedBatchId(){return H.resolve(this.mutationQueue.length===0?af:this.Yn-1)}getAllMutationBatches(e){return H.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const s=new St(t,0),o=new St(t,Number.POSITIVE_INFINITY),l=[];return this.Hr.forEachInRange([s,o],(h=>{const m=this.Zr(h.Jr);l.push(m)})),H.resolve(l)}getAllMutationBatchesAffectingDocumentKeys(e,t){let s=new vt(Ne);return t.forEach((o=>{const l=new St(o,0),h=new St(o,Number.POSITIVE_INFINITY);this.Hr.forEachInRange([l,h],(m=>{s=s.add(m.Jr)}))})),H.resolve(this.Yr(s))}getAllMutationBatchesAffectingQuery(e,t){const s=t.path,o=s.length+1;let l=s;ce.isDocumentKey(l)||(l=l.child(""));const h=new St(new ce(l),0);let m=new vt(Ne);return this.Hr.forEachWhile((g=>{const _=g.key.path;return!!s.isPrefixOf(_)&&(_.length===o&&(m=m.add(g.Jr)),!0)}),h),H.resolve(this.Yr(m))}Yr(e){const t=[];return e.forEach((s=>{const o=this.Zr(s);o!==null&&t.push(o)})),t}removeMutationBatch(e,t){ze(this.ei(t.batchId,"removed")===0,55003),this.mutationQueue.shift();let s=this.Hr;return H.forEach(t.mutations,(o=>{const l=new St(o.key,t.batchId);return s=s.delete(l),this.referenceDelegate.markPotentiallyOrphaned(e,o.key)})).next((()=>{this.Hr=s}))}nr(e){}containsKey(e,t){const s=new St(t,0),o=this.Hr.firstAfterOrEqual(s);return H.resolve(t.isEqual(o&&o.key))}performConsistencyCheck(e){return this.mutationQueue.length,H.resolve()}ei(e,t){return this.Xr(e)}Xr(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Zr(e){const t=this.Xr(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kR{constructor(e){this.ti=e,this.docs=(function(){return new nt(ce.comparator)})(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const s=t.key,o=this.docs.get(s),l=o?o.size:0,h=this.ti(t);return this.docs=this.docs.insert(s,{document:t.mutableCopy(),size:h}),this.size+=h-l,this.indexManager.addToCollectionParentIndex(e,s.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const s=this.docs.get(t);return H.resolve(s?s.document.mutableCopy():Ut.newInvalidDocument(t))}getEntries(e,t){let s=kr();return t.forEach((o=>{const l=this.docs.get(o);s=s.insert(o,l?l.document.mutableCopy():Ut.newInvalidDocument(o))})),H.resolve(s)}getDocumentsMatchingQuery(e,t,s,o){let l=kr();const h=t.path,m=new ce(h.child("__id-9223372036854775808__")),g=this.docs.getIteratorFrom(m);for(;g.hasNext();){const{key:_,value:{document:E}}=g.getNext();if(!h.isPrefixOf(_.path))break;_.path.length>h.length+1||tA(eA(E),s)<=0||(o.has(E.key)||Tc(t,E))&&(l=l.insert(E.key,E.mutableCopy()))}return H.resolve(l)}getAllFromCollectionGroup(e,t,s,o){me(9500)}ni(e,t){return H.forEach(this.docs,(s=>t(s)))}newChangeBuffer(e){return new NR(this)}getSize(e){return H.resolve(this.size)}}class NR extends TR{constructor(e){super(),this.Mr=e}applyChanges(e){const t=[];return this.changes.forEach(((s,o)=>{o.isValidDocument()?t.push(this.Mr.addEntry(e,o)):this.Mr.removeEntry(s)})),H.waitFor(t)}getFromCache(e,t){return this.Mr.getEntry(e,t)}getAllFromCache(e,t){return this.Mr.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xR{constructor(e){this.persistence=e,this.ri=new ps((t=>cf(t)),hf),this.lastRemoteSnapshotVersion=ye.min(),this.highestTargetId=0,this.ii=0,this.si=new _f,this.targetCount=0,this.oi=To._r()}forEachTarget(e,t){return this.ri.forEach(((s,o)=>t(o))),H.resolve()}getLastRemoteSnapshotVersion(e){return H.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return H.resolve(this.ii)}allocateTargetId(e){return this.highestTargetId=this.oi.next(),H.resolve(this.highestTargetId)}setTargetsMetadata(e,t,s){return s&&(this.lastRemoteSnapshotVersion=s),t>this.ii&&(this.ii=t),H.resolve()}lr(e){this.ri.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.oi=new To(t),this.highestTargetId=t),e.sequenceNumber>this.ii&&(this.ii=e.sequenceNumber)}addTargetData(e,t){return this.lr(t),this.targetCount+=1,H.resolve()}updateTargetData(e,t){return this.lr(t),H.resolve()}removeTargetData(e,t){return this.ri.delete(t.target),this.si.Gr(t.targetId),this.targetCount-=1,H.resolve()}removeTargets(e,t,s){let o=0;const l=[];return this.ri.forEach(((h,m)=>{m.sequenceNumber<=t&&s.get(m.targetId)===null&&(this.ri.delete(h),l.push(this.removeMatchingKeysForTargetId(e,m.targetId)),o++)})),H.waitFor(l).next((()=>o))}getTargetCount(e){return H.resolve(this.targetCount)}getTargetData(e,t){const s=this.ri.get(t)||null;return H.resolve(s)}addMatchingKeys(e,t,s){return this.si.$r(t,s),H.resolve()}removeMatchingKeys(e,t,s){this.si.Qr(t,s);const o=this.persistence.referenceDelegate,l=[];return o&&t.forEach((h=>{l.push(o.markPotentiallyOrphaned(e,h))})),H.waitFor(l)}removeMatchingKeysForTargetId(e,t){return this.si.Gr(t),H.resolve()}getMatchingKeysForTargetId(e,t){const s=this.si.jr(t);return H.resolve(s)}containsKey(e,t){return H.resolve(this.si.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nv{constructor(e,t){this._i={},this.overlays={},this.ai=new _c(0),this.ui=!1,this.ui=!0,this.ci=new CR,this.referenceDelegate=e(this),this.li=new xR(this),this.indexManager=new mR,this.remoteDocumentCache=(function(o){return new kR(o)})((s=>this.referenceDelegate.hi(s))),this.serializer=new fR(t),this.Pi=new AR(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.ui=!1,Promise.resolve()}get started(){return this.ui}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new RR,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let s=this._i[e.toKey()];return s||(s=new PR(t,this.referenceDelegate),this._i[e.toKey()]=s),s}getGlobalsCache(){return this.ci}getTargetCache(){return this.li}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.Pi}runTransaction(e,t,s){re("MemoryPersistence","Starting transaction:",e);const o=new DR(this.ai.next());return this.referenceDelegate.Ti(),s(o).next((l=>this.referenceDelegate.Ei(o).next((()=>l)))).toPromise().then((l=>(o.raiseOnCommittedEvent(),l)))}Ii(e,t){return H.or(Object.values(this._i).map((s=>()=>s.containsKey(e,t))))}}class DR extends rA{constructor(e){super(),this.currentSequenceNumber=e}}class vf{constructor(e){this.persistence=e,this.Ri=new _f,this.Ai=null}static Vi(e){return new vf(e)}get di(){if(this.Ai)return this.Ai;throw me(60996)}addReference(e,t,s){return this.Ri.addReference(s,t),this.di.delete(s.toString()),H.resolve()}removeReference(e,t,s){return this.Ri.removeReference(s,t),this.di.add(s.toString()),H.resolve()}markPotentiallyOrphaned(e,t){return this.di.add(t.toString()),H.resolve()}removeTarget(e,t){this.Ri.Gr(t.targetId).forEach((o=>this.di.add(o.toString())));const s=this.persistence.getTargetCache();return s.getMatchingKeysForTargetId(e,t.targetId).next((o=>{o.forEach((l=>this.di.add(l.toString())))})).next((()=>s.removeTargetData(e,t)))}Ti(){this.Ai=new Set}Ei(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return H.forEach(this.di,(s=>{const o=ce.fromPath(s);return this.mi(e,o).next((l=>{l||t.removeEntry(o,ye.min())}))})).next((()=>(this.Ai=null,t.apply(e))))}updateLimboDocument(e,t){return this.mi(e,t).next((s=>{s?this.di.delete(t.toString()):this.di.add(t.toString())}))}hi(e){return 0}mi(e,t){return H.or([()=>H.resolve(this.Ri.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Ii(e,t)])}}class ac{constructor(e,t){this.persistence=e,this.fi=new ps((s=>oA(s.path)),((s,o)=>s.isEqual(o))),this.garbageCollector=wR(this,t)}static Vi(e,t){return new ac(e,t)}Ti(){}Ei(e){return H.resolve()}forEachTarget(e,t){return this.persistence.getTargetCache().forEachTarget(e,t)}dr(e){const t=this.pr(e);return this.persistence.getTargetCache().getTargetCount(e).next((s=>t.next((o=>s+o))))}pr(e){let t=0;return this.mr(e,(s=>{t++})).next((()=>t))}mr(e,t){return H.forEach(this.fi,((s,o)=>this.wr(e,s,o).next((l=>l?H.resolve():t(o)))))}removeTargets(e,t,s){return this.persistence.getTargetCache().removeTargets(e,t,s)}removeOrphanedDocuments(e,t){let s=0;const o=this.persistence.getRemoteDocumentCache(),l=o.newChangeBuffer();return o.ni(e,(h=>this.wr(e,h,t).next((m=>{m||(s++,l.removeEntry(h,ye.min()))})))).next((()=>l.apply(e))).next((()=>s))}markPotentiallyOrphaned(e,t){return this.fi.set(t,e.currentSequenceNumber),H.resolve()}removeTarget(e,t){const s=t.withSequenceNumber(e.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(e,s)}addReference(e,t,s){return this.fi.set(s,e.currentSequenceNumber),H.resolve()}removeReference(e,t,s){return this.fi.set(s,e.currentSequenceNumber),H.resolve()}updateLimboDocument(e,t){return this.fi.set(t,e.currentSequenceNumber),H.resolve()}hi(e){let t=e.key.toString().length;return e.isFoundDocument()&&(t+=Uu(e.data.value)),t}wr(e,t,s){return H.or([()=>this.persistence.Ii(e,t),()=>this.persistence.getTargetCache().containsKey(e,t),()=>{const o=this.fi.get(t);return H.resolve(o!==void 0&&o>s)}])}getCacheSize(e){return this.persistence.getRemoteDocumentCache().getSize(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ef{constructor(e,t,s,o){this.targetId=e,this.fromCache=t,this.Ts=s,this.Es=o}static Is(e,t){let s=xe(),o=xe();for(const l of t.docChanges)switch(l.type){case 0:s=s.add(l.doc.key);break;case 1:o=o.add(l.doc.key)}return new Ef(e,t.fromCache,s,o)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class VR{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class OR{constructor(){this.Rs=!1,this.As=!1,this.Vs=100,this.ds=(function(){return rT()?8:iA(jt())>0?6:4})()}initialize(e,t){this.fs=e,this.indexManager=t,this.Rs=!0}getDocumentsMatchingQuery(e,t,s,o){const l={result:null};return this.gs(e,t).next((h=>{l.result=h})).next((()=>{if(!l.result)return this.ps(e,t,o,s).next((h=>{l.result=h}))})).next((()=>{if(l.result)return;const h=new VR;return this.ys(e,t,h).next((m=>{if(l.result=m,this.As)return this.ws(e,t,h,m.size)}))})).next((()=>l.result))}ws(e,t,s,o){return s.documentReadCount<this.Vs?(io()<=ke.DEBUG&&re("QueryEngine","SDK will not create cache indexes for query:",so(t),"since it only creates cache indexes for collection contains","more than or equal to",this.Vs,"documents"),H.resolve()):(io()<=ke.DEBUG&&re("QueryEngine","Query:",so(t),"scans",s.documentReadCount,"local documents and returns",o,"documents as results."),s.documentReadCount>this.ds*o?(io()<=ke.DEBUG&&re("QueryEngine","The SDK decides to create cache indexes for query:",so(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,tr(t))):H.resolve())}gs(e,t){if(ty(t))return H.resolve(null);let s=tr(t);return this.indexManager.getIndexType(e,s).next((o=>o===0?null:(t.limit!==null&&o===1&&(t=Ld(t,null,"F"),s=tr(t)),this.indexManager.getDocumentsMatchingTarget(e,s).next((l=>{const h=xe(...l);return this.fs.getDocuments(e,h).next((m=>this.indexManager.getMinOffset(e,s).next((g=>{const _=this.Ss(t,m);return this.bs(t,_,h,g.readTime)?this.gs(e,Ld(t,null,"F")):this.Ds(e,_,t,g)}))))})))))}ps(e,t,s,o){return ty(t)||o.isEqual(ye.min())?H.resolve(null):this.fs.getDocuments(e,s).next((l=>{const h=this.Ss(t,l);return this.bs(t,h,s,o)?H.resolve(null):(io()<=ke.DEBUG&&re("QueryEngine","Re-using previous result from %s to execute query: %s",o.toString(),so(t)),this.Ds(e,h,t,ZS(o,Ha)).next((m=>m)))}))}Ss(e,t){let s=new vt(av(e));return t.forEach(((o,l)=>{Tc(e,l)&&(s=s.add(l))})),s}bs(e,t,s,o){if(e.limit===null)return!1;if(s.size!==t.size)return!0;const l=e.limitType==="F"?t.last():t.first();return!!l&&(l.hasPendingWrites||l.version.compareTo(o)>0)}ys(e,t,s){return io()<=ke.DEBUG&&re("QueryEngine","Using full collection scan to execute query:",so(t)),this.fs.getDocumentsMatchingQuery(e,t,wi.min(),s)}Ds(e,t,s,o){return this.fs.getDocumentsMatchingQuery(e,s,o).next((l=>(t.forEach((h=>{l=l.insert(h.key,h)})),l)))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wf="LocalStore",LR=3e8;class bR{constructor(e,t,s,o){this.persistence=e,this.Cs=t,this.serializer=o,this.vs=new nt(Ne),this.Fs=new ps((l=>cf(l)),hf),this.Ms=new Map,this.xs=e.getRemoteDocumentCache(),this.li=e.getTargetCache(),this.Pi=e.getBundleCache(),this.Os(s)}Os(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new SR(this.xs,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.xs.setIndexManager(this.indexManager),this.Cs.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",(t=>e.collect(t,this.vs)))}}function MR(r,e,t,s){return new bR(r,e,t,s)}async function xv(r,e){const t=ve(r);return await t.persistence.runTransaction("Handle user change","readonly",(s=>{let o;return t.mutationQueue.getAllMutationBatches(s).next((l=>(o=l,t.Os(e),t.mutationQueue.getAllMutationBatches(s)))).next((l=>{const h=[],m=[];let g=xe();for(const _ of o){h.push(_.batchId);for(const E of _.mutations)g=g.add(E.key)}for(const _ of l){m.push(_.batchId);for(const E of _.mutations)g=g.add(E.key)}return t.localDocuments.getDocuments(s,g).next((_=>({Ns:_,removedBatchIds:h,addedBatchIds:m})))}))}))}function FR(r,e){const t=ve(r);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",(s=>{const o=e.batch.keys(),l=t.xs.newChangeBuffer({trackRemovals:!0});return(function(m,g,_,E){const I=_.batch,C=I.keys();let z=H.resolve();return C.forEach((G=>{z=z.next((()=>E.getEntry(g,G))).next((Q=>{const B=_.docVersions.get(G);ze(B!==null,48541),Q.version.compareTo(B)<0&&(I.applyToRemoteDocument(Q,_),Q.isValidDocument()&&(Q.setReadTime(_.commitVersion),E.addEntry(Q)))}))})),z.next((()=>m.mutationQueue.removeMutationBatch(g,I)))})(t,s,e,l).next((()=>l.apply(s))).next((()=>t.mutationQueue.performConsistencyCheck(s))).next((()=>t.documentOverlayCache.removeOverlaysForBatchId(s,o,e.batch.batchId))).next((()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(s,(function(m){let g=xe();for(let _=0;_<m.mutationResults.length;++_)m.mutationResults[_].transformResults.length>0&&(g=g.add(m.batch.mutations[_].key));return g})(e)))).next((()=>t.localDocuments.getDocuments(s,o)))}))}function Dv(r){const e=ve(r);return e.persistence.runTransaction("Get last remote snapshot version","readonly",(t=>e.li.getLastRemoteSnapshotVersion(t)))}function UR(r,e){const t=ve(r),s=e.snapshotVersion;let o=t.vs;return t.persistence.runTransaction("Apply remote event","readwrite-primary",(l=>{const h=t.xs.newChangeBuffer({trackRemovals:!0});o=t.vs;const m=[];e.targetChanges.forEach(((E,I)=>{const C=o.get(I);if(!C)return;m.push(t.li.removeMatchingKeys(l,E.removedDocuments,I).next((()=>t.li.addMatchingKeys(l,E.addedDocuments,I))));let z=C.withSequenceNumber(l.currentSequenceNumber);e.targetMismatches.get(I)!==null?z=z.withResumeToken(xt.EMPTY_BYTE_STRING,ye.min()).withLastLimboFreeSnapshotVersion(ye.min()):E.resumeToken.approximateByteSize()>0&&(z=z.withResumeToken(E.resumeToken,s)),o=o.insert(I,z),(function(Q,B,te){return Q.resumeToken.approximateByteSize()===0||B.snapshotVersion.toMicroseconds()-Q.snapshotVersion.toMicroseconds()>=LR?!0:te.addedDocuments.size+te.modifiedDocuments.size+te.removedDocuments.size>0})(C,z,E)&&m.push(t.li.updateTargetData(l,z))}));let g=kr(),_=xe();if(e.documentUpdates.forEach((E=>{e.resolvedLimboDocuments.has(E)&&m.push(t.persistence.referenceDelegate.updateLimboDocument(l,E))})),m.push(jR(l,h,e.documentUpdates).next((E=>{g=E.Bs,_=E.Ls}))),!s.isEqual(ye.min())){const E=t.li.getLastRemoteSnapshotVersion(l).next((I=>t.li.setTargetsMetadata(l,l.currentSequenceNumber,s)));m.push(E)}return H.waitFor(m).next((()=>h.apply(l))).next((()=>t.localDocuments.getLocalViewOfDocuments(l,g,_))).next((()=>g))})).then((l=>(t.vs=o,l)))}function jR(r,e,t){let s=xe(),o=xe();return t.forEach((l=>s=s.add(l))),e.getEntries(r,s).next((l=>{let h=kr();return t.forEach(((m,g)=>{const _=l.get(m);g.isFoundDocument()!==_.isFoundDocument()&&(o=o.add(m)),g.isNoDocument()&&g.version.isEqual(ye.min())?(e.removeEntry(m,g.readTime),h=h.insert(m,g)):!_.isValidDocument()||g.version.compareTo(_.version)>0||g.version.compareTo(_.version)===0&&_.hasPendingWrites?(e.addEntry(g),h=h.insert(m,g)):re(wf,"Ignoring outdated watch update for ",m,". Current version:",_.version," Watch version:",g.version)})),{Bs:h,Ls:o}}))}function zR(r,e){const t=ve(r);return t.persistence.runTransaction("Get next mutation batch","readonly",(s=>(e===void 0&&(e=af),t.mutationQueue.getNextMutationBatchAfterBatchId(s,e))))}function BR(r,e){const t=ve(r);return t.persistence.runTransaction("Allocate target","readwrite",(s=>{let o;return t.li.getTargetData(s,e).next((l=>l?(o=l,H.resolve(o)):t.li.allocateTargetId(s).next((h=>(o=new pi(e,h,"TargetPurposeListen",s.currentSequenceNumber),t.li.addTargetData(s,o).next((()=>o)))))))})).then((s=>{const o=t.vs.get(s.targetId);return(o===null||s.snapshotVersion.compareTo(o.snapshotVersion)>0)&&(t.vs=t.vs.insert(s.targetId,s),t.Fs.set(e,s.targetId)),s}))}async function jd(r,e,t){const s=ve(r),o=s.vs.get(e),l=t?"readwrite":"readwrite-primary";try{t||await s.persistence.runTransaction("Release target",l,(h=>s.persistence.referenceDelegate.removeTarget(h,o)))}catch(h){if(!No(h))throw h;re(wf,`Failed to update sequence numbers for target ${e}: ${h}`)}s.vs=s.vs.remove(e),s.Fs.delete(o.target)}function py(r,e,t){const s=ve(r);let o=ye.min(),l=xe();return s.persistence.runTransaction("Execute query","readwrite",(h=>(function(g,_,E){const I=ve(g),C=I.Fs.get(E);return C!==void 0?H.resolve(I.vs.get(C)):I.li.getTargetData(_,E)})(s,h,tr(e)).next((m=>{if(m)return o=m.lastLimboFreeSnapshotVersion,s.li.getMatchingKeysForTargetId(h,m.targetId).next((g=>{l=g}))})).next((()=>s.Cs.getDocumentsMatchingQuery(h,e,t?o:ye.min(),t?l:xe()))).next((m=>($R(s,CA(e),m),{documents:m,ks:l})))))}function $R(r,e,t){let s=r.Ms.get(e)||ye.min();t.forEach(((o,l)=>{l.readTime.compareTo(s)>0&&(s=l.readTime)})),r.Ms.set(e,s)}class my{constructor(){this.activeTargetIds=VA()}Qs(e){this.activeTargetIds=this.activeTargetIds.add(e)}Gs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}Ws(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class HR{constructor(){this.vo=new my,this.Fo={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,s){}addLocalQueryTarget(e,t=!0){return t&&this.vo.Qs(e),this.Fo[e]||"not-current"}updateQueryState(e,t,s){this.Fo[e]=t}removeLocalQueryTarget(e){this.vo.Gs(e)}isLocalQueryTarget(e){return this.vo.activeTargetIds.has(e)}clearQueryState(e){delete this.Fo[e]}getAllActiveQueryTargets(){return this.vo.activeTargetIds}isActiveQueryTarget(e){return this.vo.activeTargetIds.has(e)}start(){return this.vo=new my,Promise.resolve()}handleUserChange(e,t,s){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class WR{Mo(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gy="ConnectivityMonitor";class yy{constructor(){this.xo=()=>this.Oo(),this.No=()=>this.Bo(),this.Lo=[],this.ko()}Mo(e){this.Lo.push(e)}shutdown(){window.removeEventListener("online",this.xo),window.removeEventListener("offline",this.No)}ko(){window.addEventListener("online",this.xo),window.addEventListener("offline",this.No)}Oo(){re(gy,"Network connectivity changed: AVAILABLE");for(const e of this.Lo)e(0)}Bo(){re(gy,"Network connectivity changed: UNAVAILABLE");for(const e of this.Lo)e(1)}static v(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Vu=null;function zd(){return Vu===null?Vu=(function(){return 268435456+Math.round(2147483648*Math.random())})():Vu++,"0x"+Vu.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yd="RestConnection",qR={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class KR{get qo(){return!1}constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const t=e.ssl?"https":"http",s=encodeURIComponent(this.databaseId.projectId),o=encodeURIComponent(this.databaseId.database);this.Ko=t+"://"+e.host,this.Uo=`projects/${s}/databases/${o}`,this.$o=this.databaseId.database===tc?`project_id=${s}`:`project_id=${s}&database_id=${o}`}Wo(e,t,s,o,l){const h=zd(),m=this.Qo(e,t.toUriEncodedString());re(yd,`Sending RPC '${e}' ${h}:`,m,s);const g={"google-cloud-resource-prefix":this.Uo,"x-goog-request-params":this.$o};this.Go(g,o,l);const{host:_}=new URL(m),E=Za(_);return this.zo(e,m,g,s,E).then((I=>(re(yd,`Received RPC '${e}' ${h}: `,I),I)),(I=>{throw ds(yd,`RPC '${e}' ${h} failed with error: `,I,"url: ",m,"request:",s),I}))}jo(e,t,s,o,l,h){return this.Wo(e,t,s,o,l)}Go(e,t,s){e["X-Goog-Api-Client"]=(function(){return"gl-js/ fire/"+Po})(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach(((o,l)=>e[l]=o)),s&&s.headers.forEach(((o,l)=>e[l]=o))}Qo(e,t){const s=qR[e];let o=`${this.Ko}/v1/${t}:${s}`;return this.databaseInfo.apiKey&&(o=`${o}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),o}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class GR{constructor(e){this.Jo=e.Jo,this.Ho=e.Ho}Zo(e){this.Xo=e}Yo(e){this.e_=e}t_(e){this.n_=e}onMessage(e){this.r_=e}close(){this.Ho()}send(e){this.Jo(e)}i_(){this.Xo()}s_(){this.e_()}o_(e){this.n_(e)}__(e){this.r_(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mt="WebChannelConnection",Pa=(r,e,t)=>{r.listen(e,(s=>{try{t(s)}catch(o){setTimeout((()=>{throw o}),0)}}))};class fo extends KR{constructor(e){super(e),this.a_=[],this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}static u_(){if(!fo.c_){const e=M_();Pa(e,b_.STAT_EVENT,(t=>{t.stat===Pd.PROXY?re(Mt,"STAT_EVENT: detected buffering proxy"):t.stat===Pd.NOPROXY&&re(Mt,"STAT_EVENT: detected no buffering proxy")})),fo.c_=!0}}zo(e,t,s,o,l){const h=zd();return new Promise(((m,g)=>{const _=new O_;_.setWithCredentials(!0),_.listenOnce(L_.COMPLETE,(()=>{try{switch(_.getLastErrorCode()){case Fu.NO_ERROR:const I=_.getResponseJson();re(Mt,`XHR for RPC '${e}' ${h} received:`,JSON.stringify(I)),m(I);break;case Fu.TIMEOUT:re(Mt,`RPC '${e}' ${h} timed out`),g(new ie($.DEADLINE_EXCEEDED,"Request time out"));break;case Fu.HTTP_ERROR:const C=_.getStatus();if(re(Mt,`RPC '${e}' ${h} failed with status:`,C,"response text:",_.getResponseText()),C>0){let z=_.getResponseJson();Array.isArray(z)&&(z=z[0]);const G=z==null?void 0:z.error;if(G&&G.status&&G.message){const Q=(function(te){const fe=te.toLowerCase().replace(/_/g,"-");return Object.values($).indexOf(fe)>=0?fe:$.UNKNOWN})(G.status);g(new ie(Q,G.message))}else g(new ie($.UNKNOWN,"Server responded with status "+_.getStatus()))}else g(new ie($.UNAVAILABLE,"Connection failed."));break;default:me(9055,{l_:e,streamId:h,h_:_.getLastErrorCode(),P_:_.getLastError()})}}finally{re(Mt,`RPC '${e}' ${h} completed.`)}}));const E=JSON.stringify(o);re(Mt,`RPC '${e}' ${h} sending request:`,o),_.send(t,"POST",E,s,15)}))}T_(e,t,s){const o=zd(),l=[this.Ko,"/","google.firestore.v1.Firestore","/",e,"/channel"],h=this.createWebChannelTransport(),m={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},g=this.longPollingOptions.timeoutSeconds;g!==void 0&&(m.longPollingTimeout=Math.round(1e3*g)),this.useFetchStreams&&(m.useFetchStreams=!0),this.Go(m.initMessageHeaders,t,s),m.encodeInitMessageHeaders=!0;const _=l.join("");re(Mt,`Creating RPC '${e}' stream ${o}: ${_}`,m);const E=h.createWebChannel(_,m);this.E_(E);let I=!1,C=!1;const z=new GR({Jo:G=>{C?re(Mt,`Not sending because RPC '${e}' stream ${o} is closed:`,G):(I||(re(Mt,`Opening RPC '${e}' stream ${o} transport.`),E.open(),I=!0),re(Mt,`RPC '${e}' stream ${o} sending:`,G),E.send(G))},Ho:()=>E.close()});return Pa(E,xa.EventType.OPEN,(()=>{C||(re(Mt,`RPC '${e}' stream ${o} transport opened.`),z.i_())})),Pa(E,xa.EventType.CLOSE,(()=>{C||(C=!0,re(Mt,`RPC '${e}' stream ${o} transport closed`),z.o_(),this.I_(E))})),Pa(E,xa.EventType.ERROR,(G=>{C||(C=!0,ds(Mt,`RPC '${e}' stream ${o} transport errored. Name:`,G.name,"Message:",G.message),z.o_(new ie($.UNAVAILABLE,"The operation could not be completed")))})),Pa(E,xa.EventType.MESSAGE,(G=>{var Q;if(!C){const B=G.data[0];ze(!!B,16349);const te=B,fe=(te==null?void 0:te.error)||((Q=te[0])==null?void 0:Q.error);if(fe){re(Mt,`RPC '${e}' stream ${o} received error:`,fe);const Ee=fe.status;let Ae=(function(D){const T=ft[D];if(T!==void 0)return _v(T)})(Ee),De=fe.message;Ee==="NOT_FOUND"&&De.includes("database")&&De.includes("does not exist")&&De.includes(this.databaseId.database)&&ds(`Database '${this.databaseId.database}' not found. Please check your project configuration.`),Ae===void 0&&(Ae=$.INTERNAL,De="Unknown error status: "+Ee+" with message "+fe.message),C=!0,z.o_(new ie(Ae,De)),E.close()}else re(Mt,`RPC '${e}' stream ${o} received:`,B),z.__(B)}})),fo.u_(),setTimeout((()=>{z.s_()}),0),z}terminate(){this.a_.forEach((e=>e.close())),this.a_=[]}E_(e){this.a_.push(e)}I_(e){this.a_=this.a_.filter((t=>t===e))}Go(e,t,s){super.Go(e,t,s),this.databaseInfo.apiKey&&(e["x-goog-api-key"]=this.databaseInfo.apiKey)}createWebChannelTransport(){return F_()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function QR(r){return new fo(r)}function _d(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Rc(r){return new ZA(r,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */fo.c_=!1;class Vv{constructor(e,t,s=1e3,o=1.5,l=6e4){this.Ci=e,this.timerId=t,this.R_=s,this.A_=o,this.V_=l,this.d_=0,this.m_=null,this.f_=Date.now(),this.reset()}reset(){this.d_=0}g_(){this.d_=this.V_}p_(e){this.cancel();const t=Math.floor(this.d_+this.y_()),s=Math.max(0,Date.now()-this.f_),o=Math.max(0,t-s);o>0&&re("ExponentialBackoff",`Backing off for ${o} ms (base delay: ${this.d_} ms, delay with jitter: ${t} ms, last attempt: ${s} ms ago)`),this.m_=this.Ci.enqueueAfterDelay(this.timerId,o,(()=>(this.f_=Date.now(),e()))),this.d_*=this.A_,this.d_<this.R_&&(this.d_=this.R_),this.d_>this.V_&&(this.d_=this.V_)}w_(){this.m_!==null&&(this.m_.skipDelay(),this.m_=null)}cancel(){this.m_!==null&&(this.m_.cancel(),this.m_=null)}y_(){return(Math.random()-.5)*this.d_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _y="PersistentStream";class Ov{constructor(e,t,s,o,l,h,m,g){this.Ci=e,this.S_=s,this.b_=o,this.connection=l,this.authCredentialsProvider=h,this.appCheckCredentialsProvider=m,this.listener=g,this.state=0,this.D_=0,this.C_=null,this.v_=null,this.stream=null,this.F_=0,this.M_=new Vv(e,t)}x_(){return this.state===1||this.state===5||this.O_()}O_(){return this.state===2||this.state===3}start(){this.F_=0,this.state!==4?this.auth():this.N_()}async stop(){this.x_()&&await this.close(0)}B_(){this.state=0,this.M_.reset()}L_(){this.O_()&&this.C_===null&&(this.C_=this.Ci.enqueueAfterDelay(this.S_,6e4,(()=>this.k_())))}q_(e){this.K_(),this.stream.send(e)}async k_(){if(this.O_())return this.close(0)}K_(){this.C_&&(this.C_.cancel(),this.C_=null)}U_(){this.v_&&(this.v_.cancel(),this.v_=null)}async close(e,t){this.K_(),this.U_(),this.M_.cancel(),this.D_++,e!==4?this.M_.reset():t&&t.code===$.RESOURCE_EXHAUSTED?(Pr(t.toString()),Pr("Using maximum backoff delay to prevent overloading the backend."),this.M_.g_()):t&&t.code===$.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.W_(),this.stream.close(),this.stream=null),this.state=e,await this.listener.t_(t)}W_(){}auth(){this.state=1;const e=this.Q_(this.D_),t=this.D_;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then((([s,o])=>{this.D_===t&&this.G_(s,o)}),(s=>{e((()=>{const o=new ie($.UNKNOWN,"Fetching auth token failed: "+s.message);return this.z_(o)}))}))}G_(e,t){const s=this.Q_(this.D_);this.stream=this.j_(e,t),this.stream.Zo((()=>{s((()=>this.listener.Zo()))})),this.stream.Yo((()=>{s((()=>(this.state=2,this.v_=this.Ci.enqueueAfterDelay(this.b_,1e4,(()=>(this.O_()&&(this.state=3),Promise.resolve()))),this.listener.Yo())))})),this.stream.t_((o=>{s((()=>this.z_(o)))})),this.stream.onMessage((o=>{s((()=>++this.F_==1?this.J_(o):this.onNext(o)))}))}N_(){this.state=5,this.M_.p_((async()=>{this.state=0,this.start()}))}z_(e){return re(_y,`close with error: ${e}`),this.stream=null,this.close(4,e)}Q_(e){return t=>{this.Ci.enqueueAndForget((()=>this.D_===e?t():(re(_y,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve())))}}}class YR extends Ov{constructor(e,t,s,o,l,h){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,s,o,h),this.serializer=l}j_(e,t){return this.connection.T_("Listen",e,t)}J_(e){return this.onNext(e)}onNext(e){this.M_.reset();const t=nR(this.serializer,e),s=(function(l){if(!("targetChange"in l))return ye.min();const h=l.targetChange;return h.targetIds&&h.targetIds.length?ye.min():h.readTime?nr(h.readTime):ye.min()})(e);return this.listener.H_(t,s)}Z_(e){const t={};t.database=Ud(this.serializer),t.addTarget=(function(l,h){let m;const g=h.target;if(m=Vd(g)?{documents:sR(l,g)}:{query:oR(l,g).ft},m.targetId=h.targetId,h.resumeToken.approximateByteSize()>0){m.resumeToken=wv(l,h.resumeToken);const _=bd(l,h.expectedCount);_!==null&&(m.expectedCount=_)}else if(h.snapshotVersion.compareTo(ye.min())>0){m.readTime=oc(l,h.snapshotVersion.toTimestamp());const _=bd(l,h.expectedCount);_!==null&&(m.expectedCount=_)}return m})(this.serializer,e);const s=lR(this.serializer,e);s&&(t.labels=s),this.q_(t)}X_(e){const t={};t.database=Ud(this.serializer),t.removeTarget=e,this.q_(t)}}class JR extends Ov{constructor(e,t,s,o,l,h){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,s,o,h),this.serializer=l}get Y_(){return this.F_>0}start(){this.lastStreamToken=void 0,super.start()}W_(){this.Y_&&this.ea([])}j_(e,t){return this.connection.T_("Write",e,t)}J_(e){return ze(!!e.streamToken,31322),this.lastStreamToken=e.streamToken,ze(!e.writeResults||e.writeResults.length===0,55816),this.listener.ta()}onNext(e){ze(!!e.streamToken,12678),this.lastStreamToken=e.streamToken,this.M_.reset();const t=iR(e.writeResults,e.commitTime),s=nr(e.commitTime);return this.listener.na(s,t)}ra(){const e={};e.database=Ud(this.serializer),this.q_(e)}ea(e){const t={streamToken:this.lastStreamToken,writes:e.map((s=>rR(this.serializer,s)))};this.q_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class XR{}class ZR extends XR{constructor(e,t,s,o){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=s,this.serializer=o,this.ia=!1}sa(){if(this.ia)throw new ie($.FAILED_PRECONDITION,"The client has already been terminated.")}Wo(e,t,s,o){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then((([l,h])=>this.connection.Wo(e,Md(t,s),o,l,h))).catch((l=>{throw l.name==="FirebaseError"?(l.code===$.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),l):new ie($.UNKNOWN,l.toString())}))}jo(e,t,s,o,l){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then((([h,m])=>this.connection.jo(e,Md(t,s),o,h,m,l))).catch((h=>{throw h.name==="FirebaseError"?(h.code===$.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),h):new ie($.UNKNOWN,h.toString())}))}terminate(){this.ia=!0,this.connection.terminate()}}function eC(r,e,t,s){return new ZR(r,e,t,s)}class tC{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.oa=0,this._a=null,this.aa=!0}ua(){this.oa===0&&(this.ca("Unknown"),this._a=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,(()=>(this._a=null,this.la("Backend didn't respond within 10 seconds."),this.ca("Offline"),Promise.resolve()))))}ha(e){this.state==="Online"?this.ca("Unknown"):(this.oa++,this.oa>=1&&(this.Pa(),this.la(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.ca("Offline")))}set(e){this.Pa(),this.oa=0,e==="Online"&&(this.aa=!1),this.ca(e)}ca(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}la(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.aa?(Pr(t),this.aa=!1):re("OnlineStateTracker",t)}Pa(){this._a!==null&&(this._a.cancel(),this._a=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fs="RemoteStore";class nC{constructor(e,t,s,o,l){this.localStore=e,this.datastore=t,this.asyncQueue=s,this.remoteSyncer={},this.Ta=[],this.Ea=new Map,this.Ia=new Set,this.Ra=[],this.Aa=l,this.Aa.Mo((h=>{s.enqueueAndForget((async()=>{ms(this)&&(re(fs,"Restarting streams for network reachability change."),await(async function(g){const _=ve(g);_.Ia.add(4),await ll(_),_.Va.set("Unknown"),_.Ia.delete(4),await Cc(_)})(this))}))})),this.Va=new tC(s,o)}}async function Cc(r){if(ms(r))for(const e of r.Ra)await e(!0)}async function ll(r){for(const e of r.Ra)await e(!1)}function Lv(r,e){const t=ve(r);t.Ea.has(e.targetId)||(t.Ea.set(e.targetId,e),Af(t)?Sf(t):xo(t).O_()&&If(t,e))}function Tf(r,e){const t=ve(r),s=xo(t);t.Ea.delete(e),s.O_()&&bv(t,e),t.Ea.size===0&&(s.O_()?s.L_():ms(t)&&t.Va.set("Unknown"))}function If(r,e){if(r.da.$e(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(ye.min())>0){const t=r.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(t)}xo(r).Z_(e)}function bv(r,e){r.da.$e(e),xo(r).X_(e)}function Sf(r){r.da=new QA({getRemoteKeysForTarget:e=>r.remoteSyncer.getRemoteKeysForTarget(e),At:e=>r.Ea.get(e)||null,ht:()=>r.datastore.serializer.databaseId}),xo(r).start(),r.Va.ua()}function Af(r){return ms(r)&&!xo(r).x_()&&r.Ea.size>0}function ms(r){return ve(r).Ia.size===0}function Mv(r){r.da=void 0}async function rC(r){r.Va.set("Online")}async function iC(r){r.Ea.forEach(((e,t)=>{If(r,e)}))}async function sC(r,e){Mv(r),Af(r)?(r.Va.ha(e),Sf(r)):r.Va.set("Unknown")}async function oC(r,e,t){if(r.Va.set("Online"),e instanceof Ev&&e.state===2&&e.cause)try{await(async function(o,l){const h=l.cause;for(const m of l.targetIds)o.Ea.has(m)&&(await o.remoteSyncer.rejectListen(m,h),o.Ea.delete(m),o.da.removeTarget(m))})(r,e)}catch(s){re(fs,"Failed to remove targets %s: %s ",e.targetIds.join(","),s),await lc(r,s)}else if(e instanceof Bu?r.da.Xe(e):e instanceof vv?r.da.st(e):r.da.tt(e),!t.isEqual(ye.min()))try{const s=await Dv(r.localStore);t.compareTo(s)>=0&&await(function(l,h){const m=l.da.Tt(h);return m.targetChanges.forEach(((g,_)=>{if(g.resumeToken.approximateByteSize()>0){const E=l.Ea.get(_);E&&l.Ea.set(_,E.withResumeToken(g.resumeToken,h))}})),m.targetMismatches.forEach(((g,_)=>{const E=l.Ea.get(g);if(!E)return;l.Ea.set(g,E.withResumeToken(xt.EMPTY_BYTE_STRING,E.snapshotVersion)),bv(l,g);const I=new pi(E.target,g,_,E.sequenceNumber);If(l,I)})),l.remoteSyncer.applyRemoteEvent(m)})(r,t)}catch(s){re(fs,"Failed to raise snapshot:",s),await lc(r,s)}}async function lc(r,e,t){if(!No(e))throw e;r.Ia.add(1),await ll(r),r.Va.set("Offline"),t||(t=()=>Dv(r.localStore)),r.asyncQueue.enqueueRetryable((async()=>{re(fs,"Retrying IndexedDB access"),await t(),r.Ia.delete(1),await Cc(r)}))}function Fv(r,e){return e().catch((t=>lc(r,t,e)))}async function Pc(r){const e=ve(r),t=Ai(e);let s=e.Ta.length>0?e.Ta[e.Ta.length-1].batchId:af;for(;aC(e);)try{const o=await zR(e.localStore,s);if(o===null){e.Ta.length===0&&t.L_();break}s=o.batchId,lC(e,o)}catch(o){await lc(e,o)}Uv(e)&&jv(e)}function aC(r){return ms(r)&&r.Ta.length<10}function lC(r,e){r.Ta.push(e);const t=Ai(r);t.O_()&&t.Y_&&t.ea(e.mutations)}function Uv(r){return ms(r)&&!Ai(r).x_()&&r.Ta.length>0}function jv(r){Ai(r).start()}async function uC(r){Ai(r).ra()}async function cC(r){const e=Ai(r);for(const t of r.Ta)e.ea(t.mutations)}async function hC(r,e,t){const s=r.Ta.shift(),o=mf.from(s,e,t);await Fv(r,(()=>r.remoteSyncer.applySuccessfulWrite(o))),await Pc(r)}async function dC(r,e){e&&Ai(r).Y_&&await(async function(s,o){if((function(h){return qA(h)&&h!==$.ABORTED})(o.code)){const l=s.Ta.shift();Ai(s).B_(),await Fv(s,(()=>s.remoteSyncer.rejectFailedWrite(l.batchId,o))),await Pc(s)}})(r,e),Uv(r)&&jv(r)}async function vy(r,e){const t=ve(r);t.asyncQueue.verifyOperationInProgress(),re(fs,"RemoteStore received new credentials");const s=ms(t);t.Ia.add(3),await ll(t),s&&t.Va.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.Ia.delete(3),await Cc(t)}async function fC(r,e){const t=ve(r);e?(t.Ia.delete(2),await Cc(t)):e||(t.Ia.add(2),await ll(t),t.Va.set("Unknown"))}function xo(r){return r.ma||(r.ma=(function(t,s,o){const l=ve(t);return l.sa(),new YR(s,l.connection,l.authCredentials,l.appCheckCredentials,l.serializer,o)})(r.datastore,r.asyncQueue,{Zo:rC.bind(null,r),Yo:iC.bind(null,r),t_:sC.bind(null,r),H_:oC.bind(null,r)}),r.Ra.push((async e=>{e?(r.ma.B_(),Af(r)?Sf(r):r.Va.set("Unknown")):(await r.ma.stop(),Mv(r))}))),r.ma}function Ai(r){return r.fa||(r.fa=(function(t,s,o){const l=ve(t);return l.sa(),new JR(s,l.connection,l.authCredentials,l.appCheckCredentials,l.serializer,o)})(r.datastore,r.asyncQueue,{Zo:()=>Promise.resolve(),Yo:uC.bind(null,r),t_:dC.bind(null,r),ta:cC.bind(null,r),na:hC.bind(null,r)}),r.Ra.push((async e=>{e?(r.fa.B_(),await Pc(r)):(await r.fa.stop(),r.Ta.length>0&&(re(fs,`Stopping write stream with ${r.Ta.length} pending writes`),r.Ta=[]))}))),r.fa}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rf{constructor(e,t,s,o,l){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=s,this.op=o,this.removalCallback=l,this.deferred=new ss,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch((h=>{}))}get promise(){return this.deferred.promise}static createAndSchedule(e,t,s,o,l){const h=Date.now()+s,m=new Rf(e,t,h,o,l);return m.start(s),m}start(e){this.timerHandle=setTimeout((()=>this.handleDelayElapsed()),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new ie($.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget((()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then((e=>this.deferred.resolve(e)))):Promise.resolve()))}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function Cf(r,e){if(Pr("AsyncQueue",`${e}: ${r}`),No(r))return new ie($.UNAVAILABLE,`${e}: ${r}`);throw r}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class po{static emptySet(e){return new po(e.comparator)}constructor(e){this.comparator=e?(t,s)=>e(t,s)||ce.comparator(t.key,s.key):(t,s)=>ce.comparator(t.key,s.key),this.keyedMap=Da(),this.sortedSet=new nt(this.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal(((t,s)=>(e(t),!1)))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof po)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),s=e.sortedSet.getIterator();for(;t.hasNext();){const o=t.getNext().key,l=s.getNext().key;if(!o.isEqual(l))return!1}return!0}toString(){const e=[];return this.forEach((t=>{e.push(t.toString())})),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const s=new po;return s.comparator=this.comparator,s.keyedMap=e,s.sortedSet=t,s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ey{constructor(){this.ga=new nt(ce.comparator)}track(e){const t=e.doc.key,s=this.ga.get(t);s?e.type!==0&&s.type===3?this.ga=this.ga.insert(t,e):e.type===3&&s.type!==1?this.ga=this.ga.insert(t,{type:s.type,doc:e.doc}):e.type===2&&s.type===2?this.ga=this.ga.insert(t,{type:2,doc:e.doc}):e.type===2&&s.type===0?this.ga=this.ga.insert(t,{type:0,doc:e.doc}):e.type===1&&s.type===0?this.ga=this.ga.remove(t):e.type===1&&s.type===2?this.ga=this.ga.insert(t,{type:1,doc:s.doc}):e.type===0&&s.type===1?this.ga=this.ga.insert(t,{type:2,doc:e.doc}):me(63341,{Vt:e,pa:s}):this.ga=this.ga.insert(t,e)}ya(){const e=[];return this.ga.inorderTraversal(((t,s)=>{e.push(s)})),e}}class Io{constructor(e,t,s,o,l,h,m,g,_){this.query=e,this.docs=t,this.oldDocs=s,this.docChanges=o,this.mutatedKeys=l,this.fromCache=h,this.syncStateChanged=m,this.excludesMetadataChanges=g,this.hasCachedResults=_}static fromInitialDocuments(e,t,s,o,l){const h=[];return t.forEach((m=>{h.push({type:0,doc:m})})),new Io(e,t,po.emptySet(t),h,s,o,!0,!1,l)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&wc(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,s=e.docChanges;if(t.length!==s.length)return!1;for(let o=0;o<t.length;o++)if(t[o].type!==s[o].type||!t[o].doc.isEqual(s[o].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pC{constructor(){this.wa=void 0,this.Sa=[]}ba(){return this.Sa.some((e=>e.Da()))}}class mC{constructor(){this.queries=wy(),this.onlineState="Unknown",this.Ca=new Set}terminate(){(function(t,s){const o=ve(t),l=o.queries;o.queries=wy(),l.forEach(((h,m)=>{for(const g of m.Sa)g.onError(s)}))})(this,new ie($.ABORTED,"Firestore shutting down"))}}function wy(){return new ps((r=>ov(r)),wc)}async function gC(r,e){const t=ve(r);let s=3;const o=e.query;let l=t.queries.get(o);l?!l.ba()&&e.Da()&&(s=2):(l=new pC,s=e.Da()?0:1);try{switch(s){case 0:l.wa=await t.onListen(o,!0);break;case 1:l.wa=await t.onListen(o,!1);break;case 2:await t.onFirstRemoteStoreListen(o)}}catch(h){const m=Cf(h,`Initialization of query '${so(e.query)}' failed`);return void e.onError(m)}t.queries.set(o,l),l.Sa.push(e),e.va(t.onlineState),l.wa&&e.Fa(l.wa)&&Pf(t)}async function yC(r,e){const t=ve(r),s=e.query;let o=3;const l=t.queries.get(s);if(l){const h=l.Sa.indexOf(e);h>=0&&(l.Sa.splice(h,1),l.Sa.length===0?o=e.Da()?0:1:!l.ba()&&e.Da()&&(o=2))}switch(o){case 0:return t.queries.delete(s),t.onUnlisten(s,!0);case 1:return t.queries.delete(s),t.onUnlisten(s,!1);case 2:return t.onLastRemoteStoreUnlisten(s);default:return}}function _C(r,e){const t=ve(r);let s=!1;for(const o of e){const l=o.query,h=t.queries.get(l);if(h){for(const m of h.Sa)m.Fa(o)&&(s=!0);h.wa=o}}s&&Pf(t)}function vC(r,e,t){const s=ve(r),o=s.queries.get(e);if(o)for(const l of o.Sa)l.onError(t);s.queries.delete(e)}function Pf(r){r.Ca.forEach((e=>{e.next()}))}var Bd,Ty;(Ty=Bd||(Bd={})).Ma="default",Ty.Cache="cache";class EC{constructor(e,t,s){this.query=e,this.xa=t,this.Oa=!1,this.Na=null,this.onlineState="Unknown",this.options=s||{}}Fa(e){if(!this.options.includeMetadataChanges){const s=[];for(const o of e.docChanges)o.type!==3&&s.push(o);e=new Io(e.query,e.docs,e.oldDocs,s,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Oa?this.Ba(e)&&(this.xa.next(e),t=!0):this.La(e,this.onlineState)&&(this.ka(e),t=!0),this.Na=e,t}onError(e){this.xa.error(e)}va(e){this.onlineState=e;let t=!1;return this.Na&&!this.Oa&&this.La(this.Na,e)&&(this.ka(this.Na),t=!0),t}La(e,t){if(!e.fromCache||!this.Da())return!0;const s=t!=="Offline";return(!this.options.qa||!s)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}Ba(e){if(e.docChanges.length>0)return!0;const t=this.Na&&this.Na.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}ka(e){e=Io.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Oa=!0,this.xa.next(e)}Da(){return this.options.source!==Bd.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zv{constructor(e){this.key=e}}class Bv{constructor(e){this.key=e}}class wC{constructor(e,t){this.query=e,this.Za=t,this.Xa=null,this.hasCachedResults=!1,this.current=!1,this.Ya=xe(),this.mutatedKeys=xe(),this.eu=av(e),this.tu=new po(this.eu)}get nu(){return this.Za}ru(e,t){const s=t?t.iu:new Ey,o=t?t.tu:this.tu;let l=t?t.mutatedKeys:this.mutatedKeys,h=o,m=!1;const g=this.query.limitType==="F"&&o.size===this.query.limit?o.last():null,_=this.query.limitType==="L"&&o.size===this.query.limit?o.first():null;if(e.inorderTraversal(((E,I)=>{const C=o.get(E),z=Tc(this.query,I)?I:null,G=!!C&&this.mutatedKeys.has(C.key),Q=!!z&&(z.hasLocalMutations||this.mutatedKeys.has(z.key)&&z.hasCommittedMutations);let B=!1;C&&z?C.data.isEqual(z.data)?G!==Q&&(s.track({type:3,doc:z}),B=!0):this.su(C,z)||(s.track({type:2,doc:z}),B=!0,(g&&this.eu(z,g)>0||_&&this.eu(z,_)<0)&&(m=!0)):!C&&z?(s.track({type:0,doc:z}),B=!0):C&&!z&&(s.track({type:1,doc:C}),B=!0,(g||_)&&(m=!0)),B&&(z?(h=h.add(z),l=Q?l.add(E):l.delete(E)):(h=h.delete(E),l=l.delete(E)))})),this.query.limit!==null)for(;h.size>this.query.limit;){const E=this.query.limitType==="F"?h.last():h.first();h=h.delete(E.key),l=l.delete(E.key),s.track({type:1,doc:E})}return{tu:h,iu:s,bs:m,mutatedKeys:l}}su(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,s,o){const l=this.tu;this.tu=e.tu,this.mutatedKeys=e.mutatedKeys;const h=e.iu.ya();h.sort(((E,I)=>(function(z,G){const Q=B=>{switch(B){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return me(20277,{Vt:B})}};return Q(z)-Q(G)})(E.type,I.type)||this.eu(E.doc,I.doc))),this.ou(s),o=o??!1;const m=t&&!o?this._u():[],g=this.Ya.size===0&&this.current&&!o?1:0,_=g!==this.Xa;return this.Xa=g,h.length!==0||_?{snapshot:new Io(this.query,e.tu,l,h,e.mutatedKeys,g===0,_,!1,!!s&&s.resumeToken.approximateByteSize()>0),au:m}:{au:m}}va(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({tu:this.tu,iu:new Ey,mutatedKeys:this.mutatedKeys,bs:!1},!1)):{au:[]}}uu(e){return!this.Za.has(e)&&!!this.tu.has(e)&&!this.tu.get(e).hasLocalMutations}ou(e){e&&(e.addedDocuments.forEach((t=>this.Za=this.Za.add(t))),e.modifiedDocuments.forEach((t=>{})),e.removedDocuments.forEach((t=>this.Za=this.Za.delete(t))),this.current=e.current)}_u(){if(!this.current)return[];const e=this.Ya;this.Ya=xe(),this.tu.forEach((s=>{this.uu(s.key)&&(this.Ya=this.Ya.add(s.key))}));const t=[];return e.forEach((s=>{this.Ya.has(s)||t.push(new Bv(s))})),this.Ya.forEach((s=>{e.has(s)||t.push(new zv(s))})),t}cu(e){this.Za=e.ks,this.Ya=xe();const t=this.ru(e.documents);return this.applyChanges(t,!0)}lu(){return Io.fromInitialDocuments(this.query,this.tu,this.mutatedKeys,this.Xa===0,this.hasCachedResults)}}const kf="SyncEngine";class TC{constructor(e,t,s){this.query=e,this.targetId=t,this.view=s}}class IC{constructor(e){this.key=e,this.hu=!1}}class SC{constructor(e,t,s,o,l,h){this.localStore=e,this.remoteStore=t,this.eventManager=s,this.sharedClientState=o,this.currentUser=l,this.maxConcurrentLimboResolutions=h,this.Pu={},this.Tu=new ps((m=>ov(m)),wc),this.Eu=new Map,this.Iu=new Set,this.Ru=new nt(ce.comparator),this.Au=new Map,this.Vu=new _f,this.du={},this.mu=new Map,this.fu=To.ar(),this.onlineState="Unknown",this.gu=void 0}get isPrimaryClient(){return this.gu===!0}}async function AC(r,e,t=!0){const s=Gv(r);let o;const l=s.Tu.get(e);return l?(s.sharedClientState.addLocalQueryTarget(l.targetId),o=l.view.lu()):o=await $v(s,e,t,!0),o}async function RC(r,e){const t=Gv(r);await $v(t,e,!0,!1)}async function $v(r,e,t,s){const o=await BR(r.localStore,tr(e)),l=o.targetId,h=r.sharedClientState.addLocalQueryTarget(l,t);let m;return s&&(m=await CC(r,e,l,h==="current",o.resumeToken)),r.isPrimaryClient&&t&&Lv(r.remoteStore,o),m}async function CC(r,e,t,s,o){r.pu=(I,C,z)=>(async function(Q,B,te,fe){let Ee=B.view.ru(te);Ee.bs&&(Ee=await py(Q.localStore,B.query,!1).then((({documents:D})=>B.view.ru(D,Ee))));const Ae=fe&&fe.targetChanges.get(B.targetId),De=fe&&fe.targetMismatches.get(B.targetId)!=null,Re=B.view.applyChanges(Ee,Q.isPrimaryClient,Ae,De);return Sy(Q,B.targetId,Re.au),Re.snapshot})(r,I,C,z);const l=await py(r.localStore,e,!0),h=new wC(e,l.ks),m=h.ru(l.documents),g=al.createSynthesizedTargetChangeForCurrentChange(t,s&&r.onlineState!=="Offline",o),_=h.applyChanges(m,r.isPrimaryClient,g);Sy(r,t,_.au);const E=new TC(e,t,h);return r.Tu.set(e,E),r.Eu.has(t)?r.Eu.get(t).push(e):r.Eu.set(t,[e]),_.snapshot}async function PC(r,e,t){const s=ve(r),o=s.Tu.get(e),l=s.Eu.get(o.targetId);if(l.length>1)return s.Eu.set(o.targetId,l.filter((h=>!wc(h,e)))),void s.Tu.delete(e);s.isPrimaryClient?(s.sharedClientState.removeLocalQueryTarget(o.targetId),s.sharedClientState.isActiveQueryTarget(o.targetId)||await jd(s.localStore,o.targetId,!1).then((()=>{s.sharedClientState.clearQueryState(o.targetId),t&&Tf(s.remoteStore,o.targetId),$d(s,o.targetId)})).catch(ko)):($d(s,o.targetId),await jd(s.localStore,o.targetId,!0))}async function kC(r,e){const t=ve(r),s=t.Tu.get(e),o=t.Eu.get(s.targetId);t.isPrimaryClient&&o.length===1&&(t.sharedClientState.removeLocalQueryTarget(s.targetId),Tf(t.remoteStore,s.targetId))}async function NC(r,e,t){const s=MC(r);try{const o=await(function(h,m){const g=ve(h),_=Xe.now(),E=m.reduce(((z,G)=>z.add(G.key)),xe());let I,C;return g.persistence.runTransaction("Locally write mutations","readwrite",(z=>{let G=kr(),Q=xe();return g.xs.getEntries(z,E).next((B=>{G=B,G.forEach(((te,fe)=>{fe.isValidDocument()||(Q=Q.add(te))}))})).next((()=>g.localDocuments.getOverlayedDocuments(z,G))).next((B=>{I=B;const te=[];for(const fe of m){const Ee=zA(fe,I.get(fe.key).overlayedDocument);Ee!=null&&te.push(new ki(fe.key,Ee,X_(Ee.value.mapValue),Nn.exists(!0)))}return g.mutationQueue.addMutationBatch(z,_,te,m)})).next((B=>{C=B;const te=B.applyToLocalDocumentSet(I,Q);return g.documentOverlayCache.saveOverlays(z,B.batchId,te)}))})).then((()=>({batchId:C.batchId,changes:uv(I)})))})(s.localStore,e);s.sharedClientState.addPendingMutation(o.batchId),(function(h,m,g){let _=h.du[h.currentUser.toKey()];_||(_=new nt(Ne)),_=_.insert(m,g),h.du[h.currentUser.toKey()]=_})(s,o.batchId,t),await ul(s,o.changes),await Pc(s.remoteStore)}catch(o){const l=Cf(o,"Failed to persist write");t.reject(l)}}async function Hv(r,e){const t=ve(r);try{const s=await UR(t.localStore,e);e.targetChanges.forEach(((o,l)=>{const h=t.Au.get(l);h&&(ze(o.addedDocuments.size+o.modifiedDocuments.size+o.removedDocuments.size<=1,22616),o.addedDocuments.size>0?h.hu=!0:o.modifiedDocuments.size>0?ze(h.hu,14607):o.removedDocuments.size>0&&(ze(h.hu,42227),h.hu=!1))})),await ul(t,s,e)}catch(s){await ko(s)}}function Iy(r,e,t){const s=ve(r);if(s.isPrimaryClient&&t===0||!s.isPrimaryClient&&t===1){const o=[];s.Tu.forEach(((l,h)=>{const m=h.view.va(e);m.snapshot&&o.push(m.snapshot)})),(function(h,m){const g=ve(h);g.onlineState=m;let _=!1;g.queries.forEach(((E,I)=>{for(const C of I.Sa)C.va(m)&&(_=!0)})),_&&Pf(g)})(s.eventManager,e),o.length&&s.Pu.H_(o),s.onlineState=e,s.isPrimaryClient&&s.sharedClientState.setOnlineState(e)}}async function xC(r,e,t){const s=ve(r);s.sharedClientState.updateQueryState(e,"rejected",t);const o=s.Au.get(e),l=o&&o.key;if(l){let h=new nt(ce.comparator);h=h.insert(l,Ut.newNoDocument(l,ye.min()));const m=xe().add(l),g=new Ac(ye.min(),new Map,new nt(Ne),h,m);await Hv(s,g),s.Ru=s.Ru.remove(l),s.Au.delete(e),Nf(s)}else await jd(s.localStore,e,!1).then((()=>$d(s,e,t))).catch(ko)}async function DC(r,e){const t=ve(r),s=e.batch.batchId;try{const o=await FR(t.localStore,e);qv(t,s,null),Wv(t,s),t.sharedClientState.updateMutationState(s,"acknowledged"),await ul(t,o)}catch(o){await ko(o)}}async function VC(r,e,t){const s=ve(r);try{const o=await(function(h,m){const g=ve(h);return g.persistence.runTransaction("Reject batch","readwrite-primary",(_=>{let E;return g.mutationQueue.lookupMutationBatch(_,m).next((I=>(ze(I!==null,37113),E=I.keys(),g.mutationQueue.removeMutationBatch(_,I)))).next((()=>g.mutationQueue.performConsistencyCheck(_))).next((()=>g.documentOverlayCache.removeOverlaysForBatchId(_,E,m))).next((()=>g.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(_,E))).next((()=>g.localDocuments.getDocuments(_,E)))}))})(s.localStore,e);qv(s,e,t),Wv(s,e),s.sharedClientState.updateMutationState(e,"rejected",t),await ul(s,o)}catch(o){await ko(o)}}function Wv(r,e){(r.mu.get(e)||[]).forEach((t=>{t.resolve()})),r.mu.delete(e)}function qv(r,e,t){const s=ve(r);let o=s.du[s.currentUser.toKey()];if(o){const l=o.get(e);l&&(t?l.reject(t):l.resolve(),o=o.remove(e)),s.du[s.currentUser.toKey()]=o}}function $d(r,e,t=null){r.sharedClientState.removeLocalQueryTarget(e);for(const s of r.Eu.get(e))r.Tu.delete(s),t&&r.Pu.yu(s,t);r.Eu.delete(e),r.isPrimaryClient&&r.Vu.Gr(e).forEach((s=>{r.Vu.containsKey(s)||Kv(r,s)}))}function Kv(r,e){r.Iu.delete(e.path.canonicalString());const t=r.Ru.get(e);t!==null&&(Tf(r.remoteStore,t),r.Ru=r.Ru.remove(e),r.Au.delete(t),Nf(r))}function Sy(r,e,t){for(const s of t)s instanceof zv?(r.Vu.addReference(s.key,e),OC(r,s)):s instanceof Bv?(re(kf,"Document no longer in limbo: "+s.key),r.Vu.removeReference(s.key,e),r.Vu.containsKey(s.key)||Kv(r,s.key)):me(19791,{wu:s})}function OC(r,e){const t=e.key,s=t.path.canonicalString();r.Ru.get(t)||r.Iu.has(s)||(re(kf,"New document in limbo: "+t),r.Iu.add(s),Nf(r))}function Nf(r){for(;r.Iu.size>0&&r.Ru.size<r.maxConcurrentLimboResolutions;){const e=r.Iu.values().next().value;r.Iu.delete(e);const t=new ce(Ge.fromString(e)),s=r.fu.next();r.Au.set(s,new IC(t)),r.Ru=r.Ru.insert(t,s),Lv(r.remoteStore,new pi(tr(df(t.path)),s,"TargetPurposeLimboResolution",_c.ce))}}async function ul(r,e,t){const s=ve(r),o=[],l=[],h=[];s.Tu.isEmpty()||(s.Tu.forEach(((m,g)=>{h.push(s.pu(g,e,t).then((_=>{var E;if((_||t)&&s.isPrimaryClient){const I=_?!_.fromCache:(E=t==null?void 0:t.targetChanges.get(g.targetId))==null?void 0:E.current;s.sharedClientState.updateQueryState(g.targetId,I?"current":"not-current")}if(_){o.push(_);const I=Ef.Is(g.targetId,_);l.push(I)}})))})),await Promise.all(h),s.Pu.H_(o),await(async function(g,_){const E=ve(g);try{await E.persistence.runTransaction("notifyLocalViewChanges","readwrite",(I=>H.forEach(_,(C=>H.forEach(C.Ts,(z=>E.persistence.referenceDelegate.addReference(I,C.targetId,z))).next((()=>H.forEach(C.Es,(z=>E.persistence.referenceDelegate.removeReference(I,C.targetId,z)))))))))}catch(I){if(!No(I))throw I;re(wf,"Failed to update sequence numbers: "+I)}for(const I of _){const C=I.targetId;if(!I.fromCache){const z=E.vs.get(C),G=z.snapshotVersion,Q=z.withLastLimboFreeSnapshotVersion(G);E.vs=E.vs.insert(C,Q)}}})(s.localStore,l))}async function LC(r,e){const t=ve(r);if(!t.currentUser.isEqual(e)){re(kf,"User change. New user:",e.toKey());const s=await xv(t.localStore,e);t.currentUser=e,(function(l,h){l.mu.forEach((m=>{m.forEach((g=>{g.reject(new ie($.CANCELLED,h))}))})),l.mu.clear()})(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,s.removedBatchIds,s.addedBatchIds),await ul(t,s.Ns)}}function bC(r,e){const t=ve(r),s=t.Au.get(e);if(s&&s.hu)return xe().add(s.key);{let o=xe();const l=t.Eu.get(e);if(!l)return o;for(const h of l){const m=t.Tu.get(h);o=o.unionWith(m.view.nu)}return o}}function Gv(r){const e=ve(r);return e.remoteStore.remoteSyncer.applyRemoteEvent=Hv.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=bC.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=xC.bind(null,e),e.Pu.H_=_C.bind(null,e.eventManager),e.Pu.yu=vC.bind(null,e.eventManager),e}function MC(r){const e=ve(r);return e.remoteStore.remoteSyncer.applySuccessfulWrite=DC.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=VC.bind(null,e),e}class uc{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(e){this.serializer=Rc(e.databaseInfo.databaseId),this.sharedClientState=this.Du(e),this.persistence=this.Cu(e),await this.persistence.start(),this.localStore=this.vu(e),this.gcScheduler=this.Fu(e,this.localStore),this.indexBackfillerScheduler=this.Mu(e,this.localStore)}Fu(e,t){return null}Mu(e,t){return null}vu(e){return MR(this.persistence,new OR,e.initialUser,this.serializer)}Cu(e){return new Nv(vf.Vi,this.serializer)}Du(e){return new HR}async terminate(){var e,t;(e=this.gcScheduler)==null||e.stop(),(t=this.indexBackfillerScheduler)==null||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}uc.provider={build:()=>new uc};class FC extends uc{constructor(e){super(),this.cacheSizeBytes=e}Fu(e,t){ze(this.persistence.referenceDelegate instanceof ac,46915);const s=this.persistence.referenceDelegate.garbageCollector;return new vR(s,e.asyncQueue,t)}Cu(e){const t=this.cacheSizeBytes!==void 0?Yt.withCacheSize(this.cacheSizeBytes):Yt.DEFAULT;return new Nv((s=>ac.Vi(s,t)),this.serializer)}}class Hd{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=s=>Iy(this.syncEngine,s,1),this.remoteStore.remoteSyncer.handleCredentialChange=LC.bind(null,this.syncEngine),await fC(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return(function(){return new mC})()}createDatastore(e){const t=Rc(e.databaseInfo.databaseId),s=QR(e.databaseInfo);return eC(e.authCredentials,e.appCheckCredentials,s,t)}createRemoteStore(e){return(function(s,o,l,h,m){return new nC(s,o,l,h,m)})(this.localStore,this.datastore,e.asyncQueue,(t=>Iy(this.syncEngine,t,0)),(function(){return yy.v()?new yy:new WR})())}createSyncEngine(e,t){return(function(o,l,h,m,g,_,E){const I=new SC(o,l,h,m,g,_);return E&&(I.gu=!0),I})(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e,t;await(async function(o){const l=ve(o);re(fs,"RemoteStore shutting down."),l.Ia.add(5),await ll(l),l.Aa.shutdown(),l.Va.set("Unknown")})(this.remoteStore),(e=this.datastore)==null||e.terminate(),(t=this.eventManager)==null||t.terminate()}}Hd.provider={build:()=>new Hd};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class UC{constructor(e){this.observer=e,this.muted=!1}next(e){this.muted||this.observer.next&&this.Ou(this.observer.next,e)}error(e){this.muted||(this.observer.error?this.Ou(this.observer.error,e):Pr("Uncaught Error in snapshot listener:",e.toString()))}Nu(){this.muted=!0}Ou(e,t){setTimeout((()=>{this.muted||e(t)}),0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ri="FirestoreClient";class jC{constructor(e,t,s,o,l){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=s,this._databaseInfo=o,this.user=Ft.UNAUTHENTICATED,this.clientId=of.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=l,this.authCredentials.start(s,(async h=>{re(Ri,"Received user=",h.uid),await this.authCredentialListener(h),this.user=h})),this.appCheckCredentials.start(s,(h=>(re(Ri,"Received new app check token=",h),this.appCheckCredentialListener(h,this.user))))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this._databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}terminate(){this.asyncQueue.enterRestrictedMode();const e=new ss;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted((async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const s=Cf(t,"Failed to shutdown persistence");e.reject(s)}})),e.promise}}async function vd(r,e){r.asyncQueue.verifyOperationInProgress(),re(Ri,"Initializing OfflineComponentProvider");const t=r.configuration;await e.initialize(t);let s=t.initialUser;r.setCredentialChangeListener((async o=>{s.isEqual(o)||(await xv(e.localStore,o),s=o)})),e.persistence.setDatabaseDeletedListener((()=>r.terminate())),r._offlineComponents=e}async function Ay(r,e){r.asyncQueue.verifyOperationInProgress();const t=await zC(r);re(Ri,"Initializing OnlineComponentProvider"),await e.initialize(t,r.configuration),r.setCredentialChangeListener((s=>vy(e.remoteStore,s))),r.setAppCheckTokenChangeListener(((s,o)=>vy(e.remoteStore,o))),r._onlineComponents=e}async function zC(r){if(!r._offlineComponents)if(r._uninitializedComponentsProvider){re(Ri,"Using user provided OfflineComponentProvider");try{await vd(r,r._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!(function(o){return o.name==="FirebaseError"?o.code===$.FAILED_PRECONDITION||o.code===$.UNIMPLEMENTED:!(typeof DOMException<"u"&&o instanceof DOMException)||o.code===22||o.code===20||o.code===11})(t))throw t;ds("Error using user provided cache. Falling back to memory cache: "+t),await vd(r,new uc)}}else re(Ri,"Using default OfflineComponentProvider"),await vd(r,new FC(void 0));return r._offlineComponents}async function Qv(r){return r._onlineComponents||(r._uninitializedComponentsProvider?(re(Ri,"Using user provided OnlineComponentProvider"),await Ay(r,r._uninitializedComponentsProvider._online)):(re(Ri,"Using default OnlineComponentProvider"),await Ay(r,new Hd))),r._onlineComponents}function BC(r){return Qv(r).then((e=>e.syncEngine))}async function Ry(r){const e=await Qv(r),t=e.eventManager;return t.onListen=AC.bind(null,e.syncEngine),t.onUnlisten=PC.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=RC.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=kC.bind(null,e.syncEngine),t}function $C(r,e,t,s){const o=new UC(s),l=new EC(e,o,t);return r.asyncQueue.enqueueAndForget((async()=>gC(await Ry(r),l))),()=>{o.Nu(),r.asyncQueue.enqueueAndForget((async()=>yC(await Ry(r),l)))}}function HC(r,e){const t=new ss;return r.asyncQueue.enqueueAndForget((async()=>NC(await BC(r),e,t))),t.promise}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Yv(r){const e={};return r.timeoutSeconds!==void 0&&(e.timeoutSeconds=r.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const WC="ComponentProvider",Cy=new Map;function qC(r,e,t,s,o){return new uA(r,e,t,o.host,o.ssl,o.experimentalForceLongPolling,o.experimentalAutoDetectLongPolling,Yv(o.experimentalLongPollingOptions),o.useFetchStreams,o.isUsingEmulator,s)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Jv="firestore.googleapis.com",Py=!0;class ky{constructor(e){if(e.host===void 0){if(e.ssl!==void 0)throw new ie($.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=Jv,this.ssl=Py}else this.host=e.host,this.ssl=e.ssl??Py;if(this.isUsingEmulator=e.emulatorOptions!==void 0,this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=kv;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<yR)throw new ie($.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}XS("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=Yv(e.experimentalLongPollingOptions??{}),(function(s){if(s.timeoutSeconds!==void 0){if(isNaN(s.timeoutSeconds))throw new ie($.INVALID_ARGUMENT,`invalid long polling timeout: ${s.timeoutSeconds} (must not be NaN)`);if(s.timeoutSeconds<5)throw new ie($.INVALID_ARGUMENT,`invalid long polling timeout: ${s.timeoutSeconds} (minimum allowed value is 5)`);if(s.timeoutSeconds>30)throw new ie($.INVALID_ARGUMENT,`invalid long polling timeout: ${s.timeoutSeconds} (maximum allowed value is 30)`)}})(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&(function(s,o){return s.timeoutSeconds===o.timeoutSeconds})(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class kc{constructor(e,t,s,o){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=s,this._app=o,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new ky({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new ie($.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new ie($.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new ky(e),this._emulatorOptions=e.emulatorOptions||{},e.credentials!==void 0&&(this._authCredentials=(function(s){if(!s)return new BS;switch(s.type){case"firstParty":return new qS(s.sessionIndex||"0",s.iamToken||null,s.authTokenFactory||null);case"provider":return s.client;default:throw new ie($.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}})(e.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return(function(t){const s=Cy.get(t);s&&(re(WC,"Removing Datastore"),Cy.delete(t),s.terminate())})(this),Promise.resolve()}}function KC(r,e,t,s={}){var _;r=vi(r,kc);const o=Za(e),l=r._getSettings(),h={...l,emulatorOptions:r._getEmulatorOptions()},m=`${e}:${t}`;o&&qy(`https://${m}`),l.host!==Jv&&l.host!==m&&ds("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const g={...l,host:m,ssl:o,emulatorOptions:s};if(!as(g,h)&&(r._setSettings(g),s.mockUserToken)){let E,I;if(typeof s.mockUserToken=="string")E=s.mockUserToken,I=Ft.MOCK_USER;else{E=Yw(s.mockUserToken,(_=r._app)==null?void 0:_.options.projectId);const C=s.mockUserToken.sub||s.mockUserToken.user_id;if(!C)throw new ie($.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");I=new Ft(C)}r._authCredentials=new $S(new j_(E,I))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Do{constructor(e,t,s){this.converter=t,this._query=s,this.type="query",this.firestore=e}withConverter(e){return new Do(this.firestore,e,this._query)}}class gt{constructor(e,t,s){this.converter=t,this._key=s,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new Ei(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new gt(this.firestore,e,this._key)}toJSON(){return{type:gt._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(e,t,s){if(il(t,gt._jsonSchema))return new gt(e,s||null,new ce(Ge.fromString(t.referencePath)))}}gt._jsonSchemaVersion="firestore/documentReference/1.0",gt._jsonSchema={type:mt("string",gt._jsonSchemaVersion),referencePath:mt("string")};class Ei extends Do{constructor(e,t,s){super(e,t,df(s)),this._path=s,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new gt(this.firestore,null,new ce(e))}withConverter(e){return new Ei(this.firestore,e,this._path)}}function Xv(r,e,...t){if(r=Et(r),z_("collection","path",e),r instanceof kc){const s=Ge.fromString(e,...t);return zg(s),new Ei(r,null,s)}{if(!(r instanceof gt||r instanceof Ei))throw new ie($.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=r._path.child(Ge.fromString(e,...t));return zg(s),new Ei(r.firestore,null,s)}}function cc(r,e,...t){if(r=Et(r),arguments.length===1&&(e=of.newId()),z_("doc","path",e),r instanceof kc){const s=Ge.fromString(e,...t);return jg(s),new gt(r,null,new ce(s))}{if(!(r instanceof gt||r instanceof Ei))throw new ie($.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=r._path.child(Ge.fromString(e,...t));return jg(s),new gt(r.firestore,r instanceof Ei?r.converter:null,new ce(s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ny="AsyncQueue";class xy{constructor(e=Promise.resolve()){this.Yu=[],this.ec=!1,this.tc=[],this.nc=null,this.rc=!1,this.sc=!1,this.oc=[],this.M_=new Vv(this,"async_queue_retry"),this._c=()=>{const s=_d();s&&re(Ny,"Visibility state changed to "+s.visibilityState),this.M_.w_()},this.ac=e;const t=_d();t&&typeof t.addEventListener=="function"&&t.addEventListener("visibilitychange",this._c)}get isShuttingDown(){return this.ec}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.uc(),this.cc(e)}enterRestrictedMode(e){if(!this.ec){this.ec=!0,this.sc=e||!1;const t=_d();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this._c)}}enqueue(e){if(this.uc(),this.ec)return new Promise((()=>{}));const t=new ss;return this.cc((()=>this.ec&&this.sc?Promise.resolve():(e().then(t.resolve,t.reject),t.promise))).then((()=>t.promise))}enqueueRetryable(e){this.enqueueAndForget((()=>(this.Yu.push(e),this.lc())))}async lc(){if(this.Yu.length!==0){try{await this.Yu[0](),this.Yu.shift(),this.M_.reset()}catch(e){if(!No(e))throw e;re(Ny,"Operation failed with retryable error: "+e)}this.Yu.length>0&&this.M_.p_((()=>this.lc()))}}cc(e){const t=this.ac.then((()=>(this.rc=!0,e().catch((s=>{throw this.nc=s,this.rc=!1,Pr("INTERNAL UNHANDLED ERROR: ",Dy(s)),s})).then((s=>(this.rc=!1,s))))));return this.ac=t,t}enqueueAfterDelay(e,t,s){this.uc(),this.oc.indexOf(e)>-1&&(t=0);const o=Rf.createAndSchedule(this,e,t,s,(l=>this.hc(l)));return this.tc.push(o),o}uc(){this.nc&&me(47125,{Pc:Dy(this.nc)})}verifyOperationInProgress(){}async Tc(){let e;do e=this.ac,await e;while(e!==this.ac)}Ec(e){for(const t of this.tc)if(t.timerId===e)return!0;return!1}Ic(e){return this.Tc().then((()=>{this.tc.sort(((t,s)=>t.targetTimeMs-s.targetTimeMs));for(const t of this.tc)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.Tc()}))}Rc(e){this.oc.push(e)}hc(e){const t=this.tc.indexOf(e);this.tc.splice(t,1)}}function Dy(r){let e=r.message||"";return r.stack&&(e=r.stack.includes(r.message)?r.stack:r.message+`
`+r.stack),e}class So extends kc{constructor(e,t,s,o){super(e,t,s,o),this.type="firestore",this._queue=new xy,this._persistenceKey=(o==null?void 0:o.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new xy(e),this._firestoreClient=void 0,await e}}}function GC(r,e){const t=typeof r=="object"?r:Yy(),s=typeof r=="string"?r:tc,o=Qd(t,"firestore").getImmediate({identifier:s});if(!o._initialized){const l=Gw("firestore");l&&KC(o,...l)}return o}function Zv(r){if(r._terminated)throw new ie($.FAILED_PRECONDITION,"The client has already been terminated.");return r._firestoreClient||QC(r),r._firestoreClient}function QC(r){var s,o,l,h;const e=r._freezeSettings(),t=qC(r._databaseId,((s=r._app)==null?void 0:s.options.appId)||"",r._persistenceKey,(o=r._app)==null?void 0:o.options.apiKey,e);r._componentsProvider||(l=e.localCache)!=null&&l._offlineComponentProvider&&((h=e.localCache)!=null&&h._onlineComponentProvider)&&(r._componentsProvider={_offline:e.localCache._offlineComponentProvider,_online:e.localCache._onlineComponentProvider}),r._firestoreClient=new jC(r._authCredentials,r._appCheckCredentials,r._queue,t,r._componentsProvider&&(function(g){const _=g==null?void 0:g._online.build();return{_offline:g==null?void 0:g._offline.build(_),_online:_}})(r._componentsProvider))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _n{constructor(e){this._byteString=e}static fromBase64String(e){try{return new _n(xt.fromBase64String(e))}catch(t){throw new ie($.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new _n(xt.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}toJSON(){return{type:_n._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(e){if(il(e,_n._jsonSchema))return _n.fromBase64String(e.bytes)}}_n._jsonSchemaVersion="firestore/bytes/1.0",_n._jsonSchema={type:mt("string",_n._jsonSchemaVersion),bytes:mt("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xf{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new ie($.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new Nt(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nc{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rr{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new ie($.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new ie($.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}_compareTo(e){return Ne(this._lat,e._lat)||Ne(this._long,e._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:rr._jsonSchemaVersion}}static fromJSON(e){if(il(e,rr._jsonSchema))return new rr(e.latitude,e.longitude)}}rr._jsonSchemaVersion="firestore/geoPoint/1.0",rr._jsonSchema={type:mt("string",rr._jsonSchemaVersion),latitude:mt("number"),longitude:mt("number")};/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xn{constructor(e){this._values=(e||[]).map((t=>t))}toArray(){return this._values.map((e=>e))}isEqual(e){return(function(s,o){if(s.length!==o.length)return!1;for(let l=0;l<s.length;++l)if(s[l]!==o[l])return!1;return!0})(this._values,e._values)}toJSON(){return{type:xn._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(e){if(il(e,xn._jsonSchema)){if(Array.isArray(e.vectorValues)&&e.vectorValues.every((t=>typeof t=="number")))return new xn(e.vectorValues);throw new ie($.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}xn._jsonSchemaVersion="firestore/vectorValue/1.0",xn._jsonSchema={type:mt("string",xn._jsonSchemaVersion),vectorValues:mt("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const YC=/^__.*__$/;class JC{constructor(e,t,s){this.data=e,this.fieldMask=t,this.fieldTransforms=s}toMutation(e,t){return this.fieldMask!==null?new ki(e,this.data,this.fieldMask,t,this.fieldTransforms):new ol(e,this.data,t,this.fieldTransforms)}}class eE{constructor(e,t,s){this.data=e,this.fieldMask=t,this.fieldTransforms=s}toMutation(e,t){return new ki(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function tE(r){switch(r){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw me(40011,{dataSource:r})}}class Df{constructor(e,t,s,o,l,h){this.settings=e,this.databaseId=t,this.serializer=s,this.ignoreUndefinedProperties=o,l===void 0&&this.Ac(),this.fieldTransforms=l||[],this.fieldMask=h||[]}get path(){return this.settings.path}get dataSource(){return this.settings.dataSource}i(e){return new Df({...this.settings,...e},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}dc(e){var o;const t=(o=this.path)==null?void 0:o.child(e),s=this.i({path:t,arrayElement:!1});return s.mc(e),s}fc(e){var o;const t=(o=this.path)==null?void 0:o.child(e),s=this.i({path:t,arrayElement:!1});return s.Ac(),s}gc(e){return this.i({path:void 0,arrayElement:!0})}yc(e){return hc(e,this.settings.methodName,this.settings.hasConverter||!1,this.path,this.settings.targetDoc)}contains(e){return this.fieldMask.find((t=>e.isPrefixOf(t)))!==void 0||this.fieldTransforms.find((t=>e.isPrefixOf(t.field)))!==void 0}Ac(){if(this.path)for(let e=0;e<this.path.length;e++)this.mc(this.path.get(e))}mc(e){if(e.length===0)throw this.yc("Document fields must not be empty");if(tE(this.dataSource)&&YC.test(e))throw this.yc('Document fields cannot begin and end with "__"')}}class XC{constructor(e,t,s){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=s||Rc(e)}A(e,t,s,o=!1){return new Df({dataSource:e,methodName:t,targetDoc:s,path:Nt.emptyPath(),arrayElement:!1,hasConverter:o},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Vf(r){const e=r._freezeSettings(),t=Rc(r._databaseId);return new XC(r._databaseId,!!e.ignoreUndefinedProperties,t)}function ZC(r,e,t,s,o,l={}){const h=r.A(l.merge||l.mergeFields?2:0,e,t,o);Lf("Data must be an object, but it was:",h,s);const m=nE(s,h);let g,_;if(l.merge)g=new ln(h.fieldMask),_=h.fieldTransforms;else if(l.mergeFields){const E=[];for(const I of l.mergeFields){const C=Ao(e,I,t);if(!h.contains(C))throw new ie($.INVALID_ARGUMENT,`Field '${C}' is specified in your field mask but missing from your input data.`);sE(E,C)||E.push(C)}g=new ln(E),_=h.fieldTransforms.filter((I=>g.covers(I.field)))}else g=null,_=h.fieldTransforms;return new JC(new Jt(m),g,_)}class xc extends Nc{_toFieldTransform(e){if(e.dataSource!==2)throw e.dataSource===1?e.yc(`${this._methodName}() can only appear at the top level of your update data`):e.yc(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof xc}}class Of extends Nc{_toFieldTransform(e){return new MA(e.path,new Ga)}isEqual(e){return e instanceof Of}}function eP(r,e,t,s){const o=r.A(1,e,t);Lf("Data must be an object, but it was:",o,s);const l=[],h=Jt.empty();Pi(s,((g,_)=>{const E=iE(e,g,t);_=Et(_);const I=o.fc(E);if(_ instanceof xc)l.push(E);else{const C=cl(_,I);C!=null&&(l.push(E),h.set(E,C))}}));const m=new ln(l);return new eE(h,m,o.fieldTransforms)}function tP(r,e,t,s,o,l){const h=r.A(1,e,t),m=[Ao(e,s,t)],g=[o];if(l.length%2!=0)throw new ie($.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let C=0;C<l.length;C+=2)m.push(Ao(e,l[C])),g.push(l[C+1]);const _=[],E=Jt.empty();for(let C=m.length-1;C>=0;--C)if(!sE(_,m[C])){const z=m[C];let G=g[C];G=Et(G);const Q=h.fc(z);if(G instanceof xc)_.push(z);else{const B=cl(G,Q);B!=null&&(_.push(z),E.set(z,B))}}const I=new ln(_);return new eE(E,I,h.fieldTransforms)}function nP(r,e,t,s=!1){return cl(t,r.A(s?4:3,e))}function cl(r,e){if(rE(r=Et(r)))return Lf("Unsupported field value:",e,r),nE(r,e);if(r instanceof Nc)return(function(s,o){if(!tE(o.dataSource))throw o.yc(`${s._methodName}() can only be used with update() and set()`);if(!o.path)throw o.yc(`${s._methodName}() is not currently supported inside arrays`);const l=s._toFieldTransform(o);l&&o.fieldTransforms.push(l)})(r,e),null;if(r===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),r instanceof Array){if(e.settings.arrayElement&&e.dataSource!==4)throw e.yc("Nested arrays are not supported");return(function(s,o){const l=[];let h=0;for(const m of s){let g=cl(m,o.gc(h));g==null&&(g={nullValue:"NULL_VALUE"}),l.push(g),h++}return{arrayValue:{values:l}}})(r,e)}return(function(s,o){if((s=Et(s))===null)return{nullValue:"NULL_VALUE"};if(typeof s=="number")return OA(o.serializer,s);if(typeof s=="boolean")return{booleanValue:s};if(typeof s=="string")return{stringValue:s};if(s instanceof Date){const l=Xe.fromDate(s);return{timestampValue:oc(o.serializer,l)}}if(s instanceof Xe){const l=new Xe(s.seconds,1e3*Math.floor(s.nanoseconds/1e3));return{timestampValue:oc(o.serializer,l)}}if(s instanceof rr)return{geoPointValue:{latitude:s.latitude,longitude:s.longitude}};if(s instanceof _n)return{bytesValue:wv(o.serializer,s._byteString)};if(s instanceof gt){const l=o.databaseId,h=s.firestore._databaseId;if(!h.isEqual(l))throw o.yc(`Document reference is for database ${h.projectId}/${h.database} but should be for database ${l.projectId}/${l.database}`);return{referenceValue:yf(s.firestore._databaseId||o.databaseId,s._key.path)}}if(s instanceof xn)return(function(h,m){const g=h instanceof xn?h.toArray():h;return{mapValue:{fields:{[Y_]:{stringValue:J_},[nc]:{arrayValue:{values:g.map((E=>{if(typeof E!="number")throw m.yc("VectorValues must only contain numeric values.");return ff(m.serializer,E)}))}}}}}})(s,o);if(Pv(s))return s._toProto(o.serializer);throw o.yc(`Unsupported field value: ${yc(s)}`)})(r,e)}function nE(r,e){const t={};return H_(r)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):Pi(r,((s,o)=>{const l=cl(o,e.dc(s));l!=null&&(t[s]=l)})),{mapValue:{fields:t}}}function rE(r){return!(typeof r!="object"||r===null||r instanceof Array||r instanceof Date||r instanceof Xe||r instanceof rr||r instanceof _n||r instanceof gt||r instanceof Nc||r instanceof xn||Pv(r))}function Lf(r,e,t){if(!rE(t)||!B_(t)){const s=yc(t);throw s==="an object"?e.yc(r+" a custom object"):e.yc(r+" "+s)}}function Ao(r,e,t){if((e=Et(e))instanceof xf)return e._internalPath;if(typeof e=="string")return iE(r,e);throw hc("Field path arguments must be of type string or ",r,!1,void 0,t)}const rP=new RegExp("[~\\*/\\[\\]]");function iE(r,e,t){if(e.search(rP)>=0)throw hc(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,r,!1,void 0,t);try{return new xf(...e.split("."))._internalPath}catch{throw hc(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,r,!1,void 0,t)}}function hc(r,e,t,s,o){const l=s&&!s.isEmpty(),h=o!==void 0;let m=`Function ${e}() called with invalid data`;t&&(m+=" (via `toFirestore()`)"),m+=". ";let g="";return(l||h)&&(g+=" (found",l&&(g+=` in field ${s}`),h&&(g+=` in document ${o}`),g+=")"),new ie($.INVALID_ARGUMENT,m+r+g)}function sE(r,e){return r.some((t=>t.isEqual(e)))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iP{convertValue(e,t="none"){switch(Si(e)){case 0:return null;case 1:return e.booleanValue;case 2:return lt(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(Ii(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 11:return this.convertObject(e.mapValue,t);case 10:return this.convertVectorValue(e.mapValue);default:throw me(62114,{value:e})}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const s={};return Pi(e,((o,l)=>{s[o]=this.convertValue(l,t)})),s}convertVectorValue(e){var s,o,l;const t=(l=(o=(s=e.fields)==null?void 0:s[nc].arrayValue)==null?void 0:o.values)==null?void 0:l.map((h=>lt(h.doubleValue)));return new xn(t)}convertGeoPoint(e){return new rr(lt(e.latitude),lt(e.longitude))}convertArray(e,t){return(e.values||[]).map((s=>this.convertValue(s,t)))}convertServerTimestamp(e,t){switch(t){case"previous":const s=Ec(e);return s==null?null:this.convertValue(s,t);case"estimate":return this.convertTimestamp(Wa(e));default:return null}}convertTimestamp(e){const t=Ti(e);return new Xe(t.seconds,t.nanos)}convertDocumentKey(e,t){const s=Ge.fromString(e);ze(Cv(s),9688,{name:e});const o=new qa(s.get(1),s.get(3)),l=new ce(s.popFirst(5));return o.isEqual(t)||Pr(`Document ${l} contains a document reference within a different database (${o.projectId}/${o.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),l}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oE extends iP{constructor(e){super(),this.firestore=e}convertBytes(e){return new _n(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new gt(this.firestore,null,t)}}function sP(){return new Of("serverTimestamp")}const Vy="@firebase/firestore",Oy="4.13.0";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ly(r){return(function(t,s){if(typeof t!="object"||t===null)return!1;const o=t;for(const l of s)if(l in o&&typeof o[l]=="function")return!0;return!1})(r,["next","error","complete"])}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class aE{constructor(e,t,s,o,l){this._firestore=e,this._userDataWriter=t,this._key=s,this._document=o,this._converter=l}get id(){return this._key.path.lastSegment()}get ref(){return new gt(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new oP(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){var e;return((e=this._document)==null?void 0:e.data.clone().value.mapValue.fields)??void 0}get(e){if(this._document){const t=this._document.data.field(Ao("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}}class oP extends aE{data(){return super.data()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function aP(r){if(r.limitType==="L"&&r.explicitOrderBy.length===0)throw new ie($.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class bf{}class lP extends bf{}function uP(r,e,...t){let s=[];e instanceof bf&&s.push(e),s=s.concat(t),(function(l){const h=l.filter((g=>g instanceof Mf)).length,m=l.filter((g=>g instanceof Dc)).length;if(h>1||h>0&&m>0)throw new ie($.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")})(s);for(const o of s)r=o._apply(r);return r}class Dc extends lP{constructor(e,t,s){super(),this._field=e,this._op=t,this._value=s,this.type="where"}static _create(e,t,s){return new Dc(e,t,s)}_apply(e){const t=this._parse(e);return lE(e._query,t),new Do(e.firestore,e.converter,Od(e._query,t))}_parse(e){const t=Vf(e.firestore);return(function(l,h,m,g,_,E,I){let C;if(_.isKeyField()){if(E==="array-contains"||E==="array-contains-any")throw new ie($.INVALID_ARGUMENT,`Invalid Query. You can't perform '${E}' queries on documentId().`);if(E==="in"||E==="not-in"){My(I,E);const G=[];for(const Q of I)G.push(by(g,l,Q));C={arrayValue:{values:G}}}else C=by(g,l,I)}else E!=="in"&&E!=="not-in"&&E!=="array-contains-any"||My(I,E),C=nP(m,h,I,E==="in"||E==="not-in");return pt.create(_,E,C)})(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}function cP(r,e,t){const s=e,o=Ao("where",r);return Dc._create(o,s,t)}class Mf extends bf{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new Mf(e,t)}_parse(e){const t=this._queryConstraints.map((s=>s._parse(e))).filter((s=>s.getFilters().length>0));return t.length===1?t[0]:Vn.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:((function(o,l){let h=o;const m=l.getFlattenedFilters();for(const g of m)lE(h,g),h=Od(h,g)})(e._query,t),new Do(e.firestore,e.converter,Od(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}function by(r,e,t){if(typeof(t=Et(t))=="string"){if(t==="")throw new ie($.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!sv(e)&&t.indexOf("/")!==-1)throw new ie($.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const s=e.path.child(Ge.fromString(t));if(!ce.isDocumentKey(s))throw new ie($.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${s}' is not because it has an odd number of segments (${s.length}).`);return Qg(r,new ce(s))}if(t instanceof gt)return Qg(r,t._key);throw new ie($.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${yc(t)}.`)}function My(r,e){if(!Array.isArray(r)||r.length===0)throw new ie($.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function lE(r,e){const t=(function(o,l){for(const h of o)for(const m of h.getFlattenedFilters())if(l.indexOf(m.op)>=0)return m.op;return null})(r.filters,(function(o){switch(o){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}})(e.op));if(t!==null)throw t===e.op?new ie($.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new ie($.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}function hP(r,e,t){let s;return s=r?r.toFirestore(e):e,s}class Oa{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class os extends aE{constructor(e,t,s,o,l,h){super(e,t,s,o,h),this._firestore=e,this._firestoreImpl=e,this.metadata=l}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new $u(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const s=this._document.data.field(Ao("DocumentSnapshot.get",e));if(s!==null)return this._userDataWriter.convertValue(s,t.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new ie($.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e=this._document,t={};return t.type=os._jsonSchemaVersion,t.bundle="",t.bundleSource="DocumentSnapshot",t.bundleName=this._key.toString(),!e||!e.isValidDocument()||!e.isFoundDocument()?t:(this._userDataWriter.convertObjectMap(e.data.value.mapValue.fields,"previous"),t.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),t)}}os._jsonSchemaVersion="firestore/documentSnapshot/1.0",os._jsonSchema={type:mt("string",os._jsonSchemaVersion),bundleSource:mt("string","DocumentSnapshot"),bundleName:mt("string"),bundle:mt("string")};class $u extends os{data(e={}){return super.data(e)}}class mo{constructor(e,t,s,o){this._firestore=e,this._userDataWriter=t,this._snapshot=o,this.metadata=new Oa(o.hasPendingWrites,o.fromCache),this.query=s}get docs(){const e=[];return this.forEach((t=>e.push(t))),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach((s=>{e.call(t,new $u(this._firestore,this._userDataWriter,s.key,s,new Oa(this._snapshot.mutatedKeys.has(s.key),this._snapshot.fromCache),this.query.converter))}))}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new ie($.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=(function(o,l){if(o._snapshot.oldDocs.isEmpty()){let h=0;return o._snapshot.docChanges.map((m=>{const g=new $u(o._firestore,o._userDataWriter,m.doc.key,m.doc,new Oa(o._snapshot.mutatedKeys.has(m.doc.key),o._snapshot.fromCache),o.query.converter);return m.doc,{type:"added",doc:g,oldIndex:-1,newIndex:h++}}))}{let h=o._snapshot.oldDocs;return o._snapshot.docChanges.filter((m=>l||m.type!==3)).map((m=>{const g=new $u(o._firestore,o._userDataWriter,m.doc.key,m.doc,new Oa(o._snapshot.mutatedKeys.has(m.doc.key),o._snapshot.fromCache),o.query.converter);let _=-1,E=-1;return m.type!==0&&(_=h.indexOf(m.doc.key),h=h.delete(m.doc.key)),m.type!==1&&(h=h.add(m.doc),E=h.indexOf(m.doc.key)),{type:dP(m.type),doc:g,oldIndex:_,newIndex:E}}))}})(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new ie($.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e={};e.type=mo._jsonSchemaVersion,e.bundleSource="QuerySnapshot",e.bundleName=of.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const t=[],s=[],o=[];return this.docs.forEach((l=>{l._document!==null&&(t.push(l._document),s.push(this._userDataWriter.convertObjectMap(l._document.data.value.mapValue.fields,"previous")),o.push(l.ref.path))})),e.bundle=(this._firestore,this.query._query,e.bundleName,"NOT SUPPORTED"),e}}function dP(r){switch(r){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return me(61501,{type:r})}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */mo._jsonSchemaVersion="firestore/querySnapshot/1.0",mo._jsonSchema={type:mt("string",mo._jsonSchemaVersion),bundleSource:mt("string","QuerySnapshot"),bundleName:mt("string"),bundle:mt("string")};function uE(r,e,t,...s){r=vi(r,gt);const o=vi(r.firestore,So),l=Vf(o);let h;return h=typeof(e=Et(e))=="string"||e instanceof xf?tP(l,"updateDoc",r._key,e,t,s):eP(l,"updateDoc",r._key,e),Ff(o,[h.toMutation(r._key,Nn.exists(!0))])}function fP(r){return Ff(vi(r.firestore,So),[new pf(r._key,Nn.none())])}function pP(r,e){const t=vi(r.firestore,So),s=cc(r),o=hP(r.converter,e),l=Vf(r.firestore);return Ff(t,[ZC(l,"addDoc",s._key,o,r.converter!==null,{}).toMutation(s._key,Nn.exists(!1))]).then((()=>s))}function mP(r,...e){var _,E,I;r=Et(r);let t={includeMetadataChanges:!1,source:"default"},s=0;typeof e[s]!="object"||Ly(e[s])||(t=e[s++]);const o={includeMetadataChanges:t.includeMetadataChanges,source:t.source};if(Ly(e[s])){const C=e[s];e[s]=(_=C.next)==null?void 0:_.bind(C),e[s+1]=(E=C.error)==null?void 0:E.bind(C),e[s+2]=(I=C.complete)==null?void 0:I.bind(C)}let l,h,m;if(r instanceof gt)h=vi(r.firestore,So),m=df(r._key.path),l={next:C=>{e[s]&&e[s](gP(h,r,C))},error:e[s+1],complete:e[s+2]};else{const C=vi(r,Do);h=vi(C.firestore,So),m=C._query;const z=new oE(h);l={next:G=>{e[s]&&e[s](new mo(h,z,C,G))},error:e[s+1],complete:e[s+2]},aP(r._query)}const g=Zv(h);return $C(g,m,o,l)}function Ff(r,e){const t=Zv(r);return HC(t,e)}function gP(r,e,t){const s=t.docs.get(e._key),o=new oE(r);return new os(r,o,e._key,s,new Oa(t.hasPendingWrites,t.fromCache),e.converter)}(function(e,t=!0){zS(Ro),_o(new ls("firestore",((s,{instanceIdentifier:o,options:l})=>{const h=s.getProvider("app").getImmediate(),m=new So(new HS(s.getProvider("auth-internal")),new KS(h,s.getProvider("app-check-internal")),cA(h,o),h);return l={useFetchStreams:t,...l},m._setSettings(l),m}),"PUBLIC").setMultipleInstances(!0)),yi(Vy,Oy,e),yi(Vy,Oy,"esm2020")})();const yP={apiKey:"AIzaSyCjC2FETl-H_Cq07Ql8Cx2h8KYOh9T-GjM",authDomain:"landvms.firebaseapp.com",projectId:"landvms",storageBucket:"landvms.firebasestorage.app",messagingSenderId:"750813754088",appId:"1:750813754088:web:016b3f063f9a5d98df8f5d",measurementId:"G-PHR8DJEBFG"},cE=Qy(yP),go=US(cE),ja=GC(cE);function _P(){const[r,e]=Ue.useState(null),[t,s]=Ue.useState(!1),[o,l]=Ue.useState(!1),[h,m]=Ue.useState(!1);return Ue.useEffect(()=>{if(window.matchMedia("(display-mode: standalone)").matches||window.navigator.standalone===!0){m(!0);return}localStorage.getItem("pwa_install_dismissed");const E=window.navigator.userAgent,I=/iphone|ipad|ipod/i.test(E);if(l(I),I){s(!0);return}const C=z=>{z.preventDefault(),e(z),s(!0)};return window.addEventListener("beforeinstallprompt",C),window.addEventListener("appinstalled",()=>{s(!1),e(null)}),()=>window.removeEventListener("beforeinstallprompt",C)},[]),{showBanner:t,isIOS:o,isInstalled:h,install:async()=>{if(!r){alert(`To install the app: 
On Android: Tap the 3-dots Menu ⋮ and select "Install app". 
On iPhone: Tap Share ⬆ and select "Add to Home Screen".`);return}r.prompt();const{outcome:E}=await r.userChoice;E==="accepted"&&s(!1),e(null)},dismiss:()=>{s(!1),localStorage.setItem("pwa_install_dismissed",Date.now().toString())}}}function vP({isIOS:r,onInstall:e,onDismiss:t}){const[s,o]=Ue.useState(!1);return P.jsxs(P.Fragment,{children:[P.jsxs("div",{className:"install-banner glass-panel animate-slide-up",children:[P.jsx("div",{className:"install-banner-icon",children:"📱"}),P.jsxs("div",{className:"install-banner-text",children:[P.jsx("strong",{children:"Install LandVMS"}),P.jsx("span",{children:"Add to home screen for the best experience"})]}),P.jsxs("div",{className:"install-banner-actions",children:[r?P.jsx("button",{className:"btn-install",onClick:()=>o(!0),children:"How to Install"}):P.jsx("button",{className:"btn-install",onClick:e,children:"Install"}),P.jsx("button",{className:"btn-dismiss",onClick:t,children:"✕"})]})]}),s&&P.jsx("div",{className:"ios-modal-overlay",onClick:()=>o(!1),children:P.jsxs("div",{className:"ios-modal glass-panel",onClick:l=>l.stopPropagation(),children:[P.jsx("h3",{children:"Install on iPhone / iPad"}),P.jsxs("ol",{className:"ios-steps",children:[P.jsxs("li",{children:["Tap the ",P.jsx("strong",{children:"Share"})," button ",P.jsx("span",{className:"ios-icon",children:"⬆"})," at the bottom of Safari"]}),P.jsxs("li",{children:["Scroll down and tap ",P.jsx("strong",{children:'"Add to Home Screen"'})]}),P.jsxs("li",{children:["Tap ",P.jsx("strong",{children:'"Add"'})," in the top right"]})]}),P.jsx("button",{className:"btn-primary mt-md",style:{width:"100%"},onClick:()=>{o(!1),t()},children:"Got it!"})]})})]})}function EP(r,e,t){if(!("speechSynthesis"in window))return null;let s=!1,o=null;function l(g){try{const[_,E]=g.split(":").map(Number),I=_>=12?"PM":"AM";return`${_%12||12}:${E.toString().padStart(2,"0")} ${I}`}catch{return g}}const h=`Your meeting with ${r} is scheduled at ${l(e)} in ${t}`;function m(){if(s)return;const g=new SpeechSynthesisUtterance(h);g.rate=.9,g.pitch=1,g.volume=1,g.lang="en-US";const E=window.speechSynthesis.getVoices().find(I=>I.name.includes("Female")||I.name.includes("Zira")||I.name.includes("Samantha")||I.name.includes("Victoria")||I.name.includes("Google")&&I.name.includes("US English")||I.gender==="female");E&&(g.voice=E),g.onend=()=>{s||(o=setTimeout(m,5e3))},window.speechSynthesis.cancel(),window.speechSynthesis.speak(g)}return m(),{stop(){s=!0,clearTimeout(o),window.speechSynthesis.cancel()}}}function wP(){var D;const[r,e]=Ue.useState(null),[t,s]=Ue.useState("home"),[o,l]=Ue.useState([]),[h,m]=Ue.useState(null),g=Ue.useRef(new Set),[_,E]=Ue.useState(null),I=Ue.useRef(null),{showBanner:C,isIOS:z,isInstalled:G,install:Q,dismiss:B}=_P();Ue.useEffect(()=>{"Notification"in window&&Notification.permission!=="granted"&&Notification.requestPermission();const T=C0(go,N=>{N?e(N):(e(null),l([]))}),S=N=>{if(N.data&&N.data.type==="ALARM_CLICKED"){const k=N.data.visitId;window._pendingAlarmVisitId=k}};return"serviceWorker"in navigator&&navigator.serviceWorker.addEventListener("message",S),()=>{T(),"serviceWorker"in navigator&&navigator.serviceWorker.removeEventListener("message",S)}},[]),Ue.useEffect(()=>{if(!r)return;const T=uP(Xv(ja,"visits"),cP("userId","==",r.uid)),S=mP(T,N=>{const k=N.docs.map(V=>({id:V.id,...V.data()}));if(l(k),window._pendingAlarmVisitId){const V=k.find(A=>A.id===window._pendingAlarmVisitId);V&&(E(V),window._pendingAlarmVisitId=null)}navigator.serviceWorker&&navigator.serviceWorker.controller&&navigator.serviceWorker.controller.postMessage({type:"SYNC_VISITS",visits:k})},N=>{console.error("Firestore read error:",N),alert("Error reading appointments: "+N.message)});return()=>S()},[r]);const te=Ue.useCallback(async T=>{if(Hu.isNativePlatform())try{await Cu.requestPermissions();const S=new Date,k=T.filter(V=>V.status==="pending").map(V=>{const[A,Ie]=V.time.split(":").map(Number),[He,ut,Be]=V.date.split("-").map(Number),Z=new Date(He,ut-1,Be,A,Ie),ae=V.reminderMinutes||60,ee=new Date(Z.getTime()-ae*60*1e3);return ee>S?{title:`🚨 NOTIFY: ${V.customerName}`,body:`MEETING ALERT: Starting in ${V.reminderMinutes||60} minutes!`,id:Math.floor(Math.random()*1e6),schedule:{at:ee,allowWhileIdle:!0},sound:"alarm.wav",extra:{visitId:V.id}}:null}).filter(V=>V!==null);if(k.length>0){const V=await Cu.getPending();V.notifications.length>0&&await Cu.cancel({notifications:V.notifications}),await Cu.schedule({notifications:k})}}catch(S){console.error("Native Notification scheduling error:",S)}},[]);Ue.useEffect(()=>{o.length>0&&te(o)},[o,te]);const fe=async()=>{await P0(go),s("home"),g.current=new Set},Ee=T=>{m(T),s("edit_visit")},Ae=async T=>{if(window.confirm("Delete this appointment?"))try{await fP(cc(ja,"visits",T))}catch(S){console.error("Error deleting",S)}},De=async(T,S)=>{try{await uE(cc(ja,"visits",T),{status:S})}catch(N){console.error("Error updating",N)}};if(Ue.useEffect(()=>{_?I.current||(I.current=EP(_.customerName,_.time,_.location)):I.current&&(I.current.stop(),I.current=null)},[_]),Ue.useEffect(()=>{if(!r)return;const T=setInterval(()=>{const S=new Date,N=S.getFullYear(),k=String(S.getMonth()+1).padStart(2,"0"),V=String(S.getDate()).padStart(2,"0"),A=`${N}-${k}-${V}`;o.forEach(Ie=>{if(Ie.date===A&&Ie.status==="pending"){const[He,ut]=Ie.time.split(":").map(Number),Be=new Date;Be.setHours(He,ut,0,0);const Z=(Be-S)/(1e3*60),ae=Ie.reminderMinutes||60;Z>0&&Z<=ae&&!g.current.has(Ie.id)&&(E(Ie),g.current.add(Ie.id),Notification.permission==="granted"&&navigator.serviceWorker&&navigator.serviceWorker.ready.then(ee=>{const L=ae>=60?`${ae/60} hour${ae>60?"s":""}`:`${ae} minutes`;ee.showNotification(`🚨 NOTIFY: ${_.customerName}`,{body:`MEETING ALERT: Starting in ${L} at ${_.location}! TAP TO OPEN.`,icon:"/pwa-192x192.png",badge:"/pwa-192x192.png",tag:`alarm-${_.id}`,renotify:!0,requireInteraction:!0,vibrate:[1e3,500,1e3,500,1e3,500,1e3,500,1e3,500],data:{visitId:_.id},actions:[{action:"view",title:"Open & Speak Alarm",icon:"📢"},{action:"close",title:"I Got It",icon:"✅"}]})}))}})},3e4);return()=>clearInterval(T)},[o,r]),!r)return P.jsx(AP,{onInstall:Q,isInstalled:G,showBanner:C,isIOS:z,onDismissBanner:B});const Re=()=>{switch(t){case"home":return P.jsx(Fy,{visits:o,onUpdateStatus:De,onEditVisit:Ee,onDeleteVisit:Ae,username:r==null?void 0:r.email.split("@")[0]});case"visits":return P.jsx(TP,{visits:o,onUpdateStatus:De,onEditVisit:Ee,onDeleteVisit:Ae});case"customers":return P.jsx(IP,{visits:o});case"add_visit":return P.jsx(Uy,{onSave:()=>s("home")},"add");case"edit_visit":return P.jsx(Uy,{onSave:()=>{s("home"),m(null)},visitToEdit:o.find(T=>T.id===h)},`edit-${h}`);case"reports":return P.jsx(SP,{visits:o});default:return P.jsx(Fy,{visits:o,onUpdateStatus:De,onEditVisit:Ee,onDeleteVisit:Ae})}};return P.jsxs("div",{className:"app-container",children:[C&&P.jsx(vP,{isIOS:z,onInstall:Q,onDismiss:B}),P.jsxs("header",{className:"app-header glass-panel",children:[P.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"10px"},children:[P.jsx("img",{src:"/logo.png",alt:"Notify Logo",style:{width:"40px",height:"40px",borderRadius:"50%"}}),P.jsx("h1",{style:{margin:0},children:"Notify"})]}),P.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"10px"},children:[P.jsx("button",{onClick:fe,style:{background:"none",border:"1px solid var(--danger, #f87171)",borderRadius:"8px",color:"var(--danger, #f87171)",padding:"4px 10px",cursor:"pointer",fontSize:"0.8rem",fontWeight:"bold"},children:"Logout"}),P.jsx("div",{className:"user-avatar",title:r==null?void 0:r.email,children:P.jsx("span",{children:(D=r==null?void 0:r.email)==null?void 0:D.charAt(0).toUpperCase()})})]})]}),P.jsx("main",{className:"main-content animate-fade-in",children:Re()}),_&&(()=>{const T=_.reminderMinutes||60,S=T>=60?`${T/60} hour${T>60?"s":""}`:`${T} minutes`;return P.jsx("div",{className:"alarm-modal-overlay",children:P.jsxs("div",{className:"alarm-modal glass-panel animate-pulse-border",children:[P.jsx("h2",{children:"🚨 Upcoming Visit Alert 🚨"}),P.jsxs("p",{className:"alarm-time",children:["Starting in ",S,"!"]}),P.jsx("h3",{className:"customer-name",children:_.customerName}),P.jsxs("p",{className:"visit-location",children:["📍 ",_.location]}),P.jsxs("p",{className:"visit-time",children:["🕒 ",_.time]}),P.jsx("p",{className:"text-muted",style:{fontSize:"0.85rem",marginBottom:"8px"},children:"🔊 Speaking alarm. Please dismiss to stop."}),P.jsx("button",{className:"btn-primary mt-md",style:{width:"100%",cursor:"pointer",padding:"12px",fontSize:"1.1rem"},onClick:()=>{g.current.add(_.id),E(null)},children:"Dismiss Alarm"})]})})})(),P.jsxs("nav",{className:"bottom-nav glass-panel",children:[P.jsxs("button",{className:`nav-item ${t==="home"?"active":""}`,onClick:()=>s("home"),children:[P.jsx("span",{className:"icon",children:"🏠"}),P.jsx("span",{className:"label",children:"Home"})]}),P.jsxs("button",{className:`nav-item ${t==="visits"?"active":""}`,onClick:()=>s("visits"),children:[P.jsx("span",{className:"icon",children:"📅"}),P.jsx("span",{className:"label",children:"Visits"})]}),P.jsx("button",{className:"nav-fab",onClick:()=>s("add_visit"),children:P.jsx("span",{className:"icon",children:"+"})}),P.jsxs("button",{className:`nav-item ${t==="customers"?"active":""}`,onClick:()=>s("customers"),children:[P.jsx("span",{className:"icon",children:"👥"}),P.jsx("span",{className:"label",children:"Clients"})]}),P.jsxs("button",{className:`nav-item ${t==="reports"?"active":""}`,onClick:()=>s("reports"),children:[P.jsx("span",{className:"icon",children:"📊"}),P.jsx("span",{className:"label",children:"Reports"})]})]})]})}function Fy({visits:r,onUpdateStatus:e,onEditVisit:t,onDeleteVisit:s,username:o}){const[l,h]=Ue.useState(null),[m,g]=Ue.useState(!1),_=new Date,E=_.getFullYear(),I=String(_.getMonth()+1).padStart(2,"0"),C=String(_.getDate()).padStart(2,"0"),z=`${E}-${I}-${C}`,G=(r||[]).filter(te=>te.date===z),Q=G.filter(te=>te.status==="pending"),B=G.filter(te=>te.status==="completed");return P.jsxs("div",{className:"dashboard",children:[P.jsxs("h2",{className:"section-title",children:["Hello, ",o?o.charAt(0).toUpperCase()+o.slice(1):"there"," 👋"]}),P.jsx("p",{className:"section-subtitle",children:"Here's your schedule for today"}),P.jsxs("div",{className:"metrics-grid",children:[P.jsxs("div",{className:"metric-card glass-panel",onClick:()=>{const te=window.speechSynthesis,fe=new SpeechSynthesisUtterance("");fe.volume=0,te.speak(fe),alert("✅ NOTIFY CONNECTED: Alarms will now ring automatically!")},style:{cursor:"pointer",border:"1px solid #4ade80"},children:[P.jsx("div",{className:"metric-icon",children:"🚀"}),P.jsx("div",{className:"metric-value",style:{fontSize:"1.2rem",color:"#4ade80"},children:"CONNECT"}),P.jsx("div",{className:"metric-label",children:"Click Once to Enable Alarms"})]}),P.jsxs("div",{className:"metric-card glass-panel",children:[P.jsx("div",{className:"metric-icon pending",children:"⏳"}),P.jsx("div",{className:"metric-value",children:Q.length}),P.jsx("div",{className:"metric-label",children:"Pending Today"})]}),P.jsxs("div",{className:"metric-card glass-panel",children:[P.jsx("div",{className:"metric-icon completed",children:"✅"}),P.jsx("div",{className:"metric-value",children:B.length}),P.jsx("div",{className:"metric-label",children:"Completed"})]})]}),P.jsxs("div",{className:"upcoming-section",children:[P.jsx("div",{className:"flex-row justify-between items-center mb-sm",children:P.jsx("h3",{children:"Upcoming Visits"})}),P.jsx("div",{className:"visit-list",children:Q.length>0?Q.map(te=>P.jsxs("div",{className:"visit-card glass-panel",children:[P.jsxs("div",{className:"visit-header",children:[P.jsx("span",{className:"badge warning",children:"Upcoming"}),P.jsx("span",{className:"visit-time",children:te.time})]}),P.jsx("h4",{className:"customer-name",children:te.customerName}),P.jsxs("p",{className:"visit-location",children:["📍 ",te.location]}),P.jsx(hE,{location:te.location}),P.jsxs("div",{className:"visit-actions",children:[P.jsx("button",{className:"btn-icon",onClick:()=>t(te.id),title:"Edit",children:"✏️"}),P.jsx("button",{className:"btn-icon",onClick:()=>{te.phone&&(window.location.href=`tel:${te.phone.replace(/\D/g,"")}`)},title:"Call",children:"📞"}),P.jsx("button",{className:"btn-icon",onClick:()=>{const fe=`Hello ${te.customerName}! This is a reminder for our meeting today at ${te.time} at ${te.location}. See you there!`;window.open(`https://wa.me/${te.phone?te.phone.replace(/\D/g,""):""}?text=${encodeURIComponent(fe)}`,"_blank")},title:"WhatsApp",children:"💬"}),P.jsx("button",{className:"btn-primary small",onClick:()=>e(te.id,"completed"),children:"Complete"}),P.jsx("button",{className:"btn-icon btn-delete",onClick:()=>s(te.id),title:"Delete",children:"🗑️"})]})]},te.id)):P.jsx("div",{className:"empty-state glass-panel",children:P.jsx("p",{children:"No more visits scheduled for today."})})})]})]})}function TP({visits:r,onUpdateStatus:e,onEditVisit:t,onDeleteVisit:s}){return P.jsxs("div",{className:"visits-page",children:[P.jsx("h2",{children:"All Visits"}),P.jsxs("div",{className:"visit-list",children:[r.length===0&&P.jsx("div",{className:"empty-state glass-panel",children:P.jsx("p",{children:"No visits scheduled yet."})}),r.map(o=>P.jsxs("div",{className:"visit-card glass-panel",children:[P.jsxs("div",{className:"flex-row justify-between items-center mb-sm",children:[P.jsx("div",{className:"visit-header",style:{marginBottom:0},children:P.jsx("span",{className:`badge ${o.status==="completed"?"success":"warning"}`,children:o.status.charAt(0).toUpperCase()+o.status.slice(1)})}),P.jsxs("button",{className:`btn-text ${o.status==="pending"?"success-text":"warning-text"}`,onClick:()=>e(o.id,o.status==="pending"?"completed":"pending"),style:{fontSize:"0.8rem",cursor:"pointer",marginRight:"var(--spacing-sm)"},children:["Mark ",o.status==="pending"?"Completed":"Pending"]}),P.jsxs("div",{className:"flex-row gap-xs",style:{marginLeft:"auto"},children:[P.jsx("button",{className:"btn-icon",onClick:()=>{const l=`Hello ${o.customerName}! This is a reminder for our meeting on ${o.date} at ${o.time} at ${o.location}.`;window.open(`https://wa.me/${o.phone?o.phone.replace(/\D/g,""):""}?text=${encodeURIComponent(l)}`,"_blank")},title:"WhatsApp",children:"💬"}),P.jsx("button",{className:"btn-icon",onClick:()=>t(o.id),title:"Edit",children:"✏️"}),P.jsx("button",{className:"btn-icon btn-delete",onClick:()=>s(o.id),title:"Delete",children:"🗑️"})]})]}),P.jsxs("span",{className:"visit-time d-block mb-sm",children:[o.date," ",o.time]}),P.jsx("h4",{className:"customer-name",children:o.customerName}),P.jsxs("p",{className:"visit-location",children:["📍 ",o.location]}),P.jsx(hE,{location:o.location}),o.notes&&P.jsxs("p",{className:"text-muted mt-sm",style:{fontStyle:"italic",fontSize:"0.85rem"},children:['"',o.notes,'"']})]},o.id))]})]})}function IP({visits:r}){const[e,t]=Ue.useState(""),o=Array.from(new Set(r.map(l=>l.customerName))).map(l=>({name:l,visitsCount:r.filter(h=>h.customerName===l).length})).filter(l=>l.name.toLowerCase().includes(e.toLowerCase()));return P.jsxs("div",{className:"customers-page",children:[P.jsx("h2",{children:"Customers"}),P.jsx("div",{className:"search-bar mb-md mt-sm",children:P.jsx("input",{type:"text",className:"input-field",placeholder:"Search customers...",value:e,onChange:l=>t(l.target.value)})}),P.jsx("div",{className:"customer-list",children:o.length>0?o.map((l,h)=>P.jsx("div",{className:"customer-card glass-panel flex-row justify-between items-center",children:P.jsxs("div",{className:"flex-row items-center gap-md",children:[P.jsx("div",{className:"avatar",children:l.name.charAt(0)}),P.jsxs("div",{children:[P.jsx("h4",{children:l.name}),P.jsxs("p",{className:"text-muted",children:[l.visitsCount," visits"]})]})]})},h)):P.jsx("div",{className:"empty-state glass-panel",children:P.jsx("p",{children:"No customers found."})})})]})}function Uy({onSave:r,visitToEdit:e}){const[t,s]=Ue.useState({customerName:e?e.customerName:"",phone:e?e.phone:"",date:e?e.date:new Date().toISOString().split("T")[0],time:e?e.time:"10:00",location:e?e.location:"",notes:e?e.notes:"",reminderMinutes:e&&e.reminderMinutes||60}),[o,l]=Ue.useState(!1),[h,m]=Ue.useState(!1),g=async E=>{E.preventDefault(),m(!0);const I={...t,reminderMinutes:Number(t.reminderMinutes),userId:go.currentUser.uid,timestamp:sP()};try{e?await uE(cc(ja,"visits",e.id),I):await pP(Xv(ja,"visits"),{...I,status:"pending"}),r()}catch(C){console.error("Error saving visit",C),alert("Error saving: "+C.message+`

Make sure your Firestore Rules are set to 'allow read, write: if request.auth != null;'`)}finally{m(!1)}},_=()=>{if(!("webkitSpeechRecognition"in window)){alert("Speech recognition not supported.");return}const E=new window.webkitSpeechRecognition;E.onstart=()=>l(!0),E.onresult=I=>{const C=I.results[0][0].transcript;s({...t,notes:t.notes?t.notes+" "+C:C}),l(!1)},E.onerror=()=>l(!1),E.onend=()=>l(!1),E.start()};return P.jsxs("div",{className:"add-visit-page animate-fade-in",children:[P.jsxs("div",{className:"flex-row justify-between items-center mb-md",children:[P.jsx("h2",{children:e?"Edit Visit":"Schedule Visit"}),P.jsx("button",{className:"btn-text",onClick:r,children:"Cancel"})]}),P.jsxs("form",{className:"glass-panel form-container flex-col gap-md",onSubmit:g,children:[P.jsxs("div",{className:"input-group",children:[P.jsx("label",{children:"Customer Name"}),P.jsx("input",{type:"text",required:!0,placeholder:"E.g. John Doe",value:t.customerName,onChange:E=>s({...t,customerName:E.target.value}),className:"input-field"})]}),P.jsxs("div",{className:"input-group",children:[P.jsx("label",{children:"Phone Number"}),P.jsx("input",{type:"tel",placeholder:"+91 1234567890",value:t.phone,onChange:E=>s({...t,phone:E.target.value}),className:"input-field"})]}),P.jsxs("div",{className:"flex-row gap-md",children:[P.jsxs("div",{className:"input-group flex-1",children:[P.jsx("label",{children:"Date"}),P.jsx("input",{type:"date",required:!0,value:t.date,onChange:E=>s({...t,date:E.target.value}),className:"input-field"})]}),P.jsxs("div",{className:"input-group flex-1",children:[P.jsx("label",{children:"Time"}),P.jsx("input",{type:"time",required:!0,value:t.time,onChange:E=>s({...t,time:E.target.value}),className:"input-field"})]})]}),P.jsxs("div",{className:"input-group",children:[P.jsx("label",{children:"Location / Plot Details"}),P.jsx("input",{type:"text",placeholder:"Enter location",value:t.location,onChange:E=>s({...t,location:E.target.value}),className:"input-field"})]}),P.jsxs("div",{className:"input-group",children:[P.jsx("label",{children:"Notes (Voice Input Supported)"}),P.jsxs("div",{className:"textarea-wrapper",children:[P.jsx("textarea",{rows:"3",placeholder:"Add details...",value:t.notes,onChange:E=>s({...t,notes:E.target.value}),className:"input-field"}),P.jsx("button",{type:"button",className:`mic-btn ${o?"recording":""}`,onClick:_,children:"🎤"})]})]}),P.jsxs("div",{className:"reminder-row",children:[P.jsx("span",{className:"reminder-icon",children:"⏰"}),P.jsx("label",{children:"Remind me before"}),P.jsxs("select",{value:t.reminderMinutes,onChange:E=>s({...t,reminderMinutes:E.target.value}),children:[P.jsx("option",{value:15,children:"15 minutes before"}),P.jsx("option",{value:30,children:"30 minutes before"}),P.jsx("option",{value:60,children:"1 hour before"}),P.jsx("option",{value:120,children:"2 hours before"}),P.jsx("option",{value:180,children:"3 hours before"}),P.jsx("option",{value:240,children:"4 hours before"}),P.jsx("option",{value:300,children:"5 hours before"}),P.jsx("option",{value:360,children:"6 hours before"}),P.jsx("option",{value:420,children:"7 hours before"}),P.jsx("option",{value:480,children:"8 hours before"}),P.jsx("option",{value:1440,children:"1 day before"}),P.jsx("option",{value:2880,children:"2 days before"})]})]}),P.jsx("button",{type:"submit",className:"btn-primary mt-sm",disabled:h,children:h?"Saving...":e?"Save Changes":"Save Appointment"})]})]})}function SP({visits:r}){const e=new Date,t=e.getFullYear(),s=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0"),l=`${t}-${s}-${o}`,h=r.filter(m=>m.date===l);return r.filter(m=>m.status==="completed").length,P.jsxs("div",{className:"reports-page",children:[P.jsx("h2",{children:"Business Insights"}),P.jsxs("div",{className:"glass-panel mb-md p-md",children:[P.jsx("h3",{children:"Today's Performance"}),P.jsx("div",{className:"flex-row justify-between items-center mt-sm",children:P.jsxs("div",{className:"text-center flex-1",children:[P.jsx("div",{className:"metric-value",children:h.length}),P.jsx("div",{className:"text-muted",children:"Total Scheduled"})]})})]})]})}function AP({onInstall:r,isInstalled:e,showBanner:t,isIOS:s,onDismissBanner:o}){const[l,h]=Ue.useState("login"),[m,g]=Ue.useState(""),[_,E]=Ue.useState(""),[I,C]=Ue.useState(""),[z,G]=Ue.useState(""),Q=async B=>{B.preventDefault(),C(""),G("");try{l==="login"?await S0(go,m,_):l==="signup"?(await I0(go,m,_),G("Account created! Logging in...")):l==="forgot"&&(await T0(go,m),G(`Password reset instructions sent to ${m}`),setTimeout(()=>h("login"),3500))}catch(te){C(te.message)}};return P.jsxs("div",{className:"app-container",style:{justifyContent:"center",alignItems:"center",padding:"10px"},children:[t&&!e&&P.jsxs("div",{className:"glass-panel",style:{width:"100%",maxWidth:"400px",padding:"24px 16px",marginBottom:"20px",textAlign:"center"},onClick:r,children:[P.jsx("h3",{style:{color:"#fef08a"},children:"✨ INSTALL AS REAL APP"}),P.jsx("button",{className:"btn-primary",style:{width:"100%",marginTop:"10px"},children:"INSTALL NOW"})]}),P.jsxs("div",{className:"glass-panel animate-fade-in",style:{width:"100%",maxWidth:"400px",padding:"2rem"},children:[P.jsxs("div",{className:"text-center mb-xl",children:[P.jsx("div",{style:{width:"110px",height:"110px",borderRadius:"50%",margin:"0 auto 16px",overflow:"hidden",boxShadow:"0 8px 32px rgba(0,0,0,0.5), 0 0 0 3px rgba(255,255,255,0.15)",border:"2px solid rgba(255,255,255,0.2)"},children:P.jsx("img",{src:"/logo.png",alt:"Notify Logo",style:{width:"100%",height:"100%",objectFit:"cover"}})}),P.jsx("h1",{style:{fontSize:"2rem",letterSpacing:"2px",marginBottom:"4px"},children:"NOTIFY"}),P.jsx("p",{style:{fontSize:"0.75rem",letterSpacing:"2px",textTransform:"uppercase",opacity:.6},children:"ALERTS & NOTIFICATIONS"})]}),I&&P.jsx("div",{className:"badge warning",style:{display:"block",textAlign:"center",marginBottom:"1rem"},children:I}),z&&P.jsx("div",{className:"badge success",style:{display:"block",textAlign:"center",marginBottom:"1rem"},children:z}),P.jsxs("form",{onSubmit:Q,className:"flex-col gap-md",children:[P.jsxs("div",{className:"input-group",children:[P.jsx("label",{children:"Email Address"}),P.jsx("input",{type:"email",className:"input-field",placeholder:"your@email.com",value:m,onChange:B=>g(B.target.value),required:!0})]}),l!=="forgot"&&P.jsxs("div",{className:"input-group",children:[P.jsx("label",{children:"Password"}),P.jsx("input",{type:"password",className:"input-field",placeholder:"••••••••",value:_,onChange:B=>E(B.target.value),required:!0})]}),P.jsx("button",{type:"submit",className:"btn-primary mt-sm",style:{width:"100%"},children:l==="login"?"ACCESS APP":l==="signup"?"CREATE ACCOUNT":"SEND RESET LINK"}),P.jsx("div",{style:{textAlign:"center",marginTop:"1rem"},children:l==="login"?P.jsxs(P.Fragment,{children:[P.jsx("a",{href:"#",onClick:B=>{B.preventDefault(),h("signup")},style:{display:"block",marginBottom:"0.5rem"},children:"New user? Sign up"}),P.jsx("a",{href:"#",onClick:B=>{B.preventDefault(),h("forgot")},children:"Forgot password?"}),P.jsxs("div",{style:{borderTop:"1px solid rgba(255,255,255,0.1)",marginTop:"2rem",paddingTop:"2rem"},children:[P.jsx("p",{style:{color:"#aaa",fontSize:"0.8rem",marginBottom:"1rem"},children:"FOR NO-INTERRUPTION ALARMS:"}),P.jsx("a",{href:"/Notify_Android_App.zip",className:"btn-text",style:{display:"inline-block",padding:"12px 24px",border:"2px solid #4ade80",borderRadius:"40px",color:"#4ade80",fontWeight:"bold"},children:"📲 DOWNLOAD FOR ANDROID"})]})]}):P.jsx("a",{href:"#",onClick:B=>{B.preventDefault(),h("login")},children:"← Back to Login"})})]})]})]})}function hE({location:r}){return r?P.jsx("div",{className:"map-preview",style:{marginTop:"var(--spacing-xs)",marginBottom:"var(--spacing-sm)",borderRadius:"var(--border-radius-sm)",overflow:"hidden",height:"140px",border:"1px solid var(--glass-border)"},children:P.jsx("iframe",{width:"100%",height:"100%",frameBorder:"0",style:{border:0,filter:"invert(90%) hue-rotate(180deg) contrast(1.1) opacity(0.8)"},src:`https://maps.google.com/maps?q=${encodeURIComponent(r)}&t=&z=14&ie=UTF8&iwloc=&output=embed`,allowFullScreen:!0,title:`Map for ${r}`})}):null}Rw.createRoot(document.getElementById("root")).render(P.jsx(Ue.StrictMode,{children:P.jsx(wP,{})}));export{qd as W};
