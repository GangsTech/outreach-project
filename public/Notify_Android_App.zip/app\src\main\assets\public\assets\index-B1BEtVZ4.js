(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))s(o);new MutationObserver(o=>{for(const u of o)if(u.type==="childList")for(const h of u.addedNodes)h.tagName==="LINK"&&h.rel==="modulepreload"&&s(h)}).observe(document,{childList:!0,subtree:!0});function t(o){const u={};return o.integrity&&(u.integrity=o.integrity),o.referrerPolicy&&(u.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?u.credentials="include":o.crossOrigin==="anonymous"?u.credentials="omit":u.credentials="same-origin",u}function s(o){if(o.ep)return;o.ep=!0;const u=t(o);fetch(o.href,u)}})();var Xh={exports:{}},Ra={},Zh={exports:{}},Ie={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var zm;function ow(){if(zm)return Ie;zm=1;var r=Symbol.for("react.element"),e=Symbol.for("react.portal"),t=Symbol.for("react.fragment"),s=Symbol.for("react.strict_mode"),o=Symbol.for("react.profiler"),u=Symbol.for("react.provider"),h=Symbol.for("react.context"),m=Symbol.for("react.forward_ref"),g=Symbol.for("react.suspense"),_=Symbol.for("react.memo"),E=Symbol.for("react.lazy"),S=Symbol.iterator;function V(O){return O===null||typeof O!="object"?null:(O=S&&O[S]||O["@@iterator"],typeof O=="function"?O:null)}var z={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},Q=Object.assign,Y={};function H(O,q,Ee){this.props=O,this.context=q,this.refs=Y,this.updater=Ee||z}H.prototype.isReactComponent={},H.prototype.setState=function(O,q){if(typeof O!="object"&&typeof O!="function"&&O!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,O,q,"setState")},H.prototype.forceUpdate=function(O){this.updater.enqueueForceUpdate(this,O,"forceUpdate")};function ie(){}ie.prototype=H.prototype;function ge(O,q,Ee){this.props=O,this.context=q,this.refs=Y,this.updater=Ee||z}var Te=ge.prototype=new ie;Te.constructor=ge,Q(Te,H.prototype),Te.isPureReactComponent=!0;var De=Array.isArray,be=Object.prototype.hasOwnProperty,ke={current:null},C={key:!0,ref:!0,__self:!0,__source:!0};function T(O,q,Ee){var we,Se={},Ae=null,Fe=null;if(q!=null)for(we in q.ref!==void 0&&(Fe=q.ref),q.key!==void 0&&(Ae=""+q.key),q)be.call(q,we)&&!C.hasOwnProperty(we)&&(Se[we]=q[we]);var Ve=arguments.length-2;if(Ve===1)Se.children=Ee;else if(1<Ve){for(var He=Array(Ve),zt=0;zt<Ve;zt++)He[zt]=arguments[zt+2];Se.children=He}if(O&&O.defaultProps)for(we in Ve=O.defaultProps,Ve)Se[we]===void 0&&(Se[we]=Ve[we]);return{$$typeof:r,type:O,key:Ae,ref:Fe,props:Se,_owner:ke.current}}function R(O,q){return{$$typeof:r,type:O.type,key:q,ref:O.ref,props:O.props,_owner:O._owner}}function D(O){return typeof O=="object"&&O!==null&&O.$$typeof===r}function N(O){var q={"=":"=0",":":"=2"};return"$"+O.replace(/[=:]/g,function(Ee){return q[Ee]})}var L=/\/+/g;function A(O,q){return typeof O=="object"&&O!==null&&O.key!=null?N(""+O.key):q.toString(36)}function Be(O,q,Ee,we,Se){var Ae=typeof O;(Ae==="undefined"||Ae==="boolean")&&(O=null);var Fe=!1;if(O===null)Fe=!0;else switch(Ae){case"string":case"number":Fe=!0;break;case"object":switch(O.$$typeof){case r:case e:Fe=!0}}if(Fe)return Fe=O,Se=Se(Fe),O=we===""?"."+A(Fe,0):we,De(Se)?(Ee="",O!=null&&(Ee=O.replace(L,"$&/")+"/"),Be(Se,q,Ee,"",function(zt){return zt})):Se!=null&&(D(Se)&&(Se=R(Se,Ee+(!Se.key||Fe&&Fe.key===Se.key?"":(""+Se.key).replace(L,"$&/")+"/")+O)),q.push(Se)),1;if(Fe=0,we=we===""?".":we+":",De(O))for(var Ve=0;Ve<O.length;Ve++){Ae=O[Ve];var He=we+A(Ae,Ve);Fe+=Be(Ae,q,Ee,He,Se)}else if(He=V(O),typeof He=="function")for(O=He.call(O),Ve=0;!(Ae=O.next()).done;)Ae=Ae.value,He=we+A(Ae,Ve++),Fe+=Be(Ae,q,Ee,He,Se);else if(Ae==="object")throw q=String(O),Error("Objects are not valid as a React child (found: "+(q==="[object Object]"?"object with keys {"+Object.keys(O).join(", ")+"}":q)+"). If you meant to render a collection of children, use an array instead.");return Fe}function lt(O,q,Ee){if(O==null)return O;var we=[],Se=0;return Be(O,we,"","",function(Ae){return q.call(Ee,Ae,Se++)}),we}function gt(O){if(O._status===-1){var q=O._result;q=q(),q.then(function(Ee){(O._status===0||O._status===-1)&&(O._status=1,O._result=Ee)},function(Ee){(O._status===0||O._status===-1)&&(O._status=2,O._result=Ee)}),O._status===-1&&(O._status=0,O._result=q)}if(O._status===1)return O._result.default;throw O._result}var $e={current:null},X={transition:null},ue={ReactCurrentDispatcher:$e,ReactCurrentBatchConfig:X,ReactCurrentOwner:ke};function te(){throw Error("act(...) is not supported in production builds of React.")}return Ie.Children={map:lt,forEach:function(O,q,Ee){lt(O,function(){q.apply(this,arguments)},Ee)},count:function(O){var q=0;return lt(O,function(){q++}),q},toArray:function(O){return lt(O,function(q){return q})||[]},only:function(O){if(!D(O))throw Error("React.Children.only expected to receive a single React element child.");return O}},Ie.Component=H,Ie.Fragment=t,Ie.Profiler=o,Ie.PureComponent=ge,Ie.StrictMode=s,Ie.Suspense=g,Ie.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=ue,Ie.act=te,Ie.cloneElement=function(O,q,Ee){if(O==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+O+".");var we=Q({},O.props),Se=O.key,Ae=O.ref,Fe=O._owner;if(q!=null){if(q.ref!==void 0&&(Ae=q.ref,Fe=ke.current),q.key!==void 0&&(Se=""+q.key),O.type&&O.type.defaultProps)var Ve=O.type.defaultProps;for(He in q)be.call(q,He)&&!C.hasOwnProperty(He)&&(we[He]=q[He]===void 0&&Ve!==void 0?Ve[He]:q[He])}var He=arguments.length-2;if(He===1)we.children=Ee;else if(1<He){Ve=Array(He);for(var zt=0;zt<He;zt++)Ve[zt]=arguments[zt+2];we.children=Ve}return{$$typeof:r,type:O.type,key:Se,ref:Ae,props:we,_owner:Fe}},Ie.createContext=function(O){return O={$$typeof:h,_currentValue:O,_currentValue2:O,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},O.Provider={$$typeof:u,_context:O},O.Consumer=O},Ie.createElement=T,Ie.createFactory=function(O){var q=T.bind(null,O);return q.type=O,q},Ie.createRef=function(){return{current:null}},Ie.forwardRef=function(O){return{$$typeof:m,render:O}},Ie.isValidElement=D,Ie.lazy=function(O){return{$$typeof:E,_payload:{_status:-1,_result:O},_init:gt}},Ie.memo=function(O,q){return{$$typeof:_,type:O,compare:q===void 0?null:q}},Ie.startTransition=function(O){var q=X.transition;X.transition={};try{O()}finally{X.transition=q}},Ie.unstable_act=te,Ie.useCallback=function(O,q){return $e.current.useCallback(O,q)},Ie.useContext=function(O){return $e.current.useContext(O)},Ie.useDebugValue=function(){},Ie.useDeferredValue=function(O){return $e.current.useDeferredValue(O)},Ie.useEffect=function(O,q){return $e.current.useEffect(O,q)},Ie.useId=function(){return $e.current.useId()},Ie.useImperativeHandle=function(O,q,Ee){return $e.current.useImperativeHandle(O,q,Ee)},Ie.useInsertionEffect=function(O,q){return $e.current.useInsertionEffect(O,q)},Ie.useLayoutEffect=function(O,q){return $e.current.useLayoutEffect(O,q)},Ie.useMemo=function(O,q){return $e.current.useMemo(O,q)},Ie.useReducer=function(O,q,Ee){return $e.current.useReducer(O,q,Ee)},Ie.useRef=function(O){return $e.current.useRef(O)},Ie.useState=function(O){return $e.current.useState(O)},Ie.useSyncExternalStore=function(O,q,Ee){return $e.current.useSyncExternalStore(O,q,Ee)},Ie.useTransition=function(){return $e.current.useTransition()},Ie.version="18.3.1",Ie}var Bm;function jd(){return Bm||(Bm=1,Zh.exports=ow()),Zh.exports}/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var $m;function aw(){if($m)return Ra;$m=1;var r=jd(),e=Symbol.for("react.element"),t=Symbol.for("react.fragment"),s=Object.prototype.hasOwnProperty,o=r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,u={key:!0,ref:!0,__self:!0,__source:!0};function h(m,g,_){var E,S={},V=null,z=null;_!==void 0&&(V=""+_),g.key!==void 0&&(V=""+g.key),g.ref!==void 0&&(z=g.ref);for(E in g)s.call(g,E)&&!u.hasOwnProperty(E)&&(S[E]=g[E]);if(m&&m.defaultProps)for(E in g=m.defaultProps,g)S[E]===void 0&&(S[E]=g[E]);return{$$typeof:e,type:m,key:V,ref:z,props:S,_owner:o.current}}return Ra.Fragment=t,Ra.jsx=h,Ra.jsxs=h,Ra}var Hm;function lw(){return Hm||(Hm=1,Xh.exports=aw()),Xh.exports}var P=lw(),ze=jd(),Au={},ed={exports:{}},Qt={},td={exports:{}},nd={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var qm;function uw(){return qm||(qm=1,(function(r){function e(X,ue){var te=X.length;X.push(ue);e:for(;0<te;){var O=te-1>>>1,q=X[O];if(0<o(q,ue))X[O]=ue,X[te]=q,te=O;else break e}}function t(X){return X.length===0?null:X[0]}function s(X){if(X.length===0)return null;var ue=X[0],te=X.pop();if(te!==ue){X[0]=te;e:for(var O=0,q=X.length,Ee=q>>>1;O<Ee;){var we=2*(O+1)-1,Se=X[we],Ae=we+1,Fe=X[Ae];if(0>o(Se,te))Ae<q&&0>o(Fe,Se)?(X[O]=Fe,X[Ae]=te,O=Ae):(X[O]=Se,X[we]=te,O=we);else if(Ae<q&&0>o(Fe,te))X[O]=Fe,X[Ae]=te,O=Ae;else break e}}return ue}function o(X,ue){var te=X.sortIndex-ue.sortIndex;return te!==0?te:X.id-ue.id}if(typeof performance=="object"&&typeof performance.now=="function"){var u=performance;r.unstable_now=function(){return u.now()}}else{var h=Date,m=h.now();r.unstable_now=function(){return h.now()-m}}var g=[],_=[],E=1,S=null,V=3,z=!1,Q=!1,Y=!1,H=typeof setTimeout=="function"?setTimeout:null,ie=typeof clearTimeout=="function"?clearTimeout:null,ge=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function Te(X){for(var ue=t(_);ue!==null;){if(ue.callback===null)s(_);else if(ue.startTime<=X)s(_),ue.sortIndex=ue.expirationTime,e(g,ue);else break;ue=t(_)}}function De(X){if(Y=!1,Te(X),!Q)if(t(g)!==null)Q=!0,gt(be);else{var ue=t(_);ue!==null&&$e(De,ue.startTime-X)}}function be(X,ue){Q=!1,Y&&(Y=!1,ie(T),T=-1),z=!0;var te=V;try{for(Te(ue),S=t(g);S!==null&&(!(S.expirationTime>ue)||X&&!N());){var O=S.callback;if(typeof O=="function"){S.callback=null,V=S.priorityLevel;var q=O(S.expirationTime<=ue);ue=r.unstable_now(),typeof q=="function"?S.callback=q:S===t(g)&&s(g),Te(ue)}else s(g);S=t(g)}if(S!==null)var Ee=!0;else{var we=t(_);we!==null&&$e(De,we.startTime-ue),Ee=!1}return Ee}finally{S=null,V=te,z=!1}}var ke=!1,C=null,T=-1,R=5,D=-1;function N(){return!(r.unstable_now()-D<R)}function L(){if(C!==null){var X=r.unstable_now();D=X;var ue=!0;try{ue=C(!0,X)}finally{ue?A():(ke=!1,C=null)}}else ke=!1}var A;if(typeof ge=="function")A=function(){ge(L)};else if(typeof MessageChannel<"u"){var Be=new MessageChannel,lt=Be.port2;Be.port1.onmessage=L,A=function(){lt.postMessage(null)}}else A=function(){H(L,0)};function gt(X){C=X,ke||(ke=!0,A())}function $e(X,ue){T=H(function(){X(r.unstable_now())},ue)}r.unstable_IdlePriority=5,r.unstable_ImmediatePriority=1,r.unstable_LowPriority=4,r.unstable_NormalPriority=3,r.unstable_Profiling=null,r.unstable_UserBlockingPriority=2,r.unstable_cancelCallback=function(X){X.callback=null},r.unstable_continueExecution=function(){Q||z||(Q=!0,gt(be))},r.unstable_forceFrameRate=function(X){0>X||125<X?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):R=0<X?Math.floor(1e3/X):5},r.unstable_getCurrentPriorityLevel=function(){return V},r.unstable_getFirstCallbackNode=function(){return t(g)},r.unstable_next=function(X){switch(V){case 1:case 2:case 3:var ue=3;break;default:ue=V}var te=V;V=ue;try{return X()}finally{V=te}},r.unstable_pauseExecution=function(){},r.unstable_requestPaint=function(){},r.unstable_runWithPriority=function(X,ue){switch(X){case 1:case 2:case 3:case 4:case 5:break;default:X=3}var te=V;V=X;try{return ue()}finally{V=te}},r.unstable_scheduleCallback=function(X,ue,te){var O=r.unstable_now();switch(typeof te=="object"&&te!==null?(te=te.delay,te=typeof te=="number"&&0<te?O+te:O):te=O,X){case 1:var q=-1;break;case 2:q=250;break;case 5:q=1073741823;break;case 4:q=1e4;break;default:q=5e3}return q=te+q,X={id:E++,callback:ue,priorityLevel:X,startTime:te,expirationTime:q,sortIndex:-1},te>O?(X.sortIndex=te,e(_,X),t(g)===null&&X===t(_)&&(Y?(ie(T),T=-1):Y=!0,$e(De,te-O))):(X.sortIndex=q,e(g,X),Q||z||(Q=!0,gt(be))),X},r.unstable_shouldYield=N,r.unstable_wrapCallback=function(X){var ue=V;return function(){var te=V;V=ue;try{return X.apply(this,arguments)}finally{V=te}}}})(nd)),nd}var Wm;function cw(){return Wm||(Wm=1,td.exports=uw()),td.exports}/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Km;function hw(){if(Km)return Qt;Km=1;var r=jd(),e=cw();function t(n){for(var i="https://reactjs.org/docs/error-decoder.html?invariant="+n,a=1;a<arguments.length;a++)i+="&args[]="+encodeURIComponent(arguments[a]);return"Minified React error #"+n+"; visit "+i+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var s=new Set,o={};function u(n,i){h(n,i),h(n+"Capture",i)}function h(n,i){for(o[n]=i,n=0;n<i.length;n++)s.add(i[n])}var m=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),g=Object.prototype.hasOwnProperty,_=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,E={},S={};function V(n){return g.call(S,n)?!0:g.call(E,n)?!1:_.test(n)?S[n]=!0:(E[n]=!0,!1)}function z(n,i,a,c){if(a!==null&&a.type===0)return!1;switch(typeof i){case"function":case"symbol":return!0;case"boolean":return c?!1:a!==null?!a.acceptsBooleans:(n=n.toLowerCase().slice(0,5),n!=="data-"&&n!=="aria-");default:return!1}}function Q(n,i,a,c){if(i===null||typeof i>"u"||z(n,i,a,c))return!0;if(c)return!1;if(a!==null)switch(a.type){case 3:return!i;case 4:return i===!1;case 5:return isNaN(i);case 6:return isNaN(i)||1>i}return!1}function Y(n,i,a,c,d,f,v){this.acceptsBooleans=i===2||i===3||i===4,this.attributeName=c,this.attributeNamespace=d,this.mustUseProperty=a,this.propertyName=n,this.type=i,this.sanitizeURL=f,this.removeEmptyString=v}var H={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(n){H[n]=new Y(n,0,!1,n,null,!1,!1)}),[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(n){var i=n[0];H[i]=new Y(i,1,!1,n[1],null,!1,!1)}),["contentEditable","draggable","spellCheck","value"].forEach(function(n){H[n]=new Y(n,2,!1,n.toLowerCase(),null,!1,!1)}),["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(n){H[n]=new Y(n,2,!1,n,null,!1,!1)}),"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(n){H[n]=new Y(n,3,!1,n.toLowerCase(),null,!1,!1)}),["checked","multiple","muted","selected"].forEach(function(n){H[n]=new Y(n,3,!0,n,null,!1,!1)}),["capture","download"].forEach(function(n){H[n]=new Y(n,4,!1,n,null,!1,!1)}),["cols","rows","size","span"].forEach(function(n){H[n]=new Y(n,6,!1,n,null,!1,!1)}),["rowSpan","start"].forEach(function(n){H[n]=new Y(n,5,!1,n.toLowerCase(),null,!1,!1)});var ie=/[\-:]([a-z])/g;function ge(n){return n[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(n){var i=n.replace(ie,ge);H[i]=new Y(i,1,!1,n,null,!1,!1)}),"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(n){var i=n.replace(ie,ge);H[i]=new Y(i,1,!1,n,"http://www.w3.org/1999/xlink",!1,!1)}),["xml:base","xml:lang","xml:space"].forEach(function(n){var i=n.replace(ie,ge);H[i]=new Y(i,1,!1,n,"http://www.w3.org/XML/1998/namespace",!1,!1)}),["tabIndex","crossOrigin"].forEach(function(n){H[n]=new Y(n,1,!1,n.toLowerCase(),null,!1,!1)}),H.xlinkHref=new Y("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1),["src","href","action","formAction"].forEach(function(n){H[n]=new Y(n,1,!1,n.toLowerCase(),null,!0,!0)});function Te(n,i,a,c){var d=H.hasOwnProperty(i)?H[i]:null;(d!==null?d.type!==0:c||!(2<i.length)||i[0]!=="o"&&i[0]!=="O"||i[1]!=="n"&&i[1]!=="N")&&(Q(i,a,d,c)&&(a=null),c||d===null?V(i)&&(a===null?n.removeAttribute(i):n.setAttribute(i,""+a)):d.mustUseProperty?n[d.propertyName]=a===null?d.type===3?!1:"":a:(i=d.attributeName,c=d.attributeNamespace,a===null?n.removeAttribute(i):(d=d.type,a=d===3||d===4&&a===!0?"":""+a,c?n.setAttributeNS(c,i,a):n.setAttribute(i,a))))}var De=r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,be=Symbol.for("react.element"),ke=Symbol.for("react.portal"),C=Symbol.for("react.fragment"),T=Symbol.for("react.strict_mode"),R=Symbol.for("react.profiler"),D=Symbol.for("react.provider"),N=Symbol.for("react.context"),L=Symbol.for("react.forward_ref"),A=Symbol.for("react.suspense"),Be=Symbol.for("react.suspense_list"),lt=Symbol.for("react.memo"),gt=Symbol.for("react.lazy"),$e=Symbol.for("react.offscreen"),X=Symbol.iterator;function ue(n){return n===null||typeof n!="object"?null:(n=X&&n[X]||n["@@iterator"],typeof n=="function"?n:null)}var te=Object.assign,O;function q(n){if(O===void 0)try{throw Error()}catch(a){var i=a.stack.trim().match(/\n( *(at )?)/);O=i&&i[1]||""}return`
`+O+n}var Ee=!1;function we(n,i){if(!n||Ee)return"";Ee=!0;var a=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(i)if(i=function(){throw Error()},Object.defineProperty(i.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(i,[])}catch(U){var c=U}Reflect.construct(n,[],i)}else{try{i.call()}catch(U){c=U}n.call(i.prototype)}else{try{throw Error()}catch(U){c=U}n()}}catch(U){if(U&&c&&typeof U.stack=="string"){for(var d=U.stack.split(`
`),f=c.stack.split(`
`),v=d.length-1,I=f.length-1;1<=v&&0<=I&&d[v]!==f[I];)I--;for(;1<=v&&0<=I;v--,I--)if(d[v]!==f[I]){if(v!==1||I!==1)do if(v--,I--,0>I||d[v]!==f[I]){var k=`
`+d[v].replace(" at new "," at ");return n.displayName&&k.includes("<anonymous>")&&(k=k.replace("<anonymous>",n.displayName)),k}while(1<=v&&0<=I);break}}}finally{Ee=!1,Error.prepareStackTrace=a}return(n=n?n.displayName||n.name:"")?q(n):""}function Se(n){switch(n.tag){case 5:return q(n.type);case 16:return q("Lazy");case 13:return q("Suspense");case 19:return q("SuspenseList");case 0:case 2:case 15:return n=we(n.type,!1),n;case 11:return n=we(n.type.render,!1),n;case 1:return n=we(n.type,!0),n;default:return""}}function Ae(n){if(n==null)return null;if(typeof n=="function")return n.displayName||n.name||null;if(typeof n=="string")return n;switch(n){case C:return"Fragment";case ke:return"Portal";case R:return"Profiler";case T:return"StrictMode";case A:return"Suspense";case Be:return"SuspenseList"}if(typeof n=="object")switch(n.$$typeof){case N:return(n.displayName||"Context")+".Consumer";case D:return(n._context.displayName||"Context")+".Provider";case L:var i=n.render;return n=n.displayName,n||(n=i.displayName||i.name||"",n=n!==""?"ForwardRef("+n+")":"ForwardRef"),n;case lt:return i=n.displayName||null,i!==null?i:Ae(n.type)||"Memo";case gt:i=n._payload,n=n._init;try{return Ae(n(i))}catch{}}return null}function Fe(n){var i=n.type;switch(n.tag){case 24:return"Cache";case 9:return(i.displayName||"Context")+".Consumer";case 10:return(i._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return n=i.render,n=n.displayName||n.name||"",i.displayName||(n!==""?"ForwardRef("+n+")":"ForwardRef");case 7:return"Fragment";case 5:return i;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return Ae(i);case 8:return i===T?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof i=="function")return i.displayName||i.name||null;if(typeof i=="string")return i}return null}function Ve(n){switch(typeof n){case"boolean":case"number":case"string":case"undefined":return n;case"object":return n;default:return""}}function He(n){var i=n.type;return(n=n.nodeName)&&n.toLowerCase()==="input"&&(i==="checkbox"||i==="radio")}function zt(n){var i=He(n)?"checked":"value",a=Object.getOwnPropertyDescriptor(n.constructor.prototype,i),c=""+n[i];if(!n.hasOwnProperty(i)&&typeof a<"u"&&typeof a.get=="function"&&typeof a.set=="function"){var d=a.get,f=a.set;return Object.defineProperty(n,i,{configurable:!0,get:function(){return d.call(this)},set:function(v){c=""+v,f.call(this,v)}}),Object.defineProperty(n,i,{enumerable:a.enumerable}),{getValue:function(){return c},setValue:function(v){c=""+v},stopTracking:function(){n._valueTracker=null,delete n[i]}}}}function gs(n){n._valueTracker||(n._valueTracker=zt(n))}function Do(n){if(!n)return!1;var i=n._valueTracker;if(!i)return!0;var a=i.getValue(),c="";return n&&(c=He(n)?n.checked?"true":"false":n.value),n=c,n!==a?(i.setValue(n),!0):!1}function Vr(n){if(n=n||(typeof document<"u"?document:void 0),typeof n>"u")return null;try{return n.activeElement||n.body}catch{return n.body}}function ys(n,i){var a=i.checked;return te({},i,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:a??n._wrapperState.initialChecked})}function cl(n,i){var a=i.defaultValue==null?"":i.defaultValue,c=i.checked!=null?i.checked:i.defaultChecked;a=Ve(i.value!=null?i.value:a),n._wrapperState={initialChecked:c,initialValue:a,controlled:i.type==="checkbox"||i.type==="radio"?i.checked!=null:i.value!=null}}function _s(n,i){i=i.checked,i!=null&&Te(n,"checked",i,!1)}function Ni(n,i){_s(n,i);var a=Ve(i.value),c=i.type;if(a!=null)c==="number"?(a===0&&n.value===""||n.value!=a)&&(n.value=""+a):n.value!==""+a&&(n.value=""+a);else if(c==="submit"||c==="reset"){n.removeAttribute("value");return}i.hasOwnProperty("value")?ut(n,i.type,a):i.hasOwnProperty("defaultValue")&&ut(n,i.type,Ve(i.defaultValue)),i.checked==null&&i.defaultChecked!=null&&(n.defaultChecked=!!i.defaultChecked)}function Vo(n,i,a){if(i.hasOwnProperty("value")||i.hasOwnProperty("defaultValue")){var c=i.type;if(!(c!=="submit"&&c!=="reset"||i.value!==void 0&&i.value!==null))return;i=""+n._wrapperState.initialValue,a||i===n.value||(n.value=i),n.defaultValue=i}a=n.name,a!==""&&(n.name=""),n.defaultChecked=!!n._wrapperState.initialChecked,a!==""&&(n.name=a)}function ut(n,i,a){(i!=="number"||Vr(n.ownerDocument)!==n)&&(a==null?n.defaultValue=""+n._wrapperState.initialValue:n.defaultValue!==""+a&&(n.defaultValue=""+a))}var it=Array.isArray;function vn(n,i,a,c){if(n=n.options,i){i={};for(var d=0;d<a.length;d++)i["$"+a[d]]=!0;for(a=0;a<n.length;a++)d=i.hasOwnProperty("$"+n[a].value),n[a].selected!==d&&(n[a].selected=d),d&&c&&(n[a].defaultSelected=!0)}else{for(a=""+Ve(a),i=null,d=0;d<n.length;d++){if(n[d].value===a){n[d].selected=!0,c&&(n[d].defaultSelected=!0);return}i!==null||n[d].disabled||(i=n[d])}i!==null&&(i.selected=!0)}}function Oo(n,i){if(i.dangerouslySetInnerHTML!=null)throw Error(t(91));return te({},i,{value:void 0,defaultValue:void 0,children:""+n._wrapperState.initialValue})}function Lo(n,i){var a=i.value;if(a==null){if(a=i.children,i=i.defaultValue,a!=null){if(i!=null)throw Error(t(92));if(it(a)){if(1<a.length)throw Error(t(93));a=a[0]}i=a}i==null&&(i=""),a=i}n._wrapperState={initialValue:Ve(a)}}function hl(n,i){var a=Ve(i.value),c=Ve(i.defaultValue);a!=null&&(a=""+a,a!==n.value&&(n.value=a),i.defaultValue==null&&n.defaultValue!==a&&(n.defaultValue=a)),c!=null&&(n.defaultValue=""+c)}function Or(n){var i=n.textContent;i===n._wrapperState.initialValue&&i!==""&&i!==null&&(n.value=i)}function Mo(n){switch(n){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function vs(n,i){return n==null||n==="http://www.w3.org/1999/xhtml"?Mo(i):n==="http://www.w3.org/2000/svg"&&i==="foreignObject"?"http://www.w3.org/1999/xhtml":n}var Lr,dl=(function(n){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(i,a,c,d){MSApp.execUnsafeLocalFunction(function(){return n(i,a,c,d)})}:n})(function(n,i){if(n.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in n)n.innerHTML=i;else{for(Lr=Lr||document.createElement("div"),Lr.innerHTML="<svg>"+i.valueOf().toString()+"</svg>",i=Lr.firstChild;n.firstChild;)n.removeChild(n.firstChild);for(;i.firstChild;)n.appendChild(i.firstChild)}});function xi(n,i){if(i){var a=n.firstChild;if(a&&a===n.lastChild&&a.nodeType===3){a.nodeValue=i;return}}n.textContent=i}var Mr={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},fl=["Webkit","ms","Moz","O"];Object.keys(Mr).forEach(function(n){fl.forEach(function(i){i=i+n.charAt(0).toUpperCase()+n.substring(1),Mr[i]=Mr[n]})});function br(n,i,a){return i==null||typeof i=="boolean"||i===""?"":a||typeof i!="number"||i===0||Mr.hasOwnProperty(n)&&Mr[n]?(""+i).trim():i+"px"}function Es(n,i){n=n.style;for(var a in i)if(i.hasOwnProperty(a)){var c=a.indexOf("--")===0,d=br(a,i[a],c);a==="float"&&(a="cssFloat"),c?n.setProperty(a,d):n[a]=d}}var bo=te({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function En(n,i){if(i){if(bo[n]&&(i.children!=null||i.dangerouslySetInnerHTML!=null))throw Error(t(137,n));if(i.dangerouslySetInnerHTML!=null){if(i.children!=null)throw Error(t(60));if(typeof i.dangerouslySetInnerHTML!="object"||!("__html"in i.dangerouslySetInnerHTML))throw Error(t(61))}if(i.style!=null&&typeof i.style!="object")throw Error(t(62))}}function ws(n,i){if(n.indexOf("-")===-1)return typeof i.is=="string";switch(n){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Fr=null;function Ts(n){return n=n.target||n.srcElement||window,n.correspondingUseElement&&(n=n.correspondingUseElement),n.nodeType===3?n.parentNode:n}var sr=null,or=null,nt=null;function Fo(n){if(n=ha(n)){if(typeof sr!="function")throw Error(t(280));var i=n.stateNode;i&&(i=jl(i),sr(n.stateNode,n.type,i))}}function Ur(n){or?nt?nt.push(n):nt=[n]:or=n}function jr(){if(or){var n=or,i=nt;if(nt=or=null,Fo(n),i)for(n=0;n<i.length;n++)Fo(i[n])}}function pl(n,i){return n(i)}function ml(){}var On=!1;function gl(n,i,a){if(On)return n(i,a);On=!0;try{return pl(n,i,a)}finally{On=!1,(or!==null||nt!==null)&&(ml(),jr())}}function Di(n,i){var a=n.stateNode;if(a===null)return null;var c=jl(a);if(c===null)return null;a=c[i];e:switch(i){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(c=!c.disabled)||(n=n.type,c=!(n==="button"||n==="input"||n==="select"||n==="textarea")),n=!c;break e;default:n=!1}if(n)return null;if(a&&typeof a!="function")throw Error(t(231,i,typeof a));return a}var zr=!1;if(m)try{var Br={};Object.defineProperty(Br,"passive",{get:function(){zr=!0}}),window.addEventListener("test",Br,Br),window.removeEventListener("test",Br,Br)}catch{zr=!1}function yl(n,i,a,c,d,f,v,I,k){var U=Array.prototype.slice.call(arguments,3);try{i.apply(a,U)}catch(K){this.onError(K)}}var ar=!1,Ln=null,Is=!1,un=null,_l={onError:function(n){ar=!0,Ln=n}};function vl(n,i,a,c,d,f,v,I,k){ar=!1,Ln=null,yl.apply(_l,arguments)}function Uo(n,i,a,c,d,f,v,I,k){if(vl.apply(this,arguments),ar){if(ar){var U=Ln;ar=!1,Ln=null}else throw Error(t(198));Is||(Is=!0,un=U)}}function wn(n){var i=n,a=n;if(n.alternate)for(;i.return;)i=i.return;else{n=i;do i=n,(i.flags&4098)!==0&&(a=i.return),n=i.return;while(n)}return i.tag===3?a:null}function jo(n){if(n.tag===13){var i=n.memoizedState;if(i===null&&(n=n.alternate,n!==null&&(i=n.memoizedState)),i!==null)return i.dehydrated}return null}function El(n){if(wn(n)!==n)throw Error(t(188))}function wl(n){var i=n.alternate;if(!i){if(i=wn(n),i===null)throw Error(t(188));return i!==n?null:n}for(var a=n,c=i;;){var d=a.return;if(d===null)break;var f=d.alternate;if(f===null){if(c=d.return,c!==null){a=c;continue}break}if(d.child===f.child){for(f=d.child;f;){if(f===a)return El(d),n;if(f===c)return El(d),i;f=f.sibling}throw Error(t(188))}if(a.return!==c.return)a=d,c=f;else{for(var v=!1,I=d.child;I;){if(I===a){v=!0,a=d,c=f;break}if(I===c){v=!0,c=d,a=f;break}I=I.sibling}if(!v){for(I=f.child;I;){if(I===a){v=!0,a=f,c=d;break}if(I===c){v=!0,c=f,a=d;break}I=I.sibling}if(!v)throw Error(t(189))}}if(a.alternate!==c)throw Error(t(190))}if(a.tag!==3)throw Error(t(188));return a.stateNode.current===a?n:i}function Tl(n){return n=wl(n),n!==null?Vi(n):null}function Vi(n){if(n.tag===5||n.tag===6)return n;for(n=n.child;n!==null;){var i=Vi(n);if(i!==null)return i;n=n.sibling}return null}var zo=e.unstable_scheduleCallback,Ss=e.unstable_cancelCallback,Oi=e.unstable_shouldYield,lr=e.unstable_requestPaint,Ge=e.unstable_now,kc=e.unstable_getCurrentPriorityLevel,As=e.unstable_ImmediatePriority,Bo=e.unstable_UserBlockingPriority,Li=e.unstable_NormalPriority,$o=e.unstable_LowPriority,Rs=e.unstable_IdlePriority,Mi=null,Xt=null;function Il(n){if(Xt&&typeof Xt.onCommitFiberRoot=="function")try{Xt.onCommitFiberRoot(Mi,n,void 0,(n.current.flags&128)===128)}catch{}}var Zt=Math.clz32?Math.clz32:bi,Mn=Math.log,cn=Math.LN2;function bi(n){return n>>>=0,n===0?32:31-(Mn(n)/cn|0)|0}var bn=64,$r=4194304;function Me(n){switch(n&-n){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return n&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return n}}function ur(n,i){var a=n.pendingLanes;if(a===0)return 0;var c=0,d=n.suspendedLanes,f=n.pingedLanes,v=a&268435455;if(v!==0){var I=v&~d;I!==0?c=Me(I):(f&=v,f!==0&&(c=Me(f)))}else v=a&~d,v!==0?c=Me(v):f!==0&&(c=Me(f));if(c===0)return 0;if(i!==0&&i!==c&&(i&d)===0&&(d=c&-c,f=i&-i,d>=f||d===16&&(f&4194240)!==0))return i;if((c&4)!==0&&(c|=a&16),i=n.entangledLanes,i!==0)for(n=n.entanglements,i&=c;0<i;)a=31-Zt(i),d=1<<a,c|=n[a],i&=~d;return c}function Fi(n,i){switch(n){case 1:case 2:case 4:return i+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return i+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Ui(n,i){for(var a=n.suspendedLanes,c=n.pingedLanes,d=n.expirationTimes,f=n.pendingLanes;0<f;){var v=31-Zt(f),I=1<<v,k=d[v];k===-1?((I&a)===0||(I&c)!==0)&&(d[v]=Fi(I,i)):k<=i&&(n.expiredLanes|=I),f&=~I}}function Ho(n){return n=n.pendingLanes&-1073741825,n!==0?n:n&1073741824?1073741824:0}function qo(){var n=bn;return bn<<=1,(bn&4194240)===0&&(bn=64),n}function Wo(n){for(var i=[],a=0;31>a;a++)i.push(n);return i}function ji(n,i,a){n.pendingLanes|=i,i!==536870912&&(n.suspendedLanes=0,n.pingedLanes=0),n=n.eventTimes,i=31-Zt(i),n[i]=a}function Nc(n,i){var a=n.pendingLanes&~i;n.pendingLanes=i,n.suspendedLanes=0,n.pingedLanes=0,n.expiredLanes&=i,n.mutableReadLanes&=i,n.entangledLanes&=i,i=n.entanglements;var c=n.eventTimes;for(n=n.expirationTimes;0<a;){var d=31-Zt(a),f=1<<d;i[d]=0,c[d]=-1,n[d]=-1,a&=~f}}function Ko(n,i){var a=n.entangledLanes|=i;for(n=n.entanglements;a;){var c=31-Zt(a),d=1<<c;d&i|n[c]&i&&(n[c]|=i),a&=~d}}var Ne=0;function Fn(n){return n&=-n,1<n?4<n?(n&268435455)!==0?16:536870912:4:1}var Go,Cs,Qo,Yo,Jo,Un=!1,Ps=[],jn=null,zn=null,At=null,zi=new Map,cr=new Map,en=[],Sl="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function Hr(n,i){switch(n){case"focusin":case"focusout":jn=null;break;case"dragenter":case"dragleave":zn=null;break;case"mouseover":case"mouseout":At=null;break;case"pointerover":case"pointerout":zi.delete(i.pointerId);break;case"gotpointercapture":case"lostpointercapture":cr.delete(i.pointerId)}}function Tn(n,i,a,c,d,f){return n===null||n.nativeEvent!==f?(n={blockedOn:i,domEventName:a,eventSystemFlags:c,nativeEvent:f,targetContainers:[d]},i!==null&&(i=ha(i),i!==null&&Cs(i)),n):(n.eventSystemFlags|=c,i=n.targetContainers,d!==null&&i.indexOf(d)===-1&&i.push(d),n)}function Al(n,i,a,c,d){switch(i){case"focusin":return jn=Tn(jn,n,i,a,c,d),!0;case"dragenter":return zn=Tn(zn,n,i,a,c,d),!0;case"mouseover":return At=Tn(At,n,i,a,c,d),!0;case"pointerover":var f=d.pointerId;return zi.set(f,Tn(zi.get(f)||null,n,i,a,c,d)),!0;case"gotpointercapture":return f=d.pointerId,cr.set(f,Tn(cr.get(f)||null,n,i,a,c,d)),!0}return!1}function ks(n){var i=qi(n.target);if(i!==null){var a=wn(i);if(a!==null){if(i=a.tag,i===13){if(i=jo(a),i!==null){n.blockedOn=i,Jo(n.priority,function(){Qo(a)});return}}else if(i===3&&a.stateNode.current.memoizedState.isDehydrated){n.blockedOn=a.tag===3?a.stateNode.containerInfo:null;return}}}n.blockedOn=null}function qe(n){if(n.blockedOn!==null)return!1;for(var i=n.targetContainers;0<i.length;){var a=Ns(n.domEventName,n.eventSystemFlags,i[0],n.nativeEvent);if(a===null){a=n.nativeEvent;var c=new a.constructor(a.type,a);Fr=c,a.target.dispatchEvent(c),Fr=null}else return i=ha(a),i!==null&&Cs(i),n.blockedOn=a,!1;i.shift()}return!0}function Rl(n,i,a){qe(n)&&a.delete(i)}function xc(){Un=!1,jn!==null&&qe(jn)&&(jn=null),zn!==null&&qe(zn)&&(zn=null),At!==null&&qe(At)&&(At=null),zi.forEach(Rl),cr.forEach(Rl)}function qr(n,i){n.blockedOn===i&&(n.blockedOn=null,Un||(Un=!0,e.unstable_scheduleCallback(e.unstable_NormalPriority,xc)))}function Wr(n){function i(d){return qr(d,n)}if(0<Ps.length){qr(Ps[0],n);for(var a=1;a<Ps.length;a++){var c=Ps[a];c.blockedOn===n&&(c.blockedOn=null)}}for(jn!==null&&qr(jn,n),zn!==null&&qr(zn,n),At!==null&&qr(At,n),zi.forEach(i),cr.forEach(i),a=0;a<en.length;a++)c=en[a],c.blockedOn===n&&(c.blockedOn=null);for(;0<en.length&&(a=en[0],a.blockedOn===null);)ks(a),a.blockedOn===null&&en.shift()}var hr=De.ReactCurrentBatchConfig,dr=!0;function Bn(n,i,a,c){var d=Ne,f=hr.transition;hr.transition=null;try{Ne=1,Xo(n,i,a,c)}finally{Ne=d,hr.transition=f}}function Cl(n,i,a,c){var d=Ne,f=hr.transition;hr.transition=null;try{Ne=4,Xo(n,i,a,c)}finally{Ne=d,hr.transition=f}}function Xo(n,i,a,c){if(dr){var d=Ns(n,i,a,c);if(d===null)Bc(n,i,c,$n,a),Hr(n,c);else if(Al(d,n,i,a,c))c.stopPropagation();else if(Hr(n,c),i&4&&-1<Sl.indexOf(n)){for(;d!==null;){var f=ha(d);if(f!==null&&Go(f),f=Ns(n,i,a,c),f===null&&Bc(n,i,c,$n,a),f===d)break;d=f}d!==null&&c.stopPropagation()}else Bc(n,i,c,null,a)}}var $n=null;function Ns(n,i,a,c){if($n=null,n=Ts(c),n=qi(n),n!==null)if(i=wn(n),i===null)n=null;else if(a=i.tag,a===13){if(n=jo(i),n!==null)return n;n=null}else if(a===3){if(i.stateNode.current.memoizedState.isDehydrated)return i.tag===3?i.stateNode.containerInfo:null;n=null}else i!==n&&(n=null);return $n=n,null}function xs(n){switch(n){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(kc()){case As:return 1;case Bo:return 4;case Li:case $o:return 16;case Rs:return 536870912;default:return 16}default:return 16}}var tn=null,Ds=null,fr=null;function Pl(){if(fr)return fr;var n,i=Ds,a=i.length,c,d="value"in tn?tn.value:tn.textContent,f=d.length;for(n=0;n<a&&i[n]===d[n];n++);var v=a-n;for(c=1;c<=v&&i[a-c]===d[f-c];c++);return fr=d.slice(n,1<c?1-c:void 0)}function Bi(n){var i=n.keyCode;return"charCode"in n?(n=n.charCode,n===0&&i===13&&(n=13)):n=i,n===10&&(n=13),32<=n||n===13?n:0}function Hn(){return!0}function Zo(){return!1}function Dt(n){function i(a,c,d,f,v){this._reactName=a,this._targetInst=d,this.type=c,this.nativeEvent=f,this.target=v,this.currentTarget=null;for(var I in n)n.hasOwnProperty(I)&&(a=n[I],this[I]=a?a(f):f[I]);return this.isDefaultPrevented=(f.defaultPrevented!=null?f.defaultPrevented:f.returnValue===!1)?Hn:Zo,this.isPropagationStopped=Zo,this}return te(i.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():typeof a.returnValue!="unknown"&&(a.returnValue=!1),this.isDefaultPrevented=Hn)},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():typeof a.cancelBubble!="unknown"&&(a.cancelBubble=!0),this.isPropagationStopped=Hn)},persist:function(){},isPersistent:Hn}),i}var qn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(n){return n.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},$i=Dt(qn),Kr=te({},qn,{view:0,detail:0}),Vs=Dt(Kr),Os,Ls,nn,Hi=te({},Kr,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:_e,button:0,buttons:0,relatedTarget:function(n){return n.relatedTarget===void 0?n.fromElement===n.srcElement?n.toElement:n.fromElement:n.relatedTarget},movementX:function(n){return"movementX"in n?n.movementX:(n!==nn&&(nn&&n.type==="mousemove"?(Os=n.screenX-nn.screenX,Ls=n.screenY-nn.screenY):Ls=Os=0,nn=n),Os)},movementY:function(n){return"movementY"in n?n.movementY:Ls}}),ea=Dt(Hi),kl=te({},Hi,{dataTransfer:0}),Nl=Dt(kl),Ms=te({},Kr,{relatedTarget:0}),Rt=Dt(Ms),xl=te({},qn,{animationName:0,elapsedTime:0,pseudoElement:0}),Dl=Dt(xl),Gr=te({},qn,{clipboardData:function(n){return"clipboardData"in n?n.clipboardData:window.clipboardData}}),l=Dt(Gr),p=te({},qn,{data:0}),y=Dt(p),w={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},b={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},j={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Z(n){var i=this.nativeEvent;return i.getModifierState?i.getModifierState(n):(n=j[n])?!!i[n]:!1}function _e(){return Z}var st=te({},Kr,{key:function(n){if(n.key){var i=w[n.key]||n.key;if(i!=="Unidentified")return i}return n.type==="keypress"?(n=Bi(n),n===13?"Enter":String.fromCharCode(n)):n.type==="keydown"||n.type==="keyup"?b[n.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:_e,charCode:function(n){return n.type==="keypress"?Bi(n):0},keyCode:function(n){return n.type==="keydown"||n.type==="keyup"?n.keyCode:0},which:function(n){return n.type==="keypress"?Bi(n):n.type==="keydown"||n.type==="keyup"?n.keyCode:0}}),je=Dt(st),ct=te({},Hi,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),rn=Dt(ct),pr=te({},Kr,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:_e}),Wn=Dt(pr),Kn=te({},qn,{propertyName:0,elapsedTime:0,pseudoElement:0}),bs=Dt(Kn),ta=te({},Hi,{deltaX:function(n){return"deltaX"in n?n.deltaX:"wheelDeltaX"in n?-n.wheelDeltaX:0},deltaY:function(n){return"deltaY"in n?n.deltaY:"wheelDeltaY"in n?-n.wheelDeltaY:"wheelDelta"in n?-n.wheelDelta:0},deltaZ:0,deltaMode:0}),eE=Dt(ta),tE=[9,13,27,32],Dc=m&&"CompositionEvent"in window,na=null;m&&"documentMode"in document&&(na=document.documentMode);var nE=m&&"TextEvent"in window&&!na,Vf=m&&(!Dc||na&&8<na&&11>=na),Of=" ",Lf=!1;function Mf(n,i){switch(n){case"keyup":return tE.indexOf(i.keyCode)!==-1;case"keydown":return i.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function bf(n){return n=n.detail,typeof n=="object"&&"data"in n?n.data:null}var Fs=!1;function rE(n,i){switch(n){case"compositionend":return bf(i);case"keypress":return i.which!==32?null:(Lf=!0,Of);case"textInput":return n=i.data,n===Of&&Lf?null:n;default:return null}}function iE(n,i){if(Fs)return n==="compositionend"||!Dc&&Mf(n,i)?(n=Pl(),fr=Ds=tn=null,Fs=!1,n):null;switch(n){case"paste":return null;case"keypress":if(!(i.ctrlKey||i.altKey||i.metaKey)||i.ctrlKey&&i.altKey){if(i.char&&1<i.char.length)return i.char;if(i.which)return String.fromCharCode(i.which)}return null;case"compositionend":return Vf&&i.locale!=="ko"?null:i.data;default:return null}}var sE={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Ff(n){var i=n&&n.nodeName&&n.nodeName.toLowerCase();return i==="input"?!!sE[n.type]:i==="textarea"}function Uf(n,i,a,c){Ur(c),i=bl(i,"onChange"),0<i.length&&(a=new $i("onChange","change",null,a,c),n.push({event:a,listeners:i}))}var ra=null,ia=null;function oE(n){rp(n,0)}function Vl(n){var i=$s(n);if(Do(i))return n}function aE(n,i){if(n==="change")return i}var jf=!1;if(m){var Vc;if(m){var Oc="oninput"in document;if(!Oc){var zf=document.createElement("div");zf.setAttribute("oninput","return;"),Oc=typeof zf.oninput=="function"}Vc=Oc}else Vc=!1;jf=Vc&&(!document.documentMode||9<document.documentMode)}function Bf(){ra&&(ra.detachEvent("onpropertychange",$f),ia=ra=null)}function $f(n){if(n.propertyName==="value"&&Vl(ia)){var i=[];Uf(i,ia,n,Ts(n)),gl(oE,i)}}function lE(n,i,a){n==="focusin"?(Bf(),ra=i,ia=a,ra.attachEvent("onpropertychange",$f)):n==="focusout"&&Bf()}function uE(n){if(n==="selectionchange"||n==="keyup"||n==="keydown")return Vl(ia)}function cE(n,i){if(n==="click")return Vl(i)}function hE(n,i){if(n==="input"||n==="change")return Vl(i)}function dE(n,i){return n===i&&(n!==0||1/n===1/i)||n!==n&&i!==i}var In=typeof Object.is=="function"?Object.is:dE;function sa(n,i){if(In(n,i))return!0;if(typeof n!="object"||n===null||typeof i!="object"||i===null)return!1;var a=Object.keys(n),c=Object.keys(i);if(a.length!==c.length)return!1;for(c=0;c<a.length;c++){var d=a[c];if(!g.call(i,d)||!In(n[d],i[d]))return!1}return!0}function Hf(n){for(;n&&n.firstChild;)n=n.firstChild;return n}function qf(n,i){var a=Hf(n);n=0;for(var c;a;){if(a.nodeType===3){if(c=n+a.textContent.length,n<=i&&c>=i)return{node:a,offset:i-n};n=c}e:{for(;a;){if(a.nextSibling){a=a.nextSibling;break e}a=a.parentNode}a=void 0}a=Hf(a)}}function Wf(n,i){return n&&i?n===i?!0:n&&n.nodeType===3?!1:i&&i.nodeType===3?Wf(n,i.parentNode):"contains"in n?n.contains(i):n.compareDocumentPosition?!!(n.compareDocumentPosition(i)&16):!1:!1}function Kf(){for(var n=window,i=Vr();i instanceof n.HTMLIFrameElement;){try{var a=typeof i.contentWindow.location.href=="string"}catch{a=!1}if(a)n=i.contentWindow;else break;i=Vr(n.document)}return i}function Lc(n){var i=n&&n.nodeName&&n.nodeName.toLowerCase();return i&&(i==="input"&&(n.type==="text"||n.type==="search"||n.type==="tel"||n.type==="url"||n.type==="password")||i==="textarea"||n.contentEditable==="true")}function fE(n){var i=Kf(),a=n.focusedElem,c=n.selectionRange;if(i!==a&&a&&a.ownerDocument&&Wf(a.ownerDocument.documentElement,a)){if(c!==null&&Lc(a)){if(i=c.start,n=c.end,n===void 0&&(n=i),"selectionStart"in a)a.selectionStart=i,a.selectionEnd=Math.min(n,a.value.length);else if(n=(i=a.ownerDocument||document)&&i.defaultView||window,n.getSelection){n=n.getSelection();var d=a.textContent.length,f=Math.min(c.start,d);c=c.end===void 0?f:Math.min(c.end,d),!n.extend&&f>c&&(d=c,c=f,f=d),d=qf(a,f);var v=qf(a,c);d&&v&&(n.rangeCount!==1||n.anchorNode!==d.node||n.anchorOffset!==d.offset||n.focusNode!==v.node||n.focusOffset!==v.offset)&&(i=i.createRange(),i.setStart(d.node,d.offset),n.removeAllRanges(),f>c?(n.addRange(i),n.extend(v.node,v.offset)):(i.setEnd(v.node,v.offset),n.addRange(i)))}}for(i=[],n=a;n=n.parentNode;)n.nodeType===1&&i.push({element:n,left:n.scrollLeft,top:n.scrollTop});for(typeof a.focus=="function"&&a.focus(),a=0;a<i.length;a++)n=i[a],n.element.scrollLeft=n.left,n.element.scrollTop=n.top}}var pE=m&&"documentMode"in document&&11>=document.documentMode,Us=null,Mc=null,oa=null,bc=!1;function Gf(n,i,a){var c=a.window===a?a.document:a.nodeType===9?a:a.ownerDocument;bc||Us==null||Us!==Vr(c)||(c=Us,"selectionStart"in c&&Lc(c)?c={start:c.selectionStart,end:c.selectionEnd}:(c=(c.ownerDocument&&c.ownerDocument.defaultView||window).getSelection(),c={anchorNode:c.anchorNode,anchorOffset:c.anchorOffset,focusNode:c.focusNode,focusOffset:c.focusOffset}),oa&&sa(oa,c)||(oa=c,c=bl(Mc,"onSelect"),0<c.length&&(i=new $i("onSelect","select",null,i,a),n.push({event:i,listeners:c}),i.target=Us)))}function Ol(n,i){var a={};return a[n.toLowerCase()]=i.toLowerCase(),a["Webkit"+n]="webkit"+i,a["Moz"+n]="moz"+i,a}var js={animationend:Ol("Animation","AnimationEnd"),animationiteration:Ol("Animation","AnimationIteration"),animationstart:Ol("Animation","AnimationStart"),transitionend:Ol("Transition","TransitionEnd")},Fc={},Qf={};m&&(Qf=document.createElement("div").style,"AnimationEvent"in window||(delete js.animationend.animation,delete js.animationiteration.animation,delete js.animationstart.animation),"TransitionEvent"in window||delete js.transitionend.transition);function Ll(n){if(Fc[n])return Fc[n];if(!js[n])return n;var i=js[n],a;for(a in i)if(i.hasOwnProperty(a)&&a in Qf)return Fc[n]=i[a];return n}var Yf=Ll("animationend"),Jf=Ll("animationiteration"),Xf=Ll("animationstart"),Zf=Ll("transitionend"),ep=new Map,tp="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function Qr(n,i){ep.set(n,i),u(i,[n])}for(var Uc=0;Uc<tp.length;Uc++){var jc=tp[Uc],mE=jc.toLowerCase(),gE=jc[0].toUpperCase()+jc.slice(1);Qr(mE,"on"+gE)}Qr(Yf,"onAnimationEnd"),Qr(Jf,"onAnimationIteration"),Qr(Xf,"onAnimationStart"),Qr("dblclick","onDoubleClick"),Qr("focusin","onFocus"),Qr("focusout","onBlur"),Qr(Zf,"onTransitionEnd"),h("onMouseEnter",["mouseout","mouseover"]),h("onMouseLeave",["mouseout","mouseover"]),h("onPointerEnter",["pointerout","pointerover"]),h("onPointerLeave",["pointerout","pointerover"]),u("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),u("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),u("onBeforeInput",["compositionend","keypress","textInput","paste"]),u("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),u("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),u("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var aa="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),yE=new Set("cancel close invalid load scroll toggle".split(" ").concat(aa));function np(n,i,a){var c=n.type||"unknown-event";n.currentTarget=a,Uo(c,i,void 0,n),n.currentTarget=null}function rp(n,i){i=(i&4)!==0;for(var a=0;a<n.length;a++){var c=n[a],d=c.event;c=c.listeners;e:{var f=void 0;if(i)for(var v=c.length-1;0<=v;v--){var I=c[v],k=I.instance,U=I.currentTarget;if(I=I.listener,k!==f&&d.isPropagationStopped())break e;np(d,I,U),f=k}else for(v=0;v<c.length;v++){if(I=c[v],k=I.instance,U=I.currentTarget,I=I.listener,k!==f&&d.isPropagationStopped())break e;np(d,I,U),f=k}}}if(Is)throw n=un,Is=!1,un=null,n}function Qe(n,i){var a=i[Gc];a===void 0&&(a=i[Gc]=new Set);var c=n+"__bubble";a.has(c)||(ip(i,n,2,!1),a.add(c))}function zc(n,i,a){var c=0;i&&(c|=4),ip(a,n,c,i)}var Ml="_reactListening"+Math.random().toString(36).slice(2);function la(n){if(!n[Ml]){n[Ml]=!0,s.forEach(function(a){a!=="selectionchange"&&(yE.has(a)||zc(a,!1,n),zc(a,!0,n))});var i=n.nodeType===9?n:n.ownerDocument;i===null||i[Ml]||(i[Ml]=!0,zc("selectionchange",!1,i))}}function ip(n,i,a,c){switch(xs(i)){case 1:var d=Bn;break;case 4:d=Cl;break;default:d=Xo}a=d.bind(null,i,a,n),d=void 0,!zr||i!=="touchstart"&&i!=="touchmove"&&i!=="wheel"||(d=!0),c?d!==void 0?n.addEventListener(i,a,{capture:!0,passive:d}):n.addEventListener(i,a,!0):d!==void 0?n.addEventListener(i,a,{passive:d}):n.addEventListener(i,a,!1)}function Bc(n,i,a,c,d){var f=c;if((i&1)===0&&(i&2)===0&&c!==null)e:for(;;){if(c===null)return;var v=c.tag;if(v===3||v===4){var I=c.stateNode.containerInfo;if(I===d||I.nodeType===8&&I.parentNode===d)break;if(v===4)for(v=c.return;v!==null;){var k=v.tag;if((k===3||k===4)&&(k=v.stateNode.containerInfo,k===d||k.nodeType===8&&k.parentNode===d))return;v=v.return}for(;I!==null;){if(v=qi(I),v===null)return;if(k=v.tag,k===5||k===6){c=f=v;continue e}I=I.parentNode}}c=c.return}gl(function(){var U=f,K=Ts(a),G=[];e:{var W=ep.get(n);if(W!==void 0){var ee=$i,oe=n;switch(n){case"keypress":if(Bi(a)===0)break e;case"keydown":case"keyup":ee=je;break;case"focusin":oe="focus",ee=Rt;break;case"focusout":oe="blur",ee=Rt;break;case"beforeblur":case"afterblur":ee=Rt;break;case"click":if(a.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":ee=ea;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":ee=Nl;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":ee=Wn;break;case Yf:case Jf:case Xf:ee=Dl;break;case Zf:ee=bs;break;case"scroll":ee=Vs;break;case"wheel":ee=eE;break;case"copy":case"cut":case"paste":ee=l;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":ee=rn}var ae=(i&4)!==0,ot=!ae&&n==="scroll",M=ae?W!==null?W+"Capture":null:W;ae=[];for(var x=U,F;x!==null;){F=x;var J=F.stateNode;if(F.tag===5&&J!==null&&(F=J,M!==null&&(J=Di(x,M),J!=null&&ae.push(ua(x,J,F)))),ot)break;x=x.return}0<ae.length&&(W=new ee(W,oe,null,a,K),G.push({event:W,listeners:ae}))}}if((i&7)===0){e:{if(W=n==="mouseover"||n==="pointerover",ee=n==="mouseout"||n==="pointerout",W&&a!==Fr&&(oe=a.relatedTarget||a.fromElement)&&(qi(oe)||oe[mr]))break e;if((ee||W)&&(W=K.window===K?K:(W=K.ownerDocument)?W.defaultView||W.parentWindow:window,ee?(oe=a.relatedTarget||a.toElement,ee=U,oe=oe?qi(oe):null,oe!==null&&(ot=wn(oe),oe!==ot||oe.tag!==5&&oe.tag!==6)&&(oe=null)):(ee=null,oe=U),ee!==oe)){if(ae=ea,J="onMouseLeave",M="onMouseEnter",x="mouse",(n==="pointerout"||n==="pointerover")&&(ae=rn,J="onPointerLeave",M="onPointerEnter",x="pointer"),ot=ee==null?W:$s(ee),F=oe==null?W:$s(oe),W=new ae(J,x+"leave",ee,a,K),W.target=ot,W.relatedTarget=F,J=null,qi(K)===U&&(ae=new ae(M,x+"enter",oe,a,K),ae.target=F,ae.relatedTarget=ot,J=ae),ot=J,ee&&oe)t:{for(ae=ee,M=oe,x=0,F=ae;F;F=zs(F))x++;for(F=0,J=M;J;J=zs(J))F++;for(;0<x-F;)ae=zs(ae),x--;for(;0<F-x;)M=zs(M),F--;for(;x--;){if(ae===M||M!==null&&ae===M.alternate)break t;ae=zs(ae),M=zs(M)}ae=null}else ae=null;ee!==null&&sp(G,W,ee,ae,!1),oe!==null&&ot!==null&&sp(G,ot,oe,ae,!0)}}e:{if(W=U?$s(U):window,ee=W.nodeName&&W.nodeName.toLowerCase(),ee==="select"||ee==="input"&&W.type==="file")var le=aE;else if(Ff(W))if(jf)le=hE;else{le=uE;var he=lE}else(ee=W.nodeName)&&ee.toLowerCase()==="input"&&(W.type==="checkbox"||W.type==="radio")&&(le=cE);if(le&&(le=le(n,U))){Uf(G,le,a,K);break e}he&&he(n,W,U),n==="focusout"&&(he=W._wrapperState)&&he.controlled&&W.type==="number"&&ut(W,"number",W.value)}switch(he=U?$s(U):window,n){case"focusin":(Ff(he)||he.contentEditable==="true")&&(Us=he,Mc=U,oa=null);break;case"focusout":oa=Mc=Us=null;break;case"mousedown":bc=!0;break;case"contextmenu":case"mouseup":case"dragend":bc=!1,Gf(G,a,K);break;case"selectionchange":if(pE)break;case"keydown":case"keyup":Gf(G,a,K)}var de;if(Dc)e:{switch(n){case"compositionstart":var me="onCompositionStart";break e;case"compositionend":me="onCompositionEnd";break e;case"compositionupdate":me="onCompositionUpdate";break e}me=void 0}else Fs?Mf(n,a)&&(me="onCompositionEnd"):n==="keydown"&&a.keyCode===229&&(me="onCompositionStart");me&&(Vf&&a.locale!=="ko"&&(Fs||me!=="onCompositionStart"?me==="onCompositionEnd"&&Fs&&(de=Pl()):(tn=K,Ds="value"in tn?tn.value:tn.textContent,Fs=!0)),he=bl(U,me),0<he.length&&(me=new y(me,n,null,a,K),G.push({event:me,listeners:he}),de?me.data=de:(de=bf(a),de!==null&&(me.data=de)))),(de=nE?rE(n,a):iE(n,a))&&(U=bl(U,"onBeforeInput"),0<U.length&&(K=new y("onBeforeInput","beforeinput",null,a,K),G.push({event:K,listeners:U}),K.data=de))}rp(G,i)})}function ua(n,i,a){return{instance:n,listener:i,currentTarget:a}}function bl(n,i){for(var a=i+"Capture",c=[];n!==null;){var d=n,f=d.stateNode;d.tag===5&&f!==null&&(d=f,f=Di(n,a),f!=null&&c.unshift(ua(n,f,d)),f=Di(n,i),f!=null&&c.push(ua(n,f,d))),n=n.return}return c}function zs(n){if(n===null)return null;do n=n.return;while(n&&n.tag!==5);return n||null}function sp(n,i,a,c,d){for(var f=i._reactName,v=[];a!==null&&a!==c;){var I=a,k=I.alternate,U=I.stateNode;if(k!==null&&k===c)break;I.tag===5&&U!==null&&(I=U,d?(k=Di(a,f),k!=null&&v.unshift(ua(a,k,I))):d||(k=Di(a,f),k!=null&&v.push(ua(a,k,I)))),a=a.return}v.length!==0&&n.push({event:i,listeners:v})}var _E=/\r\n?/g,vE=/\u0000|\uFFFD/g;function op(n){return(typeof n=="string"?n:""+n).replace(_E,`
`).replace(vE,"")}function Fl(n,i,a){if(i=op(i),op(n)!==i&&a)throw Error(t(425))}function Ul(){}var $c=null,Hc=null;function qc(n,i){return n==="textarea"||n==="noscript"||typeof i.children=="string"||typeof i.children=="number"||typeof i.dangerouslySetInnerHTML=="object"&&i.dangerouslySetInnerHTML!==null&&i.dangerouslySetInnerHTML.__html!=null}var Wc=typeof setTimeout=="function"?setTimeout:void 0,EE=typeof clearTimeout=="function"?clearTimeout:void 0,ap=typeof Promise=="function"?Promise:void 0,wE=typeof queueMicrotask=="function"?queueMicrotask:typeof ap<"u"?function(n){return ap.resolve(null).then(n).catch(TE)}:Wc;function TE(n){setTimeout(function(){throw n})}function Kc(n,i){var a=i,c=0;do{var d=a.nextSibling;if(n.removeChild(a),d&&d.nodeType===8)if(a=d.data,a==="/$"){if(c===0){n.removeChild(d),Wr(i);return}c--}else a!=="$"&&a!=="$?"&&a!=="$!"||c++;a=d}while(a);Wr(i)}function Yr(n){for(;n!=null;n=n.nextSibling){var i=n.nodeType;if(i===1||i===3)break;if(i===8){if(i=n.data,i==="$"||i==="$!"||i==="$?")break;if(i==="/$")return null}}return n}function lp(n){n=n.previousSibling;for(var i=0;n;){if(n.nodeType===8){var a=n.data;if(a==="$"||a==="$!"||a==="$?"){if(i===0)return n;i--}else a==="/$"&&i++}n=n.previousSibling}return null}var Bs=Math.random().toString(36).slice(2),Gn="__reactFiber$"+Bs,ca="__reactProps$"+Bs,mr="__reactContainer$"+Bs,Gc="__reactEvents$"+Bs,IE="__reactListeners$"+Bs,SE="__reactHandles$"+Bs;function qi(n){var i=n[Gn];if(i)return i;for(var a=n.parentNode;a;){if(i=a[mr]||a[Gn]){if(a=i.alternate,i.child!==null||a!==null&&a.child!==null)for(n=lp(n);n!==null;){if(a=n[Gn])return a;n=lp(n)}return i}n=a,a=n.parentNode}return null}function ha(n){return n=n[Gn]||n[mr],!n||n.tag!==5&&n.tag!==6&&n.tag!==13&&n.tag!==3?null:n}function $s(n){if(n.tag===5||n.tag===6)return n.stateNode;throw Error(t(33))}function jl(n){return n[ca]||null}var Qc=[],Hs=-1;function Jr(n){return{current:n}}function Ye(n){0>Hs||(n.current=Qc[Hs],Qc[Hs]=null,Hs--)}function We(n,i){Hs++,Qc[Hs]=n.current,n.current=i}var Xr={},Vt=Jr(Xr),Ht=Jr(!1),Wi=Xr;function qs(n,i){var a=n.type.contextTypes;if(!a)return Xr;var c=n.stateNode;if(c&&c.__reactInternalMemoizedUnmaskedChildContext===i)return c.__reactInternalMemoizedMaskedChildContext;var d={},f;for(f in a)d[f]=i[f];return c&&(n=n.stateNode,n.__reactInternalMemoizedUnmaskedChildContext=i,n.__reactInternalMemoizedMaskedChildContext=d),d}function qt(n){return n=n.childContextTypes,n!=null}function zl(){Ye(Ht),Ye(Vt)}function up(n,i,a){if(Vt.current!==Xr)throw Error(t(168));We(Vt,i),We(Ht,a)}function cp(n,i,a){var c=n.stateNode;if(i=i.childContextTypes,typeof c.getChildContext!="function")return a;c=c.getChildContext();for(var d in c)if(!(d in i))throw Error(t(108,Fe(n)||"Unknown",d));return te({},a,c)}function Bl(n){return n=(n=n.stateNode)&&n.__reactInternalMemoizedMergedChildContext||Xr,Wi=Vt.current,We(Vt,n),We(Ht,Ht.current),!0}function hp(n,i,a){var c=n.stateNode;if(!c)throw Error(t(169));a?(n=cp(n,i,Wi),c.__reactInternalMemoizedMergedChildContext=n,Ye(Ht),Ye(Vt),We(Vt,n)):Ye(Ht),We(Ht,a)}var gr=null,$l=!1,Yc=!1;function dp(n){gr===null?gr=[n]:gr.push(n)}function AE(n){$l=!0,dp(n)}function Zr(){if(!Yc&&gr!==null){Yc=!0;var n=0,i=Ne;try{var a=gr;for(Ne=1;n<a.length;n++){var c=a[n];do c=c(!0);while(c!==null)}gr=null,$l=!1}catch(d){throw gr!==null&&(gr=gr.slice(n+1)),zo(As,Zr),d}finally{Ne=i,Yc=!1}}return null}var Ws=[],Ks=0,Hl=null,ql=0,hn=[],dn=0,Ki=null,yr=1,_r="";function Gi(n,i){Ws[Ks++]=ql,Ws[Ks++]=Hl,Hl=n,ql=i}function fp(n,i,a){hn[dn++]=yr,hn[dn++]=_r,hn[dn++]=Ki,Ki=n;var c=yr;n=_r;var d=32-Zt(c)-1;c&=~(1<<d),a+=1;var f=32-Zt(i)+d;if(30<f){var v=d-d%5;f=(c&(1<<v)-1).toString(32),c>>=v,d-=v,yr=1<<32-Zt(i)+d|a<<d|c,_r=f+n}else yr=1<<f|a<<d|c,_r=n}function Jc(n){n.return!==null&&(Gi(n,1),fp(n,1,0))}function Xc(n){for(;n===Hl;)Hl=Ws[--Ks],Ws[Ks]=null,ql=Ws[--Ks],Ws[Ks]=null;for(;n===Ki;)Ki=hn[--dn],hn[dn]=null,_r=hn[--dn],hn[dn]=null,yr=hn[--dn],hn[dn]=null}var sn=null,on=null,Xe=!1,Sn=null;function pp(n,i){var a=gn(5,null,null,0);a.elementType="DELETED",a.stateNode=i,a.return=n,i=n.deletions,i===null?(n.deletions=[a],n.flags|=16):i.push(a)}function mp(n,i){switch(n.tag){case 5:var a=n.type;return i=i.nodeType!==1||a.toLowerCase()!==i.nodeName.toLowerCase()?null:i,i!==null?(n.stateNode=i,sn=n,on=Yr(i.firstChild),!0):!1;case 6:return i=n.pendingProps===""||i.nodeType!==3?null:i,i!==null?(n.stateNode=i,sn=n,on=null,!0):!1;case 13:return i=i.nodeType!==8?null:i,i!==null?(a=Ki!==null?{id:yr,overflow:_r}:null,n.memoizedState={dehydrated:i,treeContext:a,retryLane:1073741824},a=gn(18,null,null,0),a.stateNode=i,a.return=n,n.child=a,sn=n,on=null,!0):!1;default:return!1}}function Zc(n){return(n.mode&1)!==0&&(n.flags&128)===0}function eh(n){if(Xe){var i=on;if(i){var a=i;if(!mp(n,i)){if(Zc(n))throw Error(t(418));i=Yr(a.nextSibling);var c=sn;i&&mp(n,i)?pp(c,a):(n.flags=n.flags&-4097|2,Xe=!1,sn=n)}}else{if(Zc(n))throw Error(t(418));n.flags=n.flags&-4097|2,Xe=!1,sn=n}}}function gp(n){for(n=n.return;n!==null&&n.tag!==5&&n.tag!==3&&n.tag!==13;)n=n.return;sn=n}function Wl(n){if(n!==sn)return!1;if(!Xe)return gp(n),Xe=!0,!1;var i;if((i=n.tag!==3)&&!(i=n.tag!==5)&&(i=n.type,i=i!=="head"&&i!=="body"&&!qc(n.type,n.memoizedProps)),i&&(i=on)){if(Zc(n))throw yp(),Error(t(418));for(;i;)pp(n,i),i=Yr(i.nextSibling)}if(gp(n),n.tag===13){if(n=n.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(t(317));e:{for(n=n.nextSibling,i=0;n;){if(n.nodeType===8){var a=n.data;if(a==="/$"){if(i===0){on=Yr(n.nextSibling);break e}i--}else a!=="$"&&a!=="$!"&&a!=="$?"||i++}n=n.nextSibling}on=null}}else on=sn?Yr(n.stateNode.nextSibling):null;return!0}function yp(){for(var n=on;n;)n=Yr(n.nextSibling)}function Gs(){on=sn=null,Xe=!1}function th(n){Sn===null?Sn=[n]:Sn.push(n)}var RE=De.ReactCurrentBatchConfig;function da(n,i,a){if(n=a.ref,n!==null&&typeof n!="function"&&typeof n!="object"){if(a._owner){if(a=a._owner,a){if(a.tag!==1)throw Error(t(309));var c=a.stateNode}if(!c)throw Error(t(147,n));var d=c,f=""+n;return i!==null&&i.ref!==null&&typeof i.ref=="function"&&i.ref._stringRef===f?i.ref:(i=function(v){var I=d.refs;v===null?delete I[f]:I[f]=v},i._stringRef=f,i)}if(typeof n!="string")throw Error(t(284));if(!a._owner)throw Error(t(290,n))}return n}function Kl(n,i){throw n=Object.prototype.toString.call(i),Error(t(31,n==="[object Object]"?"object with keys {"+Object.keys(i).join(", ")+"}":n))}function _p(n){var i=n._init;return i(n._payload)}function vp(n){function i(M,x){if(n){var F=M.deletions;F===null?(M.deletions=[x],M.flags|=16):F.push(x)}}function a(M,x){if(!n)return null;for(;x!==null;)i(M,x),x=x.sibling;return null}function c(M,x){for(M=new Map;x!==null;)x.key!==null?M.set(x.key,x):M.set(x.index,x),x=x.sibling;return M}function d(M,x){return M=ai(M,x),M.index=0,M.sibling=null,M}function f(M,x,F){return M.index=F,n?(F=M.alternate,F!==null?(F=F.index,F<x?(M.flags|=2,x):F):(M.flags|=2,x)):(M.flags|=1048576,x)}function v(M){return n&&M.alternate===null&&(M.flags|=2),M}function I(M,x,F,J){return x===null||x.tag!==6?(x=Wh(F,M.mode,J),x.return=M,x):(x=d(x,F),x.return=M,x)}function k(M,x,F,J){var le=F.type;return le===C?K(M,x,F.props.children,J,F.key):x!==null&&(x.elementType===le||typeof le=="object"&&le!==null&&le.$$typeof===gt&&_p(le)===x.type)?(J=d(x,F.props),J.ref=da(M,x,F),J.return=M,J):(J=yu(F.type,F.key,F.props,null,M.mode,J),J.ref=da(M,x,F),J.return=M,J)}function U(M,x,F,J){return x===null||x.tag!==4||x.stateNode.containerInfo!==F.containerInfo||x.stateNode.implementation!==F.implementation?(x=Kh(F,M.mode,J),x.return=M,x):(x=d(x,F.children||[]),x.return=M,x)}function K(M,x,F,J,le){return x===null||x.tag!==7?(x=ns(F,M.mode,J,le),x.return=M,x):(x=d(x,F),x.return=M,x)}function G(M,x,F){if(typeof x=="string"&&x!==""||typeof x=="number")return x=Wh(""+x,M.mode,F),x.return=M,x;if(typeof x=="object"&&x!==null){switch(x.$$typeof){case be:return F=yu(x.type,x.key,x.props,null,M.mode,F),F.ref=da(M,null,x),F.return=M,F;case ke:return x=Kh(x,M.mode,F),x.return=M,x;case gt:var J=x._init;return G(M,J(x._payload),F)}if(it(x)||ue(x))return x=ns(x,M.mode,F,null),x.return=M,x;Kl(M,x)}return null}function W(M,x,F,J){var le=x!==null?x.key:null;if(typeof F=="string"&&F!==""||typeof F=="number")return le!==null?null:I(M,x,""+F,J);if(typeof F=="object"&&F!==null){switch(F.$$typeof){case be:return F.key===le?k(M,x,F,J):null;case ke:return F.key===le?U(M,x,F,J):null;case gt:return le=F._init,W(M,x,le(F._payload),J)}if(it(F)||ue(F))return le!==null?null:K(M,x,F,J,null);Kl(M,F)}return null}function ee(M,x,F,J,le){if(typeof J=="string"&&J!==""||typeof J=="number")return M=M.get(F)||null,I(x,M,""+J,le);if(typeof J=="object"&&J!==null){switch(J.$$typeof){case be:return M=M.get(J.key===null?F:J.key)||null,k(x,M,J,le);case ke:return M=M.get(J.key===null?F:J.key)||null,U(x,M,J,le);case gt:var he=J._init;return ee(M,x,F,he(J._payload),le)}if(it(J)||ue(J))return M=M.get(F)||null,K(x,M,J,le,null);Kl(x,J)}return null}function oe(M,x,F,J){for(var le=null,he=null,de=x,me=x=0,It=null;de!==null&&me<F.length;me++){de.index>me?(It=de,de=null):It=de.sibling;var Le=W(M,de,F[me],J);if(Le===null){de===null&&(de=It);break}n&&de&&Le.alternate===null&&i(M,de),x=f(Le,x,me),he===null?le=Le:he.sibling=Le,he=Le,de=It}if(me===F.length)return a(M,de),Xe&&Gi(M,me),le;if(de===null){for(;me<F.length;me++)de=G(M,F[me],J),de!==null&&(x=f(de,x,me),he===null?le=de:he.sibling=de,he=de);return Xe&&Gi(M,me),le}for(de=c(M,de);me<F.length;me++)It=ee(de,M,me,F[me],J),It!==null&&(n&&It.alternate!==null&&de.delete(It.key===null?me:It.key),x=f(It,x,me),he===null?le=It:he.sibling=It,he=It);return n&&de.forEach(function(li){return i(M,li)}),Xe&&Gi(M,me),le}function ae(M,x,F,J){var le=ue(F);if(typeof le!="function")throw Error(t(150));if(F=le.call(F),F==null)throw Error(t(151));for(var he=le=null,de=x,me=x=0,It=null,Le=F.next();de!==null&&!Le.done;me++,Le=F.next()){de.index>me?(It=de,de=null):It=de.sibling;var li=W(M,de,Le.value,J);if(li===null){de===null&&(de=It);break}n&&de&&li.alternate===null&&i(M,de),x=f(li,x,me),he===null?le=li:he.sibling=li,he=li,de=It}if(Le.done)return a(M,de),Xe&&Gi(M,me),le;if(de===null){for(;!Le.done;me++,Le=F.next())Le=G(M,Le.value,J),Le!==null&&(x=f(Le,x,me),he===null?le=Le:he.sibling=Le,he=Le);return Xe&&Gi(M,me),le}for(de=c(M,de);!Le.done;me++,Le=F.next())Le=ee(de,M,me,Le.value,J),Le!==null&&(n&&Le.alternate!==null&&de.delete(Le.key===null?me:Le.key),x=f(Le,x,me),he===null?le=Le:he.sibling=Le,he=Le);return n&&de.forEach(function(sw){return i(M,sw)}),Xe&&Gi(M,me),le}function ot(M,x,F,J){if(typeof F=="object"&&F!==null&&F.type===C&&F.key===null&&(F=F.props.children),typeof F=="object"&&F!==null){switch(F.$$typeof){case be:e:{for(var le=F.key,he=x;he!==null;){if(he.key===le){if(le=F.type,le===C){if(he.tag===7){a(M,he.sibling),x=d(he,F.props.children),x.return=M,M=x;break e}}else if(he.elementType===le||typeof le=="object"&&le!==null&&le.$$typeof===gt&&_p(le)===he.type){a(M,he.sibling),x=d(he,F.props),x.ref=da(M,he,F),x.return=M,M=x;break e}a(M,he);break}else i(M,he);he=he.sibling}F.type===C?(x=ns(F.props.children,M.mode,J,F.key),x.return=M,M=x):(J=yu(F.type,F.key,F.props,null,M.mode,J),J.ref=da(M,x,F),J.return=M,M=J)}return v(M);case ke:e:{for(he=F.key;x!==null;){if(x.key===he)if(x.tag===4&&x.stateNode.containerInfo===F.containerInfo&&x.stateNode.implementation===F.implementation){a(M,x.sibling),x=d(x,F.children||[]),x.return=M,M=x;break e}else{a(M,x);break}else i(M,x);x=x.sibling}x=Kh(F,M.mode,J),x.return=M,M=x}return v(M);case gt:return he=F._init,ot(M,x,he(F._payload),J)}if(it(F))return oe(M,x,F,J);if(ue(F))return ae(M,x,F,J);Kl(M,F)}return typeof F=="string"&&F!==""||typeof F=="number"?(F=""+F,x!==null&&x.tag===6?(a(M,x.sibling),x=d(x,F),x.return=M,M=x):(a(M,x),x=Wh(F,M.mode,J),x.return=M,M=x),v(M)):a(M,x)}return ot}var Qs=vp(!0),Ep=vp(!1),Gl=Jr(null),Ql=null,Ys=null,nh=null;function rh(){nh=Ys=Ql=null}function ih(n){var i=Gl.current;Ye(Gl),n._currentValue=i}function sh(n,i,a){for(;n!==null;){var c=n.alternate;if((n.childLanes&i)!==i?(n.childLanes|=i,c!==null&&(c.childLanes|=i)):c!==null&&(c.childLanes&i)!==i&&(c.childLanes|=i),n===a)break;n=n.return}}function Js(n,i){Ql=n,nh=Ys=null,n=n.dependencies,n!==null&&n.firstContext!==null&&((n.lanes&i)!==0&&(Wt=!0),n.firstContext=null)}function fn(n){var i=n._currentValue;if(nh!==n)if(n={context:n,memoizedValue:i,next:null},Ys===null){if(Ql===null)throw Error(t(308));Ys=n,Ql.dependencies={lanes:0,firstContext:n}}else Ys=Ys.next=n;return i}var Qi=null;function oh(n){Qi===null?Qi=[n]:Qi.push(n)}function wp(n,i,a,c){var d=i.interleaved;return d===null?(a.next=a,oh(i)):(a.next=d.next,d.next=a),i.interleaved=a,vr(n,c)}function vr(n,i){n.lanes|=i;var a=n.alternate;for(a!==null&&(a.lanes|=i),a=n,n=n.return;n!==null;)n.childLanes|=i,a=n.alternate,a!==null&&(a.childLanes|=i),a=n,n=n.return;return a.tag===3?a.stateNode:null}var ei=!1;function ah(n){n.updateQueue={baseState:n.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function Tp(n,i){n=n.updateQueue,i.updateQueue===n&&(i.updateQueue={baseState:n.baseState,firstBaseUpdate:n.firstBaseUpdate,lastBaseUpdate:n.lastBaseUpdate,shared:n.shared,effects:n.effects})}function Er(n,i){return{eventTime:n,lane:i,tag:0,payload:null,callback:null,next:null}}function ti(n,i,a){var c=n.updateQueue;if(c===null)return null;if(c=c.shared,(Oe&2)!==0){var d=c.pending;return d===null?i.next=i:(i.next=d.next,d.next=i),c.pending=i,vr(n,a)}return d=c.interleaved,d===null?(i.next=i,oh(c)):(i.next=d.next,d.next=i),c.interleaved=i,vr(n,a)}function Yl(n,i,a){if(i=i.updateQueue,i!==null&&(i=i.shared,(a&4194240)!==0)){var c=i.lanes;c&=n.pendingLanes,a|=c,i.lanes=a,Ko(n,a)}}function Ip(n,i){var a=n.updateQueue,c=n.alternate;if(c!==null&&(c=c.updateQueue,a===c)){var d=null,f=null;if(a=a.firstBaseUpdate,a!==null){do{var v={eventTime:a.eventTime,lane:a.lane,tag:a.tag,payload:a.payload,callback:a.callback,next:null};f===null?d=f=v:f=f.next=v,a=a.next}while(a!==null);f===null?d=f=i:f=f.next=i}else d=f=i;a={baseState:c.baseState,firstBaseUpdate:d,lastBaseUpdate:f,shared:c.shared,effects:c.effects},n.updateQueue=a;return}n=a.lastBaseUpdate,n===null?a.firstBaseUpdate=i:n.next=i,a.lastBaseUpdate=i}function Jl(n,i,a,c){var d=n.updateQueue;ei=!1;var f=d.firstBaseUpdate,v=d.lastBaseUpdate,I=d.shared.pending;if(I!==null){d.shared.pending=null;var k=I,U=k.next;k.next=null,v===null?f=U:v.next=U,v=k;var K=n.alternate;K!==null&&(K=K.updateQueue,I=K.lastBaseUpdate,I!==v&&(I===null?K.firstBaseUpdate=U:I.next=U,K.lastBaseUpdate=k))}if(f!==null){var G=d.baseState;v=0,K=U=k=null,I=f;do{var W=I.lane,ee=I.eventTime;if((c&W)===W){K!==null&&(K=K.next={eventTime:ee,lane:0,tag:I.tag,payload:I.payload,callback:I.callback,next:null});e:{var oe=n,ae=I;switch(W=i,ee=a,ae.tag){case 1:if(oe=ae.payload,typeof oe=="function"){G=oe.call(ee,G,W);break e}G=oe;break e;case 3:oe.flags=oe.flags&-65537|128;case 0:if(oe=ae.payload,W=typeof oe=="function"?oe.call(ee,G,W):oe,W==null)break e;G=te({},G,W);break e;case 2:ei=!0}}I.callback!==null&&I.lane!==0&&(n.flags|=64,W=d.effects,W===null?d.effects=[I]:W.push(I))}else ee={eventTime:ee,lane:W,tag:I.tag,payload:I.payload,callback:I.callback,next:null},K===null?(U=K=ee,k=G):K=K.next=ee,v|=W;if(I=I.next,I===null){if(I=d.shared.pending,I===null)break;W=I,I=W.next,W.next=null,d.lastBaseUpdate=W,d.shared.pending=null}}while(!0);if(K===null&&(k=G),d.baseState=k,d.firstBaseUpdate=U,d.lastBaseUpdate=K,i=d.shared.interleaved,i!==null){d=i;do v|=d.lane,d=d.next;while(d!==i)}else f===null&&(d.shared.lanes=0);Xi|=v,n.lanes=v,n.memoizedState=G}}function Sp(n,i,a){if(n=i.effects,i.effects=null,n!==null)for(i=0;i<n.length;i++){var c=n[i],d=c.callback;if(d!==null){if(c.callback=null,c=a,typeof d!="function")throw Error(t(191,d));d.call(c)}}}var fa={},Qn=Jr(fa),pa=Jr(fa),ma=Jr(fa);function Yi(n){if(n===fa)throw Error(t(174));return n}function lh(n,i){switch(We(ma,i),We(pa,n),We(Qn,fa),n=i.nodeType,n){case 9:case 11:i=(i=i.documentElement)?i.namespaceURI:vs(null,"");break;default:n=n===8?i.parentNode:i,i=n.namespaceURI||null,n=n.tagName,i=vs(i,n)}Ye(Qn),We(Qn,i)}function Xs(){Ye(Qn),Ye(pa),Ye(ma)}function Ap(n){Yi(ma.current);var i=Yi(Qn.current),a=vs(i,n.type);i!==a&&(We(pa,n),We(Qn,a))}function uh(n){pa.current===n&&(Ye(Qn),Ye(pa))}var Ze=Jr(0);function Xl(n){for(var i=n;i!==null;){if(i.tag===13){var a=i.memoizedState;if(a!==null&&(a=a.dehydrated,a===null||a.data==="$?"||a.data==="$!"))return i}else if(i.tag===19&&i.memoizedProps.revealOrder!==void 0){if((i.flags&128)!==0)return i}else if(i.child!==null){i.child.return=i,i=i.child;continue}if(i===n)break;for(;i.sibling===null;){if(i.return===null||i.return===n)return null;i=i.return}i.sibling.return=i.return,i=i.sibling}return null}var ch=[];function hh(){for(var n=0;n<ch.length;n++)ch[n]._workInProgressVersionPrimary=null;ch.length=0}var Zl=De.ReactCurrentDispatcher,dh=De.ReactCurrentBatchConfig,Ji=0,et=null,yt=null,wt=null,eu=!1,ga=!1,ya=0,CE=0;function Ot(){throw Error(t(321))}function fh(n,i){if(i===null)return!1;for(var a=0;a<i.length&&a<n.length;a++)if(!In(n[a],i[a]))return!1;return!0}function ph(n,i,a,c,d,f){if(Ji=f,et=i,i.memoizedState=null,i.updateQueue=null,i.lanes=0,Zl.current=n===null||n.memoizedState===null?xE:DE,n=a(c,d),ga){f=0;do{if(ga=!1,ya=0,25<=f)throw Error(t(301));f+=1,wt=yt=null,i.updateQueue=null,Zl.current=VE,n=a(c,d)}while(ga)}if(Zl.current=ru,i=yt!==null&&yt.next!==null,Ji=0,wt=yt=et=null,eu=!1,i)throw Error(t(300));return n}function mh(){var n=ya!==0;return ya=0,n}function Yn(){var n={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return wt===null?et.memoizedState=wt=n:wt=wt.next=n,wt}function pn(){if(yt===null){var n=et.alternate;n=n!==null?n.memoizedState:null}else n=yt.next;var i=wt===null?et.memoizedState:wt.next;if(i!==null)wt=i,yt=n;else{if(n===null)throw Error(t(310));yt=n,n={memoizedState:yt.memoizedState,baseState:yt.baseState,baseQueue:yt.baseQueue,queue:yt.queue,next:null},wt===null?et.memoizedState=wt=n:wt=wt.next=n}return wt}function _a(n,i){return typeof i=="function"?i(n):i}function gh(n){var i=pn(),a=i.queue;if(a===null)throw Error(t(311));a.lastRenderedReducer=n;var c=yt,d=c.baseQueue,f=a.pending;if(f!==null){if(d!==null){var v=d.next;d.next=f.next,f.next=v}c.baseQueue=d=f,a.pending=null}if(d!==null){f=d.next,c=c.baseState;var I=v=null,k=null,U=f;do{var K=U.lane;if((Ji&K)===K)k!==null&&(k=k.next={lane:0,action:U.action,hasEagerState:U.hasEagerState,eagerState:U.eagerState,next:null}),c=U.hasEagerState?U.eagerState:n(c,U.action);else{var G={lane:K,action:U.action,hasEagerState:U.hasEagerState,eagerState:U.eagerState,next:null};k===null?(I=k=G,v=c):k=k.next=G,et.lanes|=K,Xi|=K}U=U.next}while(U!==null&&U!==f);k===null?v=c:k.next=I,In(c,i.memoizedState)||(Wt=!0),i.memoizedState=c,i.baseState=v,i.baseQueue=k,a.lastRenderedState=c}if(n=a.interleaved,n!==null){d=n;do f=d.lane,et.lanes|=f,Xi|=f,d=d.next;while(d!==n)}else d===null&&(a.lanes=0);return[i.memoizedState,a.dispatch]}function yh(n){var i=pn(),a=i.queue;if(a===null)throw Error(t(311));a.lastRenderedReducer=n;var c=a.dispatch,d=a.pending,f=i.memoizedState;if(d!==null){a.pending=null;var v=d=d.next;do f=n(f,v.action),v=v.next;while(v!==d);In(f,i.memoizedState)||(Wt=!0),i.memoizedState=f,i.baseQueue===null&&(i.baseState=f),a.lastRenderedState=f}return[f,c]}function Rp(){}function Cp(n,i){var a=et,c=pn(),d=i(),f=!In(c.memoizedState,d);if(f&&(c.memoizedState=d,Wt=!0),c=c.queue,_h(Np.bind(null,a,c,n),[n]),c.getSnapshot!==i||f||wt!==null&&wt.memoizedState.tag&1){if(a.flags|=2048,va(9,kp.bind(null,a,c,d,i),void 0,null),Tt===null)throw Error(t(349));(Ji&30)!==0||Pp(a,i,d)}return d}function Pp(n,i,a){n.flags|=16384,n={getSnapshot:i,value:a},i=et.updateQueue,i===null?(i={lastEffect:null,stores:null},et.updateQueue=i,i.stores=[n]):(a=i.stores,a===null?i.stores=[n]:a.push(n))}function kp(n,i,a,c){i.value=a,i.getSnapshot=c,xp(i)&&Dp(n)}function Np(n,i,a){return a(function(){xp(i)&&Dp(n)})}function xp(n){var i=n.getSnapshot;n=n.value;try{var a=i();return!In(n,a)}catch{return!0}}function Dp(n){var i=vr(n,1);i!==null&&Pn(i,n,1,-1)}function Vp(n){var i=Yn();return typeof n=="function"&&(n=n()),i.memoizedState=i.baseState=n,n={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:_a,lastRenderedState:n},i.queue=n,n=n.dispatch=NE.bind(null,et,n),[i.memoizedState,n]}function va(n,i,a,c){return n={tag:n,create:i,destroy:a,deps:c,next:null},i=et.updateQueue,i===null?(i={lastEffect:null,stores:null},et.updateQueue=i,i.lastEffect=n.next=n):(a=i.lastEffect,a===null?i.lastEffect=n.next=n:(c=a.next,a.next=n,n.next=c,i.lastEffect=n)),n}function Op(){return pn().memoizedState}function tu(n,i,a,c){var d=Yn();et.flags|=n,d.memoizedState=va(1|i,a,void 0,c===void 0?null:c)}function nu(n,i,a,c){var d=pn();c=c===void 0?null:c;var f=void 0;if(yt!==null){var v=yt.memoizedState;if(f=v.destroy,c!==null&&fh(c,v.deps)){d.memoizedState=va(i,a,f,c);return}}et.flags|=n,d.memoizedState=va(1|i,a,f,c)}function Lp(n,i){return tu(8390656,8,n,i)}function _h(n,i){return nu(2048,8,n,i)}function Mp(n,i){return nu(4,2,n,i)}function bp(n,i){return nu(4,4,n,i)}function Fp(n,i){if(typeof i=="function")return n=n(),i(n),function(){i(null)};if(i!=null)return n=n(),i.current=n,function(){i.current=null}}function Up(n,i,a){return a=a!=null?a.concat([n]):null,nu(4,4,Fp.bind(null,i,n),a)}function vh(){}function jp(n,i){var a=pn();i=i===void 0?null:i;var c=a.memoizedState;return c!==null&&i!==null&&fh(i,c[1])?c[0]:(a.memoizedState=[n,i],n)}function zp(n,i){var a=pn();i=i===void 0?null:i;var c=a.memoizedState;return c!==null&&i!==null&&fh(i,c[1])?c[0]:(n=n(),a.memoizedState=[n,i],n)}function Bp(n,i,a){return(Ji&21)===0?(n.baseState&&(n.baseState=!1,Wt=!0),n.memoizedState=a):(In(a,i)||(a=qo(),et.lanes|=a,Xi|=a,n.baseState=!0),i)}function PE(n,i){var a=Ne;Ne=a!==0&&4>a?a:4,n(!0);var c=dh.transition;dh.transition={};try{n(!1),i()}finally{Ne=a,dh.transition=c}}function $p(){return pn().memoizedState}function kE(n,i,a){var c=si(n);if(a={lane:c,action:a,hasEagerState:!1,eagerState:null,next:null},Hp(n))qp(i,a);else if(a=wp(n,i,a,c),a!==null){var d=$t();Pn(a,n,c,d),Wp(a,i,c)}}function NE(n,i,a){var c=si(n),d={lane:c,action:a,hasEagerState:!1,eagerState:null,next:null};if(Hp(n))qp(i,d);else{var f=n.alternate;if(n.lanes===0&&(f===null||f.lanes===0)&&(f=i.lastRenderedReducer,f!==null))try{var v=i.lastRenderedState,I=f(v,a);if(d.hasEagerState=!0,d.eagerState=I,In(I,v)){var k=i.interleaved;k===null?(d.next=d,oh(i)):(d.next=k.next,k.next=d),i.interleaved=d;return}}catch{}finally{}a=wp(n,i,d,c),a!==null&&(d=$t(),Pn(a,n,c,d),Wp(a,i,c))}}function Hp(n){var i=n.alternate;return n===et||i!==null&&i===et}function qp(n,i){ga=eu=!0;var a=n.pending;a===null?i.next=i:(i.next=a.next,a.next=i),n.pending=i}function Wp(n,i,a){if((a&4194240)!==0){var c=i.lanes;c&=n.pendingLanes,a|=c,i.lanes=a,Ko(n,a)}}var ru={readContext:fn,useCallback:Ot,useContext:Ot,useEffect:Ot,useImperativeHandle:Ot,useInsertionEffect:Ot,useLayoutEffect:Ot,useMemo:Ot,useReducer:Ot,useRef:Ot,useState:Ot,useDebugValue:Ot,useDeferredValue:Ot,useTransition:Ot,useMutableSource:Ot,useSyncExternalStore:Ot,useId:Ot,unstable_isNewReconciler:!1},xE={readContext:fn,useCallback:function(n,i){return Yn().memoizedState=[n,i===void 0?null:i],n},useContext:fn,useEffect:Lp,useImperativeHandle:function(n,i,a){return a=a!=null?a.concat([n]):null,tu(4194308,4,Fp.bind(null,i,n),a)},useLayoutEffect:function(n,i){return tu(4194308,4,n,i)},useInsertionEffect:function(n,i){return tu(4,2,n,i)},useMemo:function(n,i){var a=Yn();return i=i===void 0?null:i,n=n(),a.memoizedState=[n,i],n},useReducer:function(n,i,a){var c=Yn();return i=a!==void 0?a(i):i,c.memoizedState=c.baseState=i,n={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:n,lastRenderedState:i},c.queue=n,n=n.dispatch=kE.bind(null,et,n),[c.memoizedState,n]},useRef:function(n){var i=Yn();return n={current:n},i.memoizedState=n},useState:Vp,useDebugValue:vh,useDeferredValue:function(n){return Yn().memoizedState=n},useTransition:function(){var n=Vp(!1),i=n[0];return n=PE.bind(null,n[1]),Yn().memoizedState=n,[i,n]},useMutableSource:function(){},useSyncExternalStore:function(n,i,a){var c=et,d=Yn();if(Xe){if(a===void 0)throw Error(t(407));a=a()}else{if(a=i(),Tt===null)throw Error(t(349));(Ji&30)!==0||Pp(c,i,a)}d.memoizedState=a;var f={value:a,getSnapshot:i};return d.queue=f,Lp(Np.bind(null,c,f,n),[n]),c.flags|=2048,va(9,kp.bind(null,c,f,a,i),void 0,null),a},useId:function(){var n=Yn(),i=Tt.identifierPrefix;if(Xe){var a=_r,c=yr;a=(c&~(1<<32-Zt(c)-1)).toString(32)+a,i=":"+i+"R"+a,a=ya++,0<a&&(i+="H"+a.toString(32)),i+=":"}else a=CE++,i=":"+i+"r"+a.toString(32)+":";return n.memoizedState=i},unstable_isNewReconciler:!1},DE={readContext:fn,useCallback:jp,useContext:fn,useEffect:_h,useImperativeHandle:Up,useInsertionEffect:Mp,useLayoutEffect:bp,useMemo:zp,useReducer:gh,useRef:Op,useState:function(){return gh(_a)},useDebugValue:vh,useDeferredValue:function(n){var i=pn();return Bp(i,yt.memoizedState,n)},useTransition:function(){var n=gh(_a)[0],i=pn().memoizedState;return[n,i]},useMutableSource:Rp,useSyncExternalStore:Cp,useId:$p,unstable_isNewReconciler:!1},VE={readContext:fn,useCallback:jp,useContext:fn,useEffect:_h,useImperativeHandle:Up,useInsertionEffect:Mp,useLayoutEffect:bp,useMemo:zp,useReducer:yh,useRef:Op,useState:function(){return yh(_a)},useDebugValue:vh,useDeferredValue:function(n){var i=pn();return yt===null?i.memoizedState=n:Bp(i,yt.memoizedState,n)},useTransition:function(){var n=yh(_a)[0],i=pn().memoizedState;return[n,i]},useMutableSource:Rp,useSyncExternalStore:Cp,useId:$p,unstable_isNewReconciler:!1};function An(n,i){if(n&&n.defaultProps){i=te({},i),n=n.defaultProps;for(var a in n)i[a]===void 0&&(i[a]=n[a]);return i}return i}function Eh(n,i,a,c){i=n.memoizedState,a=a(c,i),a=a==null?i:te({},i,a),n.memoizedState=a,n.lanes===0&&(n.updateQueue.baseState=a)}var iu={isMounted:function(n){return(n=n._reactInternals)?wn(n)===n:!1},enqueueSetState:function(n,i,a){n=n._reactInternals;var c=$t(),d=si(n),f=Er(c,d);f.payload=i,a!=null&&(f.callback=a),i=ti(n,f,d),i!==null&&(Pn(i,n,d,c),Yl(i,n,d))},enqueueReplaceState:function(n,i,a){n=n._reactInternals;var c=$t(),d=si(n),f=Er(c,d);f.tag=1,f.payload=i,a!=null&&(f.callback=a),i=ti(n,f,d),i!==null&&(Pn(i,n,d,c),Yl(i,n,d))},enqueueForceUpdate:function(n,i){n=n._reactInternals;var a=$t(),c=si(n),d=Er(a,c);d.tag=2,i!=null&&(d.callback=i),i=ti(n,d,c),i!==null&&(Pn(i,n,c,a),Yl(i,n,c))}};function Kp(n,i,a,c,d,f,v){return n=n.stateNode,typeof n.shouldComponentUpdate=="function"?n.shouldComponentUpdate(c,f,v):i.prototype&&i.prototype.isPureReactComponent?!sa(a,c)||!sa(d,f):!0}function Gp(n,i,a){var c=!1,d=Xr,f=i.contextType;return typeof f=="object"&&f!==null?f=fn(f):(d=qt(i)?Wi:Vt.current,c=i.contextTypes,f=(c=c!=null)?qs(n,d):Xr),i=new i(a,f),n.memoizedState=i.state!==null&&i.state!==void 0?i.state:null,i.updater=iu,n.stateNode=i,i._reactInternals=n,c&&(n=n.stateNode,n.__reactInternalMemoizedUnmaskedChildContext=d,n.__reactInternalMemoizedMaskedChildContext=f),i}function Qp(n,i,a,c){n=i.state,typeof i.componentWillReceiveProps=="function"&&i.componentWillReceiveProps(a,c),typeof i.UNSAFE_componentWillReceiveProps=="function"&&i.UNSAFE_componentWillReceiveProps(a,c),i.state!==n&&iu.enqueueReplaceState(i,i.state,null)}function wh(n,i,a,c){var d=n.stateNode;d.props=a,d.state=n.memoizedState,d.refs={},ah(n);var f=i.contextType;typeof f=="object"&&f!==null?d.context=fn(f):(f=qt(i)?Wi:Vt.current,d.context=qs(n,f)),d.state=n.memoizedState,f=i.getDerivedStateFromProps,typeof f=="function"&&(Eh(n,i,f,a),d.state=n.memoizedState),typeof i.getDerivedStateFromProps=="function"||typeof d.getSnapshotBeforeUpdate=="function"||typeof d.UNSAFE_componentWillMount!="function"&&typeof d.componentWillMount!="function"||(i=d.state,typeof d.componentWillMount=="function"&&d.componentWillMount(),typeof d.UNSAFE_componentWillMount=="function"&&d.UNSAFE_componentWillMount(),i!==d.state&&iu.enqueueReplaceState(d,d.state,null),Jl(n,a,d,c),d.state=n.memoizedState),typeof d.componentDidMount=="function"&&(n.flags|=4194308)}function Zs(n,i){try{var a="",c=i;do a+=Se(c),c=c.return;while(c);var d=a}catch(f){d=`
Error generating stack: `+f.message+`
`+f.stack}return{value:n,source:i,stack:d,digest:null}}function Th(n,i,a){return{value:n,source:null,stack:a??null,digest:i??null}}function Ih(n,i){try{console.error(i.value)}catch(a){setTimeout(function(){throw a})}}var OE=typeof WeakMap=="function"?WeakMap:Map;function Yp(n,i,a){a=Er(-1,a),a.tag=3,a.payload={element:null};var c=i.value;return a.callback=function(){hu||(hu=!0,Fh=c),Ih(n,i)},a}function Jp(n,i,a){a=Er(-1,a),a.tag=3;var c=n.type.getDerivedStateFromError;if(typeof c=="function"){var d=i.value;a.payload=function(){return c(d)},a.callback=function(){Ih(n,i)}}var f=n.stateNode;return f!==null&&typeof f.componentDidCatch=="function"&&(a.callback=function(){Ih(n,i),typeof c!="function"&&(ri===null?ri=new Set([this]):ri.add(this));var v=i.stack;this.componentDidCatch(i.value,{componentStack:v!==null?v:""})}),a}function Xp(n,i,a){var c=n.pingCache;if(c===null){c=n.pingCache=new OE;var d=new Set;c.set(i,d)}else d=c.get(i),d===void 0&&(d=new Set,c.set(i,d));d.has(a)||(d.add(a),n=GE.bind(null,n,i,a),i.then(n,n))}function Zp(n){do{var i;if((i=n.tag===13)&&(i=n.memoizedState,i=i!==null?i.dehydrated!==null:!0),i)return n;n=n.return}while(n!==null);return null}function em(n,i,a,c,d){return(n.mode&1)===0?(n===i?n.flags|=65536:(n.flags|=128,a.flags|=131072,a.flags&=-52805,a.tag===1&&(a.alternate===null?a.tag=17:(i=Er(-1,1),i.tag=2,ti(a,i,1))),a.lanes|=1),n):(n.flags|=65536,n.lanes=d,n)}var LE=De.ReactCurrentOwner,Wt=!1;function Bt(n,i,a,c){i.child=n===null?Ep(i,null,a,c):Qs(i,n.child,a,c)}function tm(n,i,a,c,d){a=a.render;var f=i.ref;return Js(i,d),c=ph(n,i,a,c,f,d),a=mh(),n!==null&&!Wt?(i.updateQueue=n.updateQueue,i.flags&=-2053,n.lanes&=~d,wr(n,i,d)):(Xe&&a&&Jc(i),i.flags|=1,Bt(n,i,c,d),i.child)}function nm(n,i,a,c,d){if(n===null){var f=a.type;return typeof f=="function"&&!qh(f)&&f.defaultProps===void 0&&a.compare===null&&a.defaultProps===void 0?(i.tag=15,i.type=f,rm(n,i,f,c,d)):(n=yu(a.type,null,c,i,i.mode,d),n.ref=i.ref,n.return=i,i.child=n)}if(f=n.child,(n.lanes&d)===0){var v=f.memoizedProps;if(a=a.compare,a=a!==null?a:sa,a(v,c)&&n.ref===i.ref)return wr(n,i,d)}return i.flags|=1,n=ai(f,c),n.ref=i.ref,n.return=i,i.child=n}function rm(n,i,a,c,d){if(n!==null){var f=n.memoizedProps;if(sa(f,c)&&n.ref===i.ref)if(Wt=!1,i.pendingProps=c=f,(n.lanes&d)!==0)(n.flags&131072)!==0&&(Wt=!0);else return i.lanes=n.lanes,wr(n,i,d)}return Sh(n,i,a,c,d)}function im(n,i,a){var c=i.pendingProps,d=c.children,f=n!==null?n.memoizedState:null;if(c.mode==="hidden")if((i.mode&1)===0)i.memoizedState={baseLanes:0,cachePool:null,transitions:null},We(to,an),an|=a;else{if((a&1073741824)===0)return n=f!==null?f.baseLanes|a:a,i.lanes=i.childLanes=1073741824,i.memoizedState={baseLanes:n,cachePool:null,transitions:null},i.updateQueue=null,We(to,an),an|=n,null;i.memoizedState={baseLanes:0,cachePool:null,transitions:null},c=f!==null?f.baseLanes:a,We(to,an),an|=c}else f!==null?(c=f.baseLanes|a,i.memoizedState=null):c=a,We(to,an),an|=c;return Bt(n,i,d,a),i.child}function sm(n,i){var a=i.ref;(n===null&&a!==null||n!==null&&n.ref!==a)&&(i.flags|=512,i.flags|=2097152)}function Sh(n,i,a,c,d){var f=qt(a)?Wi:Vt.current;return f=qs(i,f),Js(i,d),a=ph(n,i,a,c,f,d),c=mh(),n!==null&&!Wt?(i.updateQueue=n.updateQueue,i.flags&=-2053,n.lanes&=~d,wr(n,i,d)):(Xe&&c&&Jc(i),i.flags|=1,Bt(n,i,a,d),i.child)}function om(n,i,a,c,d){if(qt(a)){var f=!0;Bl(i)}else f=!1;if(Js(i,d),i.stateNode===null)ou(n,i),Gp(i,a,c),wh(i,a,c,d),c=!0;else if(n===null){var v=i.stateNode,I=i.memoizedProps;v.props=I;var k=v.context,U=a.contextType;typeof U=="object"&&U!==null?U=fn(U):(U=qt(a)?Wi:Vt.current,U=qs(i,U));var K=a.getDerivedStateFromProps,G=typeof K=="function"||typeof v.getSnapshotBeforeUpdate=="function";G||typeof v.UNSAFE_componentWillReceiveProps!="function"&&typeof v.componentWillReceiveProps!="function"||(I!==c||k!==U)&&Qp(i,v,c,U),ei=!1;var W=i.memoizedState;v.state=W,Jl(i,c,v,d),k=i.memoizedState,I!==c||W!==k||Ht.current||ei?(typeof K=="function"&&(Eh(i,a,K,c),k=i.memoizedState),(I=ei||Kp(i,a,I,c,W,k,U))?(G||typeof v.UNSAFE_componentWillMount!="function"&&typeof v.componentWillMount!="function"||(typeof v.componentWillMount=="function"&&v.componentWillMount(),typeof v.UNSAFE_componentWillMount=="function"&&v.UNSAFE_componentWillMount()),typeof v.componentDidMount=="function"&&(i.flags|=4194308)):(typeof v.componentDidMount=="function"&&(i.flags|=4194308),i.memoizedProps=c,i.memoizedState=k),v.props=c,v.state=k,v.context=U,c=I):(typeof v.componentDidMount=="function"&&(i.flags|=4194308),c=!1)}else{v=i.stateNode,Tp(n,i),I=i.memoizedProps,U=i.type===i.elementType?I:An(i.type,I),v.props=U,G=i.pendingProps,W=v.context,k=a.contextType,typeof k=="object"&&k!==null?k=fn(k):(k=qt(a)?Wi:Vt.current,k=qs(i,k));var ee=a.getDerivedStateFromProps;(K=typeof ee=="function"||typeof v.getSnapshotBeforeUpdate=="function")||typeof v.UNSAFE_componentWillReceiveProps!="function"&&typeof v.componentWillReceiveProps!="function"||(I!==G||W!==k)&&Qp(i,v,c,k),ei=!1,W=i.memoizedState,v.state=W,Jl(i,c,v,d);var oe=i.memoizedState;I!==G||W!==oe||Ht.current||ei?(typeof ee=="function"&&(Eh(i,a,ee,c),oe=i.memoizedState),(U=ei||Kp(i,a,U,c,W,oe,k)||!1)?(K||typeof v.UNSAFE_componentWillUpdate!="function"&&typeof v.componentWillUpdate!="function"||(typeof v.componentWillUpdate=="function"&&v.componentWillUpdate(c,oe,k),typeof v.UNSAFE_componentWillUpdate=="function"&&v.UNSAFE_componentWillUpdate(c,oe,k)),typeof v.componentDidUpdate=="function"&&(i.flags|=4),typeof v.getSnapshotBeforeUpdate=="function"&&(i.flags|=1024)):(typeof v.componentDidUpdate!="function"||I===n.memoizedProps&&W===n.memoizedState||(i.flags|=4),typeof v.getSnapshotBeforeUpdate!="function"||I===n.memoizedProps&&W===n.memoizedState||(i.flags|=1024),i.memoizedProps=c,i.memoizedState=oe),v.props=c,v.state=oe,v.context=k,c=U):(typeof v.componentDidUpdate!="function"||I===n.memoizedProps&&W===n.memoizedState||(i.flags|=4),typeof v.getSnapshotBeforeUpdate!="function"||I===n.memoizedProps&&W===n.memoizedState||(i.flags|=1024),c=!1)}return Ah(n,i,a,c,f,d)}function Ah(n,i,a,c,d,f){sm(n,i);var v=(i.flags&128)!==0;if(!c&&!v)return d&&hp(i,a,!1),wr(n,i,f);c=i.stateNode,LE.current=i;var I=v&&typeof a.getDerivedStateFromError!="function"?null:c.render();return i.flags|=1,n!==null&&v?(i.child=Qs(i,n.child,null,f),i.child=Qs(i,null,I,f)):Bt(n,i,I,f),i.memoizedState=c.state,d&&hp(i,a,!0),i.child}function am(n){var i=n.stateNode;i.pendingContext?up(n,i.pendingContext,i.pendingContext!==i.context):i.context&&up(n,i.context,!1),lh(n,i.containerInfo)}function lm(n,i,a,c,d){return Gs(),th(d),i.flags|=256,Bt(n,i,a,c),i.child}var Rh={dehydrated:null,treeContext:null,retryLane:0};function Ch(n){return{baseLanes:n,cachePool:null,transitions:null}}function um(n,i,a){var c=i.pendingProps,d=Ze.current,f=!1,v=(i.flags&128)!==0,I;if((I=v)||(I=n!==null&&n.memoizedState===null?!1:(d&2)!==0),I?(f=!0,i.flags&=-129):(n===null||n.memoizedState!==null)&&(d|=1),We(Ze,d&1),n===null)return eh(i),n=i.memoizedState,n!==null&&(n=n.dehydrated,n!==null)?((i.mode&1)===0?i.lanes=1:n.data==="$!"?i.lanes=8:i.lanes=1073741824,null):(v=c.children,n=c.fallback,f?(c=i.mode,f=i.child,v={mode:"hidden",children:v},(c&1)===0&&f!==null?(f.childLanes=0,f.pendingProps=v):f=_u(v,c,0,null),n=ns(n,c,a,null),f.return=i,n.return=i,f.sibling=n,i.child=f,i.child.memoizedState=Ch(a),i.memoizedState=Rh,n):Ph(i,v));if(d=n.memoizedState,d!==null&&(I=d.dehydrated,I!==null))return ME(n,i,v,c,I,d,a);if(f){f=c.fallback,v=i.mode,d=n.child,I=d.sibling;var k={mode:"hidden",children:c.children};return(v&1)===0&&i.child!==d?(c=i.child,c.childLanes=0,c.pendingProps=k,i.deletions=null):(c=ai(d,k),c.subtreeFlags=d.subtreeFlags&14680064),I!==null?f=ai(I,f):(f=ns(f,v,a,null),f.flags|=2),f.return=i,c.return=i,c.sibling=f,i.child=c,c=f,f=i.child,v=n.child.memoizedState,v=v===null?Ch(a):{baseLanes:v.baseLanes|a,cachePool:null,transitions:v.transitions},f.memoizedState=v,f.childLanes=n.childLanes&~a,i.memoizedState=Rh,c}return f=n.child,n=f.sibling,c=ai(f,{mode:"visible",children:c.children}),(i.mode&1)===0&&(c.lanes=a),c.return=i,c.sibling=null,n!==null&&(a=i.deletions,a===null?(i.deletions=[n],i.flags|=16):a.push(n)),i.child=c,i.memoizedState=null,c}function Ph(n,i){return i=_u({mode:"visible",children:i},n.mode,0,null),i.return=n,n.child=i}function su(n,i,a,c){return c!==null&&th(c),Qs(i,n.child,null,a),n=Ph(i,i.pendingProps.children),n.flags|=2,i.memoizedState=null,n}function ME(n,i,a,c,d,f,v){if(a)return i.flags&256?(i.flags&=-257,c=Th(Error(t(422))),su(n,i,v,c)):i.memoizedState!==null?(i.child=n.child,i.flags|=128,null):(f=c.fallback,d=i.mode,c=_u({mode:"visible",children:c.children},d,0,null),f=ns(f,d,v,null),f.flags|=2,c.return=i,f.return=i,c.sibling=f,i.child=c,(i.mode&1)!==0&&Qs(i,n.child,null,v),i.child.memoizedState=Ch(v),i.memoizedState=Rh,f);if((i.mode&1)===0)return su(n,i,v,null);if(d.data==="$!"){if(c=d.nextSibling&&d.nextSibling.dataset,c)var I=c.dgst;return c=I,f=Error(t(419)),c=Th(f,c,void 0),su(n,i,v,c)}if(I=(v&n.childLanes)!==0,Wt||I){if(c=Tt,c!==null){switch(v&-v){case 4:d=2;break;case 16:d=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:d=32;break;case 536870912:d=268435456;break;default:d=0}d=(d&(c.suspendedLanes|v))!==0?0:d,d!==0&&d!==f.retryLane&&(f.retryLane=d,vr(n,d),Pn(c,n,d,-1))}return Hh(),c=Th(Error(t(421))),su(n,i,v,c)}return d.data==="$?"?(i.flags|=128,i.child=n.child,i=QE.bind(null,n),d._reactRetry=i,null):(n=f.treeContext,on=Yr(d.nextSibling),sn=i,Xe=!0,Sn=null,n!==null&&(hn[dn++]=yr,hn[dn++]=_r,hn[dn++]=Ki,yr=n.id,_r=n.overflow,Ki=i),i=Ph(i,c.children),i.flags|=4096,i)}function cm(n,i,a){n.lanes|=i;var c=n.alternate;c!==null&&(c.lanes|=i),sh(n.return,i,a)}function kh(n,i,a,c,d){var f=n.memoizedState;f===null?n.memoizedState={isBackwards:i,rendering:null,renderingStartTime:0,last:c,tail:a,tailMode:d}:(f.isBackwards=i,f.rendering=null,f.renderingStartTime=0,f.last=c,f.tail=a,f.tailMode=d)}function hm(n,i,a){var c=i.pendingProps,d=c.revealOrder,f=c.tail;if(Bt(n,i,c.children,a),c=Ze.current,(c&2)!==0)c=c&1|2,i.flags|=128;else{if(n!==null&&(n.flags&128)!==0)e:for(n=i.child;n!==null;){if(n.tag===13)n.memoizedState!==null&&cm(n,a,i);else if(n.tag===19)cm(n,a,i);else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===i)break e;for(;n.sibling===null;){if(n.return===null||n.return===i)break e;n=n.return}n.sibling.return=n.return,n=n.sibling}c&=1}if(We(Ze,c),(i.mode&1)===0)i.memoizedState=null;else switch(d){case"forwards":for(a=i.child,d=null;a!==null;)n=a.alternate,n!==null&&Xl(n)===null&&(d=a),a=a.sibling;a=d,a===null?(d=i.child,i.child=null):(d=a.sibling,a.sibling=null),kh(i,!1,d,a,f);break;case"backwards":for(a=null,d=i.child,i.child=null;d!==null;){if(n=d.alternate,n!==null&&Xl(n)===null){i.child=d;break}n=d.sibling,d.sibling=a,a=d,d=n}kh(i,!0,a,null,f);break;case"together":kh(i,!1,null,null,void 0);break;default:i.memoizedState=null}return i.child}function ou(n,i){(i.mode&1)===0&&n!==null&&(n.alternate=null,i.alternate=null,i.flags|=2)}function wr(n,i,a){if(n!==null&&(i.dependencies=n.dependencies),Xi|=i.lanes,(a&i.childLanes)===0)return null;if(n!==null&&i.child!==n.child)throw Error(t(153));if(i.child!==null){for(n=i.child,a=ai(n,n.pendingProps),i.child=a,a.return=i;n.sibling!==null;)n=n.sibling,a=a.sibling=ai(n,n.pendingProps),a.return=i;a.sibling=null}return i.child}function bE(n,i,a){switch(i.tag){case 3:am(i),Gs();break;case 5:Ap(i);break;case 1:qt(i.type)&&Bl(i);break;case 4:lh(i,i.stateNode.containerInfo);break;case 10:var c=i.type._context,d=i.memoizedProps.value;We(Gl,c._currentValue),c._currentValue=d;break;case 13:if(c=i.memoizedState,c!==null)return c.dehydrated!==null?(We(Ze,Ze.current&1),i.flags|=128,null):(a&i.child.childLanes)!==0?um(n,i,a):(We(Ze,Ze.current&1),n=wr(n,i,a),n!==null?n.sibling:null);We(Ze,Ze.current&1);break;case 19:if(c=(a&i.childLanes)!==0,(n.flags&128)!==0){if(c)return hm(n,i,a);i.flags|=128}if(d=i.memoizedState,d!==null&&(d.rendering=null,d.tail=null,d.lastEffect=null),We(Ze,Ze.current),c)break;return null;case 22:case 23:return i.lanes=0,im(n,i,a)}return wr(n,i,a)}var dm,Nh,fm,pm;dm=function(n,i){for(var a=i.child;a!==null;){if(a.tag===5||a.tag===6)n.appendChild(a.stateNode);else if(a.tag!==4&&a.child!==null){a.child.return=a,a=a.child;continue}if(a===i)break;for(;a.sibling===null;){if(a.return===null||a.return===i)return;a=a.return}a.sibling.return=a.return,a=a.sibling}},Nh=function(){},fm=function(n,i,a,c){var d=n.memoizedProps;if(d!==c){n=i.stateNode,Yi(Qn.current);var f=null;switch(a){case"input":d=ys(n,d),c=ys(n,c),f=[];break;case"select":d=te({},d,{value:void 0}),c=te({},c,{value:void 0}),f=[];break;case"textarea":d=Oo(n,d),c=Oo(n,c),f=[];break;default:typeof d.onClick!="function"&&typeof c.onClick=="function"&&(n.onclick=Ul)}En(a,c);var v;a=null;for(U in d)if(!c.hasOwnProperty(U)&&d.hasOwnProperty(U)&&d[U]!=null)if(U==="style"){var I=d[U];for(v in I)I.hasOwnProperty(v)&&(a||(a={}),a[v]="")}else U!=="dangerouslySetInnerHTML"&&U!=="children"&&U!=="suppressContentEditableWarning"&&U!=="suppressHydrationWarning"&&U!=="autoFocus"&&(o.hasOwnProperty(U)?f||(f=[]):(f=f||[]).push(U,null));for(U in c){var k=c[U];if(I=d!=null?d[U]:void 0,c.hasOwnProperty(U)&&k!==I&&(k!=null||I!=null))if(U==="style")if(I){for(v in I)!I.hasOwnProperty(v)||k&&k.hasOwnProperty(v)||(a||(a={}),a[v]="");for(v in k)k.hasOwnProperty(v)&&I[v]!==k[v]&&(a||(a={}),a[v]=k[v])}else a||(f||(f=[]),f.push(U,a)),a=k;else U==="dangerouslySetInnerHTML"?(k=k?k.__html:void 0,I=I?I.__html:void 0,k!=null&&I!==k&&(f=f||[]).push(U,k)):U==="children"?typeof k!="string"&&typeof k!="number"||(f=f||[]).push(U,""+k):U!=="suppressContentEditableWarning"&&U!=="suppressHydrationWarning"&&(o.hasOwnProperty(U)?(k!=null&&U==="onScroll"&&Qe("scroll",n),f||I===k||(f=[])):(f=f||[]).push(U,k))}a&&(f=f||[]).push("style",a);var U=f;(i.updateQueue=U)&&(i.flags|=4)}},pm=function(n,i,a,c){a!==c&&(i.flags|=4)};function Ea(n,i){if(!Xe)switch(n.tailMode){case"hidden":i=n.tail;for(var a=null;i!==null;)i.alternate!==null&&(a=i),i=i.sibling;a===null?n.tail=null:a.sibling=null;break;case"collapsed":a=n.tail;for(var c=null;a!==null;)a.alternate!==null&&(c=a),a=a.sibling;c===null?i||n.tail===null?n.tail=null:n.tail.sibling=null:c.sibling=null}}function Lt(n){var i=n.alternate!==null&&n.alternate.child===n.child,a=0,c=0;if(i)for(var d=n.child;d!==null;)a|=d.lanes|d.childLanes,c|=d.subtreeFlags&14680064,c|=d.flags&14680064,d.return=n,d=d.sibling;else for(d=n.child;d!==null;)a|=d.lanes|d.childLanes,c|=d.subtreeFlags,c|=d.flags,d.return=n,d=d.sibling;return n.subtreeFlags|=c,n.childLanes=a,i}function FE(n,i,a){var c=i.pendingProps;switch(Xc(i),i.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Lt(i),null;case 1:return qt(i.type)&&zl(),Lt(i),null;case 3:return c=i.stateNode,Xs(),Ye(Ht),Ye(Vt),hh(),c.pendingContext&&(c.context=c.pendingContext,c.pendingContext=null),(n===null||n.child===null)&&(Wl(i)?i.flags|=4:n===null||n.memoizedState.isDehydrated&&(i.flags&256)===0||(i.flags|=1024,Sn!==null&&(zh(Sn),Sn=null))),Nh(n,i),Lt(i),null;case 5:uh(i);var d=Yi(ma.current);if(a=i.type,n!==null&&i.stateNode!=null)fm(n,i,a,c,d),n.ref!==i.ref&&(i.flags|=512,i.flags|=2097152);else{if(!c){if(i.stateNode===null)throw Error(t(166));return Lt(i),null}if(n=Yi(Qn.current),Wl(i)){c=i.stateNode,a=i.type;var f=i.memoizedProps;switch(c[Gn]=i,c[ca]=f,n=(i.mode&1)!==0,a){case"dialog":Qe("cancel",c),Qe("close",c);break;case"iframe":case"object":case"embed":Qe("load",c);break;case"video":case"audio":for(d=0;d<aa.length;d++)Qe(aa[d],c);break;case"source":Qe("error",c);break;case"img":case"image":case"link":Qe("error",c),Qe("load",c);break;case"details":Qe("toggle",c);break;case"input":cl(c,f),Qe("invalid",c);break;case"select":c._wrapperState={wasMultiple:!!f.multiple},Qe("invalid",c);break;case"textarea":Lo(c,f),Qe("invalid",c)}En(a,f),d=null;for(var v in f)if(f.hasOwnProperty(v)){var I=f[v];v==="children"?typeof I=="string"?c.textContent!==I&&(f.suppressHydrationWarning!==!0&&Fl(c.textContent,I,n),d=["children",I]):typeof I=="number"&&c.textContent!==""+I&&(f.suppressHydrationWarning!==!0&&Fl(c.textContent,I,n),d=["children",""+I]):o.hasOwnProperty(v)&&I!=null&&v==="onScroll"&&Qe("scroll",c)}switch(a){case"input":gs(c),Vo(c,f,!0);break;case"textarea":gs(c),Or(c);break;case"select":case"option":break;default:typeof f.onClick=="function"&&(c.onclick=Ul)}c=d,i.updateQueue=c,c!==null&&(i.flags|=4)}else{v=d.nodeType===9?d:d.ownerDocument,n==="http://www.w3.org/1999/xhtml"&&(n=Mo(a)),n==="http://www.w3.org/1999/xhtml"?a==="script"?(n=v.createElement("div"),n.innerHTML="<script><\/script>",n=n.removeChild(n.firstChild)):typeof c.is=="string"?n=v.createElement(a,{is:c.is}):(n=v.createElement(a),a==="select"&&(v=n,c.multiple?v.multiple=!0:c.size&&(v.size=c.size))):n=v.createElementNS(n,a),n[Gn]=i,n[ca]=c,dm(n,i,!1,!1),i.stateNode=n;e:{switch(v=ws(a,c),a){case"dialog":Qe("cancel",n),Qe("close",n),d=c;break;case"iframe":case"object":case"embed":Qe("load",n),d=c;break;case"video":case"audio":for(d=0;d<aa.length;d++)Qe(aa[d],n);d=c;break;case"source":Qe("error",n),d=c;break;case"img":case"image":case"link":Qe("error",n),Qe("load",n),d=c;break;case"details":Qe("toggle",n),d=c;break;case"input":cl(n,c),d=ys(n,c),Qe("invalid",n);break;case"option":d=c;break;case"select":n._wrapperState={wasMultiple:!!c.multiple},d=te({},c,{value:void 0}),Qe("invalid",n);break;case"textarea":Lo(n,c),d=Oo(n,c),Qe("invalid",n);break;default:d=c}En(a,d),I=d;for(f in I)if(I.hasOwnProperty(f)){var k=I[f];f==="style"?Es(n,k):f==="dangerouslySetInnerHTML"?(k=k?k.__html:void 0,k!=null&&dl(n,k)):f==="children"?typeof k=="string"?(a!=="textarea"||k!=="")&&xi(n,k):typeof k=="number"&&xi(n,""+k):f!=="suppressContentEditableWarning"&&f!=="suppressHydrationWarning"&&f!=="autoFocus"&&(o.hasOwnProperty(f)?k!=null&&f==="onScroll"&&Qe("scroll",n):k!=null&&Te(n,f,k,v))}switch(a){case"input":gs(n),Vo(n,c,!1);break;case"textarea":gs(n),Or(n);break;case"option":c.value!=null&&n.setAttribute("value",""+Ve(c.value));break;case"select":n.multiple=!!c.multiple,f=c.value,f!=null?vn(n,!!c.multiple,f,!1):c.defaultValue!=null&&vn(n,!!c.multiple,c.defaultValue,!0);break;default:typeof d.onClick=="function"&&(n.onclick=Ul)}switch(a){case"button":case"input":case"select":case"textarea":c=!!c.autoFocus;break e;case"img":c=!0;break e;default:c=!1}}c&&(i.flags|=4)}i.ref!==null&&(i.flags|=512,i.flags|=2097152)}return Lt(i),null;case 6:if(n&&i.stateNode!=null)pm(n,i,n.memoizedProps,c);else{if(typeof c!="string"&&i.stateNode===null)throw Error(t(166));if(a=Yi(ma.current),Yi(Qn.current),Wl(i)){if(c=i.stateNode,a=i.memoizedProps,c[Gn]=i,(f=c.nodeValue!==a)&&(n=sn,n!==null))switch(n.tag){case 3:Fl(c.nodeValue,a,(n.mode&1)!==0);break;case 5:n.memoizedProps.suppressHydrationWarning!==!0&&Fl(c.nodeValue,a,(n.mode&1)!==0)}f&&(i.flags|=4)}else c=(a.nodeType===9?a:a.ownerDocument).createTextNode(c),c[Gn]=i,i.stateNode=c}return Lt(i),null;case 13:if(Ye(Ze),c=i.memoizedState,n===null||n.memoizedState!==null&&n.memoizedState.dehydrated!==null){if(Xe&&on!==null&&(i.mode&1)!==0&&(i.flags&128)===0)yp(),Gs(),i.flags|=98560,f=!1;else if(f=Wl(i),c!==null&&c.dehydrated!==null){if(n===null){if(!f)throw Error(t(318));if(f=i.memoizedState,f=f!==null?f.dehydrated:null,!f)throw Error(t(317));f[Gn]=i}else Gs(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;Lt(i),f=!1}else Sn!==null&&(zh(Sn),Sn=null),f=!0;if(!f)return i.flags&65536?i:null}return(i.flags&128)!==0?(i.lanes=a,i):(c=c!==null,c!==(n!==null&&n.memoizedState!==null)&&c&&(i.child.flags|=8192,(i.mode&1)!==0&&(n===null||(Ze.current&1)!==0?_t===0&&(_t=3):Hh())),i.updateQueue!==null&&(i.flags|=4),Lt(i),null);case 4:return Xs(),Nh(n,i),n===null&&la(i.stateNode.containerInfo),Lt(i),null;case 10:return ih(i.type._context),Lt(i),null;case 17:return qt(i.type)&&zl(),Lt(i),null;case 19:if(Ye(Ze),f=i.memoizedState,f===null)return Lt(i),null;if(c=(i.flags&128)!==0,v=f.rendering,v===null)if(c)Ea(f,!1);else{if(_t!==0||n!==null&&(n.flags&128)!==0)for(n=i.child;n!==null;){if(v=Xl(n),v!==null){for(i.flags|=128,Ea(f,!1),c=v.updateQueue,c!==null&&(i.updateQueue=c,i.flags|=4),i.subtreeFlags=0,c=a,a=i.child;a!==null;)f=a,n=c,f.flags&=14680066,v=f.alternate,v===null?(f.childLanes=0,f.lanes=n,f.child=null,f.subtreeFlags=0,f.memoizedProps=null,f.memoizedState=null,f.updateQueue=null,f.dependencies=null,f.stateNode=null):(f.childLanes=v.childLanes,f.lanes=v.lanes,f.child=v.child,f.subtreeFlags=0,f.deletions=null,f.memoizedProps=v.memoizedProps,f.memoizedState=v.memoizedState,f.updateQueue=v.updateQueue,f.type=v.type,n=v.dependencies,f.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),a=a.sibling;return We(Ze,Ze.current&1|2),i.child}n=n.sibling}f.tail!==null&&Ge()>no&&(i.flags|=128,c=!0,Ea(f,!1),i.lanes=4194304)}else{if(!c)if(n=Xl(v),n!==null){if(i.flags|=128,c=!0,a=n.updateQueue,a!==null&&(i.updateQueue=a,i.flags|=4),Ea(f,!0),f.tail===null&&f.tailMode==="hidden"&&!v.alternate&&!Xe)return Lt(i),null}else 2*Ge()-f.renderingStartTime>no&&a!==1073741824&&(i.flags|=128,c=!0,Ea(f,!1),i.lanes=4194304);f.isBackwards?(v.sibling=i.child,i.child=v):(a=f.last,a!==null?a.sibling=v:i.child=v,f.last=v)}return f.tail!==null?(i=f.tail,f.rendering=i,f.tail=i.sibling,f.renderingStartTime=Ge(),i.sibling=null,a=Ze.current,We(Ze,c?a&1|2:a&1),i):(Lt(i),null);case 22:case 23:return $h(),c=i.memoizedState!==null,n!==null&&n.memoizedState!==null!==c&&(i.flags|=8192),c&&(i.mode&1)!==0?(an&1073741824)!==0&&(Lt(i),i.subtreeFlags&6&&(i.flags|=8192)):Lt(i),null;case 24:return null;case 25:return null}throw Error(t(156,i.tag))}function UE(n,i){switch(Xc(i),i.tag){case 1:return qt(i.type)&&zl(),n=i.flags,n&65536?(i.flags=n&-65537|128,i):null;case 3:return Xs(),Ye(Ht),Ye(Vt),hh(),n=i.flags,(n&65536)!==0&&(n&128)===0?(i.flags=n&-65537|128,i):null;case 5:return uh(i),null;case 13:if(Ye(Ze),n=i.memoizedState,n!==null&&n.dehydrated!==null){if(i.alternate===null)throw Error(t(340));Gs()}return n=i.flags,n&65536?(i.flags=n&-65537|128,i):null;case 19:return Ye(Ze),null;case 4:return Xs(),null;case 10:return ih(i.type._context),null;case 22:case 23:return $h(),null;case 24:return null;default:return null}}var au=!1,Mt=!1,jE=typeof WeakSet=="function"?WeakSet:Set,se=null;function eo(n,i){var a=n.ref;if(a!==null)if(typeof a=="function")try{a(null)}catch(c){rt(n,i,c)}else a.current=null}function xh(n,i,a){try{a()}catch(c){rt(n,i,c)}}var mm=!1;function zE(n,i){if($c=dr,n=Kf(),Lc(n)){if("selectionStart"in n)var a={start:n.selectionStart,end:n.selectionEnd};else e:{a=(a=n.ownerDocument)&&a.defaultView||window;var c=a.getSelection&&a.getSelection();if(c&&c.rangeCount!==0){a=c.anchorNode;var d=c.anchorOffset,f=c.focusNode;c=c.focusOffset;try{a.nodeType,f.nodeType}catch{a=null;break e}var v=0,I=-1,k=-1,U=0,K=0,G=n,W=null;t:for(;;){for(var ee;G!==a||d!==0&&G.nodeType!==3||(I=v+d),G!==f||c!==0&&G.nodeType!==3||(k=v+c),G.nodeType===3&&(v+=G.nodeValue.length),(ee=G.firstChild)!==null;)W=G,G=ee;for(;;){if(G===n)break t;if(W===a&&++U===d&&(I=v),W===f&&++K===c&&(k=v),(ee=G.nextSibling)!==null)break;G=W,W=G.parentNode}G=ee}a=I===-1||k===-1?null:{start:I,end:k}}else a=null}a=a||{start:0,end:0}}else a=null;for(Hc={focusedElem:n,selectionRange:a},dr=!1,se=i;se!==null;)if(i=se,n=i.child,(i.subtreeFlags&1028)!==0&&n!==null)n.return=i,se=n;else for(;se!==null;){i=se;try{var oe=i.alternate;if((i.flags&1024)!==0)switch(i.tag){case 0:case 11:case 15:break;case 1:if(oe!==null){var ae=oe.memoizedProps,ot=oe.memoizedState,M=i.stateNode,x=M.getSnapshotBeforeUpdate(i.elementType===i.type?ae:An(i.type,ae),ot);M.__reactInternalSnapshotBeforeUpdate=x}break;case 3:var F=i.stateNode.containerInfo;F.nodeType===1?F.textContent="":F.nodeType===9&&F.documentElement&&F.removeChild(F.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(t(163))}}catch(J){rt(i,i.return,J)}if(n=i.sibling,n!==null){n.return=i.return,se=n;break}se=i.return}return oe=mm,mm=!1,oe}function wa(n,i,a){var c=i.updateQueue;if(c=c!==null?c.lastEffect:null,c!==null){var d=c=c.next;do{if((d.tag&n)===n){var f=d.destroy;d.destroy=void 0,f!==void 0&&xh(i,a,f)}d=d.next}while(d!==c)}}function lu(n,i){if(i=i.updateQueue,i=i!==null?i.lastEffect:null,i!==null){var a=i=i.next;do{if((a.tag&n)===n){var c=a.create;a.destroy=c()}a=a.next}while(a!==i)}}function Dh(n){var i=n.ref;if(i!==null){var a=n.stateNode;switch(n.tag){case 5:n=a;break;default:n=a}typeof i=="function"?i(n):i.current=n}}function gm(n){var i=n.alternate;i!==null&&(n.alternate=null,gm(i)),n.child=null,n.deletions=null,n.sibling=null,n.tag===5&&(i=n.stateNode,i!==null&&(delete i[Gn],delete i[ca],delete i[Gc],delete i[IE],delete i[SE])),n.stateNode=null,n.return=null,n.dependencies=null,n.memoizedProps=null,n.memoizedState=null,n.pendingProps=null,n.stateNode=null,n.updateQueue=null}function ym(n){return n.tag===5||n.tag===3||n.tag===4}function _m(n){e:for(;;){for(;n.sibling===null;){if(n.return===null||ym(n.return))return null;n=n.return}for(n.sibling.return=n.return,n=n.sibling;n.tag!==5&&n.tag!==6&&n.tag!==18;){if(n.flags&2||n.child===null||n.tag===4)continue e;n.child.return=n,n=n.child}if(!(n.flags&2))return n.stateNode}}function Vh(n,i,a){var c=n.tag;if(c===5||c===6)n=n.stateNode,i?a.nodeType===8?a.parentNode.insertBefore(n,i):a.insertBefore(n,i):(a.nodeType===8?(i=a.parentNode,i.insertBefore(n,a)):(i=a,i.appendChild(n)),a=a._reactRootContainer,a!=null||i.onclick!==null||(i.onclick=Ul));else if(c!==4&&(n=n.child,n!==null))for(Vh(n,i,a),n=n.sibling;n!==null;)Vh(n,i,a),n=n.sibling}function Oh(n,i,a){var c=n.tag;if(c===5||c===6)n=n.stateNode,i?a.insertBefore(n,i):a.appendChild(n);else if(c!==4&&(n=n.child,n!==null))for(Oh(n,i,a),n=n.sibling;n!==null;)Oh(n,i,a),n=n.sibling}var Ct=null,Rn=!1;function ni(n,i,a){for(a=a.child;a!==null;)vm(n,i,a),a=a.sibling}function vm(n,i,a){if(Xt&&typeof Xt.onCommitFiberUnmount=="function")try{Xt.onCommitFiberUnmount(Mi,a)}catch{}switch(a.tag){case 5:Mt||eo(a,i);case 6:var c=Ct,d=Rn;Ct=null,ni(n,i,a),Ct=c,Rn=d,Ct!==null&&(Rn?(n=Ct,a=a.stateNode,n.nodeType===8?n.parentNode.removeChild(a):n.removeChild(a)):Ct.removeChild(a.stateNode));break;case 18:Ct!==null&&(Rn?(n=Ct,a=a.stateNode,n.nodeType===8?Kc(n.parentNode,a):n.nodeType===1&&Kc(n,a),Wr(n)):Kc(Ct,a.stateNode));break;case 4:c=Ct,d=Rn,Ct=a.stateNode.containerInfo,Rn=!0,ni(n,i,a),Ct=c,Rn=d;break;case 0:case 11:case 14:case 15:if(!Mt&&(c=a.updateQueue,c!==null&&(c=c.lastEffect,c!==null))){d=c=c.next;do{var f=d,v=f.destroy;f=f.tag,v!==void 0&&((f&2)!==0||(f&4)!==0)&&xh(a,i,v),d=d.next}while(d!==c)}ni(n,i,a);break;case 1:if(!Mt&&(eo(a,i),c=a.stateNode,typeof c.componentWillUnmount=="function"))try{c.props=a.memoizedProps,c.state=a.memoizedState,c.componentWillUnmount()}catch(I){rt(a,i,I)}ni(n,i,a);break;case 21:ni(n,i,a);break;case 22:a.mode&1?(Mt=(c=Mt)||a.memoizedState!==null,ni(n,i,a),Mt=c):ni(n,i,a);break;default:ni(n,i,a)}}function Em(n){var i=n.updateQueue;if(i!==null){n.updateQueue=null;var a=n.stateNode;a===null&&(a=n.stateNode=new jE),i.forEach(function(c){var d=YE.bind(null,n,c);a.has(c)||(a.add(c),c.then(d,d))})}}function Cn(n,i){var a=i.deletions;if(a!==null)for(var c=0;c<a.length;c++){var d=a[c];try{var f=n,v=i,I=v;e:for(;I!==null;){switch(I.tag){case 5:Ct=I.stateNode,Rn=!1;break e;case 3:Ct=I.stateNode.containerInfo,Rn=!0;break e;case 4:Ct=I.stateNode.containerInfo,Rn=!0;break e}I=I.return}if(Ct===null)throw Error(t(160));vm(f,v,d),Ct=null,Rn=!1;var k=d.alternate;k!==null&&(k.return=null),d.return=null}catch(U){rt(d,i,U)}}if(i.subtreeFlags&12854)for(i=i.child;i!==null;)wm(i,n),i=i.sibling}function wm(n,i){var a=n.alternate,c=n.flags;switch(n.tag){case 0:case 11:case 14:case 15:if(Cn(i,n),Jn(n),c&4){try{wa(3,n,n.return),lu(3,n)}catch(ae){rt(n,n.return,ae)}try{wa(5,n,n.return)}catch(ae){rt(n,n.return,ae)}}break;case 1:Cn(i,n),Jn(n),c&512&&a!==null&&eo(a,a.return);break;case 5:if(Cn(i,n),Jn(n),c&512&&a!==null&&eo(a,a.return),n.flags&32){var d=n.stateNode;try{xi(d,"")}catch(ae){rt(n,n.return,ae)}}if(c&4&&(d=n.stateNode,d!=null)){var f=n.memoizedProps,v=a!==null?a.memoizedProps:f,I=n.type,k=n.updateQueue;if(n.updateQueue=null,k!==null)try{I==="input"&&f.type==="radio"&&f.name!=null&&_s(d,f),ws(I,v);var U=ws(I,f);for(v=0;v<k.length;v+=2){var K=k[v],G=k[v+1];K==="style"?Es(d,G):K==="dangerouslySetInnerHTML"?dl(d,G):K==="children"?xi(d,G):Te(d,K,G,U)}switch(I){case"input":Ni(d,f);break;case"textarea":hl(d,f);break;case"select":var W=d._wrapperState.wasMultiple;d._wrapperState.wasMultiple=!!f.multiple;var ee=f.value;ee!=null?vn(d,!!f.multiple,ee,!1):W!==!!f.multiple&&(f.defaultValue!=null?vn(d,!!f.multiple,f.defaultValue,!0):vn(d,!!f.multiple,f.multiple?[]:"",!1))}d[ca]=f}catch(ae){rt(n,n.return,ae)}}break;case 6:if(Cn(i,n),Jn(n),c&4){if(n.stateNode===null)throw Error(t(162));d=n.stateNode,f=n.memoizedProps;try{d.nodeValue=f}catch(ae){rt(n,n.return,ae)}}break;case 3:if(Cn(i,n),Jn(n),c&4&&a!==null&&a.memoizedState.isDehydrated)try{Wr(i.containerInfo)}catch(ae){rt(n,n.return,ae)}break;case 4:Cn(i,n),Jn(n);break;case 13:Cn(i,n),Jn(n),d=n.child,d.flags&8192&&(f=d.memoizedState!==null,d.stateNode.isHidden=f,!f||d.alternate!==null&&d.alternate.memoizedState!==null||(bh=Ge())),c&4&&Em(n);break;case 22:if(K=a!==null&&a.memoizedState!==null,n.mode&1?(Mt=(U=Mt)||K,Cn(i,n),Mt=U):Cn(i,n),Jn(n),c&8192){if(U=n.memoizedState!==null,(n.stateNode.isHidden=U)&&!K&&(n.mode&1)!==0)for(se=n,K=n.child;K!==null;){for(G=se=K;se!==null;){switch(W=se,ee=W.child,W.tag){case 0:case 11:case 14:case 15:wa(4,W,W.return);break;case 1:eo(W,W.return);var oe=W.stateNode;if(typeof oe.componentWillUnmount=="function"){c=W,a=W.return;try{i=c,oe.props=i.memoizedProps,oe.state=i.memoizedState,oe.componentWillUnmount()}catch(ae){rt(c,a,ae)}}break;case 5:eo(W,W.return);break;case 22:if(W.memoizedState!==null){Sm(G);continue}}ee!==null?(ee.return=W,se=ee):Sm(G)}K=K.sibling}e:for(K=null,G=n;;){if(G.tag===5){if(K===null){K=G;try{d=G.stateNode,U?(f=d.style,typeof f.setProperty=="function"?f.setProperty("display","none","important"):f.display="none"):(I=G.stateNode,k=G.memoizedProps.style,v=k!=null&&k.hasOwnProperty("display")?k.display:null,I.style.display=br("display",v))}catch(ae){rt(n,n.return,ae)}}}else if(G.tag===6){if(K===null)try{G.stateNode.nodeValue=U?"":G.memoizedProps}catch(ae){rt(n,n.return,ae)}}else if((G.tag!==22&&G.tag!==23||G.memoizedState===null||G===n)&&G.child!==null){G.child.return=G,G=G.child;continue}if(G===n)break e;for(;G.sibling===null;){if(G.return===null||G.return===n)break e;K===G&&(K=null),G=G.return}K===G&&(K=null),G.sibling.return=G.return,G=G.sibling}}break;case 19:Cn(i,n),Jn(n),c&4&&Em(n);break;case 21:break;default:Cn(i,n),Jn(n)}}function Jn(n){var i=n.flags;if(i&2){try{e:{for(var a=n.return;a!==null;){if(ym(a)){var c=a;break e}a=a.return}throw Error(t(160))}switch(c.tag){case 5:var d=c.stateNode;c.flags&32&&(xi(d,""),c.flags&=-33);var f=_m(n);Oh(n,f,d);break;case 3:case 4:var v=c.stateNode.containerInfo,I=_m(n);Vh(n,I,v);break;default:throw Error(t(161))}}catch(k){rt(n,n.return,k)}n.flags&=-3}i&4096&&(n.flags&=-4097)}function BE(n,i,a){se=n,Tm(n)}function Tm(n,i,a){for(var c=(n.mode&1)!==0;se!==null;){var d=se,f=d.child;if(d.tag===22&&c){var v=d.memoizedState!==null||au;if(!v){var I=d.alternate,k=I!==null&&I.memoizedState!==null||Mt;I=au;var U=Mt;if(au=v,(Mt=k)&&!U)for(se=d;se!==null;)v=se,k=v.child,v.tag===22&&v.memoizedState!==null?Am(d):k!==null?(k.return=v,se=k):Am(d);for(;f!==null;)se=f,Tm(f),f=f.sibling;se=d,au=I,Mt=U}Im(n)}else(d.subtreeFlags&8772)!==0&&f!==null?(f.return=d,se=f):Im(n)}}function Im(n){for(;se!==null;){var i=se;if((i.flags&8772)!==0){var a=i.alternate;try{if((i.flags&8772)!==0)switch(i.tag){case 0:case 11:case 15:Mt||lu(5,i);break;case 1:var c=i.stateNode;if(i.flags&4&&!Mt)if(a===null)c.componentDidMount();else{var d=i.elementType===i.type?a.memoizedProps:An(i.type,a.memoizedProps);c.componentDidUpdate(d,a.memoizedState,c.__reactInternalSnapshotBeforeUpdate)}var f=i.updateQueue;f!==null&&Sp(i,f,c);break;case 3:var v=i.updateQueue;if(v!==null){if(a=null,i.child!==null)switch(i.child.tag){case 5:a=i.child.stateNode;break;case 1:a=i.child.stateNode}Sp(i,v,a)}break;case 5:var I=i.stateNode;if(a===null&&i.flags&4){a=I;var k=i.memoizedProps;switch(i.type){case"button":case"input":case"select":case"textarea":k.autoFocus&&a.focus();break;case"img":k.src&&(a.src=k.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(i.memoizedState===null){var U=i.alternate;if(U!==null){var K=U.memoizedState;if(K!==null){var G=K.dehydrated;G!==null&&Wr(G)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(t(163))}Mt||i.flags&512&&Dh(i)}catch(W){rt(i,i.return,W)}}if(i===n){se=null;break}if(a=i.sibling,a!==null){a.return=i.return,se=a;break}se=i.return}}function Sm(n){for(;se!==null;){var i=se;if(i===n){se=null;break}var a=i.sibling;if(a!==null){a.return=i.return,se=a;break}se=i.return}}function Am(n){for(;se!==null;){var i=se;try{switch(i.tag){case 0:case 11:case 15:var a=i.return;try{lu(4,i)}catch(k){rt(i,a,k)}break;case 1:var c=i.stateNode;if(typeof c.componentDidMount=="function"){var d=i.return;try{c.componentDidMount()}catch(k){rt(i,d,k)}}var f=i.return;try{Dh(i)}catch(k){rt(i,f,k)}break;case 5:var v=i.return;try{Dh(i)}catch(k){rt(i,v,k)}}}catch(k){rt(i,i.return,k)}if(i===n){se=null;break}var I=i.sibling;if(I!==null){I.return=i.return,se=I;break}se=i.return}}var $E=Math.ceil,uu=De.ReactCurrentDispatcher,Lh=De.ReactCurrentOwner,mn=De.ReactCurrentBatchConfig,Oe=0,Tt=null,ht=null,Pt=0,an=0,to=Jr(0),_t=0,Ta=null,Xi=0,cu=0,Mh=0,Ia=null,Kt=null,bh=0,no=1/0,Tr=null,hu=!1,Fh=null,ri=null,du=!1,ii=null,fu=0,Sa=0,Uh=null,pu=-1,mu=0;function $t(){return(Oe&6)!==0?Ge():pu!==-1?pu:pu=Ge()}function si(n){return(n.mode&1)===0?1:(Oe&2)!==0&&Pt!==0?Pt&-Pt:RE.transition!==null?(mu===0&&(mu=qo()),mu):(n=Ne,n!==0||(n=window.event,n=n===void 0?16:xs(n.type)),n)}function Pn(n,i,a,c){if(50<Sa)throw Sa=0,Uh=null,Error(t(185));ji(n,a,c),((Oe&2)===0||n!==Tt)&&(n===Tt&&((Oe&2)===0&&(cu|=a),_t===4&&oi(n,Pt)),Gt(n,c),a===1&&Oe===0&&(i.mode&1)===0&&(no=Ge()+500,$l&&Zr()))}function Gt(n,i){var a=n.callbackNode;Ui(n,i);var c=ur(n,n===Tt?Pt:0);if(c===0)a!==null&&Ss(a),n.callbackNode=null,n.callbackPriority=0;else if(i=c&-c,n.callbackPriority!==i){if(a!=null&&Ss(a),i===1)n.tag===0?AE(Cm.bind(null,n)):dp(Cm.bind(null,n)),wE(function(){(Oe&6)===0&&Zr()}),a=null;else{switch(Fn(c)){case 1:a=As;break;case 4:a=Bo;break;case 16:a=Li;break;case 536870912:a=Rs;break;default:a=Li}a=Lm(a,Rm.bind(null,n))}n.callbackPriority=i,n.callbackNode=a}}function Rm(n,i){if(pu=-1,mu=0,(Oe&6)!==0)throw Error(t(327));var a=n.callbackNode;if(ro()&&n.callbackNode!==a)return null;var c=ur(n,n===Tt?Pt:0);if(c===0)return null;if((c&30)!==0||(c&n.expiredLanes)!==0||i)i=gu(n,c);else{i=c;var d=Oe;Oe|=2;var f=km();(Tt!==n||Pt!==i)&&(Tr=null,no=Ge()+500,es(n,i));do try{WE();break}catch(I){Pm(n,I)}while(!0);rh(),uu.current=f,Oe=d,ht!==null?i=0:(Tt=null,Pt=0,i=_t)}if(i!==0){if(i===2&&(d=Ho(n),d!==0&&(c=d,i=jh(n,d))),i===1)throw a=Ta,es(n,0),oi(n,c),Gt(n,Ge()),a;if(i===6)oi(n,c);else{if(d=n.current.alternate,(c&30)===0&&!HE(d)&&(i=gu(n,c),i===2&&(f=Ho(n),f!==0&&(c=f,i=jh(n,f))),i===1))throw a=Ta,es(n,0),oi(n,c),Gt(n,Ge()),a;switch(n.finishedWork=d,n.finishedLanes=c,i){case 0:case 1:throw Error(t(345));case 2:ts(n,Kt,Tr);break;case 3:if(oi(n,c),(c&130023424)===c&&(i=bh+500-Ge(),10<i)){if(ur(n,0)!==0)break;if(d=n.suspendedLanes,(d&c)!==c){$t(),n.pingedLanes|=n.suspendedLanes&d;break}n.timeoutHandle=Wc(ts.bind(null,n,Kt,Tr),i);break}ts(n,Kt,Tr);break;case 4:if(oi(n,c),(c&4194240)===c)break;for(i=n.eventTimes,d=-1;0<c;){var v=31-Zt(c);f=1<<v,v=i[v],v>d&&(d=v),c&=~f}if(c=d,c=Ge()-c,c=(120>c?120:480>c?480:1080>c?1080:1920>c?1920:3e3>c?3e3:4320>c?4320:1960*$E(c/1960))-c,10<c){n.timeoutHandle=Wc(ts.bind(null,n,Kt,Tr),c);break}ts(n,Kt,Tr);break;case 5:ts(n,Kt,Tr);break;default:throw Error(t(329))}}}return Gt(n,Ge()),n.callbackNode===a?Rm.bind(null,n):null}function jh(n,i){var a=Ia;return n.current.memoizedState.isDehydrated&&(es(n,i).flags|=256),n=gu(n,i),n!==2&&(i=Kt,Kt=a,i!==null&&zh(i)),n}function zh(n){Kt===null?Kt=n:Kt.push.apply(Kt,n)}function HE(n){for(var i=n;;){if(i.flags&16384){var a=i.updateQueue;if(a!==null&&(a=a.stores,a!==null))for(var c=0;c<a.length;c++){var d=a[c],f=d.getSnapshot;d=d.value;try{if(!In(f(),d))return!1}catch{return!1}}}if(a=i.child,i.subtreeFlags&16384&&a!==null)a.return=i,i=a;else{if(i===n)break;for(;i.sibling===null;){if(i.return===null||i.return===n)return!0;i=i.return}i.sibling.return=i.return,i=i.sibling}}return!0}function oi(n,i){for(i&=~Mh,i&=~cu,n.suspendedLanes|=i,n.pingedLanes&=~i,n=n.expirationTimes;0<i;){var a=31-Zt(i),c=1<<a;n[a]=-1,i&=~c}}function Cm(n){if((Oe&6)!==0)throw Error(t(327));ro();var i=ur(n,0);if((i&1)===0)return Gt(n,Ge()),null;var a=gu(n,i);if(n.tag!==0&&a===2){var c=Ho(n);c!==0&&(i=c,a=jh(n,c))}if(a===1)throw a=Ta,es(n,0),oi(n,i),Gt(n,Ge()),a;if(a===6)throw Error(t(345));return n.finishedWork=n.current.alternate,n.finishedLanes=i,ts(n,Kt,Tr),Gt(n,Ge()),null}function Bh(n,i){var a=Oe;Oe|=1;try{return n(i)}finally{Oe=a,Oe===0&&(no=Ge()+500,$l&&Zr())}}function Zi(n){ii!==null&&ii.tag===0&&(Oe&6)===0&&ro();var i=Oe;Oe|=1;var a=mn.transition,c=Ne;try{if(mn.transition=null,Ne=1,n)return n()}finally{Ne=c,mn.transition=a,Oe=i,(Oe&6)===0&&Zr()}}function $h(){an=to.current,Ye(to)}function es(n,i){n.finishedWork=null,n.finishedLanes=0;var a=n.timeoutHandle;if(a!==-1&&(n.timeoutHandle=-1,EE(a)),ht!==null)for(a=ht.return;a!==null;){var c=a;switch(Xc(c),c.tag){case 1:c=c.type.childContextTypes,c!=null&&zl();break;case 3:Xs(),Ye(Ht),Ye(Vt),hh();break;case 5:uh(c);break;case 4:Xs();break;case 13:Ye(Ze);break;case 19:Ye(Ze);break;case 10:ih(c.type._context);break;case 22:case 23:$h()}a=a.return}if(Tt=n,ht=n=ai(n.current,null),Pt=an=i,_t=0,Ta=null,Mh=cu=Xi=0,Kt=Ia=null,Qi!==null){for(i=0;i<Qi.length;i++)if(a=Qi[i],c=a.interleaved,c!==null){a.interleaved=null;var d=c.next,f=a.pending;if(f!==null){var v=f.next;f.next=d,c.next=v}a.pending=c}Qi=null}return n}function Pm(n,i){do{var a=ht;try{if(rh(),Zl.current=ru,eu){for(var c=et.memoizedState;c!==null;){var d=c.queue;d!==null&&(d.pending=null),c=c.next}eu=!1}if(Ji=0,wt=yt=et=null,ga=!1,ya=0,Lh.current=null,a===null||a.return===null){_t=1,Ta=i,ht=null;break}e:{var f=n,v=a.return,I=a,k=i;if(i=Pt,I.flags|=32768,k!==null&&typeof k=="object"&&typeof k.then=="function"){var U=k,K=I,G=K.tag;if((K.mode&1)===0&&(G===0||G===11||G===15)){var W=K.alternate;W?(K.updateQueue=W.updateQueue,K.memoizedState=W.memoizedState,K.lanes=W.lanes):(K.updateQueue=null,K.memoizedState=null)}var ee=Zp(v);if(ee!==null){ee.flags&=-257,em(ee,v,I,f,i),ee.mode&1&&Xp(f,U,i),i=ee,k=U;var oe=i.updateQueue;if(oe===null){var ae=new Set;ae.add(k),i.updateQueue=ae}else oe.add(k);break e}else{if((i&1)===0){Xp(f,U,i),Hh();break e}k=Error(t(426))}}else if(Xe&&I.mode&1){var ot=Zp(v);if(ot!==null){(ot.flags&65536)===0&&(ot.flags|=256),em(ot,v,I,f,i),th(Zs(k,I));break e}}f=k=Zs(k,I),_t!==4&&(_t=2),Ia===null?Ia=[f]:Ia.push(f),f=v;do{switch(f.tag){case 3:f.flags|=65536,i&=-i,f.lanes|=i;var M=Yp(f,k,i);Ip(f,M);break e;case 1:I=k;var x=f.type,F=f.stateNode;if((f.flags&128)===0&&(typeof x.getDerivedStateFromError=="function"||F!==null&&typeof F.componentDidCatch=="function"&&(ri===null||!ri.has(F)))){f.flags|=65536,i&=-i,f.lanes|=i;var J=Jp(f,I,i);Ip(f,J);break e}}f=f.return}while(f!==null)}xm(a)}catch(le){i=le,ht===a&&a!==null&&(ht=a=a.return);continue}break}while(!0)}function km(){var n=uu.current;return uu.current=ru,n===null?ru:n}function Hh(){(_t===0||_t===3||_t===2)&&(_t=4),Tt===null||(Xi&268435455)===0&&(cu&268435455)===0||oi(Tt,Pt)}function gu(n,i){var a=Oe;Oe|=2;var c=km();(Tt!==n||Pt!==i)&&(Tr=null,es(n,i));do try{qE();break}catch(d){Pm(n,d)}while(!0);if(rh(),Oe=a,uu.current=c,ht!==null)throw Error(t(261));return Tt=null,Pt=0,_t}function qE(){for(;ht!==null;)Nm(ht)}function WE(){for(;ht!==null&&!Oi();)Nm(ht)}function Nm(n){var i=Om(n.alternate,n,an);n.memoizedProps=n.pendingProps,i===null?xm(n):ht=i,Lh.current=null}function xm(n){var i=n;do{var a=i.alternate;if(n=i.return,(i.flags&32768)===0){if(a=FE(a,i,an),a!==null){ht=a;return}}else{if(a=UE(a,i),a!==null){a.flags&=32767,ht=a;return}if(n!==null)n.flags|=32768,n.subtreeFlags=0,n.deletions=null;else{_t=6,ht=null;return}}if(i=i.sibling,i!==null){ht=i;return}ht=i=n}while(i!==null);_t===0&&(_t=5)}function ts(n,i,a){var c=Ne,d=mn.transition;try{mn.transition=null,Ne=1,KE(n,i,a,c)}finally{mn.transition=d,Ne=c}return null}function KE(n,i,a,c){do ro();while(ii!==null);if((Oe&6)!==0)throw Error(t(327));a=n.finishedWork;var d=n.finishedLanes;if(a===null)return null;if(n.finishedWork=null,n.finishedLanes=0,a===n.current)throw Error(t(177));n.callbackNode=null,n.callbackPriority=0;var f=a.lanes|a.childLanes;if(Nc(n,f),n===Tt&&(ht=Tt=null,Pt=0),(a.subtreeFlags&2064)===0&&(a.flags&2064)===0||du||(du=!0,Lm(Li,function(){return ro(),null})),f=(a.flags&15990)!==0,(a.subtreeFlags&15990)!==0||f){f=mn.transition,mn.transition=null;var v=Ne;Ne=1;var I=Oe;Oe|=4,Lh.current=null,zE(n,a),wm(a,n),fE(Hc),dr=!!$c,Hc=$c=null,n.current=a,BE(a),lr(),Oe=I,Ne=v,mn.transition=f}else n.current=a;if(du&&(du=!1,ii=n,fu=d),f=n.pendingLanes,f===0&&(ri=null),Il(a.stateNode),Gt(n,Ge()),i!==null)for(c=n.onRecoverableError,a=0;a<i.length;a++)d=i[a],c(d.value,{componentStack:d.stack,digest:d.digest});if(hu)throw hu=!1,n=Fh,Fh=null,n;return(fu&1)!==0&&n.tag!==0&&ro(),f=n.pendingLanes,(f&1)!==0?n===Uh?Sa++:(Sa=0,Uh=n):Sa=0,Zr(),null}function ro(){if(ii!==null){var n=Fn(fu),i=mn.transition,a=Ne;try{if(mn.transition=null,Ne=16>n?16:n,ii===null)var c=!1;else{if(n=ii,ii=null,fu=0,(Oe&6)!==0)throw Error(t(331));var d=Oe;for(Oe|=4,se=n.current;se!==null;){var f=se,v=f.child;if((se.flags&16)!==0){var I=f.deletions;if(I!==null){for(var k=0;k<I.length;k++){var U=I[k];for(se=U;se!==null;){var K=se;switch(K.tag){case 0:case 11:case 15:wa(8,K,f)}var G=K.child;if(G!==null)G.return=K,se=G;else for(;se!==null;){K=se;var W=K.sibling,ee=K.return;if(gm(K),K===U){se=null;break}if(W!==null){W.return=ee,se=W;break}se=ee}}}var oe=f.alternate;if(oe!==null){var ae=oe.child;if(ae!==null){oe.child=null;do{var ot=ae.sibling;ae.sibling=null,ae=ot}while(ae!==null)}}se=f}}if((f.subtreeFlags&2064)!==0&&v!==null)v.return=f,se=v;else e:for(;se!==null;){if(f=se,(f.flags&2048)!==0)switch(f.tag){case 0:case 11:case 15:wa(9,f,f.return)}var M=f.sibling;if(M!==null){M.return=f.return,se=M;break e}se=f.return}}var x=n.current;for(se=x;se!==null;){v=se;var F=v.child;if((v.subtreeFlags&2064)!==0&&F!==null)F.return=v,se=F;else e:for(v=x;se!==null;){if(I=se,(I.flags&2048)!==0)try{switch(I.tag){case 0:case 11:case 15:lu(9,I)}}catch(le){rt(I,I.return,le)}if(I===v){se=null;break e}var J=I.sibling;if(J!==null){J.return=I.return,se=J;break e}se=I.return}}if(Oe=d,Zr(),Xt&&typeof Xt.onPostCommitFiberRoot=="function")try{Xt.onPostCommitFiberRoot(Mi,n)}catch{}c=!0}return c}finally{Ne=a,mn.transition=i}}return!1}function Dm(n,i,a){i=Zs(a,i),i=Yp(n,i,1),n=ti(n,i,1),i=$t(),n!==null&&(ji(n,1,i),Gt(n,i))}function rt(n,i,a){if(n.tag===3)Dm(n,n,a);else for(;i!==null;){if(i.tag===3){Dm(i,n,a);break}else if(i.tag===1){var c=i.stateNode;if(typeof i.type.getDerivedStateFromError=="function"||typeof c.componentDidCatch=="function"&&(ri===null||!ri.has(c))){n=Zs(a,n),n=Jp(i,n,1),i=ti(i,n,1),n=$t(),i!==null&&(ji(i,1,n),Gt(i,n));break}}i=i.return}}function GE(n,i,a){var c=n.pingCache;c!==null&&c.delete(i),i=$t(),n.pingedLanes|=n.suspendedLanes&a,Tt===n&&(Pt&a)===a&&(_t===4||_t===3&&(Pt&130023424)===Pt&&500>Ge()-bh?es(n,0):Mh|=a),Gt(n,i)}function Vm(n,i){i===0&&((n.mode&1)===0?i=1:(i=$r,$r<<=1,($r&130023424)===0&&($r=4194304)));var a=$t();n=vr(n,i),n!==null&&(ji(n,i,a),Gt(n,a))}function QE(n){var i=n.memoizedState,a=0;i!==null&&(a=i.retryLane),Vm(n,a)}function YE(n,i){var a=0;switch(n.tag){case 13:var c=n.stateNode,d=n.memoizedState;d!==null&&(a=d.retryLane);break;case 19:c=n.stateNode;break;default:throw Error(t(314))}c!==null&&c.delete(i),Vm(n,a)}var Om;Om=function(n,i,a){if(n!==null)if(n.memoizedProps!==i.pendingProps||Ht.current)Wt=!0;else{if((n.lanes&a)===0&&(i.flags&128)===0)return Wt=!1,bE(n,i,a);Wt=(n.flags&131072)!==0}else Wt=!1,Xe&&(i.flags&1048576)!==0&&fp(i,ql,i.index);switch(i.lanes=0,i.tag){case 2:var c=i.type;ou(n,i),n=i.pendingProps;var d=qs(i,Vt.current);Js(i,a),d=ph(null,i,c,n,d,a);var f=mh();return i.flags|=1,typeof d=="object"&&d!==null&&typeof d.render=="function"&&d.$$typeof===void 0?(i.tag=1,i.memoizedState=null,i.updateQueue=null,qt(c)?(f=!0,Bl(i)):f=!1,i.memoizedState=d.state!==null&&d.state!==void 0?d.state:null,ah(i),d.updater=iu,i.stateNode=d,d._reactInternals=i,wh(i,c,n,a),i=Ah(null,i,c,!0,f,a)):(i.tag=0,Xe&&f&&Jc(i),Bt(null,i,d,a),i=i.child),i;case 16:c=i.elementType;e:{switch(ou(n,i),n=i.pendingProps,d=c._init,c=d(c._payload),i.type=c,d=i.tag=XE(c),n=An(c,n),d){case 0:i=Sh(null,i,c,n,a);break e;case 1:i=om(null,i,c,n,a);break e;case 11:i=tm(null,i,c,n,a);break e;case 14:i=nm(null,i,c,An(c.type,n),a);break e}throw Error(t(306,c,""))}return i;case 0:return c=i.type,d=i.pendingProps,d=i.elementType===c?d:An(c,d),Sh(n,i,c,d,a);case 1:return c=i.type,d=i.pendingProps,d=i.elementType===c?d:An(c,d),om(n,i,c,d,a);case 3:e:{if(am(i),n===null)throw Error(t(387));c=i.pendingProps,f=i.memoizedState,d=f.element,Tp(n,i),Jl(i,c,null,a);var v=i.memoizedState;if(c=v.element,f.isDehydrated)if(f={element:c,isDehydrated:!1,cache:v.cache,pendingSuspenseBoundaries:v.pendingSuspenseBoundaries,transitions:v.transitions},i.updateQueue.baseState=f,i.memoizedState=f,i.flags&256){d=Zs(Error(t(423)),i),i=lm(n,i,c,a,d);break e}else if(c!==d){d=Zs(Error(t(424)),i),i=lm(n,i,c,a,d);break e}else for(on=Yr(i.stateNode.containerInfo.firstChild),sn=i,Xe=!0,Sn=null,a=Ep(i,null,c,a),i.child=a;a;)a.flags=a.flags&-3|4096,a=a.sibling;else{if(Gs(),c===d){i=wr(n,i,a);break e}Bt(n,i,c,a)}i=i.child}return i;case 5:return Ap(i),n===null&&eh(i),c=i.type,d=i.pendingProps,f=n!==null?n.memoizedProps:null,v=d.children,qc(c,d)?v=null:f!==null&&qc(c,f)&&(i.flags|=32),sm(n,i),Bt(n,i,v,a),i.child;case 6:return n===null&&eh(i),null;case 13:return um(n,i,a);case 4:return lh(i,i.stateNode.containerInfo),c=i.pendingProps,n===null?i.child=Qs(i,null,c,a):Bt(n,i,c,a),i.child;case 11:return c=i.type,d=i.pendingProps,d=i.elementType===c?d:An(c,d),tm(n,i,c,d,a);case 7:return Bt(n,i,i.pendingProps,a),i.child;case 8:return Bt(n,i,i.pendingProps.children,a),i.child;case 12:return Bt(n,i,i.pendingProps.children,a),i.child;case 10:e:{if(c=i.type._context,d=i.pendingProps,f=i.memoizedProps,v=d.value,We(Gl,c._currentValue),c._currentValue=v,f!==null)if(In(f.value,v)){if(f.children===d.children&&!Ht.current){i=wr(n,i,a);break e}}else for(f=i.child,f!==null&&(f.return=i);f!==null;){var I=f.dependencies;if(I!==null){v=f.child;for(var k=I.firstContext;k!==null;){if(k.context===c){if(f.tag===1){k=Er(-1,a&-a),k.tag=2;var U=f.updateQueue;if(U!==null){U=U.shared;var K=U.pending;K===null?k.next=k:(k.next=K.next,K.next=k),U.pending=k}}f.lanes|=a,k=f.alternate,k!==null&&(k.lanes|=a),sh(f.return,a,i),I.lanes|=a;break}k=k.next}}else if(f.tag===10)v=f.type===i.type?null:f.child;else if(f.tag===18){if(v=f.return,v===null)throw Error(t(341));v.lanes|=a,I=v.alternate,I!==null&&(I.lanes|=a),sh(v,a,i),v=f.sibling}else v=f.child;if(v!==null)v.return=f;else for(v=f;v!==null;){if(v===i){v=null;break}if(f=v.sibling,f!==null){f.return=v.return,v=f;break}v=v.return}f=v}Bt(n,i,d.children,a),i=i.child}return i;case 9:return d=i.type,c=i.pendingProps.children,Js(i,a),d=fn(d),c=c(d),i.flags|=1,Bt(n,i,c,a),i.child;case 14:return c=i.type,d=An(c,i.pendingProps),d=An(c.type,d),nm(n,i,c,d,a);case 15:return rm(n,i,i.type,i.pendingProps,a);case 17:return c=i.type,d=i.pendingProps,d=i.elementType===c?d:An(c,d),ou(n,i),i.tag=1,qt(c)?(n=!0,Bl(i)):n=!1,Js(i,a),Gp(i,c,d),wh(i,c,d,a),Ah(null,i,c,!0,n,a);case 19:return hm(n,i,a);case 22:return im(n,i,a)}throw Error(t(156,i.tag))};function Lm(n,i){return zo(n,i)}function JE(n,i,a,c){this.tag=n,this.key=a,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=i,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=c,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function gn(n,i,a,c){return new JE(n,i,a,c)}function qh(n){return n=n.prototype,!(!n||!n.isReactComponent)}function XE(n){if(typeof n=="function")return qh(n)?1:0;if(n!=null){if(n=n.$$typeof,n===L)return 11;if(n===lt)return 14}return 2}function ai(n,i){var a=n.alternate;return a===null?(a=gn(n.tag,i,n.key,n.mode),a.elementType=n.elementType,a.type=n.type,a.stateNode=n.stateNode,a.alternate=n,n.alternate=a):(a.pendingProps=i,a.type=n.type,a.flags=0,a.subtreeFlags=0,a.deletions=null),a.flags=n.flags&14680064,a.childLanes=n.childLanes,a.lanes=n.lanes,a.child=n.child,a.memoizedProps=n.memoizedProps,a.memoizedState=n.memoizedState,a.updateQueue=n.updateQueue,i=n.dependencies,a.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext},a.sibling=n.sibling,a.index=n.index,a.ref=n.ref,a}function yu(n,i,a,c,d,f){var v=2;if(c=n,typeof n=="function")qh(n)&&(v=1);else if(typeof n=="string")v=5;else e:switch(n){case C:return ns(a.children,d,f,i);case T:v=8,d|=8;break;case R:return n=gn(12,a,i,d|2),n.elementType=R,n.lanes=f,n;case A:return n=gn(13,a,i,d),n.elementType=A,n.lanes=f,n;case Be:return n=gn(19,a,i,d),n.elementType=Be,n.lanes=f,n;case $e:return _u(a,d,f,i);default:if(typeof n=="object"&&n!==null)switch(n.$$typeof){case D:v=10;break e;case N:v=9;break e;case L:v=11;break e;case lt:v=14;break e;case gt:v=16,c=null;break e}throw Error(t(130,n==null?n:typeof n,""))}return i=gn(v,a,i,d),i.elementType=n,i.type=c,i.lanes=f,i}function ns(n,i,a,c){return n=gn(7,n,c,i),n.lanes=a,n}function _u(n,i,a,c){return n=gn(22,n,c,i),n.elementType=$e,n.lanes=a,n.stateNode={isHidden:!1},n}function Wh(n,i,a){return n=gn(6,n,null,i),n.lanes=a,n}function Kh(n,i,a){return i=gn(4,n.children!==null?n.children:[],n.key,i),i.lanes=a,i.stateNode={containerInfo:n.containerInfo,pendingChildren:null,implementation:n.implementation},i}function ZE(n,i,a,c,d){this.tag=i,this.containerInfo=n,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=Wo(0),this.expirationTimes=Wo(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Wo(0),this.identifierPrefix=c,this.onRecoverableError=d,this.mutableSourceEagerHydrationData=null}function Gh(n,i,a,c,d,f,v,I,k){return n=new ZE(n,i,a,I,k),i===1?(i=1,f===!0&&(i|=8)):i=0,f=gn(3,null,null,i),n.current=f,f.stateNode=n,f.memoizedState={element:c,isDehydrated:a,cache:null,transitions:null,pendingSuspenseBoundaries:null},ah(f),n}function ew(n,i,a){var c=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:ke,key:c==null?null:""+c,children:n,containerInfo:i,implementation:a}}function Mm(n){if(!n)return Xr;n=n._reactInternals;e:{if(wn(n)!==n||n.tag!==1)throw Error(t(170));var i=n;do{switch(i.tag){case 3:i=i.stateNode.context;break e;case 1:if(qt(i.type)){i=i.stateNode.__reactInternalMemoizedMergedChildContext;break e}}i=i.return}while(i!==null);throw Error(t(171))}if(n.tag===1){var a=n.type;if(qt(a))return cp(n,a,i)}return i}function bm(n,i,a,c,d,f,v,I,k){return n=Gh(a,c,!0,n,d,f,v,I,k),n.context=Mm(null),a=n.current,c=$t(),d=si(a),f=Er(c,d),f.callback=i??null,ti(a,f,d),n.current.lanes=d,ji(n,d,c),Gt(n,c),n}function vu(n,i,a,c){var d=i.current,f=$t(),v=si(d);return a=Mm(a),i.context===null?i.context=a:i.pendingContext=a,i=Er(f,v),i.payload={element:n},c=c===void 0?null:c,c!==null&&(i.callback=c),n=ti(d,i,v),n!==null&&(Pn(n,d,v,f),Yl(n,d,v)),v}function Eu(n){if(n=n.current,!n.child)return null;switch(n.child.tag){case 5:return n.child.stateNode;default:return n.child.stateNode}}function Fm(n,i){if(n=n.memoizedState,n!==null&&n.dehydrated!==null){var a=n.retryLane;n.retryLane=a!==0&&a<i?a:i}}function Qh(n,i){Fm(n,i),(n=n.alternate)&&Fm(n,i)}function tw(){return null}var Um=typeof reportError=="function"?reportError:function(n){console.error(n)};function Yh(n){this._internalRoot=n}wu.prototype.render=Yh.prototype.render=function(n){var i=this._internalRoot;if(i===null)throw Error(t(409));vu(n,i,null,null)},wu.prototype.unmount=Yh.prototype.unmount=function(){var n=this._internalRoot;if(n!==null){this._internalRoot=null;var i=n.containerInfo;Zi(function(){vu(null,n,null,null)}),i[mr]=null}};function wu(n){this._internalRoot=n}wu.prototype.unstable_scheduleHydration=function(n){if(n){var i=Yo();n={blockedOn:null,target:n,priority:i};for(var a=0;a<en.length&&i!==0&&i<en[a].priority;a++);en.splice(a,0,n),a===0&&ks(n)}};function Jh(n){return!(!n||n.nodeType!==1&&n.nodeType!==9&&n.nodeType!==11)}function Tu(n){return!(!n||n.nodeType!==1&&n.nodeType!==9&&n.nodeType!==11&&(n.nodeType!==8||n.nodeValue!==" react-mount-point-unstable "))}function jm(){}function nw(n,i,a,c,d){if(d){if(typeof c=="function"){var f=c;c=function(){var U=Eu(v);f.call(U)}}var v=bm(i,c,n,0,null,!1,!1,"",jm);return n._reactRootContainer=v,n[mr]=v.current,la(n.nodeType===8?n.parentNode:n),Zi(),v}for(;d=n.lastChild;)n.removeChild(d);if(typeof c=="function"){var I=c;c=function(){var U=Eu(k);I.call(U)}}var k=Gh(n,0,!1,null,null,!1,!1,"",jm);return n._reactRootContainer=k,n[mr]=k.current,la(n.nodeType===8?n.parentNode:n),Zi(function(){vu(i,k,a,c)}),k}function Iu(n,i,a,c,d){var f=a._reactRootContainer;if(f){var v=f;if(typeof d=="function"){var I=d;d=function(){var k=Eu(v);I.call(k)}}vu(i,v,n,d)}else v=nw(a,i,n,d,c);return Eu(v)}Go=function(n){switch(n.tag){case 3:var i=n.stateNode;if(i.current.memoizedState.isDehydrated){var a=Me(i.pendingLanes);a!==0&&(Ko(i,a|1),Gt(i,Ge()),(Oe&6)===0&&(no=Ge()+500,Zr()))}break;case 13:Zi(function(){var c=vr(n,1);if(c!==null){var d=$t();Pn(c,n,1,d)}}),Qh(n,1)}},Cs=function(n){if(n.tag===13){var i=vr(n,134217728);if(i!==null){var a=$t();Pn(i,n,134217728,a)}Qh(n,134217728)}},Qo=function(n){if(n.tag===13){var i=si(n),a=vr(n,i);if(a!==null){var c=$t();Pn(a,n,i,c)}Qh(n,i)}},Yo=function(){return Ne},Jo=function(n,i){var a=Ne;try{return Ne=n,i()}finally{Ne=a}},sr=function(n,i,a){switch(i){case"input":if(Ni(n,a),i=a.name,a.type==="radio"&&i!=null){for(a=n;a.parentNode;)a=a.parentNode;for(a=a.querySelectorAll("input[name="+JSON.stringify(""+i)+'][type="radio"]'),i=0;i<a.length;i++){var c=a[i];if(c!==n&&c.form===n.form){var d=jl(c);if(!d)throw Error(t(90));Do(c),Ni(c,d)}}}break;case"textarea":hl(n,a);break;case"select":i=a.value,i!=null&&vn(n,!!a.multiple,i,!1)}},pl=Bh,ml=Zi;var rw={usingClientEntryPoint:!1,Events:[ha,$s,jl,Ur,jr,Bh]},Aa={findFiberByHostInstance:qi,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},iw={bundleType:Aa.bundleType,version:Aa.version,rendererPackageName:Aa.rendererPackageName,rendererConfig:Aa.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:De.ReactCurrentDispatcher,findHostInstanceByFiber:function(n){return n=Tl(n),n===null?null:n.stateNode},findFiberByHostInstance:Aa.findFiberByHostInstance||tw,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Su=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Su.isDisabled&&Su.supportsFiber)try{Mi=Su.inject(iw),Xt=Su}catch{}}return Qt.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=rw,Qt.createPortal=function(n,i){var a=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!Jh(i))throw Error(t(200));return ew(n,i,null,a)},Qt.createRoot=function(n,i){if(!Jh(n))throw Error(t(299));var a=!1,c="",d=Um;return i!=null&&(i.unstable_strictMode===!0&&(a=!0),i.identifierPrefix!==void 0&&(c=i.identifierPrefix),i.onRecoverableError!==void 0&&(d=i.onRecoverableError)),i=Gh(n,1,!1,null,null,a,!1,c,d),n[mr]=i.current,la(n.nodeType===8?n.parentNode:n),new Yh(i)},Qt.findDOMNode=function(n){if(n==null)return null;if(n.nodeType===1)return n;var i=n._reactInternals;if(i===void 0)throw typeof n.render=="function"?Error(t(188)):(n=Object.keys(n).join(","),Error(t(268,n)));return n=Tl(i),n=n===null?null:n.stateNode,n},Qt.flushSync=function(n){return Zi(n)},Qt.hydrate=function(n,i,a){if(!Tu(i))throw Error(t(200));return Iu(null,n,i,!0,a)},Qt.hydrateRoot=function(n,i,a){if(!Jh(n))throw Error(t(405));var c=a!=null&&a.hydratedSources||null,d=!1,f="",v=Um;if(a!=null&&(a.unstable_strictMode===!0&&(d=!0),a.identifierPrefix!==void 0&&(f=a.identifierPrefix),a.onRecoverableError!==void 0&&(v=a.onRecoverableError)),i=bm(i,null,n,1,a??null,d,!1,f,v),n[mr]=i.current,la(n),c)for(n=0;n<c.length;n++)a=c[n],d=a._getVersion,d=d(a._source),i.mutableSourceEagerHydrationData==null?i.mutableSourceEagerHydrationData=[a,d]:i.mutableSourceEagerHydrationData.push(a,d);return new wu(i)},Qt.render=function(n,i,a){if(!Tu(i))throw Error(t(200));return Iu(null,n,i,!1,a)},Qt.unmountComponentAtNode=function(n){if(!Tu(n))throw Error(t(40));return n._reactRootContainer?(Zi(function(){Iu(null,null,n,!1,function(){n._reactRootContainer=null,n[mr]=null})}),!0):!1},Qt.unstable_batchedUpdates=Bh,Qt.unstable_renderSubtreeIntoContainer=function(n,i,a,c){if(!Tu(a))throw Error(t(200));if(n==null||n._reactInternals===void 0)throw Error(t(38));return Iu(n,i,a,!1,c)},Qt.version="18.3.1-next-f1338f8080-20240426",Qt}var Gm;function dw(){if(Gm)return ed.exports;Gm=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(e){console.error(e)}}return r(),ed.exports=hw(),ed.exports}var Qm;function fw(){if(Qm)return Au;Qm=1;var r=dw();return Au.createRoot=r.createRoot,Au.hydrateRoot=r.hydrateRoot,Au}var pw=fw();const mw=()=>{};var Ym={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Py=function(r){const e=[];let t=0;for(let s=0;s<r.length;s++){let o=r.charCodeAt(s);o<128?e[t++]=o:o<2048?(e[t++]=o>>6|192,e[t++]=o&63|128):(o&64512)===55296&&s+1<r.length&&(r.charCodeAt(s+1)&64512)===56320?(o=65536+((o&1023)<<10)+(r.charCodeAt(++s)&1023),e[t++]=o>>18|240,e[t++]=o>>12&63|128,e[t++]=o>>6&63|128,e[t++]=o&63|128):(e[t++]=o>>12|224,e[t++]=o>>6&63|128,e[t++]=o&63|128)}return e},gw=function(r){const e=[];let t=0,s=0;for(;t<r.length;){const o=r[t++];if(o<128)e[s++]=String.fromCharCode(o);else if(o>191&&o<224){const u=r[t++];e[s++]=String.fromCharCode((o&31)<<6|u&63)}else if(o>239&&o<365){const u=r[t++],h=r[t++],m=r[t++],g=((o&7)<<18|(u&63)<<12|(h&63)<<6|m&63)-65536;e[s++]=String.fromCharCode(55296+(g>>10)),e[s++]=String.fromCharCode(56320+(g&1023))}else{const u=r[t++],h=r[t++];e[s++]=String.fromCharCode((o&15)<<12|(u&63)<<6|h&63)}}return e.join("")},ky={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(r,e){if(!Array.isArray(r))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,s=[];for(let o=0;o<r.length;o+=3){const u=r[o],h=o+1<r.length,m=h?r[o+1]:0,g=o+2<r.length,_=g?r[o+2]:0,E=u>>2,S=(u&3)<<4|m>>4;let V=(m&15)<<2|_>>6,z=_&63;g||(z=64,h||(V=64)),s.push(t[E],t[S],t[V],t[z])}return s.join("")},encodeString(r,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(r):this.encodeByteArray(Py(r),e)},decodeString(r,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(r):gw(this.decodeStringToByteArray(r,e))},decodeStringToByteArray(r,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,s=[];for(let o=0;o<r.length;){const u=t[r.charAt(o++)],m=o<r.length?t[r.charAt(o)]:0;++o;const _=o<r.length?t[r.charAt(o)]:64;++o;const S=o<r.length?t[r.charAt(o)]:64;if(++o,u==null||m==null||_==null||S==null)throw new yw;const V=u<<2|m>>4;if(s.push(V),_!==64){const z=m<<4&240|_>>2;if(s.push(z),S!==64){const Q=_<<6&192|S;s.push(Q)}}}return s},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let r=0;r<this.ENCODED_VALS.length;r++)this.byteToCharMap_[r]=this.ENCODED_VALS.charAt(r),this.charToByteMap_[this.byteToCharMap_[r]]=r,this.byteToCharMapWebSafe_[r]=this.ENCODED_VALS_WEBSAFE.charAt(r),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[r]]=r,r>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(r)]=r,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(r)]=r)}}};class yw extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const _w=function(r){const e=Py(r);return ky.encodeByteArray(e,!0)},Bu=function(r){return _w(r).replace(/\./g,"")},Ny=function(r){try{return ky.decodeString(r,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function vw(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ew=()=>vw().__FIREBASE_DEFAULTS__,ww=()=>{if(typeof process>"u"||typeof Ym>"u")return;const r=Ym.__FIREBASE_DEFAULTS__;if(r)return JSON.parse(r)},Tw=()=>{if(typeof document>"u")return;let r;try{r=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=r&&Ny(r[1]);return e&&JSON.parse(e)},uc=()=>{try{return mw()||Ew()||ww()||Tw()}catch(r){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${r}`);return}},xy=r=>{var e,t;return(t=(e=uc())==null?void 0:e.emulatorHosts)==null?void 0:t[r]},Iw=r=>{const e=xy(r);if(!e)return;const t=e.lastIndexOf(":");if(t<=0||t+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const s=parseInt(e.substring(t+1),10);return e[0]==="["?[e.substring(1,t-1),s]:[e.substring(0,t),s]},Dy=()=>{var r;return(r=uc())==null?void 0:r.config},Vy=r=>{var e;return(e=uc())==null?void 0:e[`_${r}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sw{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,s)=>{t?this.reject(t):this.resolve(s),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,s))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Aw(r,e){if(r.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const t={alg:"none",type:"JWT"},s=e||"demo-project",o=r.iat||0,u=r.sub||r.user_id;if(!u)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const h={iss:`https://securetoken.google.com/${s}`,aud:s,iat:o,exp:o+3600,auth_time:o,sub:u,user_id:u,firebase:{sign_in_provider:"custom",identities:{}},...r};return[Bu(JSON.stringify(t)),Bu(JSON.stringify(h)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jt(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function Rw(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(jt())}function Cw(){var e;const r=(e=uc())==null?void 0:e.forceEnvironment;if(r==="node")return!0;if(r==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function Pw(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function kw(){const r=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof r=="object"&&r.id!==void 0}function Nw(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function xw(){const r=jt();return r.indexOf("MSIE ")>=0||r.indexOf("Trident/")>=0}function Dw(){return!Cw()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function Vw(){try{return typeof indexedDB=="object"}catch{return!1}}function Ow(){return new Promise((r,e)=>{try{let t=!0;const s="validate-browser-context-for-indexeddb-analytics-module",o=self.indexedDB.open(s);o.onsuccess=()=>{o.result.close(),t||self.indexedDB.deleteDatabase(s),r(!0)},o.onupgradeneeded=()=>{t=!1},o.onerror=()=>{var u;e(((u=o.error)==null?void 0:u.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Lw="FirebaseError";class Nr extends Error{constructor(e,t,s){super(t),this.code=e,this.customData=s,this.name=Lw,Object.setPrototypeOf(this,Nr.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Ya.prototype.create)}}class Ya{constructor(e,t,s){this.service=e,this.serviceName=t,this.errors=s}create(e,...t){const s=t[0]||{},o=`${this.service}/${e}`,u=this.errors[e],h=u?Mw(u,s):"Error",m=`${this.serviceName}: ${h} (${o}).`;return new Nr(o,m,s)}}function Mw(r,e){return r.replace(bw,(t,s)=>{const o=e[s];return o!=null?String(o):`<${s}?>`})}const bw=/\{\$([^}]+)}/g;function Fw(r){for(const e in r)if(Object.prototype.hasOwnProperty.call(r,e))return!1;return!0}function as(r,e){if(r===e)return!0;const t=Object.keys(r),s=Object.keys(e);for(const o of t){if(!s.includes(o))return!1;const u=r[o],h=e[o];if(Jm(u)&&Jm(h)){if(!as(u,h))return!1}else if(u!==h)return!1}for(const o of s)if(!t.includes(o))return!1;return!0}function Jm(r){return r!==null&&typeof r=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ja(r){const e=[];for(const[t,s]of Object.entries(r))Array.isArray(s)?s.forEach(o=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(o))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(s));return e.length?"&"+e.join("&"):""}function Pa(r){const e={};return r.replace(/^\?/,"").split("&").forEach(s=>{if(s){const[o,u]=s.split("=");e[decodeURIComponent(o)]=decodeURIComponent(u)}}),e}function ka(r){const e=r.indexOf("?");if(!e)return"";const t=r.indexOf("#",e);return r.substring(e,t>0?t:void 0)}function Uw(r,e){const t=new jw(r,e);return t.subscribe.bind(t)}class jw{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(s=>{this.error(s)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,s){let o;if(e===void 0&&t===void 0&&s===void 0)throw new Error("Missing Observer.");zw(e,["next","error","complete"])?o=e:o={next:e,error:t,complete:s},o.next===void 0&&(o.next=rd),o.error===void 0&&(o.error=rd),o.complete===void 0&&(o.complete=rd);const u=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?o.error(this.finalError):o.complete()}catch{}}),this.observers.push(o),u}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(s){typeof console<"u"&&console.error&&console.error(s)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function zw(r,e){if(typeof r!="object"||r===null)return!1;for(const t of e)if(t in r&&typeof r[t]=="function")return!0;return!1}function rd(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Et(r){return r&&r._delegate?r._delegate:r}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xa(r){try{return(r.startsWith("http://")||r.startsWith("https://")?new URL(r).hostname:r).endsWith(".cloudworkstations.dev")}catch{return!1}}async function Oy(r){return(await fetch(r,{credentials:"include"})).ok}class ls{constructor(e,t,s){this.name=e,this.instanceFactory=t,this.type=s,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rs="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bw{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const s=new Sw;if(this.instancesDeferred.set(t,s),this.isInitialized(t)||this.shouldAutoInitialize())try{const o=this.getOrInitializeService({instanceIdentifier:t});o&&s.resolve(o)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){const t=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),s=(e==null?void 0:e.optional)??!1;if(this.isInitialized(t)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:t})}catch(o){if(s)return null;throw o}else{if(s)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(Hw(e))try{this.getOrInitializeService({instanceIdentifier:rs})}catch{}for(const[t,s]of this.instancesDeferred.entries()){const o=this.normalizeInstanceIdentifier(t);try{const u=this.getOrInitializeService({instanceIdentifier:o});s.resolve(u)}catch{}}}}clearInstance(e=rs){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=rs){return this.instances.has(e)}getOptions(e=rs){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,s=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(s))throw Error(`${this.name}(${s}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const o=this.getOrInitializeService({instanceIdentifier:s,options:t});for(const[u,h]of this.instancesDeferred.entries()){const m=this.normalizeInstanceIdentifier(u);s===m&&h.resolve(o)}return o}onInit(e,t){const s=this.normalizeInstanceIdentifier(t),o=this.onInitCallbacks.get(s)??new Set;o.add(e),this.onInitCallbacks.set(s,o);const u=this.instances.get(s);return u&&e(u,s),()=>{o.delete(e)}}invokeOnInitCallbacks(e,t){const s=this.onInitCallbacks.get(t);if(s)for(const o of s)try{o(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let s=this.instances.get(e);if(!s&&this.component&&(s=this.component.instanceFactory(this.container,{instanceIdentifier:$w(e),options:t}),this.instances.set(e,s),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(s,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,s)}catch{}return s||null}normalizeInstanceIdentifier(e=rs){return this.component?this.component.multipleInstances?e:rs:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function $w(r){return r===rs?void 0:r}function Hw(r){return r.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qw{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new Bw(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Re;(function(r){r[r.DEBUG=0]="DEBUG",r[r.VERBOSE=1]="VERBOSE",r[r.INFO=2]="INFO",r[r.WARN=3]="WARN",r[r.ERROR=4]="ERROR",r[r.SILENT=5]="SILENT"})(Re||(Re={}));const Ww={debug:Re.DEBUG,verbose:Re.VERBOSE,info:Re.INFO,warn:Re.WARN,error:Re.ERROR,silent:Re.SILENT},Kw=Re.INFO,Gw={[Re.DEBUG]:"log",[Re.VERBOSE]:"log",[Re.INFO]:"info",[Re.WARN]:"warn",[Re.ERROR]:"error"},Qw=(r,e,...t)=>{if(e<r.logLevel)return;const s=new Date().toISOString(),o=Gw[e];if(o)console[o](`[${s}]  ${r.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class zd{constructor(e){this.name=e,this._logLevel=Kw,this._logHandler=Qw,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in Re))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?Ww[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,Re.DEBUG,...e),this._logHandler(this,Re.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,Re.VERBOSE,...e),this._logHandler(this,Re.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,Re.INFO,...e),this._logHandler(this,Re.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,Re.WARN,...e),this._logHandler(this,Re.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,Re.ERROR,...e),this._logHandler(this,Re.ERROR,...e)}}const Yw=(r,e)=>e.some(t=>r instanceof t);let Xm,Zm;function Jw(){return Xm||(Xm=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Xw(){return Zm||(Zm=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Ly=new WeakMap,md=new WeakMap,My=new WeakMap,id=new WeakMap,Bd=new WeakMap;function Zw(r){const e=new Promise((t,s)=>{const o=()=>{r.removeEventListener("success",u),r.removeEventListener("error",h)},u=()=>{t(mi(r.result)),o()},h=()=>{s(r.error),o()};r.addEventListener("success",u),r.addEventListener("error",h)});return e.then(t=>{t instanceof IDBCursor&&Ly.set(t,r)}).catch(()=>{}),Bd.set(e,r),e}function eT(r){if(md.has(r))return;const e=new Promise((t,s)=>{const o=()=>{r.removeEventListener("complete",u),r.removeEventListener("error",h),r.removeEventListener("abort",h)},u=()=>{t(),o()},h=()=>{s(r.error||new DOMException("AbortError","AbortError")),o()};r.addEventListener("complete",u),r.addEventListener("error",h),r.addEventListener("abort",h)});md.set(r,e)}let gd={get(r,e,t){if(r instanceof IDBTransaction){if(e==="done")return md.get(r);if(e==="objectStoreNames")return r.objectStoreNames||My.get(r);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return mi(r[e])},set(r,e,t){return r[e]=t,!0},has(r,e){return r instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in r}};function tT(r){gd=r(gd)}function nT(r){return r===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const s=r.call(sd(this),e,...t);return My.set(s,e.sort?e.sort():[e]),mi(s)}:Xw().includes(r)?function(...e){return r.apply(sd(this),e),mi(Ly.get(this))}:function(...e){return mi(r.apply(sd(this),e))}}function rT(r){return typeof r=="function"?nT(r):(r instanceof IDBTransaction&&eT(r),Yw(r,Jw())?new Proxy(r,gd):r)}function mi(r){if(r instanceof IDBRequest)return Zw(r);if(id.has(r))return id.get(r);const e=rT(r);return e!==r&&(id.set(r,e),Bd.set(e,r)),e}const sd=r=>Bd.get(r);function iT(r,e,{blocked:t,upgrade:s,blocking:o,terminated:u}={}){const h=indexedDB.open(r,e),m=mi(h);return s&&h.addEventListener("upgradeneeded",g=>{s(mi(h.result),g.oldVersion,g.newVersion,mi(h.transaction),g)}),t&&h.addEventListener("blocked",g=>t(g.oldVersion,g.newVersion,g)),m.then(g=>{u&&g.addEventListener("close",()=>u()),o&&g.addEventListener("versionchange",_=>o(_.oldVersion,_.newVersion,_))}).catch(()=>{}),m}const sT=["get","getKey","getAll","getAllKeys","count"],oT=["put","add","delete","clear"],od=new Map;function eg(r,e){if(!(r instanceof IDBDatabase&&!(e in r)&&typeof e=="string"))return;if(od.get(e))return od.get(e);const t=e.replace(/FromIndex$/,""),s=e!==t,o=oT.includes(t);if(!(t in(s?IDBIndex:IDBObjectStore).prototype)||!(o||sT.includes(t)))return;const u=async function(h,...m){const g=this.transaction(h,o?"readwrite":"readonly");let _=g.store;return s&&(_=_.index(m.shift())),(await Promise.all([_[t](...m),o&&g.done]))[0]};return od.set(e,u),u}tT(r=>({...r,get:(e,t,s)=>eg(e,t)||r.get(e,t,s),has:(e,t)=>!!eg(e,t)||r.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class aT{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(lT(t)){const s=t.getImmediate();return`${s.library}/${s.version}`}else return null}).filter(t=>t).join(" ")}}function lT(r){const e=r.getComponent();return(e==null?void 0:e.type)==="VERSION"}const yd="@firebase/app",tg="0.14.10";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rr=new zd("@firebase/app"),uT="@firebase/app-compat",cT="@firebase/analytics-compat",hT="@firebase/analytics",dT="@firebase/app-check-compat",fT="@firebase/app-check",pT="@firebase/auth",mT="@firebase/auth-compat",gT="@firebase/database",yT="@firebase/data-connect",_T="@firebase/database-compat",vT="@firebase/functions",ET="@firebase/functions-compat",wT="@firebase/installations",TT="@firebase/installations-compat",IT="@firebase/messaging",ST="@firebase/messaging-compat",AT="@firebase/performance",RT="@firebase/performance-compat",CT="@firebase/remote-config",PT="@firebase/remote-config-compat",kT="@firebase/storage",NT="@firebase/storage-compat",xT="@firebase/firestore",DT="@firebase/ai",VT="@firebase/firestore-compat",OT="firebase",LT="12.11.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _d="[DEFAULT]",MT={[yd]:"fire-core",[uT]:"fire-core-compat",[hT]:"fire-analytics",[cT]:"fire-analytics-compat",[fT]:"fire-app-check",[dT]:"fire-app-check-compat",[pT]:"fire-auth",[mT]:"fire-auth-compat",[gT]:"fire-rtdb",[yT]:"fire-data-connect",[_T]:"fire-rtdb-compat",[vT]:"fire-fn",[ET]:"fire-fn-compat",[wT]:"fire-iid",[TT]:"fire-iid-compat",[IT]:"fire-fcm",[ST]:"fire-fcm-compat",[AT]:"fire-perf",[RT]:"fire-perf-compat",[CT]:"fire-rc",[PT]:"fire-rc-compat",[kT]:"fire-gcs",[NT]:"fire-gcs-compat",[xT]:"fire-fst",[VT]:"fire-fst-compat",[DT]:"fire-vertex","fire-js":"fire-js",[OT]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $u=new Map,bT=new Map,vd=new Map;function ng(r,e){try{r.container.addComponent(e)}catch(t){Rr.debug(`Component ${e.name} failed to register with FirebaseApp ${r.name}`,t)}}function yo(r){const e=r.name;if(vd.has(e))return Rr.debug(`There were multiple attempts to register component ${e}.`),!1;vd.set(e,r);for(const t of $u.values())ng(t,r);for(const t of bT.values())ng(t,r);return!0}function $d(r,e){const t=r.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),r.container.getProvider(e)}function yn(r){return r==null?!1:r.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const FT={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},gi=new Ya("app","Firebase",FT);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class UT{constructor(e,t,s){this._isDeleted=!1,this._options={...e},this._config={...t},this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=s,this.container.addComponent(new ls("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw gi.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ao=LT;function by(r,e={}){let t=r;typeof e!="object"&&(e={name:e});const s={name:_d,automaticDataCollectionEnabled:!0,...e},o=s.name;if(typeof o!="string"||!o)throw gi.create("bad-app-name",{appName:String(o)});if(t||(t=Dy()),!t)throw gi.create("no-options");const u=$u.get(o);if(u){if(as(t,u.options)&&as(s,u.config))return u;throw gi.create("duplicate-app",{appName:o})}const h=new qw(o);for(const g of vd.values())h.addComponent(g);const m=new UT(t,s,h);return $u.set(o,m),m}function Fy(r=_d){const e=$u.get(r);if(!e&&r===_d&&Dy())return by();if(!e)throw gi.create("no-app",{appName:r});return e}function yi(r,e,t){let s=MT[r]??r;t&&(s+=`-${t}`);const o=s.match(/\s|\//),u=e.match(/\s|\//);if(o||u){const h=[`Unable to register library "${s}" with version "${e}":`];o&&h.push(`library name "${s}" contains illegal characters (whitespace or "/")`),o&&u&&h.push("and"),u&&h.push(`version name "${e}" contains illegal characters (whitespace or "/")`),Rr.warn(h.join(" "));return}yo(new ls(`${s}-version`,()=>({library:s,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const jT="firebase-heartbeat-database",zT=1,ja="firebase-heartbeat-store";let ad=null;function Uy(){return ad||(ad=iT(jT,zT,{upgrade:(r,e)=>{switch(e){case 0:try{r.createObjectStore(ja)}catch(t){console.warn(t)}}}}).catch(r=>{throw gi.create("idb-open",{originalErrorMessage:r.message})})),ad}async function BT(r){try{const t=(await Uy()).transaction(ja),s=await t.objectStore(ja).get(jy(r));return await t.done,s}catch(e){if(e instanceof Nr)Rr.warn(e.message);else{const t=gi.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});Rr.warn(t.message)}}}async function rg(r,e){try{const s=(await Uy()).transaction(ja,"readwrite");await s.objectStore(ja).put(e,jy(r)),await s.done}catch(t){if(t instanceof Nr)Rr.warn(t.message);else{const s=gi.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});Rr.warn(s.message)}}}function jy(r){return`${r.name}!${r.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $T=1024,HT=30;class qT{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new KT(t),this._heartbeatsCachePromise=this._storage.read().then(s=>(this._heartbeatsCache=s,s))}async triggerHeartbeat(){var e,t;try{const o=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),u=ig();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===u||this._heartbeatsCache.heartbeats.some(h=>h.date===u))return;if(this._heartbeatsCache.heartbeats.push({date:u,agent:o}),this._heartbeatsCache.heartbeats.length>HT){const h=GT(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(h,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(s){Rr.warn(s)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=ig(),{heartbeatsToSend:s,unsentEntries:o}=WT(this._heartbeatsCache.heartbeats),u=Bu(JSON.stringify({version:2,heartbeats:s}));return this._heartbeatsCache.lastSentHeartbeatDate=t,o.length>0?(this._heartbeatsCache.heartbeats=o,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),u}catch(t){return Rr.warn(t),""}}}function ig(){return new Date().toISOString().substring(0,10)}function WT(r,e=$T){const t=[];let s=r.slice();for(const o of r){const u=t.find(h=>h.agent===o.agent);if(u){if(u.dates.push(o.date),sg(t)>e){u.dates.pop();break}}else if(t.push({agent:o.agent,dates:[o.date]}),sg(t)>e){t.pop();break}s=s.slice(1)}return{heartbeatsToSend:t,unsentEntries:s}}class KT{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return Vw()?Ow().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await BT(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const s=await this.read();return rg(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??s.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const s=await this.read();return rg(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??s.lastSentHeartbeatDate,heartbeats:[...s.heartbeats,...e.heartbeats]})}else return}}function sg(r){return Bu(JSON.stringify({version:2,heartbeats:r})).length}function GT(r){if(r.length===0)return-1;let e=0,t=r[0].date;for(let s=1;s<r.length;s++)r[s].date<t&&(t=r[s].date,e=s);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function QT(r){yo(new ls("platform-logger",e=>new aT(e),"PRIVATE")),yo(new ls("heartbeat",e=>new qT(e),"PRIVATE")),yi(yd,tg,r),yi(yd,tg,"esm2020"),yi("fire-js","")}QT("");var YT="firebase",JT="12.11.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */yi(YT,JT,"app");function zy(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const XT=zy,By=new Ya("auth","Firebase",zy());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hu=new zd("@firebase/auth");function ZT(r,...e){Hu.logLevel<=Re.WARN&&Hu.warn(`Auth (${Ao}): ${r}`,...e)}function Du(r,...e){Hu.logLevel<=Re.ERROR&&Hu.error(`Auth (${Ao}): ${r}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Dn(r,...e){throw Hd(r,...e)}function Zn(r,...e){return Hd(r,...e)}function $y(r,e,t){const s={...XT(),[e]:t};return new Ya("auth","Firebase",s).create(e,{appName:r.name})}function Ar(r){return $y(r,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function Hd(r,...e){if(typeof r!="string"){const t=e[0],s=[...e.slice(1)];return s[0]&&(s[0].appName=r.name),r._errorFactory.create(t,...s)}return By.create(r,...e)}function fe(r,e,...t){if(!r)throw Hd(e,...t)}function Ir(r){const e="INTERNAL ASSERTION FAILED: "+r;throw Du(e),new Error(e)}function Cr(r,e){r||Ir(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ed(){var r;return typeof self<"u"&&((r=self.location)==null?void 0:r.href)||""}function eI(){return og()==="http:"||og()==="https:"}function og(){var r;return typeof self<"u"&&((r=self.location)==null?void 0:r.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tI(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(eI()||kw()||"connection"in navigator)?navigator.onLine:!0}function nI(){if(typeof navigator>"u")return null;const r=navigator;return r.languages&&r.languages[0]||r.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Za{constructor(e,t){this.shortDelay=e,this.longDelay=t,Cr(t>e,"Short delay should be less than long delay!"),this.isMobile=Rw()||Nw()}get(){return tI()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qd(r,e){Cr(r.emulator,"Emulator should always be set here");const{url:t}=r.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hy{static initialize(e,t,s){this.fetchImpl=e,t&&(this.headersImpl=t),s&&(this.responseImpl=s)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;Ir("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;Ir("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;Ir("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rI={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const iI=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],sI=new Za(3e4,6e4);function xr(r,e){return r.tenantId&&!e.tenantId?{...e,tenantId:r.tenantId}:e}async function Dr(r,e,t,s,o={}){return qy(r,o,async()=>{let u={},h={};s&&(e==="GET"?h=s:u={body:JSON.stringify(s)});const m=Ja({key:r.config.apiKey,...h}).slice(1),g=await r._getAdditionalHeaders();g["Content-Type"]="application/json",r.languageCode&&(g["X-Firebase-Locale"]=r.languageCode);const _={method:e,headers:g,...u};return Pw()||(_.referrerPolicy="no-referrer"),r.emulatorConfig&&Xa(r.emulatorConfig.host)&&(_.credentials="include"),Hy.fetch()(await Wy(r,r.config.apiHost,t,m),_)})}async function qy(r,e,t){r._canInitEmulator=!1;const s={...rI,...e};try{const o=new aI(r),u=await Promise.race([t(),o.promise]);o.clearNetworkTimeout();const h=await u.json();if("needConfirmation"in h)throw Ru(r,"account-exists-with-different-credential",h);if(u.ok&&!("errorMessage"in h))return h;{const m=u.ok?h.errorMessage:h.error.message,[g,_]=m.split(" : ");if(g==="FEDERATED_USER_ID_ALREADY_LINKED")throw Ru(r,"credential-already-in-use",h);if(g==="EMAIL_EXISTS")throw Ru(r,"email-already-in-use",h);if(g==="USER_DISABLED")throw Ru(r,"user-disabled",h);const E=s[g]||g.toLowerCase().replace(/[_\s]+/g,"-");if(_)throw $y(r,E,_);Dn(r,E)}}catch(o){if(o instanceof Nr)throw o;Dn(r,"network-request-failed",{message:String(o)})}}async function el(r,e,t,s,o={}){const u=await Dr(r,e,t,s,o);return"mfaPendingCredential"in u&&Dn(r,"multi-factor-auth-required",{_serverResponse:u}),u}async function Wy(r,e,t,s){const o=`${e}${t}?${s}`,u=r,h=u.config.emulator?qd(r.config,o):`${r.config.apiScheme}://${o}`;return iI.includes(t)&&(await u._persistenceManagerAvailable,u._getPersistenceType()==="COOKIE")?u._getPersistence()._getFinalTarget(h).toString():h}function oI(r){switch(r){case"ENFORCE":return"ENFORCE";case"AUDIT":return"AUDIT";case"OFF":return"OFF";default:return"ENFORCEMENT_STATE_UNSPECIFIED"}}class aI{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,s)=>{this.timer=setTimeout(()=>s(Zn(this.auth,"network-request-failed")),sI.get())})}}function Ru(r,e,t){const s={appName:r.name};t.email&&(s.email=t.email),t.phoneNumber&&(s.phoneNumber=t.phoneNumber);const o=Zn(r,e,s);return o.customData._tokenResponse=t,o}function ag(r){return r!==void 0&&r.enterprise!==void 0}class lI{constructor(e){if(this.siteKey="",this.recaptchaEnforcementState=[],e.recaptchaKey===void 0)throw new Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.recaptchaEnforcementState=e.recaptchaEnforcementState}getProviderEnforcementState(e){if(!this.recaptchaEnforcementState||this.recaptchaEnforcementState.length===0)return null;for(const t of this.recaptchaEnforcementState)if(t.provider&&t.provider===e)return oI(t.enforcementState);return null}isProviderEnabled(e){return this.getProviderEnforcementState(e)==="ENFORCE"||this.getProviderEnforcementState(e)==="AUDIT"}isAnyProviderEnabled(){return this.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")||this.isProviderEnabled("PHONE_PROVIDER")}}async function uI(r,e){return Dr(r,"GET","/v2/recaptchaConfig",xr(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function cI(r,e){return Dr(r,"POST","/v1/accounts:delete",e)}async function qu(r,e){return Dr(r,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Oa(r){if(r)try{const e=new Date(Number(r));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function hI(r,e=!1){const t=Et(r),s=await t.getIdToken(e),o=Wd(s);fe(o&&o.exp&&o.auth_time&&o.iat,t.auth,"internal-error");const u=typeof o.firebase=="object"?o.firebase:void 0,h=u==null?void 0:u.sign_in_provider;return{claims:o,token:s,authTime:Oa(ld(o.auth_time)),issuedAtTime:Oa(ld(o.iat)),expirationTime:Oa(ld(o.exp)),signInProvider:h||null,signInSecondFactor:(u==null?void 0:u.sign_in_second_factor)||null}}function ld(r){return Number(r)*1e3}function Wd(r){const[e,t,s]=r.split(".");if(e===void 0||t===void 0||s===void 0)return Du("JWT malformed, contained fewer than 3 sections"),null;try{const o=Ny(t);return o?JSON.parse(o):(Du("Failed to decode base64 JWT payload"),null)}catch(o){return Du("Caught error parsing JWT payload as JSON",o==null?void 0:o.toString()),null}}function lg(r){const e=Wd(r);return fe(e,"internal-error"),fe(typeof e.exp<"u","internal-error"),fe(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function za(r,e,t=!1){if(t)return e;try{return await e}catch(s){throw s instanceof Nr&&dI(s)&&r.auth.currentUser===r&&await r.auth.signOut(),s}}function dI({code:r}){return r==="auth/user-disabled"||r==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fI{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){if(e){const t=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),t}else{this.errorBackoff=3e4;const s=(this.user.stsTokenManager.expirationTime??0)-Date.now()-3e5;return Math.max(0,s)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wd{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=Oa(this.lastLoginAt),this.creationTime=Oa(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Wu(r){var S;const e=r.auth,t=await r.getIdToken(),s=await za(r,qu(e,{idToken:t}));fe(s==null?void 0:s.users.length,e,"internal-error");const o=s.users[0];r._notifyReloadListener(o);const u=(S=o.providerUserInfo)!=null&&S.length?Ky(o.providerUserInfo):[],h=mI(r.providerData,u),m=r.isAnonymous,g=!(r.email&&o.passwordHash)&&!(h!=null&&h.length),_=m?g:!1,E={uid:o.localId,displayName:o.displayName||null,photoURL:o.photoUrl||null,email:o.email||null,emailVerified:o.emailVerified||!1,phoneNumber:o.phoneNumber||null,tenantId:o.tenantId||null,providerData:h,metadata:new wd(o.createdAt,o.lastLoginAt),isAnonymous:_};Object.assign(r,E)}async function pI(r){const e=Et(r);await Wu(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function mI(r,e){return[...r.filter(s=>!e.some(o=>o.providerId===s.providerId)),...e]}function Ky(r){return r.map(({providerId:e,...t})=>({providerId:e,uid:t.rawId||"",displayName:t.displayName||null,email:t.email||null,phoneNumber:t.phoneNumber||null,photoURL:t.photoUrl||null}))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function gI(r,e){const t=await qy(r,{},async()=>{const s=Ja({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:o,apiKey:u}=r.config,h=await Wy(r,o,"/v1/token",`key=${u}`),m=await r._getAdditionalHeaders();m["Content-Type"]="application/x-www-form-urlencoded";const g={method:"POST",headers:m,body:s};return r.emulatorConfig&&Xa(r.emulatorConfig.host)&&(g.credentials="include"),Hy.fetch()(h,g)});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function yI(r,e){return Dr(r,"POST","/v2/accounts:revokeToken",xr(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uo{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){fe(e.idToken,"internal-error"),fe(typeof e.idToken<"u","internal-error"),fe(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):lg(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){fe(e.length!==0,"internal-error");const t=lg(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(fe(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:s,refreshToken:o,expiresIn:u}=await gI(e,t);this.updateTokensAndExpiration(s,o,Number(u))}updateTokensAndExpiration(e,t,s){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+s*1e3}static fromJSON(e,t){const{refreshToken:s,accessToken:o,expirationTime:u}=t,h=new uo;return s&&(fe(typeof s=="string","internal-error",{appName:e}),h.refreshToken=s),o&&(fe(typeof o=="string","internal-error",{appName:e}),h.accessToken=o),u&&(fe(typeof u=="number","internal-error",{appName:e}),h.expirationTime=u),h}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new uo,this.toJSON())}_performRefresh(){return Ir("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ui(r,e){fe(typeof r=="string"||typeof r>"u","internal-error",{appName:e})}class kn{constructor({uid:e,auth:t,stsTokenManager:s,...o}){this.providerId="firebase",this.proactiveRefresh=new fI(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=e,this.auth=t,this.stsTokenManager=s,this.accessToken=s.accessToken,this.displayName=o.displayName||null,this.email=o.email||null,this.emailVerified=o.emailVerified||!1,this.phoneNumber=o.phoneNumber||null,this.photoURL=o.photoURL||null,this.isAnonymous=o.isAnonymous||!1,this.tenantId=o.tenantId||null,this.providerData=o.providerData?[...o.providerData]:[],this.metadata=new wd(o.createdAt||void 0,o.lastLoginAt||void 0)}async getIdToken(e){const t=await za(this,this.stsTokenManager.getToken(this.auth,e));return fe(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return hI(this,e)}reload(){return pI(this)}_assign(e){this!==e&&(fe(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>({...t})),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new kn({...this,auth:e,stsTokenManager:this.stsTokenManager._clone()});return t.metadata._copy(this.metadata),t}_onReload(e){fe(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let s=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),s=!0),t&&await Wu(this),await this.auth._persistUserIfCurrent(this),s&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(yn(this.auth.app))return Promise.reject(Ar(this.auth));const e=await this.getIdToken();return await za(this,cI(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return{uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>({...e})),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId,...this.metadata.toJSON(),apiKey:this.auth.config.apiKey,appName:this.auth.name}}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){const s=t.displayName??void 0,o=t.email??void 0,u=t.phoneNumber??void 0,h=t.photoURL??void 0,m=t.tenantId??void 0,g=t._redirectEventId??void 0,_=t.createdAt??void 0,E=t.lastLoginAt??void 0,{uid:S,emailVerified:V,isAnonymous:z,providerData:Q,stsTokenManager:Y}=t;fe(S&&Y,e,"internal-error");const H=uo.fromJSON(this.name,Y);fe(typeof S=="string",e,"internal-error"),ui(s,e.name),ui(o,e.name),fe(typeof V=="boolean",e,"internal-error"),fe(typeof z=="boolean",e,"internal-error"),ui(u,e.name),ui(h,e.name),ui(m,e.name),ui(g,e.name),ui(_,e.name),ui(E,e.name);const ie=new kn({uid:S,auth:e,email:o,emailVerified:V,displayName:s,isAnonymous:z,photoURL:h,phoneNumber:u,tenantId:m,stsTokenManager:H,createdAt:_,lastLoginAt:E});return Q&&Array.isArray(Q)&&(ie.providerData=Q.map(ge=>({...ge}))),g&&(ie._redirectEventId=g),ie}static async _fromIdTokenResponse(e,t,s=!1){const o=new uo;o.updateFromServerResponse(t);const u=new kn({uid:t.localId,auth:e,stsTokenManager:o,isAnonymous:s});return await Wu(u),u}static async _fromGetAccountInfoResponse(e,t,s){const o=t.users[0];fe(o.localId!==void 0,"internal-error");const u=o.providerUserInfo!==void 0?Ky(o.providerUserInfo):[],h=!(o.email&&o.passwordHash)&&!(u!=null&&u.length),m=new uo;m.updateFromIdToken(s);const g=new kn({uid:o.localId,auth:e,stsTokenManager:m,isAnonymous:h}),_={uid:o.localId,displayName:o.displayName||null,photoURL:o.photoUrl||null,email:o.email||null,emailVerified:o.emailVerified||!1,phoneNumber:o.phoneNumber||null,tenantId:o.tenantId||null,providerData:u,metadata:new wd(o.createdAt,o.lastLoginAt),isAnonymous:!(o.email&&o.passwordHash)&&!(u!=null&&u.length)};return Object.assign(g,_),g}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ug=new Map;function Sr(r){Cr(r instanceof Function,"Expected a class definition");let e=ug.get(r);return e?(Cr(e instanceof r,"Instance stored in cache mismatched with class"),e):(e=new r,ug.set(r,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gy{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}Gy.type="NONE";const cg=Gy;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vu(r,e,t){return`firebase:${r}:${e}:${t}`}class co{constructor(e,t,s){this.persistence=e,this.auth=t,this.userKey=s;const{config:o,name:u}=this.auth;this.fullUserKey=Vu(this.userKey,o.apiKey,u),this.fullPersistenceKey=Vu("persistence",o.apiKey,u),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const t=await qu(this.auth,{idToken:e}).catch(()=>{});return t?kn._fromGetAccountInfoResponse(this.auth,t,e):null}return kn._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,s="authUser"){if(!t.length)return new co(Sr(cg),e,s);const o=(await Promise.all(t.map(async _=>{if(await _._isAvailable())return _}))).filter(_=>_);let u=o[0]||Sr(cg);const h=Vu(s,e.config.apiKey,e.name);let m=null;for(const _ of t)try{const E=await _._get(h);if(E){let S;if(typeof E=="string"){const V=await qu(e,{idToken:E}).catch(()=>{});if(!V)break;S=await kn._fromGetAccountInfoResponse(e,V,E)}else S=kn._fromJSON(e,E);_!==u&&(m=S),u=_;break}}catch{}const g=o.filter(_=>_._shouldAllowMigration);return!u._shouldAllowMigration||!g.length?new co(u,e,s):(u=g[0],m&&await u._set(h,m.toJSON()),await Promise.all(t.map(async _=>{if(_!==u)try{await _._remove(h)}catch{}})),new co(u,e,s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hg(r){const e=r.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(Xy(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(Qy(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(e_(e))return"Blackberry";if(t_(e))return"Webos";if(Yy(e))return"Safari";if((e.includes("chrome/")||Jy(e))&&!e.includes("edge/"))return"Chrome";if(Zy(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,s=r.match(t);if((s==null?void 0:s.length)===2)return s[1]}return"Other"}function Qy(r=jt()){return/firefox\//i.test(r)}function Yy(r=jt()){const e=r.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function Jy(r=jt()){return/crios\//i.test(r)}function Xy(r=jt()){return/iemobile/i.test(r)}function Zy(r=jt()){return/android/i.test(r)}function e_(r=jt()){return/blackberry/i.test(r)}function t_(r=jt()){return/webos/i.test(r)}function Kd(r=jt()){return/iphone|ipad|ipod/i.test(r)||/macintosh/i.test(r)&&/mobile/i.test(r)}function _I(r=jt()){var e;return Kd(r)&&!!((e=window.navigator)!=null&&e.standalone)}function vI(){return xw()&&document.documentMode===10}function n_(r=jt()){return Kd(r)||Zy(r)||t_(r)||e_(r)||/windows phone/i.test(r)||Xy(r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function r_(r,e=[]){let t;switch(r){case"Browser":t=hg(jt());break;case"Worker":t=`${hg(jt())}-${r}`;break;default:t=r}const s=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${Ao}/${s}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class EI{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const s=u=>new Promise((h,m)=>{try{const g=e(u);h(g)}catch(g){m(g)}});s.onAbort=t,this.queue.push(s);const o=this.queue.length-1;return()=>{this.queue[o]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const s of this.queue)await s(e),s.onAbort&&t.push(s.onAbort)}catch(s){t.reverse();for(const o of t)try{o()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:s==null?void 0:s.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function wI(r,e={}){return Dr(r,"GET","/v2/passwordPolicy",xr(r,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const TI=6;class II{constructor(e){var s;const t=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=t.minPasswordLength??TI,t.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=t.maxPasswordLength),t.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=t.containsLowercaseCharacter),t.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=t.containsUppercaseCharacter),t.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=t.containsNumericCharacter),t.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=t.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=((s=e.allowedNonAlphanumericCharacters)==null?void 0:s.join(""))??"",this.forceUpgradeOnSignin=e.forceUpgradeOnSignin??!1,this.schemaVersion=e.schemaVersion}validatePassword(e){const t={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,t),this.validatePasswordCharacterOptions(e,t),t.isValid&&(t.isValid=t.meetsMinPasswordLength??!0),t.isValid&&(t.isValid=t.meetsMaxPasswordLength??!0),t.isValid&&(t.isValid=t.containsLowercaseLetter??!0),t.isValid&&(t.isValid=t.containsUppercaseLetter??!0),t.isValid&&(t.isValid=t.containsNumericCharacter??!0),t.isValid&&(t.isValid=t.containsNonAlphanumericCharacter??!0),t}validatePasswordLengthOptions(e,t){const s=this.customStrengthOptions.minPasswordLength,o=this.customStrengthOptions.maxPasswordLength;s&&(t.meetsMinPasswordLength=e.length>=s),o&&(t.meetsMaxPasswordLength=e.length<=o)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let s;for(let o=0;o<e.length;o++)s=e.charAt(o),this.updatePasswordCharacterOptionsStatuses(t,s>="a"&&s<="z",s>="A"&&s<="Z",s>="0"&&s<="9",this.allowedNonAlphanumericCharacters.includes(s))}updatePasswordCharacterOptionsStatuses(e,t,s,o,u){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=s)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=o)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=u))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class SI{constructor(e,t,s,o){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=s,this.config=o,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new dg(this),this.idTokenSubscription=new dg(this),this.beforeStateQueue=new EI(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=By,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=o.sdkClientVersion,this._persistenceManagerAvailable=new Promise(u=>this._resolvePersistenceManagerAvailable=u)}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=Sr(t)),this._initializationPromise=this.queue(async()=>{var s,o,u;if(!this._deleted&&(this.persistenceManager=await co.create(this,e),(s=this._resolvePersistenceManagerAvailable)==null||s.call(this),!this._deleted)){if((o=this._popupRedirectResolver)!=null&&o._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((u=this.currentUser)==null?void 0:u.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await qu(this,{idToken:e}),s=await kn._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(s)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var u;if(yn(this.app)){const h=this.app.settings.authIdToken;return h?new Promise(m=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(h).then(m,m))}):this.directlySetCurrentUser(null)}const t=await this.assertedPersistence.getCurrentUser();let s=t,o=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const h=(u=this.redirectUser)==null?void 0:u._redirectEventId,m=s==null?void 0:s._redirectEventId,g=await this.tryRedirectSignIn(e);(!h||h===m)&&(g!=null&&g.user)&&(s=g.user,o=!0)}if(!s)return this.directlySetCurrentUser(null);if(!s._redirectEventId){if(o)try{await this.beforeStateQueue.runMiddleware(s)}catch(h){s=t,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(h))}return s?this.reloadAndSetCurrentUserOrClear(s):this.directlySetCurrentUser(null)}return fe(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===s._redirectEventId?this.directlySetCurrentUser(s):this.reloadAndSetCurrentUserOrClear(s)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await Wu(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=nI()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(yn(this.app))return Promise.reject(Ar(this));const t=e?Et(e):null;return t&&fe(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&fe(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return yn(this.app)?Promise.reject(Ar(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return yn(this.app)?Promise.reject(Ar(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(Sr(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await wI(this),t=new II(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new Ya("auth","Firebase",e())}onAuthStateChanged(e,t,s){return this.registerStateListener(this.authStateSubscription,e,t,s)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,s){return this.registerStateListener(this.idTokenSubscription,e,t,s)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const s=this.onAuthStateChanged(()=>{s(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),s={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(s.tenantId=this.tenantId),await yI(this,s)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)==null?void 0:e.toJSON()}}async _setRedirectUser(e,t){const s=await this.getOrInitRedirectPersistenceManager(t);return e===null?s.removeCurrentUser():s.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&Sr(e)||this._popupRedirectResolver;fe(t,this,"argument-error"),this.redirectPersistenceManager=await co.create(this,[Sr(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,s;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)==null?void 0:t._redirectEventId)===e?this._currentUser:((s=this.redirectUser)==null?void 0:s._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const e=((t=this.currentUser)==null?void 0:t.uid)??null;this.lastNotifiedUid!==e&&(this.lastNotifiedUid=e,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,s,o){if(this._deleted)return()=>{};const u=typeof t=="function"?t:t.next.bind(t);let h=!1;const m=this._isInitialized?Promise.resolve():this._initializationPromise;if(fe(m,this,"internal-error"),m.then(()=>{h||u(this.currentUser)}),typeof t=="function"){const g=e.addObserver(t,s,o);return()=>{h=!0,g()}}else{const g=e.addObserver(t);return()=>{h=!0,g()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return fe(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=r_(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var o;const e={"X-Client-Version":this.clientVersion};this.app.options.appId&&(e["X-Firebase-gmpid"]=this.app.options.appId);const t=await((o=this.heartbeatServiceProvider.getImmediate({optional:!0}))==null?void 0:o.getHeartbeatsHeader());t&&(e["X-Firebase-Client"]=t);const s=await this._getAppCheckToken();return s&&(e["X-Firebase-AppCheck"]=s),e}async _getAppCheckToken(){var t;if(yn(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const e=await((t=this.appCheckServiceProvider.getImmediate({optional:!0}))==null?void 0:t.getToken());return e!=null&&e.error&&ZT(`Error while retrieving App Check token: ${e.error}`),e==null?void 0:e.token}}function Ci(r){return Et(r)}class dg{constructor(e){this.auth=e,this.observer=null,this.addObserver=Uw(t=>this.observer=t)}get next(){return fe(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let cc={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function AI(r){cc=r}function i_(r){return cc.loadJS(r)}function RI(){return cc.recaptchaEnterpriseScript}function CI(){return cc.gapiScript}function PI(r){return`__${r}${Math.floor(Math.random()*1e6)}`}class kI{constructor(){this.enterprise=new NI}ready(e){e()}execute(e,t){return Promise.resolve("token")}render(e,t){return""}}class NI{ready(e){e()}execute(e,t){return Promise.resolve("token")}render(e,t){return""}}const xI="recaptcha-enterprise",s_="NO_RECAPTCHA";class DI{constructor(e){this.type=xI,this.auth=Ci(e)}async verify(e="verify",t=!1){async function s(u){if(!t){if(u.tenantId==null&&u._agentRecaptchaConfig!=null)return u._agentRecaptchaConfig.siteKey;if(u.tenantId!=null&&u._tenantRecaptchaConfigs[u.tenantId]!==void 0)return u._tenantRecaptchaConfigs[u.tenantId].siteKey}return new Promise(async(h,m)=>{uI(u,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(g=>{if(g.recaptchaKey===void 0)m(new Error("recaptcha Enterprise site key undefined"));else{const _=new lI(g);return u.tenantId==null?u._agentRecaptchaConfig=_:u._tenantRecaptchaConfigs[u.tenantId]=_,h(_.siteKey)}}).catch(g=>{m(g)})})}function o(u,h,m){const g=window.grecaptcha;ag(g)?g.enterprise.ready(()=>{g.enterprise.execute(u,{action:e}).then(_=>{h(_)}).catch(()=>{h(s_)})}):m(Error("No reCAPTCHA enterprise script loaded."))}return this.auth.settings.appVerificationDisabledForTesting?new kI().execute("siteKey",{action:"verify"}):new Promise((u,h)=>{s(this.auth).then(m=>{if(!t&&ag(window.grecaptcha))o(m,u,h);else{if(typeof window>"u"){h(new Error("RecaptchaVerifier is only supported in browser"));return}let g=RI();g.length!==0&&(g+=m),i_(g).then(()=>{o(m,u,h)}).catch(_=>{h(_)})}}).catch(m=>{h(m)})})}}async function fg(r,e,t,s=!1,o=!1){const u=new DI(r);let h;if(o)h=s_;else try{h=await u.verify(t)}catch{h=await u.verify(t,!0)}const m={...e};if(t==="mfaSmsEnrollment"||t==="mfaSmsSignIn"){if("phoneEnrollmentInfo"in m){const g=m.phoneEnrollmentInfo.phoneNumber,_=m.phoneEnrollmentInfo.recaptchaToken;Object.assign(m,{phoneEnrollmentInfo:{phoneNumber:g,recaptchaToken:_,captchaResponse:h,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}else if("phoneSignInInfo"in m){const g=m.phoneSignInInfo.recaptchaToken;Object.assign(m,{phoneSignInInfo:{recaptchaToken:g,captchaResponse:h,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}return m}return s?Object.assign(m,{captchaResp:h}):Object.assign(m,{captchaResponse:h}),Object.assign(m,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(m,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),m}async function Ku(r,e,t,s,o){var u;if((u=r._getRecaptchaConfig())!=null&&u.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")){const h=await fg(r,e,t,t==="getOobCode");return s(r,h)}else return s(r,e).catch(async h=>{if(h.code==="auth/missing-recaptcha-token"){console.log(`${t} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);const m=await fg(r,e,t,t==="getOobCode");return s(r,m)}else return Promise.reject(h)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function VI(r,e){const t=$d(r,"auth");if(t.isInitialized()){const o=t.getImmediate(),u=t.getOptions();if(as(u,e??{}))return o;Dn(o,"already-initialized")}return t.initialize({options:e})}function OI(r,e){const t=(e==null?void 0:e.persistence)||[],s=(Array.isArray(t)?t:[t]).map(Sr);e!=null&&e.errorMap&&r._updateErrorMap(e.errorMap),r._initializeWithPersistence(s,e==null?void 0:e.popupRedirectResolver)}function LI(r,e,t){const s=Ci(r);fe(/^https?:\/\//.test(e),s,"invalid-emulator-scheme");const o=!1,u=o_(e),{host:h,port:m}=MI(e),g=m===null?"":`:${m}`,_={url:`${u}//${h}${g}/`},E=Object.freeze({host:h,port:m,protocol:u.replace(":",""),options:Object.freeze({disableWarnings:o})});if(!s._canInitEmulator){fe(s.config.emulator&&s.emulatorConfig,s,"emulator-config-failed"),fe(as(_,s.config.emulator)&&as(E,s.emulatorConfig),s,"emulator-config-failed");return}s.config.emulator=_,s.emulatorConfig=E,s.settings.appVerificationDisabledForTesting=!0,Xa(h)?Oy(`${u}//${h}${g}`):bI()}function o_(r){const e=r.indexOf(":");return e<0?"":r.substr(0,e+1)}function MI(r){const e=o_(r),t=/(\/\/)?([^?#/]+)/.exec(r.substr(e.length));if(!t)return{host:"",port:null};const s=t[2].split("@").pop()||"",o=/^(\[[^\]]+\])(:|$)/.exec(s);if(o){const u=o[1];return{host:u,port:pg(s.substr(u.length+1))}}else{const[u,h]=s.split(":");return{host:u,port:pg(h)}}}function pg(r){if(!r)return null;const e=Number(r);return isNaN(e)?null:e}function bI(){function r(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",r):r())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gd{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return Ir("not implemented")}_getIdTokenResponse(e){return Ir("not implemented")}_linkToIdToken(e,t){return Ir("not implemented")}_getReauthenticationResolver(e){return Ir("not implemented")}}async function FI(r,e){return Dr(r,"POST","/v1/accounts:signUp",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function UI(r,e){return el(r,"POST","/v1/accounts:signInWithPassword",xr(r,e))}async function jI(r,e){return Dr(r,"POST","/v1/accounts:sendOobCode",xr(r,e))}async function zI(r,e){return jI(r,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function BI(r,e){return el(r,"POST","/v1/accounts:signInWithEmailLink",xr(r,e))}async function $I(r,e){return el(r,"POST","/v1/accounts:signInWithEmailLink",xr(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ba extends Gd{constructor(e,t,s,o=null){super("password",s),this._email=e,this._password=t,this._tenantId=o}static _fromEmailAndPassword(e,t){return new Ba(e,t,"password")}static _fromEmailAndCode(e,t,s=null){return new Ba(e,t,"emailLink",s)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e;if(t!=null&&t.email&&(t!=null&&t.password)){if(t.signInMethod==="password")return this._fromEmailAndPassword(t.email,t.password);if(t.signInMethod==="emailLink")return this._fromEmailAndCode(t.email,t.password,t.tenantId)}return null}async _getIdTokenResponse(e){switch(this.signInMethod){case"password":const t={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Ku(e,t,"signInWithPassword",UI);case"emailLink":return BI(e,{email:this._email,oobCode:this._password});default:Dn(e,"internal-error")}}async _linkToIdToken(e,t){switch(this.signInMethod){case"password":const s={idToken:t,returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Ku(e,s,"signUpPassword",FI);case"emailLink":return $I(e,{idToken:t,email:this._email,oobCode:this._password});default:Dn(e,"internal-error")}}_getReauthenticationResolver(e){return this._getIdTokenResponse(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ho(r,e){return el(r,"POST","/v1/accounts:signInWithIdp",xr(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const HI="http://localhost";class us extends Gd{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new us(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):Dn("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:s,signInMethod:o,...u}=t;if(!s||!o)return null;const h=new us(s,o);return h.idToken=u.idToken||void 0,h.accessToken=u.accessToken||void 0,h.secret=u.secret,h.nonce=u.nonce,h.pendingToken=u.pendingToken||null,h}_getIdTokenResponse(e){const t=this.buildRequest();return ho(e,t)}_linkToIdToken(e,t){const s=this.buildRequest();return s.idToken=t,ho(e,s)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,ho(e,t)}buildRequest(){const e={requestUri:HI,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=Ja(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qI(r){switch(r){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function WI(r){const e=Pa(ka(r)).link,t=e?Pa(ka(e)).deep_link_id:null,s=Pa(ka(r)).deep_link_id;return(s?Pa(ka(s)).link:null)||s||t||e||r}class Qd{constructor(e){const t=Pa(ka(e)),s=t.apiKey??null,o=t.oobCode??null,u=qI(t.mode??null);fe(s&&o&&u,"argument-error"),this.apiKey=s,this.operation=u,this.code=o,this.continueUrl=t.continueUrl??null,this.languageCode=t.lang??null,this.tenantId=t.tenantId??null}static parseLink(e){const t=WI(e);try{return new Qd(t)}catch{return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ro{constructor(){this.providerId=Ro.PROVIDER_ID}static credential(e,t){return Ba._fromEmailAndPassword(e,t)}static credentialWithLink(e,t){const s=Qd.parseLink(t);return fe(s,"argument-error"),Ba._fromEmailAndCode(e,s.code,s.tenantId)}}Ro.PROVIDER_ID="password";Ro.EMAIL_PASSWORD_SIGN_IN_METHOD="password";Ro.EMAIL_LINK_SIGN_IN_METHOD="emailLink";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class a_{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tl extends a_{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ci extends tl{constructor(){super("facebook.com")}static credential(e){return us._fromParams({providerId:ci.PROVIDER_ID,signInMethod:ci.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return ci.credentialFromTaggedObject(e)}static credentialFromError(e){return ci.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return ci.credential(e.oauthAccessToken)}catch{return null}}}ci.FACEBOOK_SIGN_IN_METHOD="facebook.com";ci.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hi extends tl{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return us._fromParams({providerId:hi.PROVIDER_ID,signInMethod:hi.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return hi.credentialFromTaggedObject(e)}static credentialFromError(e){return hi.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:s}=e;if(!t&&!s)return null;try{return hi.credential(t,s)}catch{return null}}}hi.GOOGLE_SIGN_IN_METHOD="google.com";hi.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class di extends tl{constructor(){super("github.com")}static credential(e){return us._fromParams({providerId:di.PROVIDER_ID,signInMethod:di.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return di.credentialFromTaggedObject(e)}static credentialFromError(e){return di.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return di.credential(e.oauthAccessToken)}catch{return null}}}di.GITHUB_SIGN_IN_METHOD="github.com";di.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fi extends tl{constructor(){super("twitter.com")}static credential(e,t){return us._fromParams({providerId:fi.PROVIDER_ID,signInMethod:fi.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return fi.credentialFromTaggedObject(e)}static credentialFromError(e){return fi.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:s}=e;if(!t||!s)return null;try{return fi.credential(t,s)}catch{return null}}}fi.TWITTER_SIGN_IN_METHOD="twitter.com";fi.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function KI(r,e){return el(r,"POST","/v1/accounts:signUp",xr(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cs{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,s,o=!1){const u=await kn._fromIdTokenResponse(e,s,o),h=mg(s);return new cs({user:u,providerId:h,_tokenResponse:s,operationType:t})}static async _forOperation(e,t,s){await e._updateTokensIfNecessary(s,!0);const o=mg(s);return new cs({user:e,providerId:o,_tokenResponse:s,operationType:t})}}function mg(r){return r.providerId?r.providerId:"phoneNumber"in r?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gu extends Nr{constructor(e,t,s,o){super(t.code,t.message),this.operationType=s,this.user=o,Object.setPrototypeOf(this,Gu.prototype),this.customData={appName:e.name,tenantId:e.tenantId??void 0,_serverResponse:t.customData._serverResponse,operationType:s}}static _fromErrorAndOperation(e,t,s,o){return new Gu(e,t,s,o)}}function l_(r,e,t,s){return(e==="reauthenticate"?t._getReauthenticationResolver(r):t._getIdTokenResponse(r)).catch(u=>{throw u.code==="auth/multi-factor-auth-required"?Gu._fromErrorAndOperation(r,u,e,s):u})}async function GI(r,e,t=!1){const s=await za(r,e._linkToIdToken(r.auth,await r.getIdToken()),t);return cs._forOperation(r,"link",s)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function QI(r,e,t=!1){const{auth:s}=r;if(yn(s.app))return Promise.reject(Ar(s));const o="reauthenticate";try{const u=await za(r,l_(s,o,e,r),t);fe(u.idToken,s,"internal-error");const h=Wd(u.idToken);fe(h,s,"internal-error");const{sub:m}=h;return fe(r.uid===m,s,"user-mismatch"),cs._forOperation(r,o,u)}catch(u){throw(u==null?void 0:u.code)==="auth/user-not-found"&&Dn(s,"user-mismatch"),u}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function u_(r,e,t=!1){if(yn(r.app))return Promise.reject(Ar(r));const s="signIn",o=await l_(r,s,e),u=await cs._fromIdTokenResponse(r,s,o);return t||await r._updateCurrentUser(u.user),u}async function YI(r,e){return u_(Ci(r),e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function c_(r){const e=Ci(r);e._getPasswordPolicyInternal()&&await e._updatePasswordPolicy()}async function JI(r,e,t){const s=Ci(r);await Ku(s,{requestType:"PASSWORD_RESET",email:e,clientType:"CLIENT_TYPE_WEB"},"getOobCode",zI)}async function XI(r,e,t){if(yn(r.app))return Promise.reject(Ar(r));const s=Ci(r),h=await Ku(s,{returnSecureToken:!0,email:e,password:t,clientType:"CLIENT_TYPE_WEB"},"signUpPassword",KI).catch(g=>{throw g.code==="auth/password-does-not-meet-requirements"&&c_(r),g}),m=await cs._fromIdTokenResponse(s,"signIn",h);return await s._updateCurrentUser(m.user),m}function ZI(r,e,t){return yn(r.app)?Promise.reject(Ar(r)):YI(Et(r),Ro.credential(e,t)).catch(async s=>{throw s.code==="auth/password-does-not-meet-requirements"&&c_(r),s})}function e0(r,e,t,s){return Et(r).onIdTokenChanged(e,t,s)}function t0(r,e,t){return Et(r).beforeAuthStateChanged(e,t)}function n0(r,e,t,s){return Et(r).onAuthStateChanged(e,t,s)}function r0(r){return Et(r).signOut()}const Qu="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class h_{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(Qu,"1"),this.storage.removeItem(Qu),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const i0=1e3,s0=10;class d_ extends h_{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.fallbackToPolling=n_(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const s=this.storage.getItem(t),o=this.localCache[t];s!==o&&e(t,o,s)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((h,m,g)=>{this.notifyListeners(h,g)});return}const s=e.key;t?this.detachListener():this.stopPolling();const o=()=>{const h=this.storage.getItem(s);!t&&this.localCache[s]===h||this.notifyListeners(s,h)},u=this.storage.getItem(s);vI()&&u!==e.newValue&&e.newValue!==e.oldValue?setTimeout(o,s0):o()}notifyListeners(e,t){this.localCache[e]=t;const s=this.listeners[e];if(s)for(const o of Array.from(s))o(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,s)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:s}),!0)})},i0)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}d_.type="LOCAL";const o0=d_;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class f_ extends h_{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}f_.type="SESSION";const p_=f_;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function a0(r){return Promise.all(r.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hc{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(o=>o.isListeningto(e));if(t)return t;const s=new hc(e);return this.receivers.push(s),s}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:s,eventType:o,data:u}=t.data,h=this.handlersMap[o];if(!(h!=null&&h.size))return;t.ports[0].postMessage({status:"ack",eventId:s,eventType:o});const m=Array.from(h).map(async _=>_(t.origin,u)),g=await a0(m);t.ports[0].postMessage({status:"done",eventId:s,eventType:o,response:g})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}hc.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Yd(r="",e=10){let t="";for(let s=0;s<e;s++)t+=Math.floor(Math.random()*10);return r+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class l0{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,s=50){const o=typeof MessageChannel<"u"?new MessageChannel:null;if(!o)throw new Error("connection_unavailable");let u,h;return new Promise((m,g)=>{const _=Yd("",20);o.port1.start();const E=setTimeout(()=>{g(new Error("unsupported_event"))},s);h={messageChannel:o,onMessage(S){const V=S;if(V.data.eventId===_)switch(V.data.status){case"ack":clearTimeout(E),u=setTimeout(()=>{g(new Error("timeout"))},3e3);break;case"done":clearTimeout(u),m(V.data.response);break;default:clearTimeout(E),clearTimeout(u),g(new Error("invalid_response"));break}}},this.handlers.add(h),o.port1.addEventListener("message",h.onMessage),this.target.postMessage({eventType:e,eventId:_,data:t},[o.port2])}).finally(()=>{h&&this.removeMessageHandler(h)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function er(){return window}function u0(r){er().location.href=r}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function m_(){return typeof er().WorkerGlobalScope<"u"&&typeof er().importScripts=="function"}async function c0(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function h0(){var r;return((r=navigator==null?void 0:navigator.serviceWorker)==null?void 0:r.controller)||null}function d0(){return m_()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const g_="firebaseLocalStorageDb",f0=1,Yu="firebaseLocalStorage",y_="fbase_key";class nl{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function dc(r,e){return r.transaction([Yu],e?"readwrite":"readonly").objectStore(Yu)}function p0(){const r=indexedDB.deleteDatabase(g_);return new nl(r).toPromise()}function Td(){const r=indexedDB.open(g_,f0);return new Promise((e,t)=>{r.addEventListener("error",()=>{t(r.error)}),r.addEventListener("upgradeneeded",()=>{const s=r.result;try{s.createObjectStore(Yu,{keyPath:y_})}catch(o){t(o)}}),r.addEventListener("success",async()=>{const s=r.result;s.objectStoreNames.contains(Yu)?e(s):(s.close(),await p0(),e(await Td()))})})}async function gg(r,e,t){const s=dc(r,!0).put({[y_]:e,value:t});return new nl(s).toPromise()}async function m0(r,e){const t=dc(r,!1).get(e),s=await new nl(t).toPromise();return s===void 0?null:s.value}function yg(r,e){const t=dc(r,!0).delete(e);return new nl(t).toPromise()}const g0=800,y0=3;class __{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await Td(),this.db)}async _withRetries(e){let t=0;for(;;)try{const s=await this._openDb();return await e(s)}catch(s){if(t++>y0)throw s;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return m_()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=hc._getInstance(d0()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var t,s;if(this.activeServiceWorker=await c0(),!this.activeServiceWorker)return;this.sender=new l0(this.activeServiceWorker);const e=await this.sender._send("ping",{},800);e&&(t=e[0])!=null&&t.fulfilled&&(s=e[0])!=null&&s.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||h0()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await Td();return await gg(e,Qu,"1"),await yg(e,Qu),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(s=>gg(s,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(s=>m0(s,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>yg(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(o=>{const u=dc(o,!1).getAll();return new nl(u).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],s=new Set;if(e.length!==0)for(const{fbase_key:o,value:u}of e)s.add(o),JSON.stringify(this.localCache[o])!==JSON.stringify(u)&&(this.notifyListeners(o,u),t.push(o));for(const o of Object.keys(this.localCache))this.localCache[o]&&!s.has(o)&&(this.notifyListeners(o,null),t.push(o));return t}notifyListeners(e,t){this.localCache[e]=t;const s=this.listeners[e];if(s)for(const o of Array.from(s))o(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),g0)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}__.type="LOCAL";const _0=__;new Za(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function v0(r,e){return e?Sr(e):(fe(r._popupRedirectResolver,r,"argument-error"),r._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jd extends Gd{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return ho(e,this._buildIdpRequest())}_linkToIdToken(e,t){return ho(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return ho(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function E0(r){return u_(r.auth,new Jd(r),r.bypassAuthState)}function w0(r){const{auth:e,user:t}=r;return fe(t,e,"internal-error"),QI(t,new Jd(r),r.bypassAuthState)}async function T0(r){const{auth:e,user:t}=r;return fe(t,e,"internal-error"),GI(t,new Jd(r),r.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class v_{constructor(e,t,s,o,u=!1){this.auth=e,this.resolver=s,this.user=o,this.bypassAuthState=u,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(s){this.reject(s)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:s,postBody:o,tenantId:u,error:h,type:m}=e;if(h){this.reject(h);return}const g={auth:this.auth,requestUri:t,sessionId:s,tenantId:u||void 0,postBody:o||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(m)(g))}catch(_){this.reject(_)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return E0;case"linkViaPopup":case"linkViaRedirect":return T0;case"reauthViaPopup":case"reauthViaRedirect":return w0;default:Dn(this.auth,"internal-error")}}resolve(e){Cr(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){Cr(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const I0=new Za(2e3,1e4);class lo extends v_{constructor(e,t,s,o,u){super(e,t,o,u),this.provider=s,this.authWindow=null,this.pollId=null,lo.currentPopupAction&&lo.currentPopupAction.cancel(),lo.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return fe(e,this.auth,"internal-error"),e}async onExecution(){Cr(this.filter.length===1,"Popup operations only handle one event");const e=Yd();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(Zn(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)==null?void 0:e.associatedEvent)||null}cancel(){this.reject(Zn(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,lo.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,s;if((s=(t=this.authWindow)==null?void 0:t.window)!=null&&s.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(Zn(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,I0.get())};e()}}lo.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const S0="pendingRedirect",Ou=new Map;class A0 extends v_{constructor(e,t,s=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,s),this.eventId=null}async execute(){let e=Ou.get(this.auth._key());if(!e){try{const s=await R0(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(s)}catch(t){e=()=>Promise.reject(t)}Ou.set(this.auth._key(),e)}return this.bypassAuthState||Ou.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function R0(r,e){const t=k0(e),s=P0(r);if(!await s._isAvailable())return!1;const o=await s._get(t)==="true";return await s._remove(t),o}function C0(r,e){Ou.set(r._key(),e)}function P0(r){return Sr(r._redirectPersistence)}function k0(r){return Vu(S0,r.config.apiKey,r.name)}async function N0(r,e,t=!1){if(yn(r.app))return Promise.reject(Ar(r));const s=Ci(r),o=v0(s,e),h=await new A0(s,o,t).execute();return h&&!t&&(delete h.user._redirectEventId,await s._persistUserIfCurrent(h.user),await s._setRedirectUser(null,e)),h}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const x0=600*1e3;class D0{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(s=>{this.isEventForConsumer(e,s)&&(t=!0,this.sendToConsumer(e,s),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!V0(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var s;if(e.error&&!E_(e)){const o=((s=e.error.code)==null?void 0:s.split("auth/")[1])||"internal-error";t.onError(Zn(this.auth,o))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const s=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&s}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=x0&&this.cachedEventUids.clear(),this.cachedEventUids.has(_g(e))}saveEventToCache(e){this.cachedEventUids.add(_g(e)),this.lastProcessedEventTime=Date.now()}}function _g(r){return[r.type,r.eventId,r.sessionId,r.tenantId].filter(e=>e).join("-")}function E_({type:r,error:e}){return r==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function V0(r){switch(r.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return E_(r);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function O0(r,e={}){return Dr(r,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const L0=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,M0=/^https?/;async function b0(r){if(r.config.emulator)return;const{authorizedDomains:e}=await O0(r);for(const t of e)try{if(F0(t))return}catch{}Dn(r,"unauthorized-domain")}function F0(r){const e=Ed(),{protocol:t,hostname:s}=new URL(e);if(r.startsWith("chrome-extension://")){const h=new URL(r);return h.hostname===""&&s===""?t==="chrome-extension:"&&r.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&h.hostname===s}if(!M0.test(t))return!1;if(L0.test(r))return s===r;const o=r.replace(/\./g,"\\.");return new RegExp("^(.+\\."+o+"|"+o+")$","i").test(s)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const U0=new Za(3e4,6e4);function vg(){const r=er().___jsl;if(r!=null&&r.H){for(const e of Object.keys(r.H))if(r.H[e].r=r.H[e].r||[],r.H[e].L=r.H[e].L||[],r.H[e].r=[...r.H[e].L],r.CP)for(let t=0;t<r.CP.length;t++)r.CP[t]=null}}function j0(r){return new Promise((e,t)=>{var o,u,h;function s(){vg(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{vg(),t(Zn(r,"network-request-failed"))},timeout:U0.get()})}if((u=(o=er().gapi)==null?void 0:o.iframes)!=null&&u.Iframe)e(gapi.iframes.getContext());else if((h=er().gapi)!=null&&h.load)s();else{const m=PI("iframefcb");return er()[m]=()=>{gapi.load?s():t(Zn(r,"network-request-failed"))},i_(`${CI()}?onload=${m}`).catch(g=>t(g))}}).catch(e=>{throw Lu=null,e})}let Lu=null;function z0(r){return Lu=Lu||j0(r),Lu}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const B0=new Za(5e3,15e3),$0="__/auth/iframe",H0="emulator/auth/iframe",q0={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},W0=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function K0(r){const e=r.config;fe(e.authDomain,r,"auth-domain-config-required");const t=e.emulator?qd(e,H0):`https://${r.config.authDomain}/${$0}`,s={apiKey:e.apiKey,appName:r.name,v:Ao},o=W0.get(r.config.apiHost);o&&(s.eid=o);const u=r._getFrameworks();return u.length&&(s.fw=u.join(",")),`${t}?${Ja(s).slice(1)}`}async function G0(r){const e=await z0(r),t=er().gapi;return fe(t,r,"internal-error"),e.open({where:document.body,url:K0(r),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:q0,dontclear:!0},s=>new Promise(async(o,u)=>{await s.restyle({setHideOnLeave:!1});const h=Zn(r,"network-request-failed"),m=er().setTimeout(()=>{u(h)},B0.get());function g(){er().clearTimeout(m),o(s)}s.ping(g).then(g,()=>{u(h)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Q0={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},Y0=500,J0=600,X0="_blank",Z0="http://localhost";class Eg{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function eS(r,e,t,s=Y0,o=J0){const u=Math.max((window.screen.availHeight-o)/2,0).toString(),h=Math.max((window.screen.availWidth-s)/2,0).toString();let m="";const g={...Q0,width:s.toString(),height:o.toString(),top:u,left:h},_=jt().toLowerCase();t&&(m=Jy(_)?X0:t),Qy(_)&&(e=e||Z0,g.scrollbars="yes");const E=Object.entries(g).reduce((V,[z,Q])=>`${V}${z}=${Q},`,"");if(_I(_)&&m!=="_self")return tS(e||"",m),new Eg(null);const S=window.open(e||"",m,E);fe(S,r,"popup-blocked");try{S.focus()}catch{}return new Eg(S)}function tS(r,e){const t=document.createElement("a");t.href=r,t.target=e;const s=document.createEvent("MouseEvent");s.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(s)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nS="__/auth/handler",rS="emulator/auth/handler",iS=encodeURIComponent("fac");async function wg(r,e,t,s,o,u){fe(r.config.authDomain,r,"auth-domain-config-required"),fe(r.config.apiKey,r,"invalid-api-key");const h={apiKey:r.config.apiKey,appName:r.name,authType:t,redirectUrl:s,v:Ao,eventId:o};if(e instanceof a_){e.setDefaultLanguage(r.languageCode),h.providerId=e.providerId||"",Fw(e.getCustomParameters())||(h.customParameters=JSON.stringify(e.getCustomParameters()));for(const[E,S]of Object.entries({}))h[E]=S}if(e instanceof tl){const E=e.getScopes().filter(S=>S!=="");E.length>0&&(h.scopes=E.join(","))}r.tenantId&&(h.tid=r.tenantId);const m=h;for(const E of Object.keys(m))m[E]===void 0&&delete m[E];const g=await r._getAppCheckToken(),_=g?`#${iS}=${encodeURIComponent(g)}`:"";return`${sS(r)}?${Ja(m).slice(1)}${_}`}function sS({config:r}){return r.emulator?qd(r,rS):`https://${r.authDomain}/${nS}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ud="webStorageSupport";class oS{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=p_,this._completeRedirectFn=N0,this._overrideRedirectResult=C0}async _openPopup(e,t,s,o){var h;Cr((h=this.eventManagers[e._key()])==null?void 0:h.manager,"_initialize() not called before _openPopup()");const u=await wg(e,t,s,Ed(),o);return eS(e,u,Yd())}async _openRedirect(e,t,s,o){await this._originValidation(e);const u=await wg(e,t,s,Ed(),o);return u0(u),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:o,promise:u}=this.eventManagers[t];return o?Promise.resolve(o):(Cr(u,"If manager is not set, promise should be"),u)}const s=this.initAndGetManager(e);return this.eventManagers[t]={promise:s},s.catch(()=>{delete this.eventManagers[t]}),s}async initAndGetManager(e){const t=await G0(e),s=new D0(e);return t.register("authEvent",o=>(fe(o==null?void 0:o.authEvent,e,"invalid-auth-event"),{status:s.onEvent(o.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:s},this.iframes[e._key()]=t,s}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(ud,{type:ud},o=>{var h;const u=(h=o==null?void 0:o[0])==null?void 0:h[ud];u!==void 0&&t(!!u),Dn(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=b0(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return n_()||Yy()||Kd()}}const aS=oS;var Tg="@firebase/auth",Ig="1.12.2";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lS{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)==null?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(s=>{e((s==null?void 0:s.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){fe(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function uS(r){switch(r){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function cS(r){yo(new ls("auth",(e,{options:t})=>{const s=e.getProvider("app").getImmediate(),o=e.getProvider("heartbeat"),u=e.getProvider("app-check-internal"),{apiKey:h,authDomain:m}=s.options;fe(h&&!h.includes(":"),"invalid-api-key",{appName:s.name});const g={apiKey:h,authDomain:m,clientPlatform:r,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:r_(r)},_=new SI(s,o,u,g);return OI(_,t),_},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,s)=>{e.getProvider("auth-internal").initialize()})),yo(new ls("auth-internal",e=>{const t=Ci(e.getProvider("auth").getImmediate());return(s=>new lS(s))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),yi(Tg,Ig,uS(r)),yi(Tg,Ig,"esm2020")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hS=300,dS=Vy("authIdTokenMaxAge")||hS;let Sg=null;const fS=r=>async e=>{const t=e&&await e.getIdTokenResult(),s=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(s&&s>dS)return;const o=t==null?void 0:t.token;Sg!==o&&(Sg=o,await fetch(r,{method:o?"POST":"DELETE",headers:o?{Authorization:`Bearer ${o}`}:{}}))};function pS(r=Fy()){const e=$d(r,"auth");if(e.isInitialized())return e.getImmediate();const t=VI(r,{popupRedirectResolver:aS,persistence:[_0,o0,p_]}),s=Vy("authTokenSyncURL");if(s&&typeof isSecureContext=="boolean"&&isSecureContext){const u=new URL(s,location.origin);if(location.origin===u.origin){const h=fS(u.toString());t0(t,h,()=>h(t.currentUser)),e0(t,m=>h(m))}}const o=xy("auth");return o&&LI(t,`http://${o}`),t}function mS(){var r;return((r=document.getElementsByTagName("head"))==null?void 0:r[0])??document}AI({loadJS(r){return new Promise((e,t)=>{const s=document.createElement("script");s.setAttribute("src",r),s.onload=e,s.onerror=o=>{const u=Zn("internal-error");u.customData=o,t(u)},s.type="text/javascript",s.charset="UTF-8",mS().appendChild(s)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});cS("Browser");var Ag=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var _i,w_;(function(){var r;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(C,T){function R(){}R.prototype=T.prototype,C.F=T.prototype,C.prototype=new R,C.prototype.constructor=C,C.D=function(D,N,L){for(var A=Array(arguments.length-2),Be=2;Be<arguments.length;Be++)A[Be-2]=arguments[Be];return T.prototype[N].apply(D,A)}}function t(){this.blockSize=-1}function s(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}e(s,t),s.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function o(C,T,R){R||(R=0);const D=Array(16);if(typeof T=="string")for(var N=0;N<16;++N)D[N]=T.charCodeAt(R++)|T.charCodeAt(R++)<<8|T.charCodeAt(R++)<<16|T.charCodeAt(R++)<<24;else for(N=0;N<16;++N)D[N]=T[R++]|T[R++]<<8|T[R++]<<16|T[R++]<<24;T=C.g[0],R=C.g[1],N=C.g[2];let L=C.g[3],A;A=T+(L^R&(N^L))+D[0]+3614090360&4294967295,T=R+(A<<7&4294967295|A>>>25),A=L+(N^T&(R^N))+D[1]+3905402710&4294967295,L=T+(A<<12&4294967295|A>>>20),A=N+(R^L&(T^R))+D[2]+606105819&4294967295,N=L+(A<<17&4294967295|A>>>15),A=R+(T^N&(L^T))+D[3]+3250441966&4294967295,R=N+(A<<22&4294967295|A>>>10),A=T+(L^R&(N^L))+D[4]+4118548399&4294967295,T=R+(A<<7&4294967295|A>>>25),A=L+(N^T&(R^N))+D[5]+1200080426&4294967295,L=T+(A<<12&4294967295|A>>>20),A=N+(R^L&(T^R))+D[6]+2821735955&4294967295,N=L+(A<<17&4294967295|A>>>15),A=R+(T^N&(L^T))+D[7]+4249261313&4294967295,R=N+(A<<22&4294967295|A>>>10),A=T+(L^R&(N^L))+D[8]+1770035416&4294967295,T=R+(A<<7&4294967295|A>>>25),A=L+(N^T&(R^N))+D[9]+2336552879&4294967295,L=T+(A<<12&4294967295|A>>>20),A=N+(R^L&(T^R))+D[10]+4294925233&4294967295,N=L+(A<<17&4294967295|A>>>15),A=R+(T^N&(L^T))+D[11]+2304563134&4294967295,R=N+(A<<22&4294967295|A>>>10),A=T+(L^R&(N^L))+D[12]+1804603682&4294967295,T=R+(A<<7&4294967295|A>>>25),A=L+(N^T&(R^N))+D[13]+4254626195&4294967295,L=T+(A<<12&4294967295|A>>>20),A=N+(R^L&(T^R))+D[14]+2792965006&4294967295,N=L+(A<<17&4294967295|A>>>15),A=R+(T^N&(L^T))+D[15]+1236535329&4294967295,R=N+(A<<22&4294967295|A>>>10),A=T+(N^L&(R^N))+D[1]+4129170786&4294967295,T=R+(A<<5&4294967295|A>>>27),A=L+(R^N&(T^R))+D[6]+3225465664&4294967295,L=T+(A<<9&4294967295|A>>>23),A=N+(T^R&(L^T))+D[11]+643717713&4294967295,N=L+(A<<14&4294967295|A>>>18),A=R+(L^T&(N^L))+D[0]+3921069994&4294967295,R=N+(A<<20&4294967295|A>>>12),A=T+(N^L&(R^N))+D[5]+3593408605&4294967295,T=R+(A<<5&4294967295|A>>>27),A=L+(R^N&(T^R))+D[10]+38016083&4294967295,L=T+(A<<9&4294967295|A>>>23),A=N+(T^R&(L^T))+D[15]+3634488961&4294967295,N=L+(A<<14&4294967295|A>>>18),A=R+(L^T&(N^L))+D[4]+3889429448&4294967295,R=N+(A<<20&4294967295|A>>>12),A=T+(N^L&(R^N))+D[9]+568446438&4294967295,T=R+(A<<5&4294967295|A>>>27),A=L+(R^N&(T^R))+D[14]+3275163606&4294967295,L=T+(A<<9&4294967295|A>>>23),A=N+(T^R&(L^T))+D[3]+4107603335&4294967295,N=L+(A<<14&4294967295|A>>>18),A=R+(L^T&(N^L))+D[8]+1163531501&4294967295,R=N+(A<<20&4294967295|A>>>12),A=T+(N^L&(R^N))+D[13]+2850285829&4294967295,T=R+(A<<5&4294967295|A>>>27),A=L+(R^N&(T^R))+D[2]+4243563512&4294967295,L=T+(A<<9&4294967295|A>>>23),A=N+(T^R&(L^T))+D[7]+1735328473&4294967295,N=L+(A<<14&4294967295|A>>>18),A=R+(L^T&(N^L))+D[12]+2368359562&4294967295,R=N+(A<<20&4294967295|A>>>12),A=T+(R^N^L)+D[5]+4294588738&4294967295,T=R+(A<<4&4294967295|A>>>28),A=L+(T^R^N)+D[8]+2272392833&4294967295,L=T+(A<<11&4294967295|A>>>21),A=N+(L^T^R)+D[11]+1839030562&4294967295,N=L+(A<<16&4294967295|A>>>16),A=R+(N^L^T)+D[14]+4259657740&4294967295,R=N+(A<<23&4294967295|A>>>9),A=T+(R^N^L)+D[1]+2763975236&4294967295,T=R+(A<<4&4294967295|A>>>28),A=L+(T^R^N)+D[4]+1272893353&4294967295,L=T+(A<<11&4294967295|A>>>21),A=N+(L^T^R)+D[7]+4139469664&4294967295,N=L+(A<<16&4294967295|A>>>16),A=R+(N^L^T)+D[10]+3200236656&4294967295,R=N+(A<<23&4294967295|A>>>9),A=T+(R^N^L)+D[13]+681279174&4294967295,T=R+(A<<4&4294967295|A>>>28),A=L+(T^R^N)+D[0]+3936430074&4294967295,L=T+(A<<11&4294967295|A>>>21),A=N+(L^T^R)+D[3]+3572445317&4294967295,N=L+(A<<16&4294967295|A>>>16),A=R+(N^L^T)+D[6]+76029189&4294967295,R=N+(A<<23&4294967295|A>>>9),A=T+(R^N^L)+D[9]+3654602809&4294967295,T=R+(A<<4&4294967295|A>>>28),A=L+(T^R^N)+D[12]+3873151461&4294967295,L=T+(A<<11&4294967295|A>>>21),A=N+(L^T^R)+D[15]+530742520&4294967295,N=L+(A<<16&4294967295|A>>>16),A=R+(N^L^T)+D[2]+3299628645&4294967295,R=N+(A<<23&4294967295|A>>>9),A=T+(N^(R|~L))+D[0]+4096336452&4294967295,T=R+(A<<6&4294967295|A>>>26),A=L+(R^(T|~N))+D[7]+1126891415&4294967295,L=T+(A<<10&4294967295|A>>>22),A=N+(T^(L|~R))+D[14]+2878612391&4294967295,N=L+(A<<15&4294967295|A>>>17),A=R+(L^(N|~T))+D[5]+4237533241&4294967295,R=N+(A<<21&4294967295|A>>>11),A=T+(N^(R|~L))+D[12]+1700485571&4294967295,T=R+(A<<6&4294967295|A>>>26),A=L+(R^(T|~N))+D[3]+2399980690&4294967295,L=T+(A<<10&4294967295|A>>>22),A=N+(T^(L|~R))+D[10]+4293915773&4294967295,N=L+(A<<15&4294967295|A>>>17),A=R+(L^(N|~T))+D[1]+2240044497&4294967295,R=N+(A<<21&4294967295|A>>>11),A=T+(N^(R|~L))+D[8]+1873313359&4294967295,T=R+(A<<6&4294967295|A>>>26),A=L+(R^(T|~N))+D[15]+4264355552&4294967295,L=T+(A<<10&4294967295|A>>>22),A=N+(T^(L|~R))+D[6]+2734768916&4294967295,N=L+(A<<15&4294967295|A>>>17),A=R+(L^(N|~T))+D[13]+1309151649&4294967295,R=N+(A<<21&4294967295|A>>>11),A=T+(N^(R|~L))+D[4]+4149444226&4294967295,T=R+(A<<6&4294967295|A>>>26),A=L+(R^(T|~N))+D[11]+3174756917&4294967295,L=T+(A<<10&4294967295|A>>>22),A=N+(T^(L|~R))+D[2]+718787259&4294967295,N=L+(A<<15&4294967295|A>>>17),A=R+(L^(N|~T))+D[9]+3951481745&4294967295,C.g[0]=C.g[0]+T&4294967295,C.g[1]=C.g[1]+(N+(A<<21&4294967295|A>>>11))&4294967295,C.g[2]=C.g[2]+N&4294967295,C.g[3]=C.g[3]+L&4294967295}s.prototype.v=function(C,T){T===void 0&&(T=C.length);const R=T-this.blockSize,D=this.C;let N=this.h,L=0;for(;L<T;){if(N==0)for(;L<=R;)o(this,C,L),L+=this.blockSize;if(typeof C=="string"){for(;L<T;)if(D[N++]=C.charCodeAt(L++),N==this.blockSize){o(this,D),N=0;break}}else for(;L<T;)if(D[N++]=C[L++],N==this.blockSize){o(this,D),N=0;break}}this.h=N,this.o+=T},s.prototype.A=function(){var C=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);C[0]=128;for(var T=1;T<C.length-8;++T)C[T]=0;T=this.o*8;for(var R=C.length-8;R<C.length;++R)C[R]=T&255,T/=256;for(this.v(C),C=Array(16),T=0,R=0;R<4;++R)for(let D=0;D<32;D+=8)C[T++]=this.g[R]>>>D&255;return C};function u(C,T){var R=m;return Object.prototype.hasOwnProperty.call(R,C)?R[C]:R[C]=T(C)}function h(C,T){this.h=T;const R=[];let D=!0;for(let N=C.length-1;N>=0;N--){const L=C[N]|0;D&&L==T||(R[N]=L,D=!1)}this.g=R}var m={};function g(C){return-128<=C&&C<128?u(C,function(T){return new h([T|0],T<0?-1:0)}):new h([C|0],C<0?-1:0)}function _(C){if(isNaN(C)||!isFinite(C))return S;if(C<0)return H(_(-C));const T=[];let R=1;for(let D=0;C>=R;D++)T[D]=C/R|0,R*=4294967296;return new h(T,0)}function E(C,T){if(C.length==0)throw Error("number format error: empty string");if(T=T||10,T<2||36<T)throw Error("radix out of range: "+T);if(C.charAt(0)=="-")return H(E(C.substring(1),T));if(C.indexOf("-")>=0)throw Error('number format error: interior "-" character');const R=_(Math.pow(T,8));let D=S;for(let L=0;L<C.length;L+=8){var N=Math.min(8,C.length-L);const A=parseInt(C.substring(L,L+N),T);N<8?(N=_(Math.pow(T,N)),D=D.j(N).add(_(A))):(D=D.j(R),D=D.add(_(A)))}return D}var S=g(0),V=g(1),z=g(16777216);r=h.prototype,r.m=function(){if(Y(this))return-H(this).m();let C=0,T=1;for(let R=0;R<this.g.length;R++){const D=this.i(R);C+=(D>=0?D:4294967296+D)*T,T*=4294967296}return C},r.toString=function(C){if(C=C||10,C<2||36<C)throw Error("radix out of range: "+C);if(Q(this))return"0";if(Y(this))return"-"+H(this).toString(C);const T=_(Math.pow(C,6));var R=this;let D="";for(;;){const N=De(R,T).g;R=ie(R,N.j(T));let L=((R.g.length>0?R.g[0]:R.h)>>>0).toString(C);if(R=N,Q(R))return L+D;for(;L.length<6;)L="0"+L;D=L+D}},r.i=function(C){return C<0?0:C<this.g.length?this.g[C]:this.h};function Q(C){if(C.h!=0)return!1;for(let T=0;T<C.g.length;T++)if(C.g[T]!=0)return!1;return!0}function Y(C){return C.h==-1}r.l=function(C){return C=ie(this,C),Y(C)?-1:Q(C)?0:1};function H(C){const T=C.g.length,R=[];for(let D=0;D<T;D++)R[D]=~C.g[D];return new h(R,~C.h).add(V)}r.abs=function(){return Y(this)?H(this):this},r.add=function(C){const T=Math.max(this.g.length,C.g.length),R=[];let D=0;for(let N=0;N<=T;N++){let L=D+(this.i(N)&65535)+(C.i(N)&65535),A=(L>>>16)+(this.i(N)>>>16)+(C.i(N)>>>16);D=A>>>16,L&=65535,A&=65535,R[N]=A<<16|L}return new h(R,R[R.length-1]&-2147483648?-1:0)};function ie(C,T){return C.add(H(T))}r.j=function(C){if(Q(this)||Q(C))return S;if(Y(this))return Y(C)?H(this).j(H(C)):H(H(this).j(C));if(Y(C))return H(this.j(H(C)));if(this.l(z)<0&&C.l(z)<0)return _(this.m()*C.m());const T=this.g.length+C.g.length,R=[];for(var D=0;D<2*T;D++)R[D]=0;for(D=0;D<this.g.length;D++)for(let N=0;N<C.g.length;N++){const L=this.i(D)>>>16,A=this.i(D)&65535,Be=C.i(N)>>>16,lt=C.i(N)&65535;R[2*D+2*N]+=A*lt,ge(R,2*D+2*N),R[2*D+2*N+1]+=L*lt,ge(R,2*D+2*N+1),R[2*D+2*N+1]+=A*Be,ge(R,2*D+2*N+1),R[2*D+2*N+2]+=L*Be,ge(R,2*D+2*N+2)}for(C=0;C<T;C++)R[C]=R[2*C+1]<<16|R[2*C];for(C=T;C<2*T;C++)R[C]=0;return new h(R,0)};function ge(C,T){for(;(C[T]&65535)!=C[T];)C[T+1]+=C[T]>>>16,C[T]&=65535,T++}function Te(C,T){this.g=C,this.h=T}function De(C,T){if(Q(T))throw Error("division by zero");if(Q(C))return new Te(S,S);if(Y(C))return T=De(H(C),T),new Te(H(T.g),H(T.h));if(Y(T))return T=De(C,H(T)),new Te(H(T.g),T.h);if(C.g.length>30){if(Y(C)||Y(T))throw Error("slowDivide_ only works with positive integers.");for(var R=V,D=T;D.l(C)<=0;)R=be(R),D=be(D);var N=ke(R,1),L=ke(D,1);for(D=ke(D,2),R=ke(R,2);!Q(D);){var A=L.add(D);A.l(C)<=0&&(N=N.add(R),L=A),D=ke(D,1),R=ke(R,1)}return T=ie(C,N.j(T)),new Te(N,T)}for(N=S;C.l(T)>=0;){for(R=Math.max(1,Math.floor(C.m()/T.m())),D=Math.ceil(Math.log(R)/Math.LN2),D=D<=48?1:Math.pow(2,D-48),L=_(R),A=L.j(T);Y(A)||A.l(C)>0;)R-=D,L=_(R),A=L.j(T);Q(L)&&(L=V),N=N.add(L),C=ie(C,A)}return new Te(N,C)}r.B=function(C){return De(this,C).h},r.and=function(C){const T=Math.max(this.g.length,C.g.length),R=[];for(let D=0;D<T;D++)R[D]=this.i(D)&C.i(D);return new h(R,this.h&C.h)},r.or=function(C){const T=Math.max(this.g.length,C.g.length),R=[];for(let D=0;D<T;D++)R[D]=this.i(D)|C.i(D);return new h(R,this.h|C.h)},r.xor=function(C){const T=Math.max(this.g.length,C.g.length),R=[];for(let D=0;D<T;D++)R[D]=this.i(D)^C.i(D);return new h(R,this.h^C.h)};function be(C){const T=C.g.length+1,R=[];for(let D=0;D<T;D++)R[D]=C.i(D)<<1|C.i(D-1)>>>31;return new h(R,C.h)}function ke(C,T){const R=T>>5;T%=32;const D=C.g.length-R,N=[];for(let L=0;L<D;L++)N[L]=T>0?C.i(L+R)>>>T|C.i(L+R+1)<<32-T:C.i(L+R);return new h(N,C.h)}s.prototype.digest=s.prototype.A,s.prototype.reset=s.prototype.u,s.prototype.update=s.prototype.v,w_=s,h.prototype.add=h.prototype.add,h.prototype.multiply=h.prototype.j,h.prototype.modulo=h.prototype.B,h.prototype.compare=h.prototype.l,h.prototype.toNumber=h.prototype.m,h.prototype.toString=h.prototype.toString,h.prototype.getBits=h.prototype.i,h.fromNumber=_,h.fromString=E,_i=h}).apply(typeof Ag<"u"?Ag:typeof self<"u"?self:typeof window<"u"?window:{});var Cu=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var T_,Na,I_,Mu,Id,S_,A_,R_;(function(){var r,e=Object.defineProperty;function t(l){l=[typeof globalThis=="object"&&globalThis,l,typeof window=="object"&&window,typeof self=="object"&&self,typeof Cu=="object"&&Cu];for(var p=0;p<l.length;++p){var y=l[p];if(y&&y.Math==Math)return y}throw Error("Cannot find global object")}var s=t(this);function o(l,p){if(p)e:{var y=s;l=l.split(".");for(var w=0;w<l.length-1;w++){var b=l[w];if(!(b in y))break e;y=y[b]}l=l[l.length-1],w=y[l],p=p(w),p!=w&&p!=null&&e(y,l,{configurable:!0,writable:!0,value:p})}}o("Symbol.dispose",function(l){return l||Symbol("Symbol.dispose")}),o("Array.prototype.values",function(l){return l||function(){return this[Symbol.iterator]()}}),o("Object.entries",function(l){return l||function(p){var y=[],w;for(w in p)Object.prototype.hasOwnProperty.call(p,w)&&y.push([w,p[w]]);return y}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var u=u||{},h=this||self;function m(l){var p=typeof l;return p=="object"&&l!=null||p=="function"}function g(l,p,y){return l.call.apply(l.bind,arguments)}function _(l,p,y){return _=g,_.apply(null,arguments)}function E(l,p){var y=Array.prototype.slice.call(arguments,1);return function(){var w=y.slice();return w.push.apply(w,arguments),l.apply(this,w)}}function S(l,p){function y(){}y.prototype=p.prototype,l.Z=p.prototype,l.prototype=new y,l.prototype.constructor=l,l.Ob=function(w,b,j){for(var Z=Array(arguments.length-2),_e=2;_e<arguments.length;_e++)Z[_e-2]=arguments[_e];return p.prototype[b].apply(w,Z)}}var V=typeof AsyncContext<"u"&&typeof AsyncContext.Snapshot=="function"?l=>l&&AsyncContext.Snapshot.wrap(l):l=>l;function z(l){const p=l.length;if(p>0){const y=Array(p);for(let w=0;w<p;w++)y[w]=l[w];return y}return[]}function Q(l,p){for(let w=1;w<arguments.length;w++){const b=arguments[w];var y=typeof b;if(y=y!="object"?y:b?Array.isArray(b)?"array":y:"null",y=="array"||y=="object"&&typeof b.length=="number"){y=l.length||0;const j=b.length||0;l.length=y+j;for(let Z=0;Z<j;Z++)l[y+Z]=b[Z]}else l.push(b)}}class Y{constructor(p,y){this.i=p,this.j=y,this.h=0,this.g=null}get(){let p;return this.h>0?(this.h--,p=this.g,this.g=p.next,p.next=null):p=this.i(),p}}function H(l){h.setTimeout(()=>{throw l},0)}function ie(){var l=C;let p=null;return l.g&&(p=l.g,l.g=l.g.next,l.g||(l.h=null),p.next=null),p}class ge{constructor(){this.h=this.g=null}add(p,y){const w=Te.get();w.set(p,y),this.h?this.h.next=w:this.g=w,this.h=w}}var Te=new Y(()=>new De,l=>l.reset());class De{constructor(){this.next=this.g=this.h=null}set(p,y){this.h=p,this.g=y,this.next=null}reset(){this.next=this.g=this.h=null}}let be,ke=!1,C=new ge,T=()=>{const l=Promise.resolve(void 0);be=()=>{l.then(R)}};function R(){for(var l;l=ie();){try{l.h.call(l.g)}catch(y){H(y)}var p=Te;p.j(l),p.h<100&&(p.h++,l.next=p.g,p.g=l)}ke=!1}function D(){this.u=this.u,this.C=this.C}D.prototype.u=!1,D.prototype.dispose=function(){this.u||(this.u=!0,this.N())},D.prototype[Symbol.dispose]=function(){this.dispose()},D.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function N(l,p){this.type=l,this.g=this.target=p,this.defaultPrevented=!1}N.prototype.h=function(){this.defaultPrevented=!0};var L=(function(){if(!h.addEventListener||!Object.defineProperty)return!1;var l=!1,p=Object.defineProperty({},"passive",{get:function(){l=!0}});try{const y=()=>{};h.addEventListener("test",y,p),h.removeEventListener("test",y,p)}catch{}return l})();function A(l){return/^[\s\xa0]*$/.test(l)}function Be(l,p){N.call(this,l?l.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,l&&this.init(l,p)}S(Be,N),Be.prototype.init=function(l,p){const y=this.type=l.type,w=l.changedTouches&&l.changedTouches.length?l.changedTouches[0]:null;this.target=l.target||l.srcElement,this.g=p,p=l.relatedTarget,p||(y=="mouseover"?p=l.fromElement:y=="mouseout"&&(p=l.toElement)),this.relatedTarget=p,w?(this.clientX=w.clientX!==void 0?w.clientX:w.pageX,this.clientY=w.clientY!==void 0?w.clientY:w.pageY,this.screenX=w.screenX||0,this.screenY=w.screenY||0):(this.clientX=l.clientX!==void 0?l.clientX:l.pageX,this.clientY=l.clientY!==void 0?l.clientY:l.pageY,this.screenX=l.screenX||0,this.screenY=l.screenY||0),this.button=l.button,this.key=l.key||"",this.ctrlKey=l.ctrlKey,this.altKey=l.altKey,this.shiftKey=l.shiftKey,this.metaKey=l.metaKey,this.pointerId=l.pointerId||0,this.pointerType=l.pointerType,this.state=l.state,this.i=l,l.defaultPrevented&&Be.Z.h.call(this)},Be.prototype.h=function(){Be.Z.h.call(this);const l=this.i;l.preventDefault?l.preventDefault():l.returnValue=!1};var lt="closure_listenable_"+(Math.random()*1e6|0),gt=0;function $e(l,p,y,w,b){this.listener=l,this.proxy=null,this.src=p,this.type=y,this.capture=!!w,this.ha=b,this.key=++gt,this.da=this.fa=!1}function X(l){l.da=!0,l.listener=null,l.proxy=null,l.src=null,l.ha=null}function ue(l,p,y){for(const w in l)p.call(y,l[w],w,l)}function te(l,p){for(const y in l)p.call(void 0,l[y],y,l)}function O(l){const p={};for(const y in l)p[y]=l[y];return p}const q="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function Ee(l,p){let y,w;for(let b=1;b<arguments.length;b++){w=arguments[b];for(y in w)l[y]=w[y];for(let j=0;j<q.length;j++)y=q[j],Object.prototype.hasOwnProperty.call(w,y)&&(l[y]=w[y])}}function we(l){this.src=l,this.g={},this.h=0}we.prototype.add=function(l,p,y,w,b){const j=l.toString();l=this.g[j],l||(l=this.g[j]=[],this.h++);const Z=Ae(l,p,w,b);return Z>-1?(p=l[Z],y||(p.fa=!1)):(p=new $e(p,this.src,j,!!w,b),p.fa=y,l.push(p)),p};function Se(l,p){const y=p.type;if(y in l.g){var w=l.g[y],b=Array.prototype.indexOf.call(w,p,void 0),j;(j=b>=0)&&Array.prototype.splice.call(w,b,1),j&&(X(p),l.g[y].length==0&&(delete l.g[y],l.h--))}}function Ae(l,p,y,w){for(let b=0;b<l.length;++b){const j=l[b];if(!j.da&&j.listener==p&&j.capture==!!y&&j.ha==w)return b}return-1}var Fe="closure_lm_"+(Math.random()*1e6|0),Ve={};function He(l,p,y,w,b){if(Array.isArray(p)){for(let j=0;j<p.length;j++)He(l,p[j],y,w,b);return null}return y=Vo(y),l&&l[lt]?l.J(p,y,m(w)?!!w.capture:!1,b):zt(l,p,y,!1,w,b)}function zt(l,p,y,w,b,j){if(!p)throw Error("Invalid event type");const Z=m(b)?!!b.capture:!!b;let _e=_s(l);if(_e||(l[Fe]=_e=new we(l)),y=_e.add(p,y,w,Z,j),y.proxy)return y;if(w=gs(),y.proxy=w,w.src=l,w.listener=y,l.addEventListener)L||(b=Z),b===void 0&&(b=!1),l.addEventListener(p.toString(),w,b);else if(l.attachEvent)l.attachEvent(ys(p.toString()),w);else if(l.addListener&&l.removeListener)l.addListener(w);else throw Error("addEventListener and attachEvent are unavailable.");return y}function gs(){function l(y){return p.call(l.src,l.listener,y)}const p=cl;return l}function Do(l,p,y,w,b){if(Array.isArray(p))for(var j=0;j<p.length;j++)Do(l,p[j],y,w,b);else w=m(w)?!!w.capture:!!w,y=Vo(y),l&&l[lt]?(l=l.i,j=String(p).toString(),j in l.g&&(p=l.g[j],y=Ae(p,y,w,b),y>-1&&(X(p[y]),Array.prototype.splice.call(p,y,1),p.length==0&&(delete l.g[j],l.h--)))):l&&(l=_s(l))&&(p=l.g[p.toString()],l=-1,p&&(l=Ae(p,y,w,b)),(y=l>-1?p[l]:null)&&Vr(y))}function Vr(l){if(typeof l!="number"&&l&&!l.da){var p=l.src;if(p&&p[lt])Se(p.i,l);else{var y=l.type,w=l.proxy;p.removeEventListener?p.removeEventListener(y,w,l.capture):p.detachEvent?p.detachEvent(ys(y),w):p.addListener&&p.removeListener&&p.removeListener(w),(y=_s(p))?(Se(y,l),y.h==0&&(y.src=null,p[Fe]=null)):X(l)}}}function ys(l){return l in Ve?Ve[l]:Ve[l]="on"+l}function cl(l,p){if(l.da)l=!0;else{p=new Be(p,this);const y=l.listener,w=l.ha||l.src;l.fa&&Vr(l),l=y.call(w,p)}return l}function _s(l){return l=l[Fe],l instanceof we?l:null}var Ni="__closure_events_fn_"+(Math.random()*1e9>>>0);function Vo(l){return typeof l=="function"?l:(l[Ni]||(l[Ni]=function(p){return l.handleEvent(p)}),l[Ni])}function ut(){D.call(this),this.i=new we(this),this.M=this,this.G=null}S(ut,D),ut.prototype[lt]=!0,ut.prototype.removeEventListener=function(l,p,y,w){Do(this,l,p,y,w)};function it(l,p){var y,w=l.G;if(w)for(y=[];w;w=w.G)y.push(w);if(l=l.M,w=p.type||p,typeof p=="string")p=new N(p,l);else if(p instanceof N)p.target=p.target||l;else{var b=p;p=new N(w,l),Ee(p,b)}b=!0;let j,Z;if(y)for(Z=y.length-1;Z>=0;Z--)j=p.g=y[Z],b=vn(j,w,!0,p)&&b;if(j=p.g=l,b=vn(j,w,!0,p)&&b,b=vn(j,w,!1,p)&&b,y)for(Z=0;Z<y.length;Z++)j=p.g=y[Z],b=vn(j,w,!1,p)&&b}ut.prototype.N=function(){if(ut.Z.N.call(this),this.i){var l=this.i;for(const p in l.g){const y=l.g[p];for(let w=0;w<y.length;w++)X(y[w]);delete l.g[p],l.h--}}this.G=null},ut.prototype.J=function(l,p,y,w){return this.i.add(String(l),p,!1,y,w)},ut.prototype.K=function(l,p,y,w){return this.i.add(String(l),p,!0,y,w)};function vn(l,p,y,w){if(p=l.i.g[String(p)],!p)return!0;p=p.concat();let b=!0;for(let j=0;j<p.length;++j){const Z=p[j];if(Z&&!Z.da&&Z.capture==y){const _e=Z.listener,st=Z.ha||Z.src;Z.fa&&Se(l.i,Z),b=_e.call(st,w)!==!1&&b}}return b&&!w.defaultPrevented}function Oo(l,p){if(typeof l!="function")if(l&&typeof l.handleEvent=="function")l=_(l.handleEvent,l);else throw Error("Invalid listener argument");return Number(p)>2147483647?-1:h.setTimeout(l,p||0)}function Lo(l){l.g=Oo(()=>{l.g=null,l.i&&(l.i=!1,Lo(l))},l.l);const p=l.h;l.h=null,l.m.apply(null,p)}class hl extends D{constructor(p,y){super(),this.m=p,this.l=y,this.h=null,this.i=!1,this.g=null}j(p){this.h=arguments,this.g?this.i=!0:Lo(this)}N(){super.N(),this.g&&(h.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function Or(l){D.call(this),this.h=l,this.g={}}S(Or,D);var Mo=[];function vs(l){ue(l.g,function(p,y){this.g.hasOwnProperty(y)&&Vr(p)},l),l.g={}}Or.prototype.N=function(){Or.Z.N.call(this),vs(this)},Or.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var Lr=h.JSON.stringify,dl=h.JSON.parse,xi=class{stringify(l){return h.JSON.stringify(l,void 0)}parse(l){return h.JSON.parse(l,void 0)}};function Mr(){}function fl(){}var br={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function Es(){N.call(this,"d")}S(Es,N);function bo(){N.call(this,"c")}S(bo,N);var En={},ws=null;function Fr(){return ws=ws||new ut}En.Ia="serverreachability";function Ts(l){N.call(this,En.Ia,l)}S(Ts,N);function sr(l){const p=Fr();it(p,new Ts(p))}En.STAT_EVENT="statevent";function or(l,p){N.call(this,En.STAT_EVENT,l),this.stat=p}S(or,N);function nt(l){const p=Fr();it(p,new or(p,l))}En.Ja="timingevent";function Fo(l,p){N.call(this,En.Ja,l),this.size=p}S(Fo,N);function Ur(l,p){if(typeof l!="function")throw Error("Fn must not be null and must be a function");return h.setTimeout(function(){l()},p)}function jr(){this.g=!0}jr.prototype.ua=function(){this.g=!1};function pl(l,p,y,w,b,j){l.info(function(){if(l.g)if(j){var Z="",_e=j.split("&");for(let je=0;je<_e.length;je++){var st=_e[je].split("=");if(st.length>1){const ct=st[0];st=st[1];const rn=ct.split("_");Z=rn.length>=2&&rn[1]=="type"?Z+(ct+"="+st+"&"):Z+(ct+"=redacted&")}}}else Z=null;else Z=j;return"XMLHTTP REQ ("+w+") [attempt "+b+"]: "+p+`
`+y+`
`+Z})}function ml(l,p,y,w,b,j,Z){l.info(function(){return"XMLHTTP RESP ("+w+") [ attempt "+b+"]: "+p+`
`+y+`
`+j+" "+Z})}function On(l,p,y,w){l.info(function(){return"XMLHTTP TEXT ("+p+"): "+Di(l,y)+(w?" "+w:"")})}function gl(l,p){l.info(function(){return"TIMEOUT: "+p})}jr.prototype.info=function(){};function Di(l,p){if(!l.g)return p;if(!p)return null;try{const j=JSON.parse(p);if(j){for(l=0;l<j.length;l++)if(Array.isArray(j[l])){var y=j[l];if(!(y.length<2)){var w=y[1];if(Array.isArray(w)&&!(w.length<1)){var b=w[0];if(b!="noop"&&b!="stop"&&b!="close")for(let Z=1;Z<w.length;Z++)w[Z]=""}}}}return Lr(j)}catch{return p}}var zr={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},Br={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"},yl;function ar(){}S(ar,Mr),ar.prototype.g=function(){return new XMLHttpRequest},yl=new ar;function Ln(l){return encodeURIComponent(String(l))}function Is(l){var p=1;l=l.split(":");const y=[];for(;p>0&&l.length;)y.push(l.shift()),p--;return l.length&&y.push(l.join(":")),y}function un(l,p,y,w){this.j=l,this.i=p,this.l=y,this.S=w||1,this.V=new Or(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new _l}function _l(){this.i=null,this.g="",this.h=!1}var vl={},Uo={};function wn(l,p,y){l.M=1,l.A=ur(cn(p)),l.u=y,l.R=!0,jo(l,null)}function jo(l,p){l.F=Date.now(),Vi(l),l.B=cn(l.A);var y=l.B,w=l.S;Array.isArray(w)||(w=[String(w)]),Yo(y.i,"t",w),l.C=0,y=l.j.L,l.h=new _l,l.g=kl(l.j,y?p:null,!l.u),l.P>0&&(l.O=new hl(_(l.Y,l,l.g),l.P)),p=l.V,y=l.g,w=l.ba;var b="readystatechange";Array.isArray(b)||(b&&(Mo[0]=b.toString()),b=Mo);for(let j=0;j<b.length;j++){const Z=He(y,b[j],w||p.handleEvent,!1,p.h||p);if(!Z)break;p.g[Z.key]=Z}p=l.J?O(l.J):{},l.u?(l.v||(l.v="POST"),p["Content-Type"]="application/x-www-form-urlencoded",l.g.ea(l.B,l.v,l.u,p)):(l.v="GET",l.g.ea(l.B,l.v,null,p)),sr(),pl(l.i,l.v,l.B,l.l,l.S,l.u)}un.prototype.ba=function(l){l=l.target;const p=this.O;p&&Bn(l)==3?p.j():this.Y(l)},un.prototype.Y=function(l){try{if(l==this.g)e:{const _e=Bn(this.g),st=this.g.ya(),je=this.g.ca();if(!(_e<3)&&(_e!=3||this.g&&(this.h.h||this.g.la()||Cl(this.g)))){this.K||_e!=4||st==7||(st==8||je<=0?sr(3):sr(2)),Ss(this);var p=this.g.ca();this.X=p;var y=El(this);if(this.o=p==200,ml(this.i,this.v,this.B,this.l,this.S,_e,p),this.o){if(this.U&&!this.L){t:{if(this.g){var w,b=this.g;if((w=b.g?b.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!A(w)){var j=w;break t}}j=null}if(l=j)On(this.i,this.l,l,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,Ge(this,l);else{this.o=!1,this.m=3,nt(12),lr(this),Oi(this);break e}}if(this.R){l=!0;let ct;for(;!this.K&&this.C<y.length;)if(ct=Tl(this,y),ct==Uo){_e==4&&(this.m=4,nt(14),l=!1),On(this.i,this.l,null,"[Incomplete Response]");break}else if(ct==vl){this.m=4,nt(15),On(this.i,this.l,y,"[Invalid Chunk]"),l=!1;break}else On(this.i,this.l,ct,null),Ge(this,ct);if(wl(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),_e!=4||y.length!=0||this.h.h||(this.m=1,nt(16),l=!1),this.o=this.o&&l,!l)On(this.i,this.l,y,"[Invalid Chunked Response]"),lr(this),Oi(this);else if(y.length>0&&!this.W){this.W=!0;var Z=this.j;Z.g==this&&Z.aa&&!Z.P&&(Z.j.info("Great, no buffering proxy detected. Bytes received: "+y.length),$i(Z),Z.P=!0,nt(11))}}else On(this.i,this.l,y,null),Ge(this,y);_e==4&&lr(this),this.o&&!this.K&&(_e==4?Os(this.j,this):(this.o=!1,Vi(this)))}else Xo(this.g),p==400&&y.indexOf("Unknown SID")>0?(this.m=3,nt(12)):(this.m=0,nt(13)),lr(this),Oi(this)}}}catch{}finally{}};function El(l){if(!wl(l))return l.g.la();const p=Cl(l.g);if(p==="")return"";let y="";const w=p.length,b=Bn(l.g)==4;if(!l.h.i){if(typeof TextDecoder>"u")return lr(l),Oi(l),"";l.h.i=new h.TextDecoder}for(let j=0;j<w;j++)l.h.h=!0,y+=l.h.i.decode(p[j],{stream:!(b&&j==w-1)});return p.length=0,l.h.g+=y,l.C=0,l.h.g}function wl(l){return l.g?l.v=="GET"&&l.M!=2&&l.j.Aa:!1}function Tl(l,p){var y=l.C,w=p.indexOf(`
`,y);return w==-1?Uo:(y=Number(p.substring(y,w)),isNaN(y)?vl:(w+=1,w+y>p.length?Uo:(p=p.slice(w,w+y),l.C=w+y,p)))}un.prototype.cancel=function(){this.K=!0,lr(this)};function Vi(l){l.T=Date.now()+l.H,zo(l,l.H)}function zo(l,p){if(l.D!=null)throw Error("WatchDog timer not null");l.D=Ur(_(l.aa,l),p)}function Ss(l){l.D&&(h.clearTimeout(l.D),l.D=null)}un.prototype.aa=function(){this.D=null;const l=Date.now();l-this.T>=0?(gl(this.i,this.B),this.M!=2&&(sr(),nt(17)),lr(this),this.m=2,Oi(this)):zo(this,this.T-l)};function Oi(l){l.j.I==0||l.K||Os(l.j,l)}function lr(l){Ss(l);var p=l.O;p&&typeof p.dispose=="function"&&p.dispose(),l.O=null,vs(l.V),l.g&&(p=l.g,l.g=null,p.abort(),p.dispose())}function Ge(l,p){try{var y=l.j;if(y.I!=0&&(y.g==l||$o(y.h,l))){if(!l.L&&$o(y.h,l)&&y.I==3){try{var w=y.Ba.g.parse(p)}catch{w=null}if(Array.isArray(w)&&w.length==3){var b=w;if(b[0]==0){e:if(!y.v){if(y.g)if(y.g.F+3e3<l.F)Vs(y),tn(y);else break e;qn(y),nt(18)}}else y.xa=b[1],0<y.xa-y.K&&b[2]<37500&&y.F&&y.A==0&&!y.C&&(y.C=Ur(_(y.Va,y),6e3));Li(y.h)<=1&&y.ta&&(y.ta=void 0)}else nn(y,11)}else if((l.L||y.g==l)&&Vs(y),!A(p))for(b=y.Ba.g.parse(p),p=0;p<b.length;p++){let je=b[p];const ct=je[0];if(!(ct<=y.K))if(y.K=ct,je=je[1],y.I==2)if(je[0]=="c"){y.M=je[1],y.ba=je[2];const rn=je[3];rn!=null&&(y.ka=rn,y.j.info("VER="+y.ka));const pr=je[4];pr!=null&&(y.za=pr,y.j.info("SVER="+y.za));const Wn=je[5];Wn!=null&&typeof Wn=="number"&&Wn>0&&(w=1.5*Wn,y.O=w,y.j.info("backChannelRequestTimeoutMs_="+w)),w=y;const Kn=l.g;if(Kn){const bs=Kn.g?Kn.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(bs){var j=w.h;j.g||bs.indexOf("spdy")==-1&&bs.indexOf("quic")==-1&&bs.indexOf("h2")==-1||(j.j=j.l,j.g=new Set,j.h&&(Rs(j,j.h),j.h=null))}if(w.G){const ta=Kn.g?Kn.g.getResponseHeader("X-HTTP-Session-Id"):null;ta&&(w.wa=ta,Me(w.J,w.G,ta))}}y.I=3,y.l&&y.l.ra(),y.aa&&(y.T=Date.now()-l.F,y.j.info("Handshake RTT: "+y.T+"ms")),w=y;var Z=l;if(w.na=ea(w,w.L?w.ba:null,w.W),Z.L){Mi(w.h,Z);var _e=Z,st=w.O;st&&(_e.H=st),_e.D&&(Ss(_e),Vi(_e)),w.g=Z}else Dt(w);y.i.length>0&&fr(y)}else je[0]!="stop"&&je[0]!="close"||nn(y,7);else y.I==3&&(je[0]=="stop"||je[0]=="close"?je[0]=="stop"?nn(y,7):xs(y):je[0]!="noop"&&y.l&&y.l.qa(je),y.A=0)}}sr(4)}catch{}}var kc=class{constructor(l,p){this.g=l,this.map=p}};function As(l){this.l=l||10,h.PerformanceNavigationTiming?(l=h.performance.getEntriesByType("navigation"),l=l.length>0&&(l[0].nextHopProtocol=="hq"||l[0].nextHopProtocol=="h2")):l=!!(h.chrome&&h.chrome.loadTimes&&h.chrome.loadTimes()&&h.chrome.loadTimes().wasFetchedViaSpdy),this.j=l?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function Bo(l){return l.h?!0:l.g?l.g.size>=l.j:!1}function Li(l){return l.h?1:l.g?l.g.size:0}function $o(l,p){return l.h?l.h==p:l.g?l.g.has(p):!1}function Rs(l,p){l.g?l.g.add(p):l.h=p}function Mi(l,p){l.h&&l.h==p?l.h=null:l.g&&l.g.has(p)&&l.g.delete(p)}As.prototype.cancel=function(){if(this.i=Xt(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const l of this.g.values())l.cancel();this.g.clear()}};function Xt(l){if(l.h!=null)return l.i.concat(l.h.G);if(l.g!=null&&l.g.size!==0){let p=l.i;for(const y of l.g.values())p=p.concat(y.G);return p}return z(l.i)}var Il=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function Zt(l,p){if(l){l=l.split("&");for(let y=0;y<l.length;y++){const w=l[y].indexOf("=");let b,j=null;w>=0?(b=l[y].substring(0,w),j=l[y].substring(w+1)):b=l[y],p(b,j?decodeURIComponent(j.replace(/\+/g," ")):"")}}}function Mn(l){this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1;let p;l instanceof Mn?(this.l=l.l,bi(this,l.j),this.o=l.o,this.g=l.g,bn(this,l.u),this.h=l.h,$r(this,Jo(l.i)),this.m=l.m):l&&(p=String(l).match(Il))?(this.l=!1,bi(this,p[1]||"",!0),this.o=Fi(p[2]||""),this.g=Fi(p[3]||"",!0),bn(this,p[4]),this.h=Fi(p[5]||"",!0),$r(this,p[6]||"",!0),this.m=Fi(p[7]||"")):(this.l=!1,this.i=new Ne(null,this.l))}Mn.prototype.toString=function(){const l=[];var p=this.j;p&&l.push(Ui(p,qo,!0),":");var y=this.g;return(y||p=="file")&&(l.push("//"),(p=this.o)&&l.push(Ui(p,qo,!0),"@"),l.push(Ln(y).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),y=this.u,y!=null&&l.push(":",String(y))),(y=this.h)&&(this.g&&y.charAt(0)!="/"&&l.push("/"),l.push(Ui(y,y.charAt(0)=="/"?ji:Wo,!0))),(y=this.i.toString())&&l.push("?",y),(y=this.m)&&l.push("#",Ui(y,Ko)),l.join("")},Mn.prototype.resolve=function(l){const p=cn(this);let y=!!l.j;y?bi(p,l.j):y=!!l.o,y?p.o=l.o:y=!!l.g,y?p.g=l.g:y=l.u!=null;var w=l.h;if(y)bn(p,l.u);else if(y=!!l.h){if(w.charAt(0)!="/")if(this.g&&!this.h)w="/"+w;else{var b=p.h.lastIndexOf("/");b!=-1&&(w=p.h.slice(0,b+1)+w)}if(b=w,b==".."||b==".")w="";else if(b.indexOf("./")!=-1||b.indexOf("/.")!=-1){w=b.lastIndexOf("/",0)==0,b=b.split("/");const j=[];for(let Z=0;Z<b.length;){const _e=b[Z++];_e=="."?w&&Z==b.length&&j.push(""):_e==".."?((j.length>1||j.length==1&&j[0]!="")&&j.pop(),w&&Z==b.length&&j.push("")):(j.push(_e),w=!0)}w=j.join("/")}else w=b}return y?p.h=w:y=l.i.toString()!=="",y?$r(p,Jo(l.i)):y=!!l.m,y&&(p.m=l.m),p};function cn(l){return new Mn(l)}function bi(l,p,y){l.j=y?Fi(p,!0):p,l.j&&(l.j=l.j.replace(/:$/,""))}function bn(l,p){if(p){if(p=Number(p),isNaN(p)||p<0)throw Error("Bad port number "+p);l.u=p}else l.u=null}function $r(l,p,y){p instanceof Ne?(l.i=p,Ps(l.i,l.l)):(y||(p=Ui(p,Nc)),l.i=new Ne(p,l.l))}function Me(l,p,y){l.i.set(p,y)}function ur(l){return Me(l,"zx",Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)),l}function Fi(l,p){return l?p?decodeURI(l.replace(/%25/g,"%2525")):decodeURIComponent(l):""}function Ui(l,p,y){return typeof l=="string"?(l=encodeURI(l).replace(p,Ho),y&&(l=l.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),l):null}function Ho(l){return l=l.charCodeAt(0),"%"+(l>>4&15).toString(16)+(l&15).toString(16)}var qo=/[#\/\?@]/g,Wo=/[#\?:]/g,ji=/[#\?]/g,Nc=/[#\?@]/g,Ko=/#/g;function Ne(l,p){this.h=this.g=null,this.i=l||null,this.j=!!p}function Fn(l){l.g||(l.g=new Map,l.h=0,l.i&&Zt(l.i,function(p,y){l.add(decodeURIComponent(p.replace(/\+/g," ")),y)}))}r=Ne.prototype,r.add=function(l,p){Fn(this),this.i=null,l=Un(this,l);let y=this.g.get(l);return y||this.g.set(l,y=[]),y.push(p),this.h+=1,this};function Go(l,p){Fn(l),p=Un(l,p),l.g.has(p)&&(l.i=null,l.h-=l.g.get(p).length,l.g.delete(p))}function Cs(l,p){return Fn(l),p=Un(l,p),l.g.has(p)}r.forEach=function(l,p){Fn(this),this.g.forEach(function(y,w){y.forEach(function(b){l.call(p,b,w,this)},this)},this)};function Qo(l,p){Fn(l);let y=[];if(typeof p=="string")Cs(l,p)&&(y=y.concat(l.g.get(Un(l,p))));else for(l=Array.from(l.g.values()),p=0;p<l.length;p++)y=y.concat(l[p]);return y}r.set=function(l,p){return Fn(this),this.i=null,l=Un(this,l),Cs(this,l)&&(this.h-=this.g.get(l).length),this.g.set(l,[p]),this.h+=1,this},r.get=function(l,p){return l?(l=Qo(this,l),l.length>0?String(l[0]):p):p};function Yo(l,p,y){Go(l,p),y.length>0&&(l.i=null,l.g.set(Un(l,p),z(y)),l.h+=y.length)}r.toString=function(){if(this.i)return this.i;if(!this.g)return"";const l=[],p=Array.from(this.g.keys());for(let w=0;w<p.length;w++){var y=p[w];const b=Ln(y);y=Qo(this,y);for(let j=0;j<y.length;j++){let Z=b;y[j]!==""&&(Z+="="+Ln(y[j])),l.push(Z)}}return this.i=l.join("&")};function Jo(l){const p=new Ne;return p.i=l.i,l.g&&(p.g=new Map(l.g),p.h=l.h),p}function Un(l,p){return p=String(p),l.j&&(p=p.toLowerCase()),p}function Ps(l,p){p&&!l.j&&(Fn(l),l.i=null,l.g.forEach(function(y,w){const b=w.toLowerCase();w!=b&&(Go(this,w),Yo(this,b,y))},l)),l.j=p}function jn(l,p){const y=new jr;if(h.Image){const w=new Image;w.onload=E(At,y,"TestLoadImage: loaded",!0,p,w),w.onerror=E(At,y,"TestLoadImage: error",!1,p,w),w.onabort=E(At,y,"TestLoadImage: abort",!1,p,w),w.ontimeout=E(At,y,"TestLoadImage: timeout",!1,p,w),h.setTimeout(function(){w.ontimeout&&w.ontimeout()},1e4),w.src=l}else p(!1)}function zn(l,p){const y=new jr,w=new AbortController,b=setTimeout(()=>{w.abort(),At(y,"TestPingServer: timeout",!1,p)},1e4);fetch(l,{signal:w.signal}).then(j=>{clearTimeout(b),j.ok?At(y,"TestPingServer: ok",!0,p):At(y,"TestPingServer: server error",!1,p)}).catch(()=>{clearTimeout(b),At(y,"TestPingServer: error",!1,p)})}function At(l,p,y,w,b){try{b&&(b.onload=null,b.onerror=null,b.onabort=null,b.ontimeout=null),w(y)}catch{}}function zi(){this.g=new xi}function cr(l){this.i=l.Sb||null,this.h=l.ab||!1}S(cr,Mr),cr.prototype.g=function(){return new en(this.i,this.h)};function en(l,p){ut.call(this),this.H=l,this.o=p,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}S(en,ut),r=en.prototype,r.open=function(l,p){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.F=l,this.D=p,this.readyState=1,Tn(this)},r.send=function(l){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const p={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};l&&(p.body=l),(this.H||h).fetch(new Request(this.D,p)).then(this.Pa.bind(this),this.ga.bind(this))},r.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&this.readyState!=4&&(this.g=!1,Hr(this)),this.readyState=0},r.Pa=function(l){if(this.g&&(this.l=l,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=l.headers,this.readyState=2,Tn(this)),this.g&&(this.readyState=3,Tn(this),this.g)))if(this.responseType==="arraybuffer")l.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(typeof h.ReadableStream<"u"&&"body"in l){if(this.j=l.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;Sl(this)}else l.text().then(this.Oa.bind(this),this.ga.bind(this))};function Sl(l){l.j.read().then(l.Ma.bind(l)).catch(l.ga.bind(l))}r.Ma=function(l){if(this.g){if(this.o&&l.value)this.response.push(l.value);else if(!this.o){var p=l.value?l.value:new Uint8Array(0);(p=this.B.decode(p,{stream:!l.done}))&&(this.response=this.responseText+=p)}l.done?Hr(this):Tn(this),this.readyState==3&&Sl(this)}},r.Oa=function(l){this.g&&(this.response=this.responseText=l,Hr(this))},r.Na=function(l){this.g&&(this.response=l,Hr(this))},r.ga=function(){this.g&&Hr(this)};function Hr(l){l.readyState=4,l.l=null,l.j=null,l.B=null,Tn(l)}r.setRequestHeader=function(l,p){this.A.append(l,p)},r.getResponseHeader=function(l){return this.h&&this.h.get(l.toLowerCase())||""},r.getAllResponseHeaders=function(){if(!this.h)return"";const l=[],p=this.h.entries();for(var y=p.next();!y.done;)y=y.value,l.push(y[0]+": "+y[1]),y=p.next();return l.join(`\r
`)};function Tn(l){l.onreadystatechange&&l.onreadystatechange.call(l)}Object.defineProperty(en.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(l){this.m=l?"include":"same-origin"}});function Al(l){let p="";return ue(l,function(y,w){p+=w,p+=":",p+=y,p+=`\r
`}),p}function ks(l,p,y){e:{for(w in y){var w=!1;break e}w=!0}w||(y=Al(y),typeof l=="string"?y!=null&&Ln(y):Me(l,p,y))}function qe(l){ut.call(this),this.headers=new Map,this.L=l||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}S(qe,ut);var Rl=/^https?$/i,xc=["POST","PUT"];r=qe.prototype,r.Fa=function(l){this.H=l},r.ea=function(l,p,y,w){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+l);p=p?p.toUpperCase():"GET",this.D=l,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():yl.g(),this.g.onreadystatechange=V(_(this.Ca,this));try{this.B=!0,this.g.open(p,String(l),!0),this.B=!1}catch(j){qr(this,j);return}if(l=y||"",y=new Map(this.headers),w)if(Object.getPrototypeOf(w)===Object.prototype)for(var b in w)y.set(b,w[b]);else if(typeof w.keys=="function"&&typeof w.get=="function")for(const j of w.keys())y.set(j,w.get(j));else throw Error("Unknown input type for opt_headers: "+String(w));w=Array.from(y.keys()).find(j=>j.toLowerCase()=="content-type"),b=h.FormData&&l instanceof h.FormData,!(Array.prototype.indexOf.call(xc,p,void 0)>=0)||w||b||y.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[j,Z]of y)this.g.setRequestHeader(j,Z);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(l),this.v=!1}catch(j){qr(this,j)}};function qr(l,p){l.h=!1,l.g&&(l.j=!0,l.g.abort(),l.j=!1),l.l=p,l.o=5,Wr(l),dr(l)}function Wr(l){l.A||(l.A=!0,it(l,"complete"),it(l,"error"))}r.abort=function(l){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=l||7,it(this,"complete"),it(this,"abort"),dr(this))},r.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),dr(this,!0)),qe.Z.N.call(this)},r.Ca=function(){this.u||(this.B||this.v||this.j?hr(this):this.Xa())},r.Xa=function(){hr(this)};function hr(l){if(l.h&&typeof u<"u"){if(l.v&&Bn(l)==4)setTimeout(l.Ca.bind(l),0);else if(it(l,"readystatechange"),Bn(l)==4){l.h=!1;try{const j=l.ca();e:switch(j){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var p=!0;break e;default:p=!1}var y;if(!(y=p)){var w;if(w=j===0){let Z=String(l.D).match(Il)[1]||null;!Z&&h.self&&h.self.location&&(Z=h.self.location.protocol.slice(0,-1)),w=!Rl.test(Z?Z.toLowerCase():"")}y=w}if(y)it(l,"complete"),it(l,"success");else{l.o=6;try{var b=Bn(l)>2?l.g.statusText:""}catch{b=""}l.l=b+" ["+l.ca()+"]",Wr(l)}}finally{dr(l)}}}}function dr(l,p){if(l.g){l.m&&(clearTimeout(l.m),l.m=null);const y=l.g;l.g=null,p||it(l,"ready");try{y.onreadystatechange=null}catch{}}}r.isActive=function(){return!!this.g};function Bn(l){return l.g?l.g.readyState:0}r.ca=function(){try{return Bn(this)>2?this.g.status:-1}catch{return-1}},r.la=function(){try{return this.g?this.g.responseText:""}catch{return""}},r.La=function(l){if(this.g){var p=this.g.responseText;return l&&p.indexOf(l)==0&&(p=p.substring(l.length)),dl(p)}};function Cl(l){try{if(!l.g)return null;if("response"in l.g)return l.g.response;switch(l.F){case"":case"text":return l.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in l.g)return l.g.mozResponseArrayBuffer}return null}catch{return null}}function Xo(l){const p={};l=(l.g&&Bn(l)>=2&&l.g.getAllResponseHeaders()||"").split(`\r
`);for(let w=0;w<l.length;w++){if(A(l[w]))continue;var y=Is(l[w]);const b=y[0];if(y=y[1],typeof y!="string")continue;y=y.trim();const j=p[b]||[];p[b]=j,j.push(y)}te(p,function(w){return w.join(", ")})}r.ya=function(){return this.o},r.Ha=function(){return typeof this.l=="string"?this.l:String(this.l)};function $n(l,p,y){return y&&y.internalChannelParams&&y.internalChannelParams[l]||p}function Ns(l){this.za=0,this.i=[],this.j=new jr,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=$n("failFast",!1,l),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=$n("baseRetryDelayMs",5e3,l),this.Za=$n("retryDelaySeedMs",1e4,l),this.Ta=$n("forwardChannelMaxRetries",2,l),this.va=$n("forwardChannelRequestTimeoutMs",2e4,l),this.ma=l&&l.xmlHttpFactory||void 0,this.Ua=l&&l.Rb||void 0,this.Aa=l&&l.useFetchStreams||!1,this.O=void 0,this.L=l&&l.supportsCrossDomainXhr||!1,this.M="",this.h=new As(l&&l.concurrentRequestLimit),this.Ba=new zi,this.S=l&&l.fastHandshake||!1,this.R=l&&l.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=l&&l.Pb||!1,l&&l.ua&&this.j.ua(),l&&l.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&l&&l.detectBufferingProxy||!1,this.ia=void 0,l&&l.longPollingTimeout&&l.longPollingTimeout>0&&(this.ia=l.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}r=Ns.prototype,r.ka=8,r.I=1,r.connect=function(l,p,y,w){nt(0),this.W=l,this.H=p||{},y&&w!==void 0&&(this.H.OSID=y,this.H.OAID=w),this.F=this.X,this.J=ea(this,null,this.W),fr(this)};function xs(l){if(Ds(l),l.I==3){var p=l.V++,y=cn(l.J);if(Me(y,"SID",l.M),Me(y,"RID",p),Me(y,"TYPE","terminate"),Hn(l,y),p=new un(l,l.j,p),p.M=2,p.A=ur(cn(y)),y=!1,h.navigator&&h.navigator.sendBeacon)try{y=h.navigator.sendBeacon(p.A.toString(),"")}catch{}!y&&h.Image&&(new Image().src=p.A,y=!0),y||(p.g=kl(p.j,null),p.g.ea(p.A)),p.F=Date.now(),Vi(p)}Hi(l)}function tn(l){l.g&&($i(l),l.g.cancel(),l.g=null)}function Ds(l){tn(l),l.v&&(h.clearTimeout(l.v),l.v=null),Vs(l),l.h.cancel(),l.m&&(typeof l.m=="number"&&h.clearTimeout(l.m),l.m=null)}function fr(l){if(!Bo(l.h)&&!l.m){l.m=!0;var p=l.Ea;be||T(),ke||(be(),ke=!0),C.add(p,l),l.D=0}}function Pl(l,p){return Li(l.h)>=l.h.j-(l.m?1:0)?!1:l.m?(l.i=p.G.concat(l.i),!0):l.I==1||l.I==2||l.D>=(l.Sa?0:l.Ta)?!1:(l.m=Ur(_(l.Ea,l,p),Ls(l,l.D)),l.D++,!0)}r.Ea=function(l){if(this.m)if(this.m=null,this.I==1){if(!l){this.V=Math.floor(Math.random()*1e5),l=this.V++;const b=new un(this,this.j,l);let j=this.o;if(this.U&&(j?(j=O(j),Ee(j,this.U)):j=this.U),this.u!==null||this.R||(b.J=j,j=null),this.S)e:{for(var p=0,y=0;y<this.i.length;y++){t:{var w=this.i[y];if("__data__"in w.map&&(w=w.map.__data__,typeof w=="string")){w=w.length;break t}w=void 0}if(w===void 0)break;if(p+=w,p>4096){p=y;break e}if(p===4096||y===this.i.length-1){p=y+1;break e}}p=1e3}else p=1e3;p=Zo(this,b,p),y=cn(this.J),Me(y,"RID",l),Me(y,"CVER",22),this.G&&Me(y,"X-HTTP-Session-Id",this.G),Hn(this,y),j&&(this.R?p="headers="+Ln(Al(j))+"&"+p:this.u&&ks(y,this.u,j)),Rs(this.h,b),this.Ra&&Me(y,"TYPE","init"),this.S?(Me(y,"$req",p),Me(y,"SID","null"),b.U=!0,wn(b,y,null)):wn(b,y,p),this.I=2}}else this.I==3&&(l?Bi(this,l):this.i.length==0||Bo(this.h)||Bi(this))};function Bi(l,p){var y;p?y=p.l:y=l.V++;const w=cn(l.J);Me(w,"SID",l.M),Me(w,"RID",y),Me(w,"AID",l.K),Hn(l,w),l.u&&l.o&&ks(w,l.u,l.o),y=new un(l,l.j,y,l.D+1),l.u===null&&(y.J=l.o),p&&(l.i=p.G.concat(l.i)),p=Zo(l,y,1e3),y.H=Math.round(l.va*.5)+Math.round(l.va*.5*Math.random()),Rs(l.h,y),wn(y,w,p)}function Hn(l,p){l.H&&ue(l.H,function(y,w){Me(p,w,y)}),l.l&&ue({},function(y,w){Me(p,w,y)})}function Zo(l,p,y){y=Math.min(l.i.length,y);const w=l.l?_(l.l.Ka,l.l,l):null;e:{var b=l.i;let _e=-1;for(;;){const st=["count="+y];_e==-1?y>0?(_e=b[0].g,st.push("ofs="+_e)):_e=0:st.push("ofs="+_e);let je=!0;for(let ct=0;ct<y;ct++){var j=b[ct].g;const rn=b[ct].map;if(j-=_e,j<0)_e=Math.max(0,b[ct].g-100),je=!1;else try{j="req"+j+"_"||"";try{var Z=rn instanceof Map?rn:Object.entries(rn);for(const[pr,Wn]of Z){let Kn=Wn;m(Wn)&&(Kn=Lr(Wn)),st.push(j+pr+"="+encodeURIComponent(Kn))}}catch(pr){throw st.push(j+"type="+encodeURIComponent("_badmap")),pr}}catch{w&&w(rn)}}if(je){Z=st.join("&");break e}}Z=void 0}return l=l.i.splice(0,y),p.G=l,Z}function Dt(l){if(!l.g&&!l.v){l.Y=1;var p=l.Da;be||T(),ke||(be(),ke=!0),C.add(p,l),l.A=0}}function qn(l){return l.g||l.v||l.A>=3?!1:(l.Y++,l.v=Ur(_(l.Da,l),Ls(l,l.A)),l.A++,!0)}r.Da=function(){if(this.v=null,Kr(this),this.aa&&!(this.P||this.g==null||this.T<=0)){var l=4*this.T;this.j.info("BP detection timer enabled: "+l),this.B=Ur(_(this.Wa,this),l)}},r.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,nt(10),tn(this),Kr(this))};function $i(l){l.B!=null&&(h.clearTimeout(l.B),l.B=null)}function Kr(l){l.g=new un(l,l.j,"rpc",l.Y),l.u===null&&(l.g.J=l.o),l.g.P=0;var p=cn(l.na);Me(p,"RID","rpc"),Me(p,"SID",l.M),Me(p,"AID",l.K),Me(p,"CI",l.F?"0":"1"),!l.F&&l.ia&&Me(p,"TO",l.ia),Me(p,"TYPE","xmlhttp"),Hn(l,p),l.u&&l.o&&ks(p,l.u,l.o),l.O&&(l.g.H=l.O);var y=l.g;l=l.ba,y.M=1,y.A=ur(cn(p)),y.u=null,y.R=!0,jo(y,l)}r.Va=function(){this.C!=null&&(this.C=null,tn(this),qn(this),nt(19))};function Vs(l){l.C!=null&&(h.clearTimeout(l.C),l.C=null)}function Os(l,p){var y=null;if(l.g==p){Vs(l),$i(l),l.g=null;var w=2}else if($o(l.h,p))y=p.G,Mi(l.h,p),w=1;else return;if(l.I!=0){if(p.o)if(w==1){y=p.u?p.u.length:0,p=Date.now()-p.F;var b=l.D;w=Fr(),it(w,new Fo(w,y)),fr(l)}else Dt(l);else if(b=p.m,b==3||b==0&&p.X>0||!(w==1&&Pl(l,p)||w==2&&qn(l)))switch(y&&y.length>0&&(p=l.h,p.i=p.i.concat(y)),b){case 1:nn(l,5);break;case 4:nn(l,10);break;case 3:nn(l,6);break;default:nn(l,2)}}}function Ls(l,p){let y=l.Qa+Math.floor(Math.random()*l.Za);return l.isActive()||(y*=2),y*p}function nn(l,p){if(l.j.info("Error code "+p),p==2){var y=_(l.bb,l),w=l.Ua;const b=!w;w=new Mn(w||"//www.google.com/images/cleardot.gif"),h.location&&h.location.protocol=="http"||bi(w,"https"),ur(w),b?jn(w.toString(),y):zn(w.toString(),y)}else nt(2);l.I=0,l.l&&l.l.pa(p),Hi(l),Ds(l)}r.bb=function(l){l?(this.j.info("Successfully pinged google.com"),nt(2)):(this.j.info("Failed to ping google.com"),nt(1))};function Hi(l){if(l.I=0,l.ja=[],l.l){const p=Xt(l.h);(p.length!=0||l.i.length!=0)&&(Q(l.ja,p),Q(l.ja,l.i),l.h.i.length=0,z(l.i),l.i.length=0),l.l.oa()}}function ea(l,p,y){var w=y instanceof Mn?cn(y):new Mn(y);if(w.g!="")p&&(w.g=p+"."+w.g),bn(w,w.u);else{var b=h.location;w=b.protocol,p=p?p+"."+b.hostname:b.hostname,b=+b.port;const j=new Mn(null);w&&bi(j,w),p&&(j.g=p),b&&bn(j,b),y&&(j.h=y),w=j}return y=l.G,p=l.wa,y&&p&&Me(w,y,p),Me(w,"VER",l.ka),Hn(l,w),w}function kl(l,p,y){if(p&&!l.L)throw Error("Can't create secondary domain capable XhrIo object.");return p=l.Aa&&!l.ma?new qe(new cr({ab:y})):new qe(l.ma),p.Fa(l.L),p}r.isActive=function(){return!!this.l&&this.l.isActive(this)};function Nl(){}r=Nl.prototype,r.ra=function(){},r.qa=function(){},r.pa=function(){},r.oa=function(){},r.isActive=function(){return!0},r.Ka=function(){};function Ms(){}Ms.prototype.g=function(l,p){return new Rt(l,p)};function Rt(l,p){ut.call(this),this.g=new Ns(p),this.l=l,this.h=p&&p.messageUrlParams||null,l=p&&p.messageHeaders||null,p&&p.clientProtocolHeaderRequired&&(l?l["X-Client-Protocol"]="webchannel":l={"X-Client-Protocol":"webchannel"}),this.g.o=l,l=p&&p.initMessageHeaders||null,p&&p.messageContentType&&(l?l["X-WebChannel-Content-Type"]=p.messageContentType:l={"X-WebChannel-Content-Type":p.messageContentType}),p&&p.sa&&(l?l["X-WebChannel-Client-Profile"]=p.sa:l={"X-WebChannel-Client-Profile":p.sa}),this.g.U=l,(l=p&&p.Qb)&&!A(l)&&(this.g.u=l),this.A=p&&p.supportsCrossDomainXhr||!1,this.v=p&&p.sendRawJson||!1,(p=p&&p.httpSessionIdParam)&&!A(p)&&(this.g.G=p,l=this.h,l!==null&&p in l&&(l=this.h,p in l&&delete l[p])),this.j=new Gr(this)}S(Rt,ut),Rt.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},Rt.prototype.close=function(){xs(this.g)},Rt.prototype.o=function(l){var p=this.g;if(typeof l=="string"){var y={};y.__data__=l,l=y}else this.v&&(y={},y.__data__=Lr(l),l=y);p.i.push(new kc(p.Ya++,l)),p.I==3&&fr(p)},Rt.prototype.N=function(){this.g.l=null,delete this.j,xs(this.g),delete this.g,Rt.Z.N.call(this)};function xl(l){Es.call(this),l.__headers__&&(this.headers=l.__headers__,this.statusCode=l.__status__,delete l.__headers__,delete l.__status__);var p=l.__sm__;if(p){e:{for(const y in p){l=y;break e}l=void 0}(this.i=l)&&(l=this.i,p=p!==null&&l in p?p[l]:void 0),this.data=p}else this.data=l}S(xl,Es);function Dl(){bo.call(this),this.status=1}S(Dl,bo);function Gr(l){this.g=l}S(Gr,Nl),Gr.prototype.ra=function(){it(this.g,"a")},Gr.prototype.qa=function(l){it(this.g,new xl(l))},Gr.prototype.pa=function(l){it(this.g,new Dl)},Gr.prototype.oa=function(){it(this.g,"b")},Ms.prototype.createWebChannel=Ms.prototype.g,Rt.prototype.send=Rt.prototype.o,Rt.prototype.open=Rt.prototype.m,Rt.prototype.close=Rt.prototype.close,R_=function(){return new Ms},A_=function(){return Fr()},S_=En,Id={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},zr.NO_ERROR=0,zr.TIMEOUT=8,zr.HTTP_ERROR=6,Mu=zr,Br.COMPLETE="complete",I_=Br,fl.EventType=br,br.OPEN="a",br.CLOSE="b",br.ERROR="c",br.MESSAGE="d",ut.prototype.listen=ut.prototype.J,Na=fl,qe.prototype.listenOnce=qe.prototype.K,qe.prototype.getLastError=qe.prototype.Ha,qe.prototype.getLastErrorCode=qe.prototype.ya,qe.prototype.getStatus=qe.prototype.ca,qe.prototype.getResponseJson=qe.prototype.La,qe.prototype.getResponseText=qe.prototype.la,qe.prototype.send=qe.prototype.ea,qe.prototype.setWithCredentials=qe.prototype.Fa,T_=qe}).apply(typeof Cu<"u"?Cu:typeof self<"u"?self:typeof window<"u"?window:{});/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ft{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}Ft.UNAUTHENTICATED=new Ft(null),Ft.GOOGLE_CREDENTIALS=new Ft("google-credentials-uid"),Ft.FIRST_PARTY=new Ft("first-party-uid"),Ft.MOCK_USER=new Ft("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Co="12.11.0";function gS(r){Co=r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hs=new zd("@firebase/firestore");function io(){return hs.logLevel}function ne(r,...e){if(hs.logLevel<=Re.DEBUG){const t=e.map(Xd);hs.debug(`Firestore (${Co}): ${r}`,...t)}}function Pr(r,...e){if(hs.logLevel<=Re.ERROR){const t=e.map(Xd);hs.error(`Firestore (${Co}): ${r}`,...t)}}function ds(r,...e){if(hs.logLevel<=Re.WARN){const t=e.map(Xd);hs.warn(`Firestore (${Co}): ${r}`,...t)}}function Xd(r){if(typeof r=="string")return r;try{return(function(t){return JSON.stringify(t)})(r)}catch{return r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pe(r,e,t){let s="Unexpected state";typeof e=="string"?s=e:t=e,C_(r,s,t)}function C_(r,e,t){let s=`FIRESTORE (${Co}) INTERNAL ASSERTION FAILED: ${e} (ID: ${r.toString(16)})`;if(t!==void 0)try{s+=" CONTEXT: "+JSON.stringify(t)}catch{s+=" CONTEXT: "+t}throw Pr(s),new Error(s)}function Ue(r,e,t,s){let o="Unexpected state";typeof t=="string"?o=t:s=t,r||C_(e,o,s)}function ve(r,e){return r}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const B={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class re extends Nr{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ss{constructor(){this.promise=new Promise(((e,t)=>{this.resolve=e,this.reject=t}))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class P_{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class yS{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable((()=>t(Ft.UNAUTHENTICATED)))}shutdown(){}}class _S{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable((()=>t(this.token.user)))}shutdown(){this.changeListener=null}}class vS{constructor(e){this.t=e,this.currentUser=Ft.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){Ue(this.o===void 0,42304);let s=this.i;const o=g=>this.i!==s?(s=this.i,t(g)):Promise.resolve();let u=new ss;this.o=()=>{this.i++,this.currentUser=this.u(),u.resolve(),u=new ss,e.enqueueRetryable((()=>o(this.currentUser)))};const h=()=>{const g=u;e.enqueueRetryable((async()=>{await g.promise,await o(this.currentUser)}))},m=g=>{ne("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=g,this.o&&(this.auth.addAuthTokenListener(this.o),h())};this.t.onInit((g=>m(g))),setTimeout((()=>{if(!this.auth){const g=this.t.getImmediate({optional:!0});g?m(g):(ne("FirebaseAuthCredentialsProvider","Auth not yet detected"),u.resolve(),u=new ss)}}),0),h()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then((s=>this.i!==e?(ne("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):s?(Ue(typeof s.accessToken=="string",31837,{l:s}),new P_(s.accessToken,this.currentUser)):null)):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.o&&this.auth.removeAuthTokenListener(this.o),this.o=void 0}u(){const e=this.auth&&this.auth.getUid();return Ue(e===null||typeof e=="string",2055,{h:e}),new Ft(e)}}class ES{constructor(e,t,s){this.P=e,this.T=t,this.I=s,this.type="FirstParty",this.user=Ft.FIRST_PARTY,this.R=new Map}A(){return this.I?this.I():null}get headers(){this.R.set("X-Goog-AuthUser",this.P);const e=this.A();return e&&this.R.set("Authorization",e),this.T&&this.R.set("X-Goog-Iam-Authorization-Token",this.T),this.R}}class wS{constructor(e,t,s){this.P=e,this.T=t,this.I=s}getToken(){return Promise.resolve(new ES(this.P,this.T,this.I))}start(e,t){e.enqueueRetryable((()=>t(Ft.FIRST_PARTY)))}shutdown(){}invalidateToken(){}}class Rg{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class TS{constructor(e,t){this.V=t,this.forceRefresh=!1,this.appCheck=null,this.m=null,this.p=null,yn(e)&&e.settings.appCheckToken&&(this.p=e.settings.appCheckToken)}start(e,t){Ue(this.o===void 0,3512);const s=u=>{u.error!=null&&ne("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${u.error.message}`);const h=u.token!==this.m;return this.m=u.token,ne("FirebaseAppCheckTokenProvider",`Received ${h?"new":"existing"} token.`),h?t(u.token):Promise.resolve()};this.o=u=>{e.enqueueRetryable((()=>s(u)))};const o=u=>{ne("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=u,this.o&&this.appCheck.addTokenListener(this.o)};this.V.onInit((u=>o(u))),setTimeout((()=>{if(!this.appCheck){const u=this.V.getImmediate({optional:!0});u?o(u):ne("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}}),0)}getToken(){if(this.p)return Promise.resolve(new Rg(this.p));const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then((t=>t?(Ue(typeof t.token=="string",44558,{tokenResult:t}),this.m=t.token,new Rg(t.token)):null)):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.o&&this.appCheck.removeTokenListener(this.o),this.o=void 0}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function IS(r){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(r);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let s=0;s<r;s++)t[s]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zd{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=62*Math.floor(4.129032258064516);let s="";for(;s.length<20;){const o=IS(40);for(let u=0;u<o.length;++u)s.length<20&&o[u]<t&&(s+=e.charAt(o[u]%62))}return s}}function Ce(r,e){return r<e?-1:r>e?1:0}function Sd(r,e){const t=Math.min(r.length,e.length);for(let s=0;s<t;s++){const o=r.charAt(s),u=e.charAt(s);if(o!==u)return cd(o)===cd(u)?Ce(o,u):cd(o)?1:-1}return Ce(r.length,e.length)}const SS=55296,AS=57343;function cd(r){const e=r.charCodeAt(0);return e>=SS&&e<=AS}function _o(r,e,t){return r.length===e.length&&r.every(((s,o)=>t(s,e[o])))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Cg="__name__";class Xn{constructor(e,t,s){t===void 0?t=0:t>e.length&&pe(637,{offset:t,range:e.length}),s===void 0?s=e.length-t:s>e.length-t&&pe(1746,{length:s,range:e.length-t}),this.segments=e,this.offset=t,this.len=s}get length(){return this.len}isEqual(e){return Xn.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof Xn?e.forEach((s=>{t.push(s)})):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,s=this.limit();t<s;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const s=Math.min(e.length,t.length);for(let o=0;o<s;o++){const u=Xn.compareSegments(e.get(o),t.get(o));if(u!==0)return u}return Ce(e.length,t.length)}static compareSegments(e,t){const s=Xn.isNumericId(e),o=Xn.isNumericId(t);return s&&!o?-1:!s&&o?1:s&&o?Xn.extractNumericId(e).compare(Xn.extractNumericId(t)):Sd(e,t)}static isNumericId(e){return e.startsWith("__id")&&e.endsWith("__")}static extractNumericId(e){return _i.fromString(e.substring(4,e.length-2))}}class Ke extends Xn{construct(e,t,s){return new Ke(e,t,s)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const s of e){if(s.indexOf("//")>=0)throw new re(B.INVALID_ARGUMENT,`Invalid segment (${s}). Paths must not contain // in them.`);t.push(...s.split("/").filter((o=>o.length>0)))}return new Ke(t)}static emptyPath(){return new Ke([])}}const RS=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class Nt extends Xn{construct(e,t,s){return new Nt(e,t,s)}static isValidIdentifier(e){return RS.test(e)}canonicalString(){return this.toArray().map((e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),Nt.isValidIdentifier(e)||(e="`"+e+"`"),e))).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===Cg}static keyField(){return new Nt([Cg])}static fromServerFormat(e){const t=[];let s="",o=0;const u=()=>{if(s.length===0)throw new re(B.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(s),s=""};let h=!1;for(;o<e.length;){const m=e[o];if(m==="\\"){if(o+1===e.length)throw new re(B.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const g=e[o+1];if(g!=="\\"&&g!=="."&&g!=="`")throw new re(B.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);s+=g,o+=2}else m==="`"?(h=!h,o++):m!=="."||h?(s+=m,o++):(u(),o++)}if(u(),h)throw new re(B.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new Nt(t)}static emptyPath(){return new Nt([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ce{constructor(e){this.path=e}static fromPath(e){return new ce(Ke.fromString(e))}static fromName(e){return new ce(Ke.fromString(e).popFirst(5))}static empty(){return new ce(Ke.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&Ke.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return Ke.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new ce(new Ke(e.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function k_(r,e,t){if(!t)throw new re(B.INVALID_ARGUMENT,`Function ${r}() cannot be called with an empty ${e}.`)}function CS(r,e,t,s){if(e===!0&&s===!0)throw new re(B.INVALID_ARGUMENT,`${r} and ${t} cannot be used together.`)}function Pg(r){if(!ce.isDocumentKey(r))throw new re(B.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${r} has ${r.length}.`)}function kg(r){if(ce.isDocumentKey(r))throw new re(B.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${r} has ${r.length}.`)}function N_(r){return typeof r=="object"&&r!==null&&(Object.getPrototypeOf(r)===Object.prototype||Object.getPrototypeOf(r)===null)}function fc(r){if(r===void 0)return"undefined";if(r===null)return"null";if(typeof r=="string")return r.length>20&&(r=`${r.substring(0,20)}...`),JSON.stringify(r);if(typeof r=="number"||typeof r=="boolean")return""+r;if(typeof r=="object"){if(r instanceof Array)return"an array";{const e=(function(s){return s.constructor?s.constructor.name:null})(r);return e?`a custom ${e} object`:"an object"}}return typeof r=="function"?"a function":pe(12329,{type:typeof r})}function vi(r,e){if("_delegate"in r&&(r=r._delegate),!(r instanceof e)){if(e.name===r.constructor.name)throw new re(B.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=fc(r);throw new re(B.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return r}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pt(r,e){const t={typeString:r};return e&&(t.value=e),t}function rl(r,e){if(!N_(r))throw new re(B.INVALID_ARGUMENT,"JSON must be an object");let t;for(const s in e)if(e[s]){const o=e[s].typeString,u="value"in e[s]?{value:e[s].value}:void 0;if(!(s in r)){t=`JSON missing required field: '${s}'`;break}const h=r[s];if(o&&typeof h!==o){t=`JSON field '${s}' must be a ${o}.`;break}if(u!==void 0&&h!==u.value){t=`Expected '${s}' field to equal '${u.value}'`;break}}if(t)throw new re(B.INVALID_ARGUMENT,t);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ng=-62135596800,xg=1e6;class Je{static now(){return Je.fromMillis(Date.now())}static fromDate(e){return Je.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),s=Math.floor((e-1e3*t)*xg);return new Je(t,s)}constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new re(B.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new re(B.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<Ng)throw new re(B.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new re(B.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/xg}_compareTo(e){return this.seconds===e.seconds?Ce(this.nanoseconds,e.nanoseconds):Ce(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:Je._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(e){if(rl(e,Je._jsonSchema))return new Je(e.seconds,e.nanoseconds)}valueOf(){const e=this.seconds-Ng;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}Je._jsonSchemaVersion="firestore/timestamp/1.0",Je._jsonSchema={type:pt("string",Je._jsonSchemaVersion),seconds:pt("number"),nanoseconds:pt("number")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ye{static fromTimestamp(e){return new ye(e)}static min(){return new ye(new Je(0,0))}static max(){return new ye(new Je(253402300799,999999999))}constructor(e){this.timestamp=e}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $a=-1;function PS(r,e){const t=r.toTimestamp().seconds,s=r.toTimestamp().nanoseconds+1,o=ye.fromTimestamp(s===1e9?new Je(t+1,0):new Je(t,s));return new wi(o,ce.empty(),e)}function kS(r){return new wi(r.readTime,r.key,$a)}class wi{constructor(e,t,s){this.readTime=e,this.documentKey=t,this.largestBatchId=s}static min(){return new wi(ye.min(),ce.empty(),$a)}static max(){return new wi(ye.max(),ce.empty(),$a)}}function NS(r,e){let t=r.readTime.compareTo(e.readTime);return t!==0?t:(t=ce.comparator(r.documentKey,e.documentKey),t!==0?t:Ce(r.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const xS="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class DS{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach((e=>e()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Po(r){if(r.code!==B.FAILED_PRECONDITION||r.message!==xS)throw r;ne("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ${constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e((t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)}),(t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)}))}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&pe(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new $(((s,o)=>{this.nextCallback=u=>{this.wrapSuccess(e,u).next(s,o)},this.catchCallback=u=>{this.wrapFailure(t,u).next(s,o)}}))}toPromise(){return new Promise(((e,t)=>{this.next(e,t)}))}wrapUserFunction(e){try{const t=e();return t instanceof $?t:$.resolve(t)}catch(t){return $.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction((()=>e(t))):$.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction((()=>e(t))):$.reject(t)}static resolve(e){return new $(((t,s)=>{t(e)}))}static reject(e){return new $(((t,s)=>{s(e)}))}static waitFor(e){return new $(((t,s)=>{let o=0,u=0,h=!1;e.forEach((m=>{++o,m.next((()=>{++u,h&&u===o&&t()}),(g=>s(g)))})),h=!0,u===o&&t()}))}static or(e){let t=$.resolve(!1);for(const s of e)t=t.next((o=>o?$.resolve(o):s()));return t}static forEach(e,t){const s=[];return e.forEach(((o,u)=>{s.push(t.call(this,o,u))})),this.waitFor(s)}static mapArray(e,t){return new $(((s,o)=>{const u=e.length,h=new Array(u);let m=0;for(let g=0;g<u;g++){const _=g;t(e[_]).next((E=>{h[_]=E,++m,m===u&&s(h)}),(E=>o(E)))}}))}static doWhile(e,t){return new $(((s,o)=>{const u=()=>{e()===!0?t().next((()=>{u()}),o):s()};u()}))}}function VS(r){const e=r.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}function ko(r){return r.name==="IndexedDbTransactionError"}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pc{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=s=>this.ae(s),this.ue=s=>t.writeSequenceNumber(s))}ae(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.ue&&this.ue(e),e}}pc.ce=-1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ef=-1;function mc(r){return r==null}function Ju(r){return r===0&&1/r==-1/0}function OS(r){return typeof r=="number"&&Number.isInteger(r)&&!Ju(r)&&r<=Number.MAX_SAFE_INTEGER&&r>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const x_="";function LS(r){let e="";for(let t=0;t<r.length;t++)e.length>0&&(e=Dg(e)),e=MS(r.get(t),e);return Dg(e)}function MS(r,e){let t=e;const s=r.length;for(let o=0;o<s;o++){const u=r.charAt(o);switch(u){case"\0":t+="";break;case x_:t+="";break;default:t+=u}}return t}function Dg(r){return r+x_+""}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vg(r){let e=0;for(const t in r)Object.prototype.hasOwnProperty.call(r,t)&&e++;return e}function Pi(r,e){for(const t in r)Object.prototype.hasOwnProperty.call(r,t)&&e(t,r[t])}function D_(r){for(const e in r)if(Object.prototype.hasOwnProperty.call(r,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tt{constructor(e,t){this.comparator=e,this.root=t||kt.EMPTY}insert(e,t){return new tt(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,kt.BLACK,null,null))}remove(e){return new tt(this.comparator,this.root.remove(e,this.comparator).copy(null,null,kt.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const s=this.comparator(e,t.key);if(s===0)return t.value;s<0?t=t.left:s>0&&(t=t.right)}return null}indexOf(e){let t=0,s=this.root;for(;!s.isEmpty();){const o=this.comparator(e,s.key);if(o===0)return t+s.left.size;o<0?s=s.left:(t+=s.left.size+1,s=s.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal(((t,s)=>(e(t,s),!1)))}toString(){const e=[];return this.inorderTraversal(((t,s)=>(e.push(`${t}:${s}`),!1))),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new Pu(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new Pu(this.root,e,this.comparator,!1)}getReverseIterator(){return new Pu(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new Pu(this.root,e,this.comparator,!0)}}class Pu{constructor(e,t,s,o){this.isReverse=o,this.nodeStack=[];let u=1;for(;!e.isEmpty();)if(u=t?s(e.key,t):1,t&&o&&(u*=-1),u<0)e=this.isReverse?e.left:e.right;else{if(u===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class kt{constructor(e,t,s,o,u){this.key=e,this.value=t,this.color=s??kt.RED,this.left=o??kt.EMPTY,this.right=u??kt.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,s,o,u){return new kt(e??this.key,t??this.value,s??this.color,o??this.left,u??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,s){let o=this;const u=s(e,o.key);return o=u<0?o.copy(null,null,null,o.left.insert(e,t,s),null):u===0?o.copy(null,t,null,null,null):o.copy(null,null,null,null,o.right.insert(e,t,s)),o.fixUp()}removeMin(){if(this.left.isEmpty())return kt.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let s,o=this;if(t(e,o.key)<0)o.left.isEmpty()||o.left.isRed()||o.left.left.isRed()||(o=o.moveRedLeft()),o=o.copy(null,null,null,o.left.remove(e,t),null);else{if(o.left.isRed()&&(o=o.rotateRight()),o.right.isEmpty()||o.right.isRed()||o.right.left.isRed()||(o=o.moveRedRight()),t(e,o.key)===0){if(o.right.isEmpty())return kt.EMPTY;s=o.right.min(),o=o.copy(s.key,s.value,null,null,o.right.removeMin())}o=o.copy(null,null,null,null,o.right.remove(e,t))}return o.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,kt.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,kt.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw pe(43730,{key:this.key,value:this.value});if(this.right.isRed())throw pe(14113,{key:this.key,value:this.value});const e=this.left.check();if(e!==this.right.check())throw pe(27949);return e+(this.isRed()?0:1)}}kt.EMPTY=null,kt.RED=!0,kt.BLACK=!1;kt.EMPTY=new class{constructor(){this.size=0}get key(){throw pe(57766)}get value(){throw pe(16141)}get color(){throw pe(16727)}get left(){throw pe(29726)}get right(){throw pe(36894)}copy(e,t,s,o,u){return this}insert(e,t,s){return new kt(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vt{constructor(e){this.comparator=e,this.data=new tt(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal(((t,s)=>(e(t),!1)))}forEachInRange(e,t){const s=this.data.getIteratorFrom(e[0]);for(;s.hasNext();){const o=s.getNext();if(this.comparator(o.key,e[1])>=0)return;t(o.key)}}forEachWhile(e,t){let s;for(s=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();s.hasNext();)if(!e(s.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new Og(this.data.getIterator())}getIteratorFrom(e){return new Og(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach((s=>{t=t.add(s)})),t}isEqual(e){if(!(e instanceof vt)||this.size!==e.size)return!1;const t=this.data.getIterator(),s=e.data.getIterator();for(;t.hasNext();){const o=t.getNext().key,u=s.getNext().key;if(this.comparator(o,u)!==0)return!1}return!0}toArray(){const e=[];return this.forEach((t=>{e.push(t)})),e}toString(){const e=[];return this.forEach((t=>e.push(t))),"SortedSet("+e.toString()+")"}copy(e){const t=new vt(this.comparator);return t.data=e,t}}class Og{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ln{constructor(e){this.fields=e,e.sort(Nt.comparator)}static empty(){return new ln([])}unionWith(e){let t=new vt(Nt.comparator);for(const s of this.fields)t=t.add(s);for(const s of e)t=t.add(s);return new ln(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return _o(this.fields,e.fields,((t,s)=>t.isEqual(s)))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class V_ extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xt{constructor(e){this.binaryString=e}static fromBase64String(e){const t=(function(o){try{return atob(o)}catch(u){throw typeof DOMException<"u"&&u instanceof DOMException?new V_("Invalid base64 string: "+u):u}})(e);return new xt(t)}static fromUint8Array(e){const t=(function(o){let u="";for(let h=0;h<o.length;++h)u+=String.fromCharCode(o[h]);return u})(e);return new xt(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return(function(t){return btoa(t)})(this.binaryString)}toUint8Array(){return(function(t){const s=new Uint8Array(t.length);for(let o=0;o<t.length;o++)s[o]=t.charCodeAt(o);return s})(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return Ce(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}xt.EMPTY_BYTE_STRING=new xt("");const bS=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function Ti(r){if(Ue(!!r,39018),typeof r=="string"){let e=0;const t=bS.exec(r);if(Ue(!!t,46558,{timestamp:r}),t[1]){let o=t[1];o=(o+"000000000").substr(0,9),e=Number(o)}const s=new Date(r);return{seconds:Math.floor(s.getTime()/1e3),nanos:e}}return{seconds:at(r.seconds),nanos:at(r.nanos)}}function at(r){return typeof r=="number"?r:typeof r=="string"?Number(r):0}function Ii(r){return typeof r=="string"?xt.fromBase64String(r):xt.fromUint8Array(r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const O_="server_timestamp",L_="__type__",M_="__previous_value__",b_="__local_write_time__";function tf(r){var t,s;return((s=(((t=r==null?void 0:r.mapValue)==null?void 0:t.fields)||{})[L_])==null?void 0:s.stringValue)===O_}function gc(r){const e=r.mapValue.fields[M_];return tf(e)?gc(e):e}function Ha(r){const e=Ti(r.mapValue.fields[b_].timestampValue);return new Je(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class FS{constructor(e,t,s,o,u,h,m,g,_,E,S){this.databaseId=e,this.appId=t,this.persistenceKey=s,this.host=o,this.ssl=u,this.forceLongPolling=h,this.autoDetectLongPolling=m,this.longPollingOptions=g,this.useFetchStreams=_,this.isUsingEmulator=E,this.apiKey=S}}const Xu="(default)";class qa{constructor(e,t){this.projectId=e,this.database=t||Xu}static empty(){return new qa("","")}get isDefaultDatabase(){return this.database===Xu}isEqual(e){return e instanceof qa&&e.projectId===this.projectId&&e.database===this.database}}function US(r,e){if(!Object.prototype.hasOwnProperty.apply(r.options,["projectId"]))throw new re(B.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new qa(r.options.projectId,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const F_="__type__",jS="__max__",ku={mapValue:{}},U_="__vector__",Zu="value";function Si(r){return"nullValue"in r?0:"booleanValue"in r?1:"integerValue"in r||"doubleValue"in r?2:"timestampValue"in r?3:"stringValue"in r?5:"bytesValue"in r?6:"referenceValue"in r?7:"geoPointValue"in r?8:"arrayValue"in r?9:"mapValue"in r?tf(r)?4:BS(r)?9007199254740991:zS(r)?10:11:pe(28295,{value:r})}function ir(r,e){if(r===e)return!0;const t=Si(r);if(t!==Si(e))return!1;switch(t){case 0:case 9007199254740991:return!0;case 1:return r.booleanValue===e.booleanValue;case 4:return Ha(r).isEqual(Ha(e));case 3:return(function(o,u){if(typeof o.timestampValue=="string"&&typeof u.timestampValue=="string"&&o.timestampValue.length===u.timestampValue.length)return o.timestampValue===u.timestampValue;const h=Ti(o.timestampValue),m=Ti(u.timestampValue);return h.seconds===m.seconds&&h.nanos===m.nanos})(r,e);case 5:return r.stringValue===e.stringValue;case 6:return(function(o,u){return Ii(o.bytesValue).isEqual(Ii(u.bytesValue))})(r,e);case 7:return r.referenceValue===e.referenceValue;case 8:return(function(o,u){return at(o.geoPointValue.latitude)===at(u.geoPointValue.latitude)&&at(o.geoPointValue.longitude)===at(u.geoPointValue.longitude)})(r,e);case 2:return(function(o,u){if("integerValue"in o&&"integerValue"in u)return at(o.integerValue)===at(u.integerValue);if("doubleValue"in o&&"doubleValue"in u){const h=at(o.doubleValue),m=at(u.doubleValue);return h===m?Ju(h)===Ju(m):isNaN(h)&&isNaN(m)}return!1})(r,e);case 9:return _o(r.arrayValue.values||[],e.arrayValue.values||[],ir);case 10:case 11:return(function(o,u){const h=o.mapValue.fields||{},m=u.mapValue.fields||{};if(Vg(h)!==Vg(m))return!1;for(const g in h)if(h.hasOwnProperty(g)&&(m[g]===void 0||!ir(h[g],m[g])))return!1;return!0})(r,e);default:return pe(52216,{left:r})}}function Wa(r,e){return(r.values||[]).find((t=>ir(t,e)))!==void 0}function vo(r,e){if(r===e)return 0;const t=Si(r),s=Si(e);if(t!==s)return Ce(t,s);switch(t){case 0:case 9007199254740991:return 0;case 1:return Ce(r.booleanValue,e.booleanValue);case 2:return(function(u,h){const m=at(u.integerValue||u.doubleValue),g=at(h.integerValue||h.doubleValue);return m<g?-1:m>g?1:m===g?0:isNaN(m)?isNaN(g)?0:-1:1})(r,e);case 3:return Lg(r.timestampValue,e.timestampValue);case 4:return Lg(Ha(r),Ha(e));case 5:return Sd(r.stringValue,e.stringValue);case 6:return(function(u,h){const m=Ii(u),g=Ii(h);return m.compareTo(g)})(r.bytesValue,e.bytesValue);case 7:return(function(u,h){const m=u.split("/"),g=h.split("/");for(let _=0;_<m.length&&_<g.length;_++){const E=Ce(m[_],g[_]);if(E!==0)return E}return Ce(m.length,g.length)})(r.referenceValue,e.referenceValue);case 8:return(function(u,h){const m=Ce(at(u.latitude),at(h.latitude));return m!==0?m:Ce(at(u.longitude),at(h.longitude))})(r.geoPointValue,e.geoPointValue);case 9:return Mg(r.arrayValue,e.arrayValue);case 10:return(function(u,h){var V,z,Q,Y;const m=u.fields||{},g=h.fields||{},_=(V=m[Zu])==null?void 0:V.arrayValue,E=(z=g[Zu])==null?void 0:z.arrayValue,S=Ce(((Q=_==null?void 0:_.values)==null?void 0:Q.length)||0,((Y=E==null?void 0:E.values)==null?void 0:Y.length)||0);return S!==0?S:Mg(_,E)})(r.mapValue,e.mapValue);case 11:return(function(u,h){if(u===ku.mapValue&&h===ku.mapValue)return 0;if(u===ku.mapValue)return 1;if(h===ku.mapValue)return-1;const m=u.fields||{},g=Object.keys(m),_=h.fields||{},E=Object.keys(_);g.sort(),E.sort();for(let S=0;S<g.length&&S<E.length;++S){const V=Sd(g[S],E[S]);if(V!==0)return V;const z=vo(m[g[S]],_[E[S]]);if(z!==0)return z}return Ce(g.length,E.length)})(r.mapValue,e.mapValue);default:throw pe(23264,{he:t})}}function Lg(r,e){if(typeof r=="string"&&typeof e=="string"&&r.length===e.length)return Ce(r,e);const t=Ti(r),s=Ti(e),o=Ce(t.seconds,s.seconds);return o!==0?o:Ce(t.nanos,s.nanos)}function Mg(r,e){const t=r.values||[],s=e.values||[];for(let o=0;o<t.length&&o<s.length;++o){const u=vo(t[o],s[o]);if(u)return u}return Ce(t.length,s.length)}function Eo(r){return Ad(r)}function Ad(r){return"nullValue"in r?"null":"booleanValue"in r?""+r.booleanValue:"integerValue"in r?""+r.integerValue:"doubleValue"in r?""+r.doubleValue:"timestampValue"in r?(function(t){const s=Ti(t);return`time(${s.seconds},${s.nanos})`})(r.timestampValue):"stringValue"in r?r.stringValue:"bytesValue"in r?(function(t){return Ii(t).toBase64()})(r.bytesValue):"referenceValue"in r?(function(t){return ce.fromName(t).toString()})(r.referenceValue):"geoPointValue"in r?(function(t){return`geo(${t.latitude},${t.longitude})`})(r.geoPointValue):"arrayValue"in r?(function(t){let s="[",o=!0;for(const u of t.values||[])o?o=!1:s+=",",s+=Ad(u);return s+"]"})(r.arrayValue):"mapValue"in r?(function(t){const s=Object.keys(t.fields||{}).sort();let o="{",u=!0;for(const h of s)u?u=!1:o+=",",o+=`${h}:${Ad(t.fields[h])}`;return o+"}"})(r.mapValue):pe(61005,{value:r})}function bu(r){switch(Si(r)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const e=gc(r);return e?16+bu(e):16;case 5:return 2*r.stringValue.length;case 6:return Ii(r.bytesValue).approximateByteSize();case 7:return r.referenceValue.length;case 9:return(function(s){return(s.values||[]).reduce(((o,u)=>o+bu(u)),0)})(r.arrayValue);case 10:case 11:return(function(s){let o=0;return Pi(s.fields,((u,h)=>{o+=u.length+bu(h)})),o})(r.mapValue);default:throw pe(13486,{value:r})}}function bg(r,e){return{referenceValue:`projects/${r.projectId}/databases/${r.database}/documents/${e.path.canonicalString()}`}}function Rd(r){return!!r&&"integerValue"in r}function nf(r){return!!r&&"arrayValue"in r}function Fg(r){return!!r&&"nullValue"in r}function Ug(r){return!!r&&"doubleValue"in r&&isNaN(Number(r.doubleValue))}function Fu(r){return!!r&&"mapValue"in r}function zS(r){var t,s;return((s=(((t=r==null?void 0:r.mapValue)==null?void 0:t.fields)||{})[F_])==null?void 0:s.stringValue)===U_}function La(r){if(r.geoPointValue)return{geoPointValue:{...r.geoPointValue}};if(r.timestampValue&&typeof r.timestampValue=="object")return{timestampValue:{...r.timestampValue}};if(r.mapValue){const e={mapValue:{fields:{}}};return Pi(r.mapValue.fields,((t,s)=>e.mapValue.fields[t]=La(s))),e}if(r.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(r.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=La(r.arrayValue.values[t]);return e}return{...r}}function BS(r){return(((r.mapValue||{}).fields||{}).__type__||{}).stringValue===jS}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jt{constructor(e){this.value=e}static empty(){return new Jt({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let s=0;s<e.length-1;++s)if(t=(t.mapValue.fields||{})[e.get(s)],!Fu(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=La(t)}setAll(e){let t=Nt.emptyPath(),s={},o=[];e.forEach(((h,m)=>{if(!t.isImmediateParentOf(m)){const g=this.getFieldsMap(t);this.applyChanges(g,s,o),s={},o=[],t=m.popLast()}h?s[m.lastSegment()]=La(h):o.push(m.lastSegment())}));const u=this.getFieldsMap(t);this.applyChanges(u,s,o)}delete(e){const t=this.field(e.popLast());Fu(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return ir(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let s=0;s<e.length;++s){let o=t.mapValue.fields[e.get(s)];Fu(o)&&o.mapValue.fields||(o={mapValue:{fields:{}}},t.mapValue.fields[e.get(s)]=o),t=o}return t.mapValue.fields}applyChanges(e,t,s){Pi(t,((o,u)=>e[o]=u));for(const o of s)delete e[o]}clone(){return new Jt(La(this.value))}}function j_(r){const e=[];return Pi(r.fields,((t,s)=>{const o=new Nt([t]);if(Fu(s)){const u=j_(s.mapValue).fields;if(u.length===0)e.push(o);else for(const h of u)e.push(o.child(h))}else e.push(o)})),new ln(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ut{constructor(e,t,s,o,u,h,m){this.key=e,this.documentType=t,this.version=s,this.readTime=o,this.createTime=u,this.data=h,this.documentState=m}static newInvalidDocument(e){return new Ut(e,0,ye.min(),ye.min(),ye.min(),Jt.empty(),0)}static newFoundDocument(e,t,s,o){return new Ut(e,1,t,ye.min(),s,o,0)}static newNoDocument(e,t){return new Ut(e,2,t,ye.min(),ye.min(),Jt.empty(),0)}static newUnknownDocument(e,t){return new Ut(e,3,t,ye.min(),ye.min(),Jt.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(ye.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=Jt.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=Jt.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=ye.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof Ut&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new Ut(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ec{constructor(e,t){this.position=e,this.inclusive=t}}function jg(r,e,t){let s=0;for(let o=0;o<r.position.length;o++){const u=e[o],h=r.position[o];if(u.field.isKeyField()?s=ce.comparator(ce.fromName(h.referenceValue),t.key):s=vo(h,t.data.field(u.field)),u.dir==="desc"&&(s*=-1),s!==0)break}return s}function zg(r,e){if(r===null)return e===null;if(e===null||r.inclusive!==e.inclusive||r.position.length!==e.position.length)return!1;for(let t=0;t<r.position.length;t++)if(!ir(r.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tc{constructor(e,t="asc"){this.field=e,this.dir=t}}function $S(r,e){return r.dir===e.dir&&r.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class z_{}class ft extends z_{constructor(e,t,s){super(),this.field=e,this.op=t,this.value=s}static create(e,t,s){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,s):new qS(e,t,s):t==="array-contains"?new GS(e,s):t==="in"?new QS(e,s):t==="not-in"?new YS(e,s):t==="array-contains-any"?new JS(e,s):new ft(e,t,s)}static createKeyFieldInFilter(e,t,s){return t==="in"?new WS(e,s):new KS(e,s)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&t.nullValue===void 0&&this.matchesComparison(vo(t,this.value)):t!==null&&Si(this.value)===Si(t)&&this.matchesComparison(vo(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return pe(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class Vn extends z_{constructor(e,t){super(),this.filters=e,this.op=t,this.Pe=null}static create(e,t){return new Vn(e,t)}matches(e){return B_(this)?this.filters.find((t=>!t.matches(e)))===void 0:this.filters.find((t=>t.matches(e)))!==void 0}getFlattenedFilters(){return this.Pe!==null||(this.Pe=this.filters.reduce(((e,t)=>e.concat(t.getFlattenedFilters())),[])),this.Pe}getFilters(){return Object.assign([],this.filters)}}function B_(r){return r.op==="and"}function $_(r){return HS(r)&&B_(r)}function HS(r){for(const e of r.filters)if(e instanceof Vn)return!1;return!0}function Cd(r){if(r instanceof ft)return r.field.canonicalString()+r.op.toString()+Eo(r.value);if($_(r))return r.filters.map((e=>Cd(e))).join(",");{const e=r.filters.map((t=>Cd(t))).join(",");return`${r.op}(${e})`}}function H_(r,e){return r instanceof ft?(function(s,o){return o instanceof ft&&s.op===o.op&&s.field.isEqual(o.field)&&ir(s.value,o.value)})(r,e):r instanceof Vn?(function(s,o){return o instanceof Vn&&s.op===o.op&&s.filters.length===o.filters.length?s.filters.reduce(((u,h,m)=>u&&H_(h,o.filters[m])),!0):!1})(r,e):void pe(19439)}function q_(r){return r instanceof ft?(function(t){return`${t.field.canonicalString()} ${t.op} ${Eo(t.value)}`})(r):r instanceof Vn?(function(t){return t.op.toString()+" {"+t.getFilters().map(q_).join(" ,")+"}"})(r):"Filter"}class qS extends ft{constructor(e,t,s){super(e,t,s),this.key=ce.fromName(s.referenceValue)}matches(e){const t=ce.comparator(e.key,this.key);return this.matchesComparison(t)}}class WS extends ft{constructor(e,t){super(e,"in",t),this.keys=W_("in",t)}matches(e){return this.keys.some((t=>t.isEqual(e.key)))}}class KS extends ft{constructor(e,t){super(e,"not-in",t),this.keys=W_("not-in",t)}matches(e){return!this.keys.some((t=>t.isEqual(e.key)))}}function W_(r,e){var t;return(((t=e.arrayValue)==null?void 0:t.values)||[]).map((s=>ce.fromName(s.referenceValue)))}class GS extends ft{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return nf(t)&&Wa(t.arrayValue,this.value)}}class QS extends ft{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&Wa(this.value.arrayValue,t)}}class YS extends ft{constructor(e,t){super(e,"not-in",t)}matches(e){if(Wa(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&t.nullValue===void 0&&!Wa(this.value.arrayValue,t)}}class JS extends ft{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!nf(t)||!t.arrayValue.values)&&t.arrayValue.values.some((s=>Wa(this.value.arrayValue,s)))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class XS{constructor(e,t=null,s=[],o=[],u=null,h=null,m=null){this.path=e,this.collectionGroup=t,this.orderBy=s,this.filters=o,this.limit=u,this.startAt=h,this.endAt=m,this.Te=null}}function Bg(r,e=null,t=[],s=[],o=null,u=null,h=null){return new XS(r,e,t,s,o,u,h)}function rf(r){const e=ve(r);if(e.Te===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map((s=>Cd(s))).join(","),t+="|ob:",t+=e.orderBy.map((s=>(function(u){return u.field.canonicalString()+u.dir})(s))).join(","),mc(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map((s=>Eo(s))).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map((s=>Eo(s))).join(",")),e.Te=t}return e.Te}function sf(r,e){if(r.limit!==e.limit||r.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<r.orderBy.length;t++)if(!$S(r.orderBy[t],e.orderBy[t]))return!1;if(r.filters.length!==e.filters.length)return!1;for(let t=0;t<r.filters.length;t++)if(!H_(r.filters[t],e.filters[t]))return!1;return r.collectionGroup===e.collectionGroup&&!!r.path.isEqual(e.path)&&!!zg(r.startAt,e.startAt)&&zg(r.endAt,e.endAt)}function Pd(r){return ce.isDocumentKey(r.path)&&r.collectionGroup===null&&r.filters.length===0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class il{constructor(e,t=null,s=[],o=[],u=null,h="F",m=null,g=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=s,this.filters=o,this.limit=u,this.limitType=h,this.startAt=m,this.endAt=g,this.Ee=null,this.Ie=null,this.Re=null,this.startAt,this.endAt}}function ZS(r,e,t,s,o,u,h,m){return new il(r,e,t,s,o,u,h,m)}function of(r){return new il(r)}function $g(r){return r.filters.length===0&&r.limit===null&&r.startAt==null&&r.endAt==null&&(r.explicitOrderBy.length===0||r.explicitOrderBy.length===1&&r.explicitOrderBy[0].field.isKeyField())}function eA(r){return ce.isDocumentKey(r.path)&&r.collectionGroup===null&&r.filters.length===0}function K_(r){return r.collectionGroup!==null}function Ma(r){const e=ve(r);if(e.Ee===null){e.Ee=[];const t=new Set;for(const u of e.explicitOrderBy)e.Ee.push(u),t.add(u.field.canonicalString());const s=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(h){let m=new vt(Nt.comparator);return h.filters.forEach((g=>{g.getFlattenedFilters().forEach((_=>{_.isInequality()&&(m=m.add(_.field))}))})),m})(e).forEach((u=>{t.has(u.canonicalString())||u.isKeyField()||e.Ee.push(new tc(u,s))})),t.has(Nt.keyField().canonicalString())||e.Ee.push(new tc(Nt.keyField(),s))}return e.Ee}function tr(r){const e=ve(r);return e.Ie||(e.Ie=tA(e,Ma(r))),e.Ie}function tA(r,e){if(r.limitType==="F")return Bg(r.path,r.collectionGroup,e,r.filters,r.limit,r.startAt,r.endAt);{e=e.map((o=>{const u=o.dir==="desc"?"asc":"desc";return new tc(o.field,u)}));const t=r.endAt?new ec(r.endAt.position,r.endAt.inclusive):null,s=r.startAt?new ec(r.startAt.position,r.startAt.inclusive):null;return Bg(r.path,r.collectionGroup,e,r.filters,r.limit,t,s)}}function kd(r,e){const t=r.filters.concat([e]);return new il(r.path,r.collectionGroup,r.explicitOrderBy.slice(),t,r.limit,r.limitType,r.startAt,r.endAt)}function Nd(r,e,t){return new il(r.path,r.collectionGroup,r.explicitOrderBy.slice(),r.filters.slice(),e,t,r.startAt,r.endAt)}function yc(r,e){return sf(tr(r),tr(e))&&r.limitType===e.limitType}function G_(r){return`${rf(tr(r))}|lt:${r.limitType}`}function so(r){return`Query(target=${(function(t){let s=t.path.canonicalString();return t.collectionGroup!==null&&(s+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(s+=`, filters: [${t.filters.map((o=>q_(o))).join(", ")}]`),mc(t.limit)||(s+=", limit: "+t.limit),t.orderBy.length>0&&(s+=`, orderBy: [${t.orderBy.map((o=>(function(h){return`${h.field.canonicalString()} (${h.dir})`})(o))).join(", ")}]`),t.startAt&&(s+=", startAt: ",s+=t.startAt.inclusive?"b:":"a:",s+=t.startAt.position.map((o=>Eo(o))).join(",")),t.endAt&&(s+=", endAt: ",s+=t.endAt.inclusive?"a:":"b:",s+=t.endAt.position.map((o=>Eo(o))).join(",")),`Target(${s})`})(tr(r))}; limitType=${r.limitType})`}function _c(r,e){return e.isFoundDocument()&&(function(s,o){const u=o.key.path;return s.collectionGroup!==null?o.key.hasCollectionId(s.collectionGroup)&&s.path.isPrefixOf(u):ce.isDocumentKey(s.path)?s.path.isEqual(u):s.path.isImmediateParentOf(u)})(r,e)&&(function(s,o){for(const u of Ma(s))if(!u.field.isKeyField()&&o.data.field(u.field)===null)return!1;return!0})(r,e)&&(function(s,o){for(const u of s.filters)if(!u.matches(o))return!1;return!0})(r,e)&&(function(s,o){return!(s.startAt&&!(function(h,m,g){const _=jg(h,m,g);return h.inclusive?_<=0:_<0})(s.startAt,Ma(s),o)||s.endAt&&!(function(h,m,g){const _=jg(h,m,g);return h.inclusive?_>=0:_>0})(s.endAt,Ma(s),o))})(r,e)}function nA(r){return r.collectionGroup||(r.path.length%2==1?r.path.lastSegment():r.path.get(r.path.length-2))}function Q_(r){return(e,t)=>{let s=!1;for(const o of Ma(r)){const u=rA(o,e,t);if(u!==0)return u;s=s||o.field.isKeyField()}return 0}}function rA(r,e,t){const s=r.field.isKeyField()?ce.comparator(e.key,t.key):(function(u,h,m){const g=h.data.field(u),_=m.data.field(u);return g!==null&&_!==null?vo(g,_):pe(42886)})(r.field,e,t);switch(r.dir){case"asc":return s;case"desc":return-1*s;default:return pe(19790,{direction:r.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ps{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),s=this.inner[t];if(s!==void 0){for(const[o,u]of s)if(this.equalsFn(o,e))return u}}has(e){return this.get(e)!==void 0}set(e,t){const s=this.mapKeyFn(e),o=this.inner[s];if(o===void 0)return this.inner[s]=[[e,t]],void this.innerSize++;for(let u=0;u<o.length;u++)if(this.equalsFn(o[u][0],e))return void(o[u]=[e,t]);o.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),s=this.inner[t];if(s===void 0)return!1;for(let o=0;o<s.length;o++)if(this.equalsFn(s[o][0],e))return s.length===1?delete this.inner[t]:s.splice(o,1),this.innerSize--,!0;return!1}forEach(e){Pi(this.inner,((t,s)=>{for(const[o,u]of s)e(o,u)}))}isEmpty(){return D_(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const iA=new tt(ce.comparator);function kr(){return iA}const Y_=new tt(ce.comparator);function xa(...r){let e=Y_;for(const t of r)e=e.insert(t.key,t);return e}function J_(r){let e=Y_;return r.forEach(((t,s)=>e=e.insert(t,s.overlayedDocument))),e}function is(){return ba()}function X_(){return ba()}function ba(){return new ps((r=>r.toString()),((r,e)=>r.isEqual(e)))}const sA=new tt(ce.comparator),oA=new vt(ce.comparator);function Pe(...r){let e=oA;for(const t of r)e=e.add(t);return e}const aA=new vt(Ce);function lA(){return aA}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function af(r,e){if(r.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Ju(e)?"-0":e}}function Z_(r){return{integerValue:""+r}}function uA(r,e){return OS(e)?Z_(e):af(r,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vc{constructor(){this._=void 0}}function cA(r,e,t){return r instanceof Ka?(function(o,u){const h={fields:{[L_]:{stringValue:O_},[b_]:{timestampValue:{seconds:o.seconds,nanos:o.nanoseconds}}}};return u&&tf(u)&&(u=gc(u)),u&&(h.fields[M_]=u),{mapValue:h}})(t,e):r instanceof Ga?tv(r,e):r instanceof Qa?nv(r,e):(function(o,u){const h=ev(o,u),m=Hg(h)+Hg(o.Ae);return Rd(h)&&Rd(o.Ae)?Z_(m):af(o.serializer,m)})(r,e)}function hA(r,e,t){return r instanceof Ga?tv(r,e):r instanceof Qa?nv(r,e):t}function ev(r,e){return r instanceof nc?(function(s){return Rd(s)||(function(u){return!!u&&"doubleValue"in u})(s)})(e)?e:{integerValue:0}:null}class Ka extends vc{}class Ga extends vc{constructor(e){super(),this.elements=e}}function tv(r,e){const t=rv(e);for(const s of r.elements)t.some((o=>ir(o,s)))||t.push(s);return{arrayValue:{values:t}}}class Qa extends vc{constructor(e){super(),this.elements=e}}function nv(r,e){let t=rv(e);for(const s of r.elements)t=t.filter((o=>!ir(o,s)));return{arrayValue:{values:t}}}class nc extends vc{constructor(e,t){super(),this.serializer=e,this.Ae=t}}function Hg(r){return at(r.integerValue||r.doubleValue)}function rv(r){return nf(r)&&r.arrayValue.values?r.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dA{constructor(e,t){this.field=e,this.transform=t}}function fA(r,e){return r.field.isEqual(e.field)&&(function(s,o){return s instanceof Ga&&o instanceof Ga||s instanceof Qa&&o instanceof Qa?_o(s.elements,o.elements,ir):s instanceof nc&&o instanceof nc?ir(s.Ae,o.Ae):s instanceof Ka&&o instanceof Ka})(r.transform,e.transform)}class pA{constructor(e,t){this.version=e,this.transformResults=t}}class Nn{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new Nn}static exists(e){return new Nn(void 0,e)}static updateTime(e){return new Nn(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function Uu(r,e){return r.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(r.updateTime):r.exists===void 0||r.exists===e.isFoundDocument()}class Ec{}function iv(r,e){if(!r.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return r.isNoDocument()?new lf(r.key,Nn.none()):new sl(r.key,r.data,Nn.none());{const t=r.data,s=Jt.empty();let o=new vt(Nt.comparator);for(let u of e.fields)if(!o.has(u)){let h=t.field(u);h===null&&u.length>1&&(u=u.popLast(),h=t.field(u)),h===null?s.delete(u):s.set(u,h),o=o.add(u)}return new ki(r.key,s,new ln(o.toArray()),Nn.none())}}function mA(r,e,t){r instanceof sl?(function(o,u,h){const m=o.value.clone(),g=Wg(o.fieldTransforms,u,h.transformResults);m.setAll(g),u.convertToFoundDocument(h.version,m).setHasCommittedMutations()})(r,e,t):r instanceof ki?(function(o,u,h){if(!Uu(o.precondition,u))return void u.convertToUnknownDocument(h.version);const m=Wg(o.fieldTransforms,u,h.transformResults),g=u.data;g.setAll(sv(o)),g.setAll(m),u.convertToFoundDocument(h.version,g).setHasCommittedMutations()})(r,e,t):(function(o,u,h){u.convertToNoDocument(h.version).setHasCommittedMutations()})(0,e,t)}function Fa(r,e,t,s){return r instanceof sl?(function(u,h,m,g){if(!Uu(u.precondition,h))return m;const _=u.value.clone(),E=Kg(u.fieldTransforms,g,h);return _.setAll(E),h.convertToFoundDocument(h.version,_).setHasLocalMutations(),null})(r,e,t,s):r instanceof ki?(function(u,h,m,g){if(!Uu(u.precondition,h))return m;const _=Kg(u.fieldTransforms,g,h),E=h.data;return E.setAll(sv(u)),E.setAll(_),h.convertToFoundDocument(h.version,E).setHasLocalMutations(),m===null?null:m.unionWith(u.fieldMask.fields).unionWith(u.fieldTransforms.map((S=>S.field)))})(r,e,t,s):(function(u,h,m){return Uu(u.precondition,h)?(h.convertToNoDocument(h.version).setHasLocalMutations(),null):m})(r,e,t)}function gA(r,e){let t=null;for(const s of r.fieldTransforms){const o=e.data.field(s.field),u=ev(s.transform,o||null);u!=null&&(t===null&&(t=Jt.empty()),t.set(s.field,u))}return t||null}function qg(r,e){return r.type===e.type&&!!r.key.isEqual(e.key)&&!!r.precondition.isEqual(e.precondition)&&!!(function(s,o){return s===void 0&&o===void 0||!(!s||!o)&&_o(s,o,((u,h)=>fA(u,h)))})(r.fieldTransforms,e.fieldTransforms)&&(r.type===0?r.value.isEqual(e.value):r.type!==1||r.data.isEqual(e.data)&&r.fieldMask.isEqual(e.fieldMask))}class sl extends Ec{constructor(e,t,s,o=[]){super(),this.key=e,this.value=t,this.precondition=s,this.fieldTransforms=o,this.type=0}getFieldMask(){return null}}class ki extends Ec{constructor(e,t,s,o,u=[]){super(),this.key=e,this.data=t,this.fieldMask=s,this.precondition=o,this.fieldTransforms=u,this.type=1}getFieldMask(){return this.fieldMask}}function sv(r){const e=new Map;return r.fieldMask.fields.forEach((t=>{if(!t.isEmpty()){const s=r.data.field(t);e.set(t,s)}})),e}function Wg(r,e,t){const s=new Map;Ue(r.length===t.length,32656,{Ve:t.length,de:r.length});for(let o=0;o<t.length;o++){const u=r[o],h=u.transform,m=e.data.field(u.field);s.set(u.field,hA(h,m,t[o]))}return s}function Kg(r,e,t){const s=new Map;for(const o of r){const u=o.transform,h=t.data.field(o.field);s.set(o.field,cA(u,h,e))}return s}class lf extends Ec{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class yA extends Ec{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _A{constructor(e,t,s,o){this.batchId=e,this.localWriteTime=t,this.baseMutations=s,this.mutations=o}applyToRemoteDocument(e,t){const s=t.mutationResults;for(let o=0;o<this.mutations.length;o++){const u=this.mutations[o];u.key.isEqual(e.key)&&mA(u,e,s[o])}}applyToLocalView(e,t){for(const s of this.baseMutations)s.key.isEqual(e.key)&&(t=Fa(s,e,t,this.localWriteTime));for(const s of this.mutations)s.key.isEqual(e.key)&&(t=Fa(s,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const s=X_();return this.mutations.forEach((o=>{const u=e.get(o.key),h=u.overlayedDocument;let m=this.applyToLocalView(h,u.mutatedFields);m=t.has(o.key)?null:m;const g=iv(h,m);g!==null&&s.set(o.key,g),h.isValidDocument()||h.convertToNoDocument(ye.min())})),s}keys(){return this.mutations.reduce(((e,t)=>e.add(t.key)),Pe())}isEqual(e){return this.batchId===e.batchId&&_o(this.mutations,e.mutations,((t,s)=>qg(t,s)))&&_o(this.baseMutations,e.baseMutations,((t,s)=>qg(t,s)))}}class uf{constructor(e,t,s,o){this.batch=e,this.commitVersion=t,this.mutationResults=s,this.docVersions=o}static from(e,t,s){Ue(e.mutations.length===s.length,58842,{me:e.mutations.length,fe:s.length});let o=(function(){return sA})();const u=e.mutations;for(let h=0;h<u.length;h++)o=o.insert(u[h].key,s[h].version);return new uf(e,t,s,o)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vA{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class EA{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var dt,xe;function wA(r){switch(r){case B.OK:return pe(64938);case B.CANCELLED:case B.UNKNOWN:case B.DEADLINE_EXCEEDED:case B.RESOURCE_EXHAUSTED:case B.INTERNAL:case B.UNAVAILABLE:case B.UNAUTHENTICATED:return!1;case B.INVALID_ARGUMENT:case B.NOT_FOUND:case B.ALREADY_EXISTS:case B.PERMISSION_DENIED:case B.FAILED_PRECONDITION:case B.ABORTED:case B.OUT_OF_RANGE:case B.UNIMPLEMENTED:case B.DATA_LOSS:return!0;default:return pe(15467,{code:r})}}function ov(r){if(r===void 0)return Pr("GRPC error has no .code"),B.UNKNOWN;switch(r){case dt.OK:return B.OK;case dt.CANCELLED:return B.CANCELLED;case dt.UNKNOWN:return B.UNKNOWN;case dt.DEADLINE_EXCEEDED:return B.DEADLINE_EXCEEDED;case dt.RESOURCE_EXHAUSTED:return B.RESOURCE_EXHAUSTED;case dt.INTERNAL:return B.INTERNAL;case dt.UNAVAILABLE:return B.UNAVAILABLE;case dt.UNAUTHENTICATED:return B.UNAUTHENTICATED;case dt.INVALID_ARGUMENT:return B.INVALID_ARGUMENT;case dt.NOT_FOUND:return B.NOT_FOUND;case dt.ALREADY_EXISTS:return B.ALREADY_EXISTS;case dt.PERMISSION_DENIED:return B.PERMISSION_DENIED;case dt.FAILED_PRECONDITION:return B.FAILED_PRECONDITION;case dt.ABORTED:return B.ABORTED;case dt.OUT_OF_RANGE:return B.OUT_OF_RANGE;case dt.UNIMPLEMENTED:return B.UNIMPLEMENTED;case dt.DATA_LOSS:return B.DATA_LOSS;default:return pe(39323,{code:r})}}(xe=dt||(dt={}))[xe.OK=0]="OK",xe[xe.CANCELLED=1]="CANCELLED",xe[xe.UNKNOWN=2]="UNKNOWN",xe[xe.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",xe[xe.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",xe[xe.NOT_FOUND=5]="NOT_FOUND",xe[xe.ALREADY_EXISTS=6]="ALREADY_EXISTS",xe[xe.PERMISSION_DENIED=7]="PERMISSION_DENIED",xe[xe.UNAUTHENTICATED=16]="UNAUTHENTICATED",xe[xe.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",xe[xe.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",xe[xe.ABORTED=10]="ABORTED",xe[xe.OUT_OF_RANGE=11]="OUT_OF_RANGE",xe[xe.UNIMPLEMENTED=12]="UNIMPLEMENTED",xe[xe.INTERNAL=13]="INTERNAL",xe[xe.UNAVAILABLE=14]="UNAVAILABLE",xe[xe.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function TA(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const IA=new _i([4294967295,4294967295],0);function Gg(r){const e=TA().encode(r),t=new w_;return t.update(e),new Uint8Array(t.digest())}function Qg(r){const e=new DataView(r.buffer),t=e.getUint32(0,!0),s=e.getUint32(4,!0),o=e.getUint32(8,!0),u=e.getUint32(12,!0);return[new _i([t,s],0),new _i([o,u],0)]}class cf{constructor(e,t,s){if(this.bitmap=e,this.padding=t,this.hashCount=s,t<0||t>=8)throw new Da(`Invalid padding: ${t}`);if(s<0)throw new Da(`Invalid hash count: ${s}`);if(e.length>0&&this.hashCount===0)throw new Da(`Invalid hash count: ${s}`);if(e.length===0&&t!==0)throw new Da(`Invalid padding when bitmap length is 0: ${t}`);this.ge=8*e.length-t,this.pe=_i.fromNumber(this.ge)}ye(e,t,s){let o=e.add(t.multiply(_i.fromNumber(s)));return o.compare(IA)===1&&(o=new _i([o.getBits(0),o.getBits(1)],0)),o.modulo(this.pe).toNumber()}we(e){return!!(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(this.ge===0)return!1;const t=Gg(e),[s,o]=Qg(t);for(let u=0;u<this.hashCount;u++){const h=this.ye(s,o,u);if(!this.we(h))return!1}return!0}static create(e,t,s){const o=e%8==0?0:8-e%8,u=new Uint8Array(Math.ceil(e/8)),h=new cf(u,o,t);return s.forEach((m=>h.insert(m))),h}insert(e){if(this.ge===0)return;const t=Gg(e),[s,o]=Qg(t);for(let u=0;u<this.hashCount;u++){const h=this.ye(s,o,u);this.Se(h)}}Se(e){const t=Math.floor(e/8),s=e%8;this.bitmap[t]|=1<<s}}class Da extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wc{constructor(e,t,s,o,u){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=s,this.documentUpdates=o,this.resolvedLimboDocuments=u}static createSynthesizedRemoteEventForCurrentChange(e,t,s){const o=new Map;return o.set(e,ol.createSynthesizedTargetChangeForCurrentChange(e,t,s)),new wc(ye.min(),o,new tt(Ce),kr(),Pe())}}class ol{constructor(e,t,s,o,u){this.resumeToken=e,this.current=t,this.addedDocuments=s,this.modifiedDocuments=o,this.removedDocuments=u}static createSynthesizedTargetChangeForCurrentChange(e,t,s){return new ol(s,t,Pe(),Pe(),Pe())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ju{constructor(e,t,s,o){this.be=e,this.removedTargetIds=t,this.key=s,this.De=o}}class av{constructor(e,t){this.targetId=e,this.Ce=t}}class lv{constructor(e,t,s=xt.EMPTY_BYTE_STRING,o=null){this.state=e,this.targetIds=t,this.resumeToken=s,this.cause=o}}class Yg{constructor(){this.ve=0,this.Fe=Jg(),this.Me=xt.EMPTY_BYTE_STRING,this.xe=!1,this.Oe=!0}get current(){return this.xe}get resumeToken(){return this.Me}get Ne(){return this.ve!==0}get Be(){return this.Oe}Le(e){e.approximateByteSize()>0&&(this.Oe=!0,this.Me=e)}ke(){let e=Pe(),t=Pe(),s=Pe();return this.Fe.forEach(((o,u)=>{switch(u){case 0:e=e.add(o);break;case 2:t=t.add(o);break;case 1:s=s.add(o);break;default:pe(38017,{changeType:u})}})),new ol(this.Me,this.xe,e,t,s)}qe(){this.Oe=!1,this.Fe=Jg()}Ke(e,t){this.Oe=!0,this.Fe=this.Fe.insert(e,t)}Ue(e){this.Oe=!0,this.Fe=this.Fe.remove(e)}$e(){this.ve+=1}We(){this.ve-=1,Ue(this.ve>=0,3241,{ve:this.ve})}Qe(){this.Oe=!0,this.xe=!0}}class SA{constructor(e){this.Ge=e,this.ze=new Map,this.je=kr(),this.Je=Nu(),this.He=Nu(),this.Ze=new tt(Ce)}Xe(e){for(const t of e.be)e.De&&e.De.isFoundDocument()?this.Ye(t,e.De):this.et(t,e.key,e.De);for(const t of e.removedTargetIds)this.et(t,e.key,e.De)}tt(e){this.forEachTarget(e,(t=>{const s=this.nt(t);switch(e.state){case 0:this.rt(t)&&s.Le(e.resumeToken);break;case 1:s.We(),s.Ne||s.qe(),s.Le(e.resumeToken);break;case 2:s.We(),s.Ne||this.removeTarget(t);break;case 3:this.rt(t)&&(s.Qe(),s.Le(e.resumeToken));break;case 4:this.rt(t)&&(this.it(t),s.Le(e.resumeToken));break;default:pe(56790,{state:e.state})}}))}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.ze.forEach(((s,o)=>{this.rt(o)&&t(o)}))}st(e){const t=e.targetId,s=e.Ce.count,o=this.ot(t);if(o){const u=o.target;if(Pd(u))if(s===0){const h=new ce(u.path);this.et(t,h,Ut.newNoDocument(h,ye.min()))}else Ue(s===1,20013,{expectedCount:s});else{const h=this._t(t);if(h!==s){const m=this.ut(e),g=m?this.ct(m,e,h):1;if(g!==0){this.it(t);const _=g===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Ze=this.Ze.insert(t,_)}}}}}ut(e){const t=e.Ce.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:s="",padding:o=0},hashCount:u=0}=t;let h,m;try{h=Ii(s).toUint8Array()}catch(g){if(g instanceof V_)return ds("Decoding the base64 bloom filter in existence filter failed ("+g.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw g}try{m=new cf(h,o,u)}catch(g){return ds(g instanceof Da?"BloomFilter error: ":"Applying bloom filter failed: ",g),null}return m.ge===0?null:m}ct(e,t,s){return t.Ce.count===s-this.Pt(e,t.targetId)?0:2}Pt(e,t){const s=this.Ge.getRemoteKeysForTarget(t);let o=0;return s.forEach((u=>{const h=this.Ge.ht(),m=`projects/${h.projectId}/databases/${h.database}/documents/${u.path.canonicalString()}`;e.mightContain(m)||(this.et(t,u,null),o++)})),o}Tt(e){const t=new Map;this.ze.forEach(((u,h)=>{const m=this.ot(h);if(m){if(u.current&&Pd(m.target)){const g=new ce(m.target.path);this.Et(g).has(h)||this.It(h,g)||this.et(h,g,Ut.newNoDocument(g,e))}u.Be&&(t.set(h,u.ke()),u.qe())}}));let s=Pe();this.He.forEach(((u,h)=>{let m=!0;h.forEachWhile((g=>{const _=this.ot(g);return!_||_.purpose==="TargetPurposeLimboResolution"||(m=!1,!1)})),m&&(s=s.add(u))})),this.je.forEach(((u,h)=>h.setReadTime(e)));const o=new wc(e,t,this.Ze,this.je,s);return this.je=kr(),this.Je=Nu(),this.He=Nu(),this.Ze=new tt(Ce),o}Ye(e,t){if(!this.rt(e))return;const s=this.It(e,t.key)?2:0;this.nt(e).Ke(t.key,s),this.je=this.je.insert(t.key,t),this.Je=this.Je.insert(t.key,this.Et(t.key).add(e)),this.He=this.He.insert(t.key,this.Rt(t.key).add(e))}et(e,t,s){if(!this.rt(e))return;const o=this.nt(e);this.It(e,t)?o.Ke(t,1):o.Ue(t),this.He=this.He.insert(t,this.Rt(t).delete(e)),this.He=this.He.insert(t,this.Rt(t).add(e)),s&&(this.je=this.je.insert(t,s))}removeTarget(e){this.ze.delete(e)}_t(e){const t=this.nt(e).ke();return this.Ge.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}$e(e){this.nt(e).$e()}nt(e){let t=this.ze.get(e);return t||(t=new Yg,this.ze.set(e,t)),t}Rt(e){let t=this.He.get(e);return t||(t=new vt(Ce),this.He=this.He.insert(e,t)),t}Et(e){let t=this.Je.get(e);return t||(t=new vt(Ce),this.Je=this.Je.insert(e,t)),t}rt(e){const t=this.ot(e)!==null;return t||ne("WatchChangeAggregator","Detected inactive target",e),t}ot(e){const t=this.ze.get(e);return t&&t.Ne?null:this.Ge.At(e)}it(e){this.ze.set(e,new Yg),this.Ge.getRemoteKeysForTarget(e).forEach((t=>{this.et(e,t,null)}))}It(e,t){return this.Ge.getRemoteKeysForTarget(e).has(t)}}function Nu(){return new tt(ce.comparator)}function Jg(){return new tt(ce.comparator)}const AA={asc:"ASCENDING",desc:"DESCENDING"},RA={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},CA={and:"AND",or:"OR"};class PA{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function xd(r,e){return r.useProto3Json||mc(e)?e:{value:e}}function rc(r,e){return r.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function uv(r,e){return r.useProto3Json?e.toBase64():e.toUint8Array()}function kA(r,e){return rc(r,e.toTimestamp())}function nr(r){return Ue(!!r,49232),ye.fromTimestamp((function(t){const s=Ti(t);return new Je(s.seconds,s.nanos)})(r))}function hf(r,e){return Dd(r,e).canonicalString()}function Dd(r,e){const t=(function(o){return new Ke(["projects",o.projectId,"databases",o.database])})(r).child("documents");return e===void 0?t:t.child(e)}function cv(r){const e=Ke.fromString(r);return Ue(mv(e),10190,{key:e.toString()}),e}function Vd(r,e){return hf(r.databaseId,e.path)}function hd(r,e){const t=cv(e);if(t.get(1)!==r.databaseId.projectId)throw new re(B.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+r.databaseId.projectId);if(t.get(3)!==r.databaseId.database)throw new re(B.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+r.databaseId.database);return new ce(dv(t))}function hv(r,e){return hf(r.databaseId,e)}function NA(r){const e=cv(r);return e.length===4?Ke.emptyPath():dv(e)}function Od(r){return new Ke(["projects",r.databaseId.projectId,"databases",r.databaseId.database]).canonicalString()}function dv(r){return Ue(r.length>4&&r.get(4)==="documents",29091,{key:r.toString()}),r.popFirst(5)}function Xg(r,e,t){return{name:Vd(r,e),fields:t.value.mapValue.fields}}function xA(r,e){let t;if("targetChange"in e){e.targetChange;const s=(function(_){return _==="NO_CHANGE"?0:_==="ADD"?1:_==="REMOVE"?2:_==="CURRENT"?3:_==="RESET"?4:pe(39313,{state:_})})(e.targetChange.targetChangeType||"NO_CHANGE"),o=e.targetChange.targetIds||[],u=(function(_,E){return _.useProto3Json?(Ue(E===void 0||typeof E=="string",58123),xt.fromBase64String(E||"")):(Ue(E===void 0||E instanceof Buffer||E instanceof Uint8Array,16193),xt.fromUint8Array(E||new Uint8Array))})(r,e.targetChange.resumeToken),h=e.targetChange.cause,m=h&&(function(_){const E=_.code===void 0?B.UNKNOWN:ov(_.code);return new re(E,_.message||"")})(h);t=new lv(s,o,u,m||null)}else if("documentChange"in e){e.documentChange;const s=e.documentChange;s.document,s.document.name,s.document.updateTime;const o=hd(r,s.document.name),u=nr(s.document.updateTime),h=s.document.createTime?nr(s.document.createTime):ye.min(),m=new Jt({mapValue:{fields:s.document.fields}}),g=Ut.newFoundDocument(o,u,h,m),_=s.targetIds||[],E=s.removedTargetIds||[];t=new ju(_,E,g.key,g)}else if("documentDelete"in e){e.documentDelete;const s=e.documentDelete;s.document;const o=hd(r,s.document),u=s.readTime?nr(s.readTime):ye.min(),h=Ut.newNoDocument(o,u),m=s.removedTargetIds||[];t=new ju([],m,h.key,h)}else if("documentRemove"in e){e.documentRemove;const s=e.documentRemove;s.document;const o=hd(r,s.document),u=s.removedTargetIds||[];t=new ju([],u,o,null)}else{if(!("filter"in e))return pe(11601,{Vt:e});{e.filter;const s=e.filter;s.targetId;const{count:o=0,unchangedNames:u}=s,h=new EA(o,u),m=s.targetId;t=new av(m,h)}}return t}function DA(r,e){let t;if(e instanceof sl)t={update:Xg(r,e.key,e.value)};else if(e instanceof lf)t={delete:Vd(r,e.key)};else if(e instanceof ki)t={update:Xg(r,e.key,e.data),updateMask:zA(e.fieldMask)};else{if(!(e instanceof yA))return pe(16599,{dt:e.type});t={verify:Vd(r,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map((s=>(function(u,h){const m=h.transform;if(m instanceof Ka)return{fieldPath:h.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(m instanceof Ga)return{fieldPath:h.field.canonicalString(),appendMissingElements:{values:m.elements}};if(m instanceof Qa)return{fieldPath:h.field.canonicalString(),removeAllFromArray:{values:m.elements}};if(m instanceof nc)return{fieldPath:h.field.canonicalString(),increment:m.Ae};throw pe(20930,{transform:h.transform})})(0,s)))),e.precondition.isNone||(t.currentDocument=(function(o,u){return u.updateTime!==void 0?{updateTime:kA(o,u.updateTime)}:u.exists!==void 0?{exists:u.exists}:pe(27497)})(r,e.precondition)),t}function VA(r,e){return r&&r.length>0?(Ue(e!==void 0,14353),r.map((t=>(function(o,u){let h=o.updateTime?nr(o.updateTime):nr(u);return h.isEqual(ye.min())&&(h=nr(u)),new pA(h,o.transformResults||[])})(t,e)))):[]}function OA(r,e){return{documents:[hv(r,e.path)]}}function LA(r,e){const t={structuredQuery:{}},s=e.path;let o;e.collectionGroup!==null?(o=s,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(o=s.popLast(),t.structuredQuery.from=[{collectionId:s.lastSegment()}]),t.parent=hv(r,o);const u=(function(_){if(_.length!==0)return pv(Vn.create(_,"and"))})(e.filters);u&&(t.structuredQuery.where=u);const h=(function(_){if(_.length!==0)return _.map((E=>(function(V){return{field:oo(V.field),direction:FA(V.dir)}})(E)))})(e.orderBy);h&&(t.structuredQuery.orderBy=h);const m=xd(r,e.limit);return m!==null&&(t.structuredQuery.limit=m),e.startAt&&(t.structuredQuery.startAt=(function(_){return{before:_.inclusive,values:_.position}})(e.startAt)),e.endAt&&(t.structuredQuery.endAt=(function(_){return{before:!_.inclusive,values:_.position}})(e.endAt)),{ft:t,parent:o}}function MA(r){let e=NA(r.parent);const t=r.structuredQuery,s=t.from?t.from.length:0;let o=null;if(s>0){Ue(s===1,65062);const E=t.from[0];E.allDescendants?o=E.collectionId:e=e.child(E.collectionId)}let u=[];t.where&&(u=(function(S){const V=fv(S);return V instanceof Vn&&$_(V)?V.getFilters():[V]})(t.where));let h=[];t.orderBy&&(h=(function(S){return S.map((V=>(function(Q){return new tc(ao(Q.field),(function(H){switch(H){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}})(Q.direction))})(V)))})(t.orderBy));let m=null;t.limit&&(m=(function(S){let V;return V=typeof S=="object"?S.value:S,mc(V)?null:V})(t.limit));let g=null;t.startAt&&(g=(function(S){const V=!!S.before,z=S.values||[];return new ec(z,V)})(t.startAt));let _=null;return t.endAt&&(_=(function(S){const V=!S.before,z=S.values||[];return new ec(z,V)})(t.endAt)),ZS(e,o,h,u,m,"F",g,_)}function bA(r,e){const t=(function(o){switch(o){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return pe(28987,{purpose:o})}})(e.purpose);return t==null?null:{"goog-listen-tags":t}}function fv(r){return r.unaryFilter!==void 0?(function(t){switch(t.unaryFilter.op){case"IS_NAN":const s=ao(t.unaryFilter.field);return ft.create(s,"==",{doubleValue:NaN});case"IS_NULL":const o=ao(t.unaryFilter.field);return ft.create(o,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const u=ao(t.unaryFilter.field);return ft.create(u,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const h=ao(t.unaryFilter.field);return ft.create(h,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return pe(61313);default:return pe(60726)}})(r):r.fieldFilter!==void 0?(function(t){return ft.create(ao(t.fieldFilter.field),(function(o){switch(o){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return pe(58110);default:return pe(50506)}})(t.fieldFilter.op),t.fieldFilter.value)})(r):r.compositeFilter!==void 0?(function(t){return Vn.create(t.compositeFilter.filters.map((s=>fv(s))),(function(o){switch(o){case"AND":return"and";case"OR":return"or";default:return pe(1026)}})(t.compositeFilter.op))})(r):pe(30097,{filter:r})}function FA(r){return AA[r]}function UA(r){return RA[r]}function jA(r){return CA[r]}function oo(r){return{fieldPath:r.canonicalString()}}function ao(r){return Nt.fromServerFormat(r.fieldPath)}function pv(r){return r instanceof ft?(function(t){if(t.op==="=="){if(Ug(t.value))return{unaryFilter:{field:oo(t.field),op:"IS_NAN"}};if(Fg(t.value))return{unaryFilter:{field:oo(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(Ug(t.value))return{unaryFilter:{field:oo(t.field),op:"IS_NOT_NAN"}};if(Fg(t.value))return{unaryFilter:{field:oo(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:oo(t.field),op:UA(t.op),value:t.value}}})(r):r instanceof Vn?(function(t){const s=t.getFilters().map((o=>pv(o)));return s.length===1?s[0]:{compositeFilter:{op:jA(t.op),filters:s}}})(r):pe(54877,{filter:r})}function zA(r){const e=[];return r.fields.forEach((t=>e.push(t.canonicalString()))),{fieldPaths:e}}function mv(r){return r.length>=4&&r.get(0)==="projects"&&r.get(2)==="databases"}function gv(r){return!!r&&typeof r._toProto=="function"&&r._protoValueType==="ProtoValue"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pi{constructor(e,t,s,o,u=ye.min(),h=ye.min(),m=xt.EMPTY_BYTE_STRING,g=null){this.target=e,this.targetId=t,this.purpose=s,this.sequenceNumber=o,this.snapshotVersion=u,this.lastLimboFreeSnapshotVersion=h,this.resumeToken=m,this.expectedCount=g}withSequenceNumber(e){return new pi(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new pi(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new pi(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new pi(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class BA{constructor(e){this.yt=e}}function $A(r){const e=MA({parent:r.parent,structuredQuery:r.structuredQuery});return r.limitType==="LAST"?Nd(e,e.limit,"L"):e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class HA{constructor(){this.bn=new qA}addToCollectionParentIndex(e,t){return this.bn.add(t),$.resolve()}getCollectionParents(e,t){return $.resolve(this.bn.getEntries(t))}addFieldIndex(e,t){return $.resolve()}deleteFieldIndex(e,t){return $.resolve()}deleteAllFieldIndexes(e){return $.resolve()}createTargetIndexes(e,t){return $.resolve()}getDocumentsMatchingTarget(e,t){return $.resolve(null)}getIndexType(e,t){return $.resolve(0)}getFieldIndexes(e,t){return $.resolve([])}getNextCollectionGroupToUpdate(e){return $.resolve(null)}getMinOffset(e,t){return $.resolve(wi.min())}getMinOffsetFromCollectionGroup(e,t){return $.resolve(wi.min())}updateCollectionGroup(e,t,s){return $.resolve()}updateIndexEntries(e,t){return $.resolve()}}class qA{constructor(){this.index={}}add(e){const t=e.lastSegment(),s=e.popLast(),o=this.index[t]||new vt(Ke.comparator),u=!o.has(s);return this.index[t]=o.add(s),u}has(e){const t=e.lastSegment(),s=e.popLast(),o=this.index[t];return o&&o.has(s)}getEntries(e){return(this.index[e]||new vt(Ke.comparator)).toArray()}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Zg={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},yv=41943040;class Yt{static withCacheSize(e){return new Yt(e,Yt.DEFAULT_COLLECTION_PERCENTILE,Yt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(e,t,s){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Yt.DEFAULT_COLLECTION_PERCENTILE=10,Yt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,Yt.DEFAULT=new Yt(yv,Yt.DEFAULT_COLLECTION_PERCENTILE,Yt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),Yt.DISABLED=new Yt(-1,0,0);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wo{constructor(e){this.sr=e}next(){return this.sr+=2,this.sr}static _r(){return new wo(0)}static ar(){return new wo(-1)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ey="LruGarbageCollector",WA=1048576;function ty([r,e],[t,s]){const o=Ce(r,t);return o===0?Ce(e,s):o}class KA{constructor(e){this.Pr=e,this.buffer=new vt(ty),this.Tr=0}Er(){return++this.Tr}Ir(e){const t=[e,this.Er()];if(this.buffer.size<this.Pr)this.buffer=this.buffer.add(t);else{const s=this.buffer.last();ty(t,s)<0&&(this.buffer=this.buffer.delete(s).add(t))}}get maxValue(){return this.buffer.last()[0]}}class GA{constructor(e,t,s){this.garbageCollector=e,this.asyncQueue=t,this.localStore=s,this.Rr=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.Ar(6e4)}stop(){this.Rr&&(this.Rr.cancel(),this.Rr=null)}get started(){return this.Rr!==null}Ar(e){ne(ey,`Garbage collection scheduled in ${e}ms`),this.Rr=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,(async()=>{this.Rr=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){ko(t)?ne(ey,"Ignoring IndexedDB error during garbage collection: ",t):await Po(t)}await this.Ar(3e5)}))}}class QA{constructor(e,t){this.Vr=e,this.params=t}calculateTargetCount(e,t){return this.Vr.dr(e).next((s=>Math.floor(t/100*s)))}nthSequenceNumber(e,t){if(t===0)return $.resolve(pc.ce);const s=new KA(t);return this.Vr.forEachTarget(e,(o=>s.Ir(o.sequenceNumber))).next((()=>this.Vr.mr(e,(o=>s.Ir(o))))).next((()=>s.maxValue))}removeTargets(e,t,s){return this.Vr.removeTargets(e,t,s)}removeOrphanedDocuments(e,t){return this.Vr.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(ne("LruGarbageCollector","Garbage collection skipped; disabled"),$.resolve(Zg)):this.getCacheSize(e).next((s=>s<this.params.cacheSizeCollectionThreshold?(ne("LruGarbageCollector",`Garbage collection skipped; Cache size ${s} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),Zg):this.gr(e,t)))}getCacheSize(e){return this.Vr.getCacheSize(e)}gr(e,t){let s,o,u,h,m,g,_;const E=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next((S=>(S>this.params.maximumSequenceNumbersToCollect?(ne("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${S}`),o=this.params.maximumSequenceNumbersToCollect):o=S,h=Date.now(),this.nthSequenceNumber(e,o)))).next((S=>(s=S,m=Date.now(),this.removeTargets(e,s,t)))).next((S=>(u=S,g=Date.now(),this.removeOrphanedDocuments(e,s)))).next((S=>(_=Date.now(),io()<=Re.DEBUG&&ne("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${h-E}ms
	Determined least recently used ${o} in `+(m-h)+`ms
	Removed ${u} targets in `+(g-m)+`ms
	Removed ${S} documents in `+(_-g)+`ms
Total Duration: ${_-E}ms`),$.resolve({didRun:!0,sequenceNumbersCollected:o,targetsRemoved:u,documentsRemoved:S}))))}}function YA(r,e){return new QA(r,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class JA{constructor(){this.changes=new ps((e=>e.toString()),((e,t)=>e.isEqual(t))),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,Ut.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const s=this.changes.get(t);return s!==void 0?$.resolve(s):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class XA{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ZA{constructor(e,t,s,o){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=s,this.indexManager=o}getDocument(e,t){let s=null;return this.documentOverlayCache.getOverlay(e,t).next((o=>(s=o,this.remoteDocumentCache.getEntry(e,t)))).next((o=>(s!==null&&Fa(s.mutation,o,ln.empty(),Je.now()),o)))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next((s=>this.getLocalViewOfDocuments(e,s,Pe()).next((()=>s))))}getLocalViewOfDocuments(e,t,s=Pe()){const o=is();return this.populateOverlays(e,o,t).next((()=>this.computeViews(e,t,o,s).next((u=>{let h=xa();return u.forEach(((m,g)=>{h=h.insert(m,g.overlayedDocument)})),h}))))}getOverlayedDocuments(e,t){const s=is();return this.populateOverlays(e,s,t).next((()=>this.computeViews(e,t,s,Pe())))}populateOverlays(e,t,s){const o=[];return s.forEach((u=>{t.has(u)||o.push(u)})),this.documentOverlayCache.getOverlays(e,o).next((u=>{u.forEach(((h,m)=>{t.set(h,m)}))}))}computeViews(e,t,s,o){let u=kr();const h=ba(),m=(function(){return ba()})();return t.forEach(((g,_)=>{const E=s.get(_.key);o.has(_.key)&&(E===void 0||E.mutation instanceof ki)?u=u.insert(_.key,_):E!==void 0?(h.set(_.key,E.mutation.getFieldMask()),Fa(E.mutation,_,E.mutation.getFieldMask(),Je.now())):h.set(_.key,ln.empty())})),this.recalculateAndSaveOverlays(e,u).next((g=>(g.forEach(((_,E)=>h.set(_,E))),t.forEach(((_,E)=>m.set(_,new XA(E,h.get(_)??null)))),m)))}recalculateAndSaveOverlays(e,t){const s=ba();let o=new tt(((h,m)=>h-m)),u=Pe();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next((h=>{for(const m of h)m.keys().forEach((g=>{const _=t.get(g);if(_===null)return;let E=s.get(g)||ln.empty();E=m.applyToLocalView(_,E),s.set(g,E);const S=(o.get(m.batchId)||Pe()).add(g);o=o.insert(m.batchId,S)}))})).next((()=>{const h=[],m=o.getReverseIterator();for(;m.hasNext();){const g=m.getNext(),_=g.key,E=g.value,S=X_();E.forEach((V=>{if(!u.has(V)){const z=iv(t.get(V),s.get(V));z!==null&&S.set(V,z),u=u.add(V)}})),h.push(this.documentOverlayCache.saveOverlays(e,_,S))}return $.waitFor(h)})).next((()=>s))}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next((s=>this.recalculateAndSaveOverlays(e,s)))}getDocumentsMatchingQuery(e,t,s,o){return eA(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):K_(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,s,o):this.getDocumentsMatchingCollectionQuery(e,t,s,o)}getNextDocuments(e,t,s,o){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,s,o).next((u=>{const h=o-u.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,s.largestBatchId,o-u.size):$.resolve(is());let m=$a,g=u;return h.next((_=>$.forEach(_,((E,S)=>(m<S.largestBatchId&&(m=S.largestBatchId),u.get(E)?$.resolve():this.remoteDocumentCache.getEntry(e,E).next((V=>{g=g.insert(E,V)}))))).next((()=>this.populateOverlays(e,_,u))).next((()=>this.computeViews(e,g,_,Pe()))).next((E=>({batchId:m,changes:J_(E)})))))}))}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new ce(t)).next((s=>{let o=xa();return s.isFoundDocument()&&(o=o.insert(s.key,s)),o}))}getDocumentsMatchingCollectionGroupQuery(e,t,s,o){const u=t.collectionGroup;let h=xa();return this.indexManager.getCollectionParents(e,u).next((m=>$.forEach(m,(g=>{const _=(function(S,V){return new il(V,null,S.explicitOrderBy.slice(),S.filters.slice(),S.limit,S.limitType,S.startAt,S.endAt)})(t,g.child(u));return this.getDocumentsMatchingCollectionQuery(e,_,s,o).next((E=>{E.forEach(((S,V)=>{h=h.insert(S,V)}))}))})).next((()=>h))))}getDocumentsMatchingCollectionQuery(e,t,s,o){let u;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,s.largestBatchId).next((h=>(u=h,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,s,u,o)))).next((h=>{u.forEach(((g,_)=>{const E=_.getKey();h.get(E)===null&&(h=h.insert(E,Ut.newInvalidDocument(E)))}));let m=xa();return h.forEach(((g,_)=>{const E=u.get(g);E!==void 0&&Fa(E.mutation,_,ln.empty(),Je.now()),_c(t,_)&&(m=m.insert(g,_))})),m}))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eR{constructor(e){this.serializer=e,this.Nr=new Map,this.Br=new Map}getBundleMetadata(e,t){return $.resolve(this.Nr.get(t))}saveBundleMetadata(e,t){return this.Nr.set(t.id,(function(o){return{id:o.id,version:o.version,createTime:nr(o.createTime)}})(t)),$.resolve()}getNamedQuery(e,t){return $.resolve(this.Br.get(t))}saveNamedQuery(e,t){return this.Br.set(t.name,(function(o){return{name:o.name,query:$A(o.bundledQuery),readTime:nr(o.readTime)}})(t)),$.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tR{constructor(){this.overlays=new tt(ce.comparator),this.Lr=new Map}getOverlay(e,t){return $.resolve(this.overlays.get(t))}getOverlays(e,t){const s=is();return $.forEach(t,(o=>this.getOverlay(e,o).next((u=>{u!==null&&s.set(o,u)})))).next((()=>s))}saveOverlays(e,t,s){return s.forEach(((o,u)=>{this.St(e,t,u)})),$.resolve()}removeOverlaysForBatchId(e,t,s){const o=this.Lr.get(s);return o!==void 0&&(o.forEach((u=>this.overlays=this.overlays.remove(u))),this.Lr.delete(s)),$.resolve()}getOverlaysForCollection(e,t,s){const o=is(),u=t.length+1,h=new ce(t.child("")),m=this.overlays.getIteratorFrom(h);for(;m.hasNext();){const g=m.getNext().value,_=g.getKey();if(!t.isPrefixOf(_.path))break;_.path.length===u&&g.largestBatchId>s&&o.set(g.getKey(),g)}return $.resolve(o)}getOverlaysForCollectionGroup(e,t,s,o){let u=new tt(((_,E)=>_-E));const h=this.overlays.getIterator();for(;h.hasNext();){const _=h.getNext().value;if(_.getKey().getCollectionGroup()===t&&_.largestBatchId>s){let E=u.get(_.largestBatchId);E===null&&(E=is(),u=u.insert(_.largestBatchId,E)),E.set(_.getKey(),_)}}const m=is(),g=u.getIterator();for(;g.hasNext()&&(g.getNext().value.forEach(((_,E)=>m.set(_,E))),!(m.size()>=o)););return $.resolve(m)}St(e,t,s){const o=this.overlays.get(s.key);if(o!==null){const h=this.Lr.get(o.largestBatchId).delete(s.key);this.Lr.set(o.largestBatchId,h)}this.overlays=this.overlays.insert(s.key,new vA(t,s));let u=this.Lr.get(t);u===void 0&&(u=Pe(),this.Lr.set(t,u)),this.Lr.set(t,u.add(s.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nR{constructor(){this.sessionToken=xt.EMPTY_BYTE_STRING}getSessionToken(e){return $.resolve(this.sessionToken)}setSessionToken(e,t){return this.sessionToken=t,$.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class df{constructor(){this.kr=new vt(St.qr),this.Kr=new vt(St.Ur)}isEmpty(){return this.kr.isEmpty()}addReference(e,t){const s=new St(e,t);this.kr=this.kr.add(s),this.Kr=this.Kr.add(s)}$r(e,t){e.forEach((s=>this.addReference(s,t)))}removeReference(e,t){this.Wr(new St(e,t))}Qr(e,t){e.forEach((s=>this.removeReference(s,t)))}Gr(e){const t=new ce(new Ke([])),s=new St(t,e),o=new St(t,e+1),u=[];return this.Kr.forEachInRange([s,o],(h=>{this.Wr(h),u.push(h.key)})),u}zr(){this.kr.forEach((e=>this.Wr(e)))}Wr(e){this.kr=this.kr.delete(e),this.Kr=this.Kr.delete(e)}jr(e){const t=new ce(new Ke([])),s=new St(t,e),o=new St(t,e+1);let u=Pe();return this.Kr.forEachInRange([s,o],(h=>{u=u.add(h.key)})),u}containsKey(e){const t=new St(e,0),s=this.kr.firstAfterOrEqual(t);return s!==null&&e.isEqual(s.key)}}class St{constructor(e,t){this.key=e,this.Jr=t}static qr(e,t){return ce.comparator(e.key,t.key)||Ce(e.Jr,t.Jr)}static Ur(e,t){return Ce(e.Jr,t.Jr)||ce.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rR{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.Yn=1,this.Hr=new vt(St.qr)}checkEmpty(e){return $.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,s,o){const u=this.Yn;this.Yn++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const h=new _A(u,t,s,o);this.mutationQueue.push(h);for(const m of o)this.Hr=this.Hr.add(new St(m.key,u)),this.indexManager.addToCollectionParentIndex(e,m.key.path.popLast());return $.resolve(h)}lookupMutationBatch(e,t){return $.resolve(this.Zr(t))}getNextMutationBatchAfterBatchId(e,t){const s=t+1,o=this.Xr(s),u=o<0?0:o;return $.resolve(this.mutationQueue.length>u?this.mutationQueue[u]:null)}getHighestUnacknowledgedBatchId(){return $.resolve(this.mutationQueue.length===0?ef:this.Yn-1)}getAllMutationBatches(e){return $.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const s=new St(t,0),o=new St(t,Number.POSITIVE_INFINITY),u=[];return this.Hr.forEachInRange([s,o],(h=>{const m=this.Zr(h.Jr);u.push(m)})),$.resolve(u)}getAllMutationBatchesAffectingDocumentKeys(e,t){let s=new vt(Ce);return t.forEach((o=>{const u=new St(o,0),h=new St(o,Number.POSITIVE_INFINITY);this.Hr.forEachInRange([u,h],(m=>{s=s.add(m.Jr)}))})),$.resolve(this.Yr(s))}getAllMutationBatchesAffectingQuery(e,t){const s=t.path,o=s.length+1;let u=s;ce.isDocumentKey(u)||(u=u.child(""));const h=new St(new ce(u),0);let m=new vt(Ce);return this.Hr.forEachWhile((g=>{const _=g.key.path;return!!s.isPrefixOf(_)&&(_.length===o&&(m=m.add(g.Jr)),!0)}),h),$.resolve(this.Yr(m))}Yr(e){const t=[];return e.forEach((s=>{const o=this.Zr(s);o!==null&&t.push(o)})),t}removeMutationBatch(e,t){Ue(this.ei(t.batchId,"removed")===0,55003),this.mutationQueue.shift();let s=this.Hr;return $.forEach(t.mutations,(o=>{const u=new St(o.key,t.batchId);return s=s.delete(u),this.referenceDelegate.markPotentiallyOrphaned(e,o.key)})).next((()=>{this.Hr=s}))}nr(e){}containsKey(e,t){const s=new St(t,0),o=this.Hr.firstAfterOrEqual(s);return $.resolve(t.isEqual(o&&o.key))}performConsistencyCheck(e){return this.mutationQueue.length,$.resolve()}ei(e,t){return this.Xr(e)}Xr(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Zr(e){const t=this.Xr(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iR{constructor(e){this.ti=e,this.docs=(function(){return new tt(ce.comparator)})(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const s=t.key,o=this.docs.get(s),u=o?o.size:0,h=this.ti(t);return this.docs=this.docs.insert(s,{document:t.mutableCopy(),size:h}),this.size+=h-u,this.indexManager.addToCollectionParentIndex(e,s.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const s=this.docs.get(t);return $.resolve(s?s.document.mutableCopy():Ut.newInvalidDocument(t))}getEntries(e,t){let s=kr();return t.forEach((o=>{const u=this.docs.get(o);s=s.insert(o,u?u.document.mutableCopy():Ut.newInvalidDocument(o))})),$.resolve(s)}getDocumentsMatchingQuery(e,t,s,o){let u=kr();const h=t.path,m=new ce(h.child("__id-9223372036854775808__")),g=this.docs.getIteratorFrom(m);for(;g.hasNext();){const{key:_,value:{document:E}}=g.getNext();if(!h.isPrefixOf(_.path))break;_.path.length>h.length+1||NS(kS(E),s)<=0||(o.has(E.key)||_c(t,E))&&(u=u.insert(E.key,E.mutableCopy()))}return $.resolve(u)}getAllFromCollectionGroup(e,t,s,o){pe(9500)}ni(e,t){return $.forEach(this.docs,(s=>t(s)))}newChangeBuffer(e){return new sR(this)}getSize(e){return $.resolve(this.size)}}class sR extends JA{constructor(e){super(),this.Mr=e}applyChanges(e){const t=[];return this.changes.forEach(((s,o)=>{o.isValidDocument()?t.push(this.Mr.addEntry(e,o)):this.Mr.removeEntry(s)})),$.waitFor(t)}getFromCache(e,t){return this.Mr.getEntry(e,t)}getAllFromCache(e,t){return this.Mr.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oR{constructor(e){this.persistence=e,this.ri=new ps((t=>rf(t)),sf),this.lastRemoteSnapshotVersion=ye.min(),this.highestTargetId=0,this.ii=0,this.si=new df,this.targetCount=0,this.oi=wo._r()}forEachTarget(e,t){return this.ri.forEach(((s,o)=>t(o))),$.resolve()}getLastRemoteSnapshotVersion(e){return $.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return $.resolve(this.ii)}allocateTargetId(e){return this.highestTargetId=this.oi.next(),$.resolve(this.highestTargetId)}setTargetsMetadata(e,t,s){return s&&(this.lastRemoteSnapshotVersion=s),t>this.ii&&(this.ii=t),$.resolve()}lr(e){this.ri.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.oi=new wo(t),this.highestTargetId=t),e.sequenceNumber>this.ii&&(this.ii=e.sequenceNumber)}addTargetData(e,t){return this.lr(t),this.targetCount+=1,$.resolve()}updateTargetData(e,t){return this.lr(t),$.resolve()}removeTargetData(e,t){return this.ri.delete(t.target),this.si.Gr(t.targetId),this.targetCount-=1,$.resolve()}removeTargets(e,t,s){let o=0;const u=[];return this.ri.forEach(((h,m)=>{m.sequenceNumber<=t&&s.get(m.targetId)===null&&(this.ri.delete(h),u.push(this.removeMatchingKeysForTargetId(e,m.targetId)),o++)})),$.waitFor(u).next((()=>o))}getTargetCount(e){return $.resolve(this.targetCount)}getTargetData(e,t){const s=this.ri.get(t)||null;return $.resolve(s)}addMatchingKeys(e,t,s){return this.si.$r(t,s),$.resolve()}removeMatchingKeys(e,t,s){this.si.Qr(t,s);const o=this.persistence.referenceDelegate,u=[];return o&&t.forEach((h=>{u.push(o.markPotentiallyOrphaned(e,h))})),$.waitFor(u)}removeMatchingKeysForTargetId(e,t){return this.si.Gr(t),$.resolve()}getMatchingKeysForTargetId(e,t){const s=this.si.jr(t);return $.resolve(s)}containsKey(e,t){return $.resolve(this.si.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _v{constructor(e,t){this._i={},this.overlays={},this.ai=new pc(0),this.ui=!1,this.ui=!0,this.ci=new nR,this.referenceDelegate=e(this),this.li=new oR(this),this.indexManager=new HA,this.remoteDocumentCache=(function(o){return new iR(o)})((s=>this.referenceDelegate.hi(s))),this.serializer=new BA(t),this.Pi=new eR(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.ui=!1,Promise.resolve()}get started(){return this.ui}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new tR,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let s=this._i[e.toKey()];return s||(s=new rR(t,this.referenceDelegate),this._i[e.toKey()]=s),s}getGlobalsCache(){return this.ci}getTargetCache(){return this.li}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.Pi}runTransaction(e,t,s){ne("MemoryPersistence","Starting transaction:",e);const o=new aR(this.ai.next());return this.referenceDelegate.Ti(),s(o).next((u=>this.referenceDelegate.Ei(o).next((()=>u)))).toPromise().then((u=>(o.raiseOnCommittedEvent(),u)))}Ii(e,t){return $.or(Object.values(this._i).map((s=>()=>s.containsKey(e,t))))}}class aR extends DS{constructor(e){super(),this.currentSequenceNumber=e}}class ff{constructor(e){this.persistence=e,this.Ri=new df,this.Ai=null}static Vi(e){return new ff(e)}get di(){if(this.Ai)return this.Ai;throw pe(60996)}addReference(e,t,s){return this.Ri.addReference(s,t),this.di.delete(s.toString()),$.resolve()}removeReference(e,t,s){return this.Ri.removeReference(s,t),this.di.add(s.toString()),$.resolve()}markPotentiallyOrphaned(e,t){return this.di.add(t.toString()),$.resolve()}removeTarget(e,t){this.Ri.Gr(t.targetId).forEach((o=>this.di.add(o.toString())));const s=this.persistence.getTargetCache();return s.getMatchingKeysForTargetId(e,t.targetId).next((o=>{o.forEach((u=>this.di.add(u.toString())))})).next((()=>s.removeTargetData(e,t)))}Ti(){this.Ai=new Set}Ei(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return $.forEach(this.di,(s=>{const o=ce.fromPath(s);return this.mi(e,o).next((u=>{u||t.removeEntry(o,ye.min())}))})).next((()=>(this.Ai=null,t.apply(e))))}updateLimboDocument(e,t){return this.mi(e,t).next((s=>{s?this.di.delete(t.toString()):this.di.add(t.toString())}))}hi(e){return 0}mi(e,t){return $.or([()=>$.resolve(this.Ri.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Ii(e,t)])}}class ic{constructor(e,t){this.persistence=e,this.fi=new ps((s=>LS(s.path)),((s,o)=>s.isEqual(o))),this.garbageCollector=YA(this,t)}static Vi(e,t){return new ic(e,t)}Ti(){}Ei(e){return $.resolve()}forEachTarget(e,t){return this.persistence.getTargetCache().forEachTarget(e,t)}dr(e){const t=this.pr(e);return this.persistence.getTargetCache().getTargetCount(e).next((s=>t.next((o=>s+o))))}pr(e){let t=0;return this.mr(e,(s=>{t++})).next((()=>t))}mr(e,t){return $.forEach(this.fi,((s,o)=>this.wr(e,s,o).next((u=>u?$.resolve():t(o)))))}removeTargets(e,t,s){return this.persistence.getTargetCache().removeTargets(e,t,s)}removeOrphanedDocuments(e,t){let s=0;const o=this.persistence.getRemoteDocumentCache(),u=o.newChangeBuffer();return o.ni(e,(h=>this.wr(e,h,t).next((m=>{m||(s++,u.removeEntry(h,ye.min()))})))).next((()=>u.apply(e))).next((()=>s))}markPotentiallyOrphaned(e,t){return this.fi.set(t,e.currentSequenceNumber),$.resolve()}removeTarget(e,t){const s=t.withSequenceNumber(e.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(e,s)}addReference(e,t,s){return this.fi.set(s,e.currentSequenceNumber),$.resolve()}removeReference(e,t,s){return this.fi.set(s,e.currentSequenceNumber),$.resolve()}updateLimboDocument(e,t){return this.fi.set(t,e.currentSequenceNumber),$.resolve()}hi(e){let t=e.key.toString().length;return e.isFoundDocument()&&(t+=bu(e.data.value)),t}wr(e,t,s){return $.or([()=>this.persistence.Ii(e,t),()=>this.persistence.getTargetCache().containsKey(e,t),()=>{const o=this.fi.get(t);return $.resolve(o!==void 0&&o>s)}])}getCacheSize(e){return this.persistence.getRemoteDocumentCache().getSize(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pf{constructor(e,t,s,o){this.targetId=e,this.fromCache=t,this.Ts=s,this.Es=o}static Is(e,t){let s=Pe(),o=Pe();for(const u of t.docChanges)switch(u.type){case 0:s=s.add(u.doc.key);break;case 1:o=o.add(u.doc.key)}return new pf(e,t.fromCache,s,o)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lR{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uR{constructor(){this.Rs=!1,this.As=!1,this.Vs=100,this.ds=(function(){return Dw()?8:VS(jt())>0?6:4})()}initialize(e,t){this.fs=e,this.indexManager=t,this.Rs=!0}getDocumentsMatchingQuery(e,t,s,o){const u={result:null};return this.gs(e,t).next((h=>{u.result=h})).next((()=>{if(!u.result)return this.ps(e,t,o,s).next((h=>{u.result=h}))})).next((()=>{if(u.result)return;const h=new lR;return this.ys(e,t,h).next((m=>{if(u.result=m,this.As)return this.ws(e,t,h,m.size)}))})).next((()=>u.result))}ws(e,t,s,o){return s.documentReadCount<this.Vs?(io()<=Re.DEBUG&&ne("QueryEngine","SDK will not create cache indexes for query:",so(t),"since it only creates cache indexes for collection contains","more than or equal to",this.Vs,"documents"),$.resolve()):(io()<=Re.DEBUG&&ne("QueryEngine","Query:",so(t),"scans",s.documentReadCount,"local documents and returns",o,"documents as results."),s.documentReadCount>this.ds*o?(io()<=Re.DEBUG&&ne("QueryEngine","The SDK decides to create cache indexes for query:",so(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,tr(t))):$.resolve())}gs(e,t){if($g(t))return $.resolve(null);let s=tr(t);return this.indexManager.getIndexType(e,s).next((o=>o===0?null:(t.limit!==null&&o===1&&(t=Nd(t,null,"F"),s=tr(t)),this.indexManager.getDocumentsMatchingTarget(e,s).next((u=>{const h=Pe(...u);return this.fs.getDocuments(e,h).next((m=>this.indexManager.getMinOffset(e,s).next((g=>{const _=this.Ss(t,m);return this.bs(t,_,h,g.readTime)?this.gs(e,Nd(t,null,"F")):this.Ds(e,_,t,g)}))))})))))}ps(e,t,s,o){return $g(t)||o.isEqual(ye.min())?$.resolve(null):this.fs.getDocuments(e,s).next((u=>{const h=this.Ss(t,u);return this.bs(t,h,s,o)?$.resolve(null):(io()<=Re.DEBUG&&ne("QueryEngine","Re-using previous result from %s to execute query: %s",o.toString(),so(t)),this.Ds(e,h,t,PS(o,$a)).next((m=>m)))}))}Ss(e,t){let s=new vt(Q_(e));return t.forEach(((o,u)=>{_c(e,u)&&(s=s.add(u))})),s}bs(e,t,s,o){if(e.limit===null)return!1;if(s.size!==t.size)return!0;const u=e.limitType==="F"?t.last():t.first();return!!u&&(u.hasPendingWrites||u.version.compareTo(o)>0)}ys(e,t,s){return io()<=Re.DEBUG&&ne("QueryEngine","Using full collection scan to execute query:",so(t)),this.fs.getDocumentsMatchingQuery(e,t,wi.min(),s)}Ds(e,t,s,o){return this.fs.getDocumentsMatchingQuery(e,s,o).next((u=>(t.forEach((h=>{u=u.insert(h.key,h)})),u)))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mf="LocalStore",cR=3e8;class hR{constructor(e,t,s,o){this.persistence=e,this.Cs=t,this.serializer=o,this.vs=new tt(Ce),this.Fs=new ps((u=>rf(u)),sf),this.Ms=new Map,this.xs=e.getRemoteDocumentCache(),this.li=e.getTargetCache(),this.Pi=e.getBundleCache(),this.Os(s)}Os(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new ZA(this.xs,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.xs.setIndexManager(this.indexManager),this.Cs.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",(t=>e.collect(t,this.vs)))}}function dR(r,e,t,s){return new hR(r,e,t,s)}async function vv(r,e){const t=ve(r);return await t.persistence.runTransaction("Handle user change","readonly",(s=>{let o;return t.mutationQueue.getAllMutationBatches(s).next((u=>(o=u,t.Os(e),t.mutationQueue.getAllMutationBatches(s)))).next((u=>{const h=[],m=[];let g=Pe();for(const _ of o){h.push(_.batchId);for(const E of _.mutations)g=g.add(E.key)}for(const _ of u){m.push(_.batchId);for(const E of _.mutations)g=g.add(E.key)}return t.localDocuments.getDocuments(s,g).next((_=>({Ns:_,removedBatchIds:h,addedBatchIds:m})))}))}))}function fR(r,e){const t=ve(r);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",(s=>{const o=e.batch.keys(),u=t.xs.newChangeBuffer({trackRemovals:!0});return(function(m,g,_,E){const S=_.batch,V=S.keys();let z=$.resolve();return V.forEach((Q=>{z=z.next((()=>E.getEntry(g,Q))).next((Y=>{const H=_.docVersions.get(Q);Ue(H!==null,48541),Y.version.compareTo(H)<0&&(S.applyToRemoteDocument(Y,_),Y.isValidDocument()&&(Y.setReadTime(_.commitVersion),E.addEntry(Y)))}))})),z.next((()=>m.mutationQueue.removeMutationBatch(g,S)))})(t,s,e,u).next((()=>u.apply(s))).next((()=>t.mutationQueue.performConsistencyCheck(s))).next((()=>t.documentOverlayCache.removeOverlaysForBatchId(s,o,e.batch.batchId))).next((()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(s,(function(m){let g=Pe();for(let _=0;_<m.mutationResults.length;++_)m.mutationResults[_].transformResults.length>0&&(g=g.add(m.batch.mutations[_].key));return g})(e)))).next((()=>t.localDocuments.getDocuments(s,o)))}))}function Ev(r){const e=ve(r);return e.persistence.runTransaction("Get last remote snapshot version","readonly",(t=>e.li.getLastRemoteSnapshotVersion(t)))}function pR(r,e){const t=ve(r),s=e.snapshotVersion;let o=t.vs;return t.persistence.runTransaction("Apply remote event","readwrite-primary",(u=>{const h=t.xs.newChangeBuffer({trackRemovals:!0});o=t.vs;const m=[];e.targetChanges.forEach(((E,S)=>{const V=o.get(S);if(!V)return;m.push(t.li.removeMatchingKeys(u,E.removedDocuments,S).next((()=>t.li.addMatchingKeys(u,E.addedDocuments,S))));let z=V.withSequenceNumber(u.currentSequenceNumber);e.targetMismatches.get(S)!==null?z=z.withResumeToken(xt.EMPTY_BYTE_STRING,ye.min()).withLastLimboFreeSnapshotVersion(ye.min()):E.resumeToken.approximateByteSize()>0&&(z=z.withResumeToken(E.resumeToken,s)),o=o.insert(S,z),(function(Y,H,ie){return Y.resumeToken.approximateByteSize()===0||H.snapshotVersion.toMicroseconds()-Y.snapshotVersion.toMicroseconds()>=cR?!0:ie.addedDocuments.size+ie.modifiedDocuments.size+ie.removedDocuments.size>0})(V,z,E)&&m.push(t.li.updateTargetData(u,z))}));let g=kr(),_=Pe();if(e.documentUpdates.forEach((E=>{e.resolvedLimboDocuments.has(E)&&m.push(t.persistence.referenceDelegate.updateLimboDocument(u,E))})),m.push(mR(u,h,e.documentUpdates).next((E=>{g=E.Bs,_=E.Ls}))),!s.isEqual(ye.min())){const E=t.li.getLastRemoteSnapshotVersion(u).next((S=>t.li.setTargetsMetadata(u,u.currentSequenceNumber,s)));m.push(E)}return $.waitFor(m).next((()=>h.apply(u))).next((()=>t.localDocuments.getLocalViewOfDocuments(u,g,_))).next((()=>g))})).then((u=>(t.vs=o,u)))}function mR(r,e,t){let s=Pe(),o=Pe();return t.forEach((u=>s=s.add(u))),e.getEntries(r,s).next((u=>{let h=kr();return t.forEach(((m,g)=>{const _=u.get(m);g.isFoundDocument()!==_.isFoundDocument()&&(o=o.add(m)),g.isNoDocument()&&g.version.isEqual(ye.min())?(e.removeEntry(m,g.readTime),h=h.insert(m,g)):!_.isValidDocument()||g.version.compareTo(_.version)>0||g.version.compareTo(_.version)===0&&_.hasPendingWrites?(e.addEntry(g),h=h.insert(m,g)):ne(mf,"Ignoring outdated watch update for ",m,". Current version:",_.version," Watch version:",g.version)})),{Bs:h,Ls:o}}))}function gR(r,e){const t=ve(r);return t.persistence.runTransaction("Get next mutation batch","readonly",(s=>(e===void 0&&(e=ef),t.mutationQueue.getNextMutationBatchAfterBatchId(s,e))))}function yR(r,e){const t=ve(r);return t.persistence.runTransaction("Allocate target","readwrite",(s=>{let o;return t.li.getTargetData(s,e).next((u=>u?(o=u,$.resolve(o)):t.li.allocateTargetId(s).next((h=>(o=new pi(e,h,"TargetPurposeListen",s.currentSequenceNumber),t.li.addTargetData(s,o).next((()=>o)))))))})).then((s=>{const o=t.vs.get(s.targetId);return(o===null||s.snapshotVersion.compareTo(o.snapshotVersion)>0)&&(t.vs=t.vs.insert(s.targetId,s),t.Fs.set(e,s.targetId)),s}))}async function Ld(r,e,t){const s=ve(r),o=s.vs.get(e),u=t?"readwrite":"readwrite-primary";try{t||await s.persistence.runTransaction("Release target",u,(h=>s.persistence.referenceDelegate.removeTarget(h,o)))}catch(h){if(!ko(h))throw h;ne(mf,`Failed to update sequence numbers for target ${e}: ${h}`)}s.vs=s.vs.remove(e),s.Fs.delete(o.target)}function ny(r,e,t){const s=ve(r);let o=ye.min(),u=Pe();return s.persistence.runTransaction("Execute query","readwrite",(h=>(function(g,_,E){const S=ve(g),V=S.Fs.get(E);return V!==void 0?$.resolve(S.vs.get(V)):S.li.getTargetData(_,E)})(s,h,tr(e)).next((m=>{if(m)return o=m.lastLimboFreeSnapshotVersion,s.li.getMatchingKeysForTargetId(h,m.targetId).next((g=>{u=g}))})).next((()=>s.Cs.getDocumentsMatchingQuery(h,e,t?o:ye.min(),t?u:Pe()))).next((m=>(_R(s,nA(e),m),{documents:m,ks:u})))))}function _R(r,e,t){let s=r.Ms.get(e)||ye.min();t.forEach(((o,u)=>{u.readTime.compareTo(s)>0&&(s=u.readTime)})),r.Ms.set(e,s)}class ry{constructor(){this.activeTargetIds=lA()}Qs(e){this.activeTargetIds=this.activeTargetIds.add(e)}Gs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}Ws(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class vR{constructor(){this.vo=new ry,this.Fo={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,s){}addLocalQueryTarget(e,t=!0){return t&&this.vo.Qs(e),this.Fo[e]||"not-current"}updateQueryState(e,t,s){this.Fo[e]=t}removeLocalQueryTarget(e){this.vo.Gs(e)}isLocalQueryTarget(e){return this.vo.activeTargetIds.has(e)}clearQueryState(e){delete this.Fo[e]}getAllActiveQueryTargets(){return this.vo.activeTargetIds}isActiveQueryTarget(e){return this.vo.activeTargetIds.has(e)}start(){return this.vo=new ry,Promise.resolve()}handleUserChange(e,t,s){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ER{Mo(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const iy="ConnectivityMonitor";class sy{constructor(){this.xo=()=>this.Oo(),this.No=()=>this.Bo(),this.Lo=[],this.ko()}Mo(e){this.Lo.push(e)}shutdown(){window.removeEventListener("online",this.xo),window.removeEventListener("offline",this.No)}ko(){window.addEventListener("online",this.xo),window.addEventListener("offline",this.No)}Oo(){ne(iy,"Network connectivity changed: AVAILABLE");for(const e of this.Lo)e(0)}Bo(){ne(iy,"Network connectivity changed: UNAVAILABLE");for(const e of this.Lo)e(1)}static v(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let xu=null;function Md(){return xu===null?xu=(function(){return 268435456+Math.round(2147483648*Math.random())})():xu++,"0x"+xu.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dd="RestConnection",wR={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class TR{get qo(){return!1}constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const t=e.ssl?"https":"http",s=encodeURIComponent(this.databaseId.projectId),o=encodeURIComponent(this.databaseId.database);this.Ko=t+"://"+e.host,this.Uo=`projects/${s}/databases/${o}`,this.$o=this.databaseId.database===Xu?`project_id=${s}`:`project_id=${s}&database_id=${o}`}Wo(e,t,s,o,u){const h=Md(),m=this.Qo(e,t.toUriEncodedString());ne(dd,`Sending RPC '${e}' ${h}:`,m,s);const g={"google-cloud-resource-prefix":this.Uo,"x-goog-request-params":this.$o};this.Go(g,o,u);const{host:_}=new URL(m),E=Xa(_);return this.zo(e,m,g,s,E).then((S=>(ne(dd,`Received RPC '${e}' ${h}: `,S),S)),(S=>{throw ds(dd,`RPC '${e}' ${h} failed with error: `,S,"url: ",m,"request:",s),S}))}jo(e,t,s,o,u,h){return this.Wo(e,t,s,o,u)}Go(e,t,s){e["X-Goog-Api-Client"]=(function(){return"gl-js/ fire/"+Co})(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach(((o,u)=>e[u]=o)),s&&s.headers.forEach(((o,u)=>e[u]=o))}Qo(e,t){const s=wR[e];let o=`${this.Ko}/v1/${t}:${s}`;return this.databaseInfo.apiKey&&(o=`${o}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),o}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class IR{constructor(e){this.Jo=e.Jo,this.Ho=e.Ho}Zo(e){this.Xo=e}Yo(e){this.e_=e}t_(e){this.n_=e}onMessage(e){this.r_=e}close(){this.Ho()}send(e){this.Jo(e)}i_(){this.Xo()}s_(){this.e_()}o_(e){this.n_(e)}__(e){this.r_(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bt="WebChannelConnection",Ca=(r,e,t)=>{r.listen(e,(s=>{try{t(s)}catch(o){setTimeout((()=>{throw o}),0)}}))};class fo extends TR{constructor(e){super(e),this.a_=[],this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}static u_(){if(!fo.c_){const e=A_();Ca(e,S_.STAT_EVENT,(t=>{t.stat===Id.PROXY?ne(bt,"STAT_EVENT: detected buffering proxy"):t.stat===Id.NOPROXY&&ne(bt,"STAT_EVENT: detected no buffering proxy")})),fo.c_=!0}}zo(e,t,s,o,u){const h=Md();return new Promise(((m,g)=>{const _=new T_;_.setWithCredentials(!0),_.listenOnce(I_.COMPLETE,(()=>{try{switch(_.getLastErrorCode()){case Mu.NO_ERROR:const S=_.getResponseJson();ne(bt,`XHR for RPC '${e}' ${h} received:`,JSON.stringify(S)),m(S);break;case Mu.TIMEOUT:ne(bt,`RPC '${e}' ${h} timed out`),g(new re(B.DEADLINE_EXCEEDED,"Request time out"));break;case Mu.HTTP_ERROR:const V=_.getStatus();if(ne(bt,`RPC '${e}' ${h} failed with status:`,V,"response text:",_.getResponseText()),V>0){let z=_.getResponseJson();Array.isArray(z)&&(z=z[0]);const Q=z==null?void 0:z.error;if(Q&&Q.status&&Q.message){const Y=(function(ie){const ge=ie.toLowerCase().replace(/_/g,"-");return Object.values(B).indexOf(ge)>=0?ge:B.UNKNOWN})(Q.status);g(new re(Y,Q.message))}else g(new re(B.UNKNOWN,"Server responded with status "+_.getStatus()))}else g(new re(B.UNAVAILABLE,"Connection failed."));break;default:pe(9055,{l_:e,streamId:h,h_:_.getLastErrorCode(),P_:_.getLastError()})}}finally{ne(bt,`RPC '${e}' ${h} completed.`)}}));const E=JSON.stringify(o);ne(bt,`RPC '${e}' ${h} sending request:`,o),_.send(t,"POST",E,s,15)}))}T_(e,t,s){const o=Md(),u=[this.Ko,"/","google.firestore.v1.Firestore","/",e,"/channel"],h=this.createWebChannelTransport(),m={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},g=this.longPollingOptions.timeoutSeconds;g!==void 0&&(m.longPollingTimeout=Math.round(1e3*g)),this.useFetchStreams&&(m.useFetchStreams=!0),this.Go(m.initMessageHeaders,t,s),m.encodeInitMessageHeaders=!0;const _=u.join("");ne(bt,`Creating RPC '${e}' stream ${o}: ${_}`,m);const E=h.createWebChannel(_,m);this.E_(E);let S=!1,V=!1;const z=new IR({Jo:Q=>{V?ne(bt,`Not sending because RPC '${e}' stream ${o} is closed:`,Q):(S||(ne(bt,`Opening RPC '${e}' stream ${o} transport.`),E.open(),S=!0),ne(bt,`RPC '${e}' stream ${o} sending:`,Q),E.send(Q))},Ho:()=>E.close()});return Ca(E,Na.EventType.OPEN,(()=>{V||(ne(bt,`RPC '${e}' stream ${o} transport opened.`),z.i_())})),Ca(E,Na.EventType.CLOSE,(()=>{V||(V=!0,ne(bt,`RPC '${e}' stream ${o} transport closed`),z.o_(),this.I_(E))})),Ca(E,Na.EventType.ERROR,(Q=>{V||(V=!0,ds(bt,`RPC '${e}' stream ${o} transport errored. Name:`,Q.name,"Message:",Q.message),z.o_(new re(B.UNAVAILABLE,"The operation could not be completed")))})),Ca(E,Na.EventType.MESSAGE,(Q=>{var Y;if(!V){const H=Q.data[0];Ue(!!H,16349);const ie=H,ge=(ie==null?void 0:ie.error)||((Y=ie[0])==null?void 0:Y.error);if(ge){ne(bt,`RPC '${e}' stream ${o} received error:`,ge);const Te=ge.status;let De=(function(C){const T=dt[C];if(T!==void 0)return ov(T)})(Te),be=ge.message;Te==="NOT_FOUND"&&be.includes("database")&&be.includes("does not exist")&&be.includes(this.databaseId.database)&&ds(`Database '${this.databaseId.database}' not found. Please check your project configuration.`),De===void 0&&(De=B.INTERNAL,be="Unknown error status: "+Te+" with message "+ge.message),V=!0,z.o_(new re(De,be)),E.close()}else ne(bt,`RPC '${e}' stream ${o} received:`,H),z.__(H)}})),fo.u_(),setTimeout((()=>{z.s_()}),0),z}terminate(){this.a_.forEach((e=>e.close())),this.a_=[]}E_(e){this.a_.push(e)}I_(e){this.a_=this.a_.filter((t=>t===e))}Go(e,t,s){super.Go(e,t,s),this.databaseInfo.apiKey&&(e["x-goog-api-key"]=this.databaseInfo.apiKey)}createWebChannelTransport(){return R_()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function SR(r){return new fo(r)}function fd(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Tc(r){return new PA(r,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */fo.c_=!1;class wv{constructor(e,t,s=1e3,o=1.5,u=6e4){this.Ci=e,this.timerId=t,this.R_=s,this.A_=o,this.V_=u,this.d_=0,this.m_=null,this.f_=Date.now(),this.reset()}reset(){this.d_=0}g_(){this.d_=this.V_}p_(e){this.cancel();const t=Math.floor(this.d_+this.y_()),s=Math.max(0,Date.now()-this.f_),o=Math.max(0,t-s);o>0&&ne("ExponentialBackoff",`Backing off for ${o} ms (base delay: ${this.d_} ms, delay with jitter: ${t} ms, last attempt: ${s} ms ago)`),this.m_=this.Ci.enqueueAfterDelay(this.timerId,o,(()=>(this.f_=Date.now(),e()))),this.d_*=this.A_,this.d_<this.R_&&(this.d_=this.R_),this.d_>this.V_&&(this.d_=this.V_)}w_(){this.m_!==null&&(this.m_.skipDelay(),this.m_=null)}cancel(){this.m_!==null&&(this.m_.cancel(),this.m_=null)}y_(){return(Math.random()-.5)*this.d_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oy="PersistentStream";class Tv{constructor(e,t,s,o,u,h,m,g){this.Ci=e,this.S_=s,this.b_=o,this.connection=u,this.authCredentialsProvider=h,this.appCheckCredentialsProvider=m,this.listener=g,this.state=0,this.D_=0,this.C_=null,this.v_=null,this.stream=null,this.F_=0,this.M_=new wv(e,t)}x_(){return this.state===1||this.state===5||this.O_()}O_(){return this.state===2||this.state===3}start(){this.F_=0,this.state!==4?this.auth():this.N_()}async stop(){this.x_()&&await this.close(0)}B_(){this.state=0,this.M_.reset()}L_(){this.O_()&&this.C_===null&&(this.C_=this.Ci.enqueueAfterDelay(this.S_,6e4,(()=>this.k_())))}q_(e){this.K_(),this.stream.send(e)}async k_(){if(this.O_())return this.close(0)}K_(){this.C_&&(this.C_.cancel(),this.C_=null)}U_(){this.v_&&(this.v_.cancel(),this.v_=null)}async close(e,t){this.K_(),this.U_(),this.M_.cancel(),this.D_++,e!==4?this.M_.reset():t&&t.code===B.RESOURCE_EXHAUSTED?(Pr(t.toString()),Pr("Using maximum backoff delay to prevent overloading the backend."),this.M_.g_()):t&&t.code===B.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.W_(),this.stream.close(),this.stream=null),this.state=e,await this.listener.t_(t)}W_(){}auth(){this.state=1;const e=this.Q_(this.D_),t=this.D_;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then((([s,o])=>{this.D_===t&&this.G_(s,o)}),(s=>{e((()=>{const o=new re(B.UNKNOWN,"Fetching auth token failed: "+s.message);return this.z_(o)}))}))}G_(e,t){const s=this.Q_(this.D_);this.stream=this.j_(e,t),this.stream.Zo((()=>{s((()=>this.listener.Zo()))})),this.stream.Yo((()=>{s((()=>(this.state=2,this.v_=this.Ci.enqueueAfterDelay(this.b_,1e4,(()=>(this.O_()&&(this.state=3),Promise.resolve()))),this.listener.Yo())))})),this.stream.t_((o=>{s((()=>this.z_(o)))})),this.stream.onMessage((o=>{s((()=>++this.F_==1?this.J_(o):this.onNext(o)))}))}N_(){this.state=5,this.M_.p_((async()=>{this.state=0,this.start()}))}z_(e){return ne(oy,`close with error: ${e}`),this.stream=null,this.close(4,e)}Q_(e){return t=>{this.Ci.enqueueAndForget((()=>this.D_===e?t():(ne(oy,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve())))}}}class AR extends Tv{constructor(e,t,s,o,u,h){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,s,o,h),this.serializer=u}j_(e,t){return this.connection.T_("Listen",e,t)}J_(e){return this.onNext(e)}onNext(e){this.M_.reset();const t=xA(this.serializer,e),s=(function(u){if(!("targetChange"in u))return ye.min();const h=u.targetChange;return h.targetIds&&h.targetIds.length?ye.min():h.readTime?nr(h.readTime):ye.min()})(e);return this.listener.H_(t,s)}Z_(e){const t={};t.database=Od(this.serializer),t.addTarget=(function(u,h){let m;const g=h.target;if(m=Pd(g)?{documents:OA(u,g)}:{query:LA(u,g).ft},m.targetId=h.targetId,h.resumeToken.approximateByteSize()>0){m.resumeToken=uv(u,h.resumeToken);const _=xd(u,h.expectedCount);_!==null&&(m.expectedCount=_)}else if(h.snapshotVersion.compareTo(ye.min())>0){m.readTime=rc(u,h.snapshotVersion.toTimestamp());const _=xd(u,h.expectedCount);_!==null&&(m.expectedCount=_)}return m})(this.serializer,e);const s=bA(this.serializer,e);s&&(t.labels=s),this.q_(t)}X_(e){const t={};t.database=Od(this.serializer),t.removeTarget=e,this.q_(t)}}class RR extends Tv{constructor(e,t,s,o,u,h){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,s,o,h),this.serializer=u}get Y_(){return this.F_>0}start(){this.lastStreamToken=void 0,super.start()}W_(){this.Y_&&this.ea([])}j_(e,t){return this.connection.T_("Write",e,t)}J_(e){return Ue(!!e.streamToken,31322),this.lastStreamToken=e.streamToken,Ue(!e.writeResults||e.writeResults.length===0,55816),this.listener.ta()}onNext(e){Ue(!!e.streamToken,12678),this.lastStreamToken=e.streamToken,this.M_.reset();const t=VA(e.writeResults,e.commitTime),s=nr(e.commitTime);return this.listener.na(s,t)}ra(){const e={};e.database=Od(this.serializer),this.q_(e)}ea(e){const t={streamToken:this.lastStreamToken,writes:e.map((s=>DA(this.serializer,s)))};this.q_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class CR{}class PR extends CR{constructor(e,t,s,o){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=s,this.serializer=o,this.ia=!1}sa(){if(this.ia)throw new re(B.FAILED_PRECONDITION,"The client has already been terminated.")}Wo(e,t,s,o){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then((([u,h])=>this.connection.Wo(e,Dd(t,s),o,u,h))).catch((u=>{throw u.name==="FirebaseError"?(u.code===B.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),u):new re(B.UNKNOWN,u.toString())}))}jo(e,t,s,o,u){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then((([h,m])=>this.connection.jo(e,Dd(t,s),o,h,m,u))).catch((h=>{throw h.name==="FirebaseError"?(h.code===B.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),h):new re(B.UNKNOWN,h.toString())}))}terminate(){this.ia=!0,this.connection.terminate()}}function kR(r,e,t,s){return new PR(r,e,t,s)}class NR{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.oa=0,this._a=null,this.aa=!0}ua(){this.oa===0&&(this.ca("Unknown"),this._a=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,(()=>(this._a=null,this.la("Backend didn't respond within 10 seconds."),this.ca("Offline"),Promise.resolve()))))}ha(e){this.state==="Online"?this.ca("Unknown"):(this.oa++,this.oa>=1&&(this.Pa(),this.la(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.ca("Offline")))}set(e){this.Pa(),this.oa=0,e==="Online"&&(this.aa=!1),this.ca(e)}ca(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}la(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.aa?(Pr(t),this.aa=!1):ne("OnlineStateTracker",t)}Pa(){this._a!==null&&(this._a.cancel(),this._a=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fs="RemoteStore";class xR{constructor(e,t,s,o,u){this.localStore=e,this.datastore=t,this.asyncQueue=s,this.remoteSyncer={},this.Ta=[],this.Ea=new Map,this.Ia=new Set,this.Ra=[],this.Aa=u,this.Aa.Mo((h=>{s.enqueueAndForget((async()=>{ms(this)&&(ne(fs,"Restarting streams for network reachability change."),await(async function(g){const _=ve(g);_.Ia.add(4),await al(_),_.Va.set("Unknown"),_.Ia.delete(4),await Ic(_)})(this))}))})),this.Va=new NR(s,o)}}async function Ic(r){if(ms(r))for(const e of r.Ra)await e(!0)}async function al(r){for(const e of r.Ra)await e(!1)}function Iv(r,e){const t=ve(r);t.Ea.has(e.targetId)||(t.Ea.set(e.targetId,e),vf(t)?_f(t):No(t).O_()&&yf(t,e))}function gf(r,e){const t=ve(r),s=No(t);t.Ea.delete(e),s.O_()&&Sv(t,e),t.Ea.size===0&&(s.O_()?s.L_():ms(t)&&t.Va.set("Unknown"))}function yf(r,e){if(r.da.$e(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(ye.min())>0){const t=r.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(t)}No(r).Z_(e)}function Sv(r,e){r.da.$e(e),No(r).X_(e)}function _f(r){r.da=new SA({getRemoteKeysForTarget:e=>r.remoteSyncer.getRemoteKeysForTarget(e),At:e=>r.Ea.get(e)||null,ht:()=>r.datastore.serializer.databaseId}),No(r).start(),r.Va.ua()}function vf(r){return ms(r)&&!No(r).x_()&&r.Ea.size>0}function ms(r){return ve(r).Ia.size===0}function Av(r){r.da=void 0}async function DR(r){r.Va.set("Online")}async function VR(r){r.Ea.forEach(((e,t)=>{yf(r,e)}))}async function OR(r,e){Av(r),vf(r)?(r.Va.ha(e),_f(r)):r.Va.set("Unknown")}async function LR(r,e,t){if(r.Va.set("Online"),e instanceof lv&&e.state===2&&e.cause)try{await(async function(o,u){const h=u.cause;for(const m of u.targetIds)o.Ea.has(m)&&(await o.remoteSyncer.rejectListen(m,h),o.Ea.delete(m),o.da.removeTarget(m))})(r,e)}catch(s){ne(fs,"Failed to remove targets %s: %s ",e.targetIds.join(","),s),await sc(r,s)}else if(e instanceof ju?r.da.Xe(e):e instanceof av?r.da.st(e):r.da.tt(e),!t.isEqual(ye.min()))try{const s=await Ev(r.localStore);t.compareTo(s)>=0&&await(function(u,h){const m=u.da.Tt(h);return m.targetChanges.forEach(((g,_)=>{if(g.resumeToken.approximateByteSize()>0){const E=u.Ea.get(_);E&&u.Ea.set(_,E.withResumeToken(g.resumeToken,h))}})),m.targetMismatches.forEach(((g,_)=>{const E=u.Ea.get(g);if(!E)return;u.Ea.set(g,E.withResumeToken(xt.EMPTY_BYTE_STRING,E.snapshotVersion)),Sv(u,g);const S=new pi(E.target,g,_,E.sequenceNumber);yf(u,S)})),u.remoteSyncer.applyRemoteEvent(m)})(r,t)}catch(s){ne(fs,"Failed to raise snapshot:",s),await sc(r,s)}}async function sc(r,e,t){if(!ko(e))throw e;r.Ia.add(1),await al(r),r.Va.set("Offline"),t||(t=()=>Ev(r.localStore)),r.asyncQueue.enqueueRetryable((async()=>{ne(fs,"Retrying IndexedDB access"),await t(),r.Ia.delete(1),await Ic(r)}))}function Rv(r,e){return e().catch((t=>sc(r,t,e)))}async function Sc(r){const e=ve(r),t=Ai(e);let s=e.Ta.length>0?e.Ta[e.Ta.length-1].batchId:ef;for(;MR(e);)try{const o=await gR(e.localStore,s);if(o===null){e.Ta.length===0&&t.L_();break}s=o.batchId,bR(e,o)}catch(o){await sc(e,o)}Cv(e)&&Pv(e)}function MR(r){return ms(r)&&r.Ta.length<10}function bR(r,e){r.Ta.push(e);const t=Ai(r);t.O_()&&t.Y_&&t.ea(e.mutations)}function Cv(r){return ms(r)&&!Ai(r).x_()&&r.Ta.length>0}function Pv(r){Ai(r).start()}async function FR(r){Ai(r).ra()}async function UR(r){const e=Ai(r);for(const t of r.Ta)e.ea(t.mutations)}async function jR(r,e,t){const s=r.Ta.shift(),o=uf.from(s,e,t);await Rv(r,(()=>r.remoteSyncer.applySuccessfulWrite(o))),await Sc(r)}async function zR(r,e){e&&Ai(r).Y_&&await(async function(s,o){if((function(h){return wA(h)&&h!==B.ABORTED})(o.code)){const u=s.Ta.shift();Ai(s).B_(),await Rv(s,(()=>s.remoteSyncer.rejectFailedWrite(u.batchId,o))),await Sc(s)}})(r,e),Cv(r)&&Pv(r)}async function ay(r,e){const t=ve(r);t.asyncQueue.verifyOperationInProgress(),ne(fs,"RemoteStore received new credentials");const s=ms(t);t.Ia.add(3),await al(t),s&&t.Va.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.Ia.delete(3),await Ic(t)}async function BR(r,e){const t=ve(r);e?(t.Ia.delete(2),await Ic(t)):e||(t.Ia.add(2),await al(t),t.Va.set("Unknown"))}function No(r){return r.ma||(r.ma=(function(t,s,o){const u=ve(t);return u.sa(),new AR(s,u.connection,u.authCredentials,u.appCheckCredentials,u.serializer,o)})(r.datastore,r.asyncQueue,{Zo:DR.bind(null,r),Yo:VR.bind(null,r),t_:OR.bind(null,r),H_:LR.bind(null,r)}),r.Ra.push((async e=>{e?(r.ma.B_(),vf(r)?_f(r):r.Va.set("Unknown")):(await r.ma.stop(),Av(r))}))),r.ma}function Ai(r){return r.fa||(r.fa=(function(t,s,o){const u=ve(t);return u.sa(),new RR(s,u.connection,u.authCredentials,u.appCheckCredentials,u.serializer,o)})(r.datastore,r.asyncQueue,{Zo:()=>Promise.resolve(),Yo:FR.bind(null,r),t_:zR.bind(null,r),ta:UR.bind(null,r),na:jR.bind(null,r)}),r.Ra.push((async e=>{e?(r.fa.B_(),await Sc(r)):(await r.fa.stop(),r.Ta.length>0&&(ne(fs,`Stopping write stream with ${r.Ta.length} pending writes`),r.Ta=[]))}))),r.fa}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ef{constructor(e,t,s,o,u){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=s,this.op=o,this.removalCallback=u,this.deferred=new ss,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch((h=>{}))}get promise(){return this.deferred.promise}static createAndSchedule(e,t,s,o,u){const h=Date.now()+s,m=new Ef(e,t,h,o,u);return m.start(s),m}start(e){this.timerHandle=setTimeout((()=>this.handleDelayElapsed()),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new re(B.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget((()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then((e=>this.deferred.resolve(e)))):Promise.resolve()))}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function wf(r,e){if(Pr("AsyncQueue",`${e}: ${r}`),ko(r))return new re(B.UNAVAILABLE,`${e}: ${r}`);throw r}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class po{static emptySet(e){return new po(e.comparator)}constructor(e){this.comparator=e?(t,s)=>e(t,s)||ce.comparator(t.key,s.key):(t,s)=>ce.comparator(t.key,s.key),this.keyedMap=xa(),this.sortedSet=new tt(this.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal(((t,s)=>(e(t),!1)))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof po)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),s=e.sortedSet.getIterator();for(;t.hasNext();){const o=t.getNext().key,u=s.getNext().key;if(!o.isEqual(u))return!1}return!0}toString(){const e=[];return this.forEach((t=>{e.push(t.toString())})),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const s=new po;return s.comparator=this.comparator,s.keyedMap=e,s.sortedSet=t,s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ly{constructor(){this.ga=new tt(ce.comparator)}track(e){const t=e.doc.key,s=this.ga.get(t);s?e.type!==0&&s.type===3?this.ga=this.ga.insert(t,e):e.type===3&&s.type!==1?this.ga=this.ga.insert(t,{type:s.type,doc:e.doc}):e.type===2&&s.type===2?this.ga=this.ga.insert(t,{type:2,doc:e.doc}):e.type===2&&s.type===0?this.ga=this.ga.insert(t,{type:0,doc:e.doc}):e.type===1&&s.type===0?this.ga=this.ga.remove(t):e.type===1&&s.type===2?this.ga=this.ga.insert(t,{type:1,doc:s.doc}):e.type===0&&s.type===1?this.ga=this.ga.insert(t,{type:2,doc:e.doc}):pe(63341,{Vt:e,pa:s}):this.ga=this.ga.insert(t,e)}ya(){const e=[];return this.ga.inorderTraversal(((t,s)=>{e.push(s)})),e}}class To{constructor(e,t,s,o,u,h,m,g,_){this.query=e,this.docs=t,this.oldDocs=s,this.docChanges=o,this.mutatedKeys=u,this.fromCache=h,this.syncStateChanged=m,this.excludesMetadataChanges=g,this.hasCachedResults=_}static fromInitialDocuments(e,t,s,o,u){const h=[];return t.forEach((m=>{h.push({type:0,doc:m})})),new To(e,t,po.emptySet(t),h,s,o,!0,!1,u)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&yc(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,s=e.docChanges;if(t.length!==s.length)return!1;for(let o=0;o<t.length;o++)if(t[o].type!==s[o].type||!t[o].doc.isEqual(s[o].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $R{constructor(){this.wa=void 0,this.Sa=[]}ba(){return this.Sa.some((e=>e.Da()))}}class HR{constructor(){this.queries=uy(),this.onlineState="Unknown",this.Ca=new Set}terminate(){(function(t,s){const o=ve(t),u=o.queries;o.queries=uy(),u.forEach(((h,m)=>{for(const g of m.Sa)g.onError(s)}))})(this,new re(B.ABORTED,"Firestore shutting down"))}}function uy(){return new ps((r=>G_(r)),yc)}async function qR(r,e){const t=ve(r);let s=3;const o=e.query;let u=t.queries.get(o);u?!u.ba()&&e.Da()&&(s=2):(u=new $R,s=e.Da()?0:1);try{switch(s){case 0:u.wa=await t.onListen(o,!0);break;case 1:u.wa=await t.onListen(o,!1);break;case 2:await t.onFirstRemoteStoreListen(o)}}catch(h){const m=wf(h,`Initialization of query '${so(e.query)}' failed`);return void e.onError(m)}t.queries.set(o,u),u.Sa.push(e),e.va(t.onlineState),u.wa&&e.Fa(u.wa)&&Tf(t)}async function WR(r,e){const t=ve(r),s=e.query;let o=3;const u=t.queries.get(s);if(u){const h=u.Sa.indexOf(e);h>=0&&(u.Sa.splice(h,1),u.Sa.length===0?o=e.Da()?0:1:!u.ba()&&e.Da()&&(o=2))}switch(o){case 0:return t.queries.delete(s),t.onUnlisten(s,!0);case 1:return t.queries.delete(s),t.onUnlisten(s,!1);case 2:return t.onLastRemoteStoreUnlisten(s);default:return}}function KR(r,e){const t=ve(r);let s=!1;for(const o of e){const u=o.query,h=t.queries.get(u);if(h){for(const m of h.Sa)m.Fa(o)&&(s=!0);h.wa=o}}s&&Tf(t)}function GR(r,e,t){const s=ve(r),o=s.queries.get(e);if(o)for(const u of o.Sa)u.onError(t);s.queries.delete(e)}function Tf(r){r.Ca.forEach((e=>{e.next()}))}var bd,cy;(cy=bd||(bd={})).Ma="default",cy.Cache="cache";class QR{constructor(e,t,s){this.query=e,this.xa=t,this.Oa=!1,this.Na=null,this.onlineState="Unknown",this.options=s||{}}Fa(e){if(!this.options.includeMetadataChanges){const s=[];for(const o of e.docChanges)o.type!==3&&s.push(o);e=new To(e.query,e.docs,e.oldDocs,s,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Oa?this.Ba(e)&&(this.xa.next(e),t=!0):this.La(e,this.onlineState)&&(this.ka(e),t=!0),this.Na=e,t}onError(e){this.xa.error(e)}va(e){this.onlineState=e;let t=!1;return this.Na&&!this.Oa&&this.La(this.Na,e)&&(this.ka(this.Na),t=!0),t}La(e,t){if(!e.fromCache||!this.Da())return!0;const s=t!=="Offline";return(!this.options.qa||!s)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}Ba(e){if(e.docChanges.length>0)return!0;const t=this.Na&&this.Na.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}ka(e){e=To.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Oa=!0,this.xa.next(e)}Da(){return this.options.source!==bd.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kv{constructor(e){this.key=e}}class Nv{constructor(e){this.key=e}}class YR{constructor(e,t){this.query=e,this.Za=t,this.Xa=null,this.hasCachedResults=!1,this.current=!1,this.Ya=Pe(),this.mutatedKeys=Pe(),this.eu=Q_(e),this.tu=new po(this.eu)}get nu(){return this.Za}ru(e,t){const s=t?t.iu:new ly,o=t?t.tu:this.tu;let u=t?t.mutatedKeys:this.mutatedKeys,h=o,m=!1;const g=this.query.limitType==="F"&&o.size===this.query.limit?o.last():null,_=this.query.limitType==="L"&&o.size===this.query.limit?o.first():null;if(e.inorderTraversal(((E,S)=>{const V=o.get(E),z=_c(this.query,S)?S:null,Q=!!V&&this.mutatedKeys.has(V.key),Y=!!z&&(z.hasLocalMutations||this.mutatedKeys.has(z.key)&&z.hasCommittedMutations);let H=!1;V&&z?V.data.isEqual(z.data)?Q!==Y&&(s.track({type:3,doc:z}),H=!0):this.su(V,z)||(s.track({type:2,doc:z}),H=!0,(g&&this.eu(z,g)>0||_&&this.eu(z,_)<0)&&(m=!0)):!V&&z?(s.track({type:0,doc:z}),H=!0):V&&!z&&(s.track({type:1,doc:V}),H=!0,(g||_)&&(m=!0)),H&&(z?(h=h.add(z),u=Y?u.add(E):u.delete(E)):(h=h.delete(E),u=u.delete(E)))})),this.query.limit!==null)for(;h.size>this.query.limit;){const E=this.query.limitType==="F"?h.last():h.first();h=h.delete(E.key),u=u.delete(E.key),s.track({type:1,doc:E})}return{tu:h,iu:s,bs:m,mutatedKeys:u}}su(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,s,o){const u=this.tu;this.tu=e.tu,this.mutatedKeys=e.mutatedKeys;const h=e.iu.ya();h.sort(((E,S)=>(function(z,Q){const Y=H=>{switch(H){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return pe(20277,{Vt:H})}};return Y(z)-Y(Q)})(E.type,S.type)||this.eu(E.doc,S.doc))),this.ou(s),o=o??!1;const m=t&&!o?this._u():[],g=this.Ya.size===0&&this.current&&!o?1:0,_=g!==this.Xa;return this.Xa=g,h.length!==0||_?{snapshot:new To(this.query,e.tu,u,h,e.mutatedKeys,g===0,_,!1,!!s&&s.resumeToken.approximateByteSize()>0),au:m}:{au:m}}va(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({tu:this.tu,iu:new ly,mutatedKeys:this.mutatedKeys,bs:!1},!1)):{au:[]}}uu(e){return!this.Za.has(e)&&!!this.tu.has(e)&&!this.tu.get(e).hasLocalMutations}ou(e){e&&(e.addedDocuments.forEach((t=>this.Za=this.Za.add(t))),e.modifiedDocuments.forEach((t=>{})),e.removedDocuments.forEach((t=>this.Za=this.Za.delete(t))),this.current=e.current)}_u(){if(!this.current)return[];const e=this.Ya;this.Ya=Pe(),this.tu.forEach((s=>{this.uu(s.key)&&(this.Ya=this.Ya.add(s.key))}));const t=[];return e.forEach((s=>{this.Ya.has(s)||t.push(new Nv(s))})),this.Ya.forEach((s=>{e.has(s)||t.push(new kv(s))})),t}cu(e){this.Za=e.ks,this.Ya=Pe();const t=this.ru(e.documents);return this.applyChanges(t,!0)}lu(){return To.fromInitialDocuments(this.query,this.tu,this.mutatedKeys,this.Xa===0,this.hasCachedResults)}}const If="SyncEngine";class JR{constructor(e,t,s){this.query=e,this.targetId=t,this.view=s}}class XR{constructor(e){this.key=e,this.hu=!1}}class ZR{constructor(e,t,s,o,u,h){this.localStore=e,this.remoteStore=t,this.eventManager=s,this.sharedClientState=o,this.currentUser=u,this.maxConcurrentLimboResolutions=h,this.Pu={},this.Tu=new ps((m=>G_(m)),yc),this.Eu=new Map,this.Iu=new Set,this.Ru=new tt(ce.comparator),this.Au=new Map,this.Vu=new df,this.du={},this.mu=new Map,this.fu=wo.ar(),this.onlineState="Unknown",this.gu=void 0}get isPrimaryClient(){return this.gu===!0}}async function eC(r,e,t=!0){const s=Mv(r);let o;const u=s.Tu.get(e);return u?(s.sharedClientState.addLocalQueryTarget(u.targetId),o=u.view.lu()):o=await xv(s,e,t,!0),o}async function tC(r,e){const t=Mv(r);await xv(t,e,!0,!1)}async function xv(r,e,t,s){const o=await yR(r.localStore,tr(e)),u=o.targetId,h=r.sharedClientState.addLocalQueryTarget(u,t);let m;return s&&(m=await nC(r,e,u,h==="current",o.resumeToken)),r.isPrimaryClient&&t&&Iv(r.remoteStore,o),m}async function nC(r,e,t,s,o){r.pu=(S,V,z)=>(async function(Y,H,ie,ge){let Te=H.view.ru(ie);Te.bs&&(Te=await ny(Y.localStore,H.query,!1).then((({documents:C})=>H.view.ru(C,Te))));const De=ge&&ge.targetChanges.get(H.targetId),be=ge&&ge.targetMismatches.get(H.targetId)!=null,ke=H.view.applyChanges(Te,Y.isPrimaryClient,De,be);return dy(Y,H.targetId,ke.au),ke.snapshot})(r,S,V,z);const u=await ny(r.localStore,e,!0),h=new YR(e,u.ks),m=h.ru(u.documents),g=ol.createSynthesizedTargetChangeForCurrentChange(t,s&&r.onlineState!=="Offline",o),_=h.applyChanges(m,r.isPrimaryClient,g);dy(r,t,_.au);const E=new JR(e,t,h);return r.Tu.set(e,E),r.Eu.has(t)?r.Eu.get(t).push(e):r.Eu.set(t,[e]),_.snapshot}async function rC(r,e,t){const s=ve(r),o=s.Tu.get(e),u=s.Eu.get(o.targetId);if(u.length>1)return s.Eu.set(o.targetId,u.filter((h=>!yc(h,e)))),void s.Tu.delete(e);s.isPrimaryClient?(s.sharedClientState.removeLocalQueryTarget(o.targetId),s.sharedClientState.isActiveQueryTarget(o.targetId)||await Ld(s.localStore,o.targetId,!1).then((()=>{s.sharedClientState.clearQueryState(o.targetId),t&&gf(s.remoteStore,o.targetId),Fd(s,o.targetId)})).catch(Po)):(Fd(s,o.targetId),await Ld(s.localStore,o.targetId,!0))}async function iC(r,e){const t=ve(r),s=t.Tu.get(e),o=t.Eu.get(s.targetId);t.isPrimaryClient&&o.length===1&&(t.sharedClientState.removeLocalQueryTarget(s.targetId),gf(t.remoteStore,s.targetId))}async function sC(r,e,t){const s=dC(r);try{const o=await(function(h,m){const g=ve(h),_=Je.now(),E=m.reduce(((z,Q)=>z.add(Q.key)),Pe());let S,V;return g.persistence.runTransaction("Locally write mutations","readwrite",(z=>{let Q=kr(),Y=Pe();return g.xs.getEntries(z,E).next((H=>{Q=H,Q.forEach(((ie,ge)=>{ge.isValidDocument()||(Y=Y.add(ie))}))})).next((()=>g.localDocuments.getOverlayedDocuments(z,Q))).next((H=>{S=H;const ie=[];for(const ge of m){const Te=gA(ge,S.get(ge.key).overlayedDocument);Te!=null&&ie.push(new ki(ge.key,Te,j_(Te.value.mapValue),Nn.exists(!0)))}return g.mutationQueue.addMutationBatch(z,_,ie,m)})).next((H=>{V=H;const ie=H.applyToLocalDocumentSet(S,Y);return g.documentOverlayCache.saveOverlays(z,H.batchId,ie)}))})).then((()=>({batchId:V.batchId,changes:J_(S)})))})(s.localStore,e);s.sharedClientState.addPendingMutation(o.batchId),(function(h,m,g){let _=h.du[h.currentUser.toKey()];_||(_=new tt(Ce)),_=_.insert(m,g),h.du[h.currentUser.toKey()]=_})(s,o.batchId,t),await ll(s,o.changes),await Sc(s.remoteStore)}catch(o){const u=wf(o,"Failed to persist write");t.reject(u)}}async function Dv(r,e){const t=ve(r);try{const s=await pR(t.localStore,e);e.targetChanges.forEach(((o,u)=>{const h=t.Au.get(u);h&&(Ue(o.addedDocuments.size+o.modifiedDocuments.size+o.removedDocuments.size<=1,22616),o.addedDocuments.size>0?h.hu=!0:o.modifiedDocuments.size>0?Ue(h.hu,14607):o.removedDocuments.size>0&&(Ue(h.hu,42227),h.hu=!1))})),await ll(t,s,e)}catch(s){await Po(s)}}function hy(r,e,t){const s=ve(r);if(s.isPrimaryClient&&t===0||!s.isPrimaryClient&&t===1){const o=[];s.Tu.forEach(((u,h)=>{const m=h.view.va(e);m.snapshot&&o.push(m.snapshot)})),(function(h,m){const g=ve(h);g.onlineState=m;let _=!1;g.queries.forEach(((E,S)=>{for(const V of S.Sa)V.va(m)&&(_=!0)})),_&&Tf(g)})(s.eventManager,e),o.length&&s.Pu.H_(o),s.onlineState=e,s.isPrimaryClient&&s.sharedClientState.setOnlineState(e)}}async function oC(r,e,t){const s=ve(r);s.sharedClientState.updateQueryState(e,"rejected",t);const o=s.Au.get(e),u=o&&o.key;if(u){let h=new tt(ce.comparator);h=h.insert(u,Ut.newNoDocument(u,ye.min()));const m=Pe().add(u),g=new wc(ye.min(),new Map,new tt(Ce),h,m);await Dv(s,g),s.Ru=s.Ru.remove(u),s.Au.delete(e),Sf(s)}else await Ld(s.localStore,e,!1).then((()=>Fd(s,e,t))).catch(Po)}async function aC(r,e){const t=ve(r),s=e.batch.batchId;try{const o=await fR(t.localStore,e);Ov(t,s,null),Vv(t,s),t.sharedClientState.updateMutationState(s,"acknowledged"),await ll(t,o)}catch(o){await Po(o)}}async function lC(r,e,t){const s=ve(r);try{const o=await(function(h,m){const g=ve(h);return g.persistence.runTransaction("Reject batch","readwrite-primary",(_=>{let E;return g.mutationQueue.lookupMutationBatch(_,m).next((S=>(Ue(S!==null,37113),E=S.keys(),g.mutationQueue.removeMutationBatch(_,S)))).next((()=>g.mutationQueue.performConsistencyCheck(_))).next((()=>g.documentOverlayCache.removeOverlaysForBatchId(_,E,m))).next((()=>g.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(_,E))).next((()=>g.localDocuments.getDocuments(_,E)))}))})(s.localStore,e);Ov(s,e,t),Vv(s,e),s.sharedClientState.updateMutationState(e,"rejected",t),await ll(s,o)}catch(o){await Po(o)}}function Vv(r,e){(r.mu.get(e)||[]).forEach((t=>{t.resolve()})),r.mu.delete(e)}function Ov(r,e,t){const s=ve(r);let o=s.du[s.currentUser.toKey()];if(o){const u=o.get(e);u&&(t?u.reject(t):u.resolve(),o=o.remove(e)),s.du[s.currentUser.toKey()]=o}}function Fd(r,e,t=null){r.sharedClientState.removeLocalQueryTarget(e);for(const s of r.Eu.get(e))r.Tu.delete(s),t&&r.Pu.yu(s,t);r.Eu.delete(e),r.isPrimaryClient&&r.Vu.Gr(e).forEach((s=>{r.Vu.containsKey(s)||Lv(r,s)}))}function Lv(r,e){r.Iu.delete(e.path.canonicalString());const t=r.Ru.get(e);t!==null&&(gf(r.remoteStore,t),r.Ru=r.Ru.remove(e),r.Au.delete(t),Sf(r))}function dy(r,e,t){for(const s of t)s instanceof kv?(r.Vu.addReference(s.key,e),uC(r,s)):s instanceof Nv?(ne(If,"Document no longer in limbo: "+s.key),r.Vu.removeReference(s.key,e),r.Vu.containsKey(s.key)||Lv(r,s.key)):pe(19791,{wu:s})}function uC(r,e){const t=e.key,s=t.path.canonicalString();r.Ru.get(t)||r.Iu.has(s)||(ne(If,"New document in limbo: "+t),r.Iu.add(s),Sf(r))}function Sf(r){for(;r.Iu.size>0&&r.Ru.size<r.maxConcurrentLimboResolutions;){const e=r.Iu.values().next().value;r.Iu.delete(e);const t=new ce(Ke.fromString(e)),s=r.fu.next();r.Au.set(s,new XR(t)),r.Ru=r.Ru.insert(t,s),Iv(r.remoteStore,new pi(tr(of(t.path)),s,"TargetPurposeLimboResolution",pc.ce))}}async function ll(r,e,t){const s=ve(r),o=[],u=[],h=[];s.Tu.isEmpty()||(s.Tu.forEach(((m,g)=>{h.push(s.pu(g,e,t).then((_=>{var E;if((_||t)&&s.isPrimaryClient){const S=_?!_.fromCache:(E=t==null?void 0:t.targetChanges.get(g.targetId))==null?void 0:E.current;s.sharedClientState.updateQueryState(g.targetId,S?"current":"not-current")}if(_){o.push(_);const S=pf.Is(g.targetId,_);u.push(S)}})))})),await Promise.all(h),s.Pu.H_(o),await(async function(g,_){const E=ve(g);try{await E.persistence.runTransaction("notifyLocalViewChanges","readwrite",(S=>$.forEach(_,(V=>$.forEach(V.Ts,(z=>E.persistence.referenceDelegate.addReference(S,V.targetId,z))).next((()=>$.forEach(V.Es,(z=>E.persistence.referenceDelegate.removeReference(S,V.targetId,z)))))))))}catch(S){if(!ko(S))throw S;ne(mf,"Failed to update sequence numbers: "+S)}for(const S of _){const V=S.targetId;if(!S.fromCache){const z=E.vs.get(V),Q=z.snapshotVersion,Y=z.withLastLimboFreeSnapshotVersion(Q);E.vs=E.vs.insert(V,Y)}}})(s.localStore,u))}async function cC(r,e){const t=ve(r);if(!t.currentUser.isEqual(e)){ne(If,"User change. New user:",e.toKey());const s=await vv(t.localStore,e);t.currentUser=e,(function(u,h){u.mu.forEach((m=>{m.forEach((g=>{g.reject(new re(B.CANCELLED,h))}))})),u.mu.clear()})(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,s.removedBatchIds,s.addedBatchIds),await ll(t,s.Ns)}}function hC(r,e){const t=ve(r),s=t.Au.get(e);if(s&&s.hu)return Pe().add(s.key);{let o=Pe();const u=t.Eu.get(e);if(!u)return o;for(const h of u){const m=t.Tu.get(h);o=o.unionWith(m.view.nu)}return o}}function Mv(r){const e=ve(r);return e.remoteStore.remoteSyncer.applyRemoteEvent=Dv.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=hC.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=oC.bind(null,e),e.Pu.H_=KR.bind(null,e.eventManager),e.Pu.yu=GR.bind(null,e.eventManager),e}function dC(r){const e=ve(r);return e.remoteStore.remoteSyncer.applySuccessfulWrite=aC.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=lC.bind(null,e),e}class oc{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(e){this.serializer=Tc(e.databaseInfo.databaseId),this.sharedClientState=this.Du(e),this.persistence=this.Cu(e),await this.persistence.start(),this.localStore=this.vu(e),this.gcScheduler=this.Fu(e,this.localStore),this.indexBackfillerScheduler=this.Mu(e,this.localStore)}Fu(e,t){return null}Mu(e,t){return null}vu(e){return dR(this.persistence,new uR,e.initialUser,this.serializer)}Cu(e){return new _v(ff.Vi,this.serializer)}Du(e){return new vR}async terminate(){var e,t;(e=this.gcScheduler)==null||e.stop(),(t=this.indexBackfillerScheduler)==null||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}oc.provider={build:()=>new oc};class fC extends oc{constructor(e){super(),this.cacheSizeBytes=e}Fu(e,t){Ue(this.persistence.referenceDelegate instanceof ic,46915);const s=this.persistence.referenceDelegate.garbageCollector;return new GA(s,e.asyncQueue,t)}Cu(e){const t=this.cacheSizeBytes!==void 0?Yt.withCacheSize(this.cacheSizeBytes):Yt.DEFAULT;return new _v((s=>ic.Vi(s,t)),this.serializer)}}class Ud{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=s=>hy(this.syncEngine,s,1),this.remoteStore.remoteSyncer.handleCredentialChange=cC.bind(null,this.syncEngine),await BR(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return(function(){return new HR})()}createDatastore(e){const t=Tc(e.databaseInfo.databaseId),s=SR(e.databaseInfo);return kR(e.authCredentials,e.appCheckCredentials,s,t)}createRemoteStore(e){return(function(s,o,u,h,m){return new xR(s,o,u,h,m)})(this.localStore,this.datastore,e.asyncQueue,(t=>hy(this.syncEngine,t,0)),(function(){return sy.v()?new sy:new ER})())}createSyncEngine(e,t){return(function(o,u,h,m,g,_,E){const S=new ZR(o,u,h,m,g,_);return E&&(S.gu=!0),S})(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e,t;await(async function(o){const u=ve(o);ne(fs,"RemoteStore shutting down."),u.Ia.add(5),await al(u),u.Aa.shutdown(),u.Va.set("Unknown")})(this.remoteStore),(e=this.datastore)==null||e.terminate(),(t=this.eventManager)==null||t.terminate()}}Ud.provider={build:()=>new Ud};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pC{constructor(e){this.observer=e,this.muted=!1}next(e){this.muted||this.observer.next&&this.Ou(this.observer.next,e)}error(e){this.muted||(this.observer.error?this.Ou(this.observer.error,e):Pr("Uncaught Error in snapshot listener:",e.toString()))}Nu(){this.muted=!0}Ou(e,t){setTimeout((()=>{this.muted||e(t)}),0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ri="FirestoreClient";class mC{constructor(e,t,s,o,u){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=s,this._databaseInfo=o,this.user=Ft.UNAUTHENTICATED,this.clientId=Zd.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=u,this.authCredentials.start(s,(async h=>{ne(Ri,"Received user=",h.uid),await this.authCredentialListener(h),this.user=h})),this.appCheckCredentials.start(s,(h=>(ne(Ri,"Received new app check token=",h),this.appCheckCredentialListener(h,this.user))))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this._databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}terminate(){this.asyncQueue.enterRestrictedMode();const e=new ss;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted((async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const s=wf(t,"Failed to shutdown persistence");e.reject(s)}})),e.promise}}async function pd(r,e){r.asyncQueue.verifyOperationInProgress(),ne(Ri,"Initializing OfflineComponentProvider");const t=r.configuration;await e.initialize(t);let s=t.initialUser;r.setCredentialChangeListener((async o=>{s.isEqual(o)||(await vv(e.localStore,o),s=o)})),e.persistence.setDatabaseDeletedListener((()=>r.terminate())),r._offlineComponents=e}async function fy(r,e){r.asyncQueue.verifyOperationInProgress();const t=await gC(r);ne(Ri,"Initializing OnlineComponentProvider"),await e.initialize(t,r.configuration),r.setCredentialChangeListener((s=>ay(e.remoteStore,s))),r.setAppCheckTokenChangeListener(((s,o)=>ay(e.remoteStore,o))),r._onlineComponents=e}async function gC(r){if(!r._offlineComponents)if(r._uninitializedComponentsProvider){ne(Ri,"Using user provided OfflineComponentProvider");try{await pd(r,r._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!(function(o){return o.name==="FirebaseError"?o.code===B.FAILED_PRECONDITION||o.code===B.UNIMPLEMENTED:!(typeof DOMException<"u"&&o instanceof DOMException)||o.code===22||o.code===20||o.code===11})(t))throw t;ds("Error using user provided cache. Falling back to memory cache: "+t),await pd(r,new oc)}}else ne(Ri,"Using default OfflineComponentProvider"),await pd(r,new fC(void 0));return r._offlineComponents}async function bv(r){return r._onlineComponents||(r._uninitializedComponentsProvider?(ne(Ri,"Using user provided OnlineComponentProvider"),await fy(r,r._uninitializedComponentsProvider._online)):(ne(Ri,"Using default OnlineComponentProvider"),await fy(r,new Ud))),r._onlineComponents}function yC(r){return bv(r).then((e=>e.syncEngine))}async function py(r){const e=await bv(r),t=e.eventManager;return t.onListen=eC.bind(null,e.syncEngine),t.onUnlisten=rC.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=tC.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=iC.bind(null,e.syncEngine),t}function _C(r,e,t,s){const o=new pC(s),u=new QR(e,o,t);return r.asyncQueue.enqueueAndForget((async()=>qR(await py(r),u))),()=>{o.Nu(),r.asyncQueue.enqueueAndForget((async()=>WR(await py(r),u)))}}function vC(r,e){const t=new ss;return r.asyncQueue.enqueueAndForget((async()=>sC(await yC(r),e,t))),t.promise}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Fv(r){const e={};return r.timeoutSeconds!==void 0&&(e.timeoutSeconds=r.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const EC="ComponentProvider",my=new Map;function wC(r,e,t,s,o){return new FS(r,e,t,o.host,o.ssl,o.experimentalForceLongPolling,o.experimentalAutoDetectLongPolling,Fv(o.experimentalLongPollingOptions),o.useFetchStreams,o.isUsingEmulator,s)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Uv="firestore.googleapis.com",gy=!0;class yy{constructor(e){if(e.host===void 0){if(e.ssl!==void 0)throw new re(B.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=Uv,this.ssl=gy}else this.host=e.host,this.ssl=e.ssl??gy;if(this.isUsingEmulator=e.emulatorOptions!==void 0,this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=yv;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<WA)throw new re(B.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}CS("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=Fv(e.experimentalLongPollingOptions??{}),(function(s){if(s.timeoutSeconds!==void 0){if(isNaN(s.timeoutSeconds))throw new re(B.INVALID_ARGUMENT,`invalid long polling timeout: ${s.timeoutSeconds} (must not be NaN)`);if(s.timeoutSeconds<5)throw new re(B.INVALID_ARGUMENT,`invalid long polling timeout: ${s.timeoutSeconds} (minimum allowed value is 5)`);if(s.timeoutSeconds>30)throw new re(B.INVALID_ARGUMENT,`invalid long polling timeout: ${s.timeoutSeconds} (maximum allowed value is 30)`)}})(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&(function(s,o){return s.timeoutSeconds===o.timeoutSeconds})(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class Ac{constructor(e,t,s,o){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=s,this._app=o,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new yy({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new re(B.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new re(B.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new yy(e),this._emulatorOptions=e.emulatorOptions||{},e.credentials!==void 0&&(this._authCredentials=(function(s){if(!s)return new yS;switch(s.type){case"firstParty":return new wS(s.sessionIndex||"0",s.iamToken||null,s.authTokenFactory||null);case"provider":return s.client;default:throw new re(B.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}})(e.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return(function(t){const s=my.get(t);s&&(ne(EC,"Removing Datastore"),my.delete(t),s.terminate())})(this),Promise.resolve()}}function TC(r,e,t,s={}){var _;r=vi(r,Ac);const o=Xa(e),u=r._getSettings(),h={...u,emulatorOptions:r._getEmulatorOptions()},m=`${e}:${t}`;o&&Oy(`https://${m}`),u.host!==Uv&&u.host!==m&&ds("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const g={...u,host:m,ssl:o,emulatorOptions:s};if(!as(g,h)&&(r._setSettings(g),s.mockUserToken)){let E,S;if(typeof s.mockUserToken=="string")E=s.mockUserToken,S=Ft.MOCK_USER;else{E=Aw(s.mockUserToken,(_=r._app)==null?void 0:_.options.projectId);const V=s.mockUserToken.sub||s.mockUserToken.user_id;if(!V)throw new re(B.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");S=new Ft(V)}r._authCredentials=new _S(new P_(E,S))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xo{constructor(e,t,s){this.converter=t,this._query=s,this.type="query",this.firestore=e}withConverter(e){return new xo(this.firestore,e,this._query)}}class mt{constructor(e,t,s){this.converter=t,this._key=s,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new Ei(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new mt(this.firestore,e,this._key)}toJSON(){return{type:mt._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(e,t,s){if(rl(t,mt._jsonSchema))return new mt(e,s||null,new ce(Ke.fromString(t.referencePath)))}}mt._jsonSchemaVersion="firestore/documentReference/1.0",mt._jsonSchema={type:pt("string",mt._jsonSchemaVersion),referencePath:pt("string")};class Ei extends xo{constructor(e,t,s){super(e,t,of(s)),this._path=s,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new mt(this.firestore,null,new ce(e))}withConverter(e){return new Ei(this.firestore,e,this._path)}}function jv(r,e,...t){if(r=Et(r),k_("collection","path",e),r instanceof Ac){const s=Ke.fromString(e,...t);return kg(s),new Ei(r,null,s)}{if(!(r instanceof mt||r instanceof Ei))throw new re(B.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=r._path.child(Ke.fromString(e,...t));return kg(s),new Ei(r.firestore,null,s)}}function ac(r,e,...t){if(r=Et(r),arguments.length===1&&(e=Zd.newId()),k_("doc","path",e),r instanceof Ac){const s=Ke.fromString(e,...t);return Pg(s),new mt(r,null,new ce(s))}{if(!(r instanceof mt||r instanceof Ei))throw new re(B.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=r._path.child(Ke.fromString(e,...t));return Pg(s),new mt(r.firestore,r instanceof Ei?r.converter:null,new ce(s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _y="AsyncQueue";class vy{constructor(e=Promise.resolve()){this.Yu=[],this.ec=!1,this.tc=[],this.nc=null,this.rc=!1,this.sc=!1,this.oc=[],this.M_=new wv(this,"async_queue_retry"),this._c=()=>{const s=fd();s&&ne(_y,"Visibility state changed to "+s.visibilityState),this.M_.w_()},this.ac=e;const t=fd();t&&typeof t.addEventListener=="function"&&t.addEventListener("visibilitychange",this._c)}get isShuttingDown(){return this.ec}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.uc(),this.cc(e)}enterRestrictedMode(e){if(!this.ec){this.ec=!0,this.sc=e||!1;const t=fd();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this._c)}}enqueue(e){if(this.uc(),this.ec)return new Promise((()=>{}));const t=new ss;return this.cc((()=>this.ec&&this.sc?Promise.resolve():(e().then(t.resolve,t.reject),t.promise))).then((()=>t.promise))}enqueueRetryable(e){this.enqueueAndForget((()=>(this.Yu.push(e),this.lc())))}async lc(){if(this.Yu.length!==0){try{await this.Yu[0](),this.Yu.shift(),this.M_.reset()}catch(e){if(!ko(e))throw e;ne(_y,"Operation failed with retryable error: "+e)}this.Yu.length>0&&this.M_.p_((()=>this.lc()))}}cc(e){const t=this.ac.then((()=>(this.rc=!0,e().catch((s=>{throw this.nc=s,this.rc=!1,Pr("INTERNAL UNHANDLED ERROR: ",Ey(s)),s})).then((s=>(this.rc=!1,s))))));return this.ac=t,t}enqueueAfterDelay(e,t,s){this.uc(),this.oc.indexOf(e)>-1&&(t=0);const o=Ef.createAndSchedule(this,e,t,s,(u=>this.hc(u)));return this.tc.push(o),o}uc(){this.nc&&pe(47125,{Pc:Ey(this.nc)})}verifyOperationInProgress(){}async Tc(){let e;do e=this.ac,await e;while(e!==this.ac)}Ec(e){for(const t of this.tc)if(t.timerId===e)return!0;return!1}Ic(e){return this.Tc().then((()=>{this.tc.sort(((t,s)=>t.targetTimeMs-s.targetTimeMs));for(const t of this.tc)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.Tc()}))}Rc(e){this.oc.push(e)}hc(e){const t=this.tc.indexOf(e);this.tc.splice(t,1)}}function Ey(r){let e=r.message||"";return r.stack&&(e=r.stack.includes(r.message)?r.stack:r.message+`
`+r.stack),e}class Io extends Ac{constructor(e,t,s,o){super(e,t,s,o),this.type="firestore",this._queue=new vy,this._persistenceKey=(o==null?void 0:o.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new vy(e),this._firestoreClient=void 0,await e}}}function IC(r,e){const t=typeof r=="object"?r:Fy(),s=typeof r=="string"?r:Xu,o=$d(t,"firestore").getImmediate({identifier:s});if(!o._initialized){const u=Iw("firestore");u&&TC(o,...u)}return o}function zv(r){if(r._terminated)throw new re(B.FAILED_PRECONDITION,"The client has already been terminated.");return r._firestoreClient||SC(r),r._firestoreClient}function SC(r){var s,o,u,h;const e=r._freezeSettings(),t=wC(r._databaseId,((s=r._app)==null?void 0:s.options.appId)||"",r._persistenceKey,(o=r._app)==null?void 0:o.options.apiKey,e);r._componentsProvider||(u=e.localCache)!=null&&u._offlineComponentProvider&&((h=e.localCache)!=null&&h._onlineComponentProvider)&&(r._componentsProvider={_offline:e.localCache._offlineComponentProvider,_online:e.localCache._onlineComponentProvider}),r._firestoreClient=new mC(r._authCredentials,r._appCheckCredentials,r._queue,t,r._componentsProvider&&(function(g){const _=g==null?void 0:g._online.build();return{_offline:g==null?void 0:g._offline.build(_),_online:_}})(r._componentsProvider))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _n{constructor(e){this._byteString=e}static fromBase64String(e){try{return new _n(xt.fromBase64String(e))}catch(t){throw new re(B.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new _n(xt.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}toJSON(){return{type:_n._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(e){if(rl(e,_n._jsonSchema))return _n.fromBase64String(e.bytes)}}_n._jsonSchemaVersion="firestore/bytes/1.0",_n._jsonSchema={type:pt("string",_n._jsonSchemaVersion),bytes:pt("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Af{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new re(B.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new Nt(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rc{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rr{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new re(B.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new re(B.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}_compareTo(e){return Ce(this._lat,e._lat)||Ce(this._long,e._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:rr._jsonSchemaVersion}}static fromJSON(e){if(rl(e,rr._jsonSchema))return new rr(e.latitude,e.longitude)}}rr._jsonSchemaVersion="firestore/geoPoint/1.0",rr._jsonSchema={type:pt("string",rr._jsonSchemaVersion),latitude:pt("number"),longitude:pt("number")};/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xn{constructor(e){this._values=(e||[]).map((t=>t))}toArray(){return this._values.map((e=>e))}isEqual(e){return(function(s,o){if(s.length!==o.length)return!1;for(let u=0;u<s.length;++u)if(s[u]!==o[u])return!1;return!0})(this._values,e._values)}toJSON(){return{type:xn._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(e){if(rl(e,xn._jsonSchema)){if(Array.isArray(e.vectorValues)&&e.vectorValues.every((t=>typeof t=="number")))return new xn(e.vectorValues);throw new re(B.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}xn._jsonSchemaVersion="firestore/vectorValue/1.0",xn._jsonSchema={type:pt("string",xn._jsonSchemaVersion),vectorValues:pt("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const AC=/^__.*__$/;class RC{constructor(e,t,s){this.data=e,this.fieldMask=t,this.fieldTransforms=s}toMutation(e,t){return this.fieldMask!==null?new ki(e,this.data,this.fieldMask,t,this.fieldTransforms):new sl(e,this.data,t,this.fieldTransforms)}}class Bv{constructor(e,t,s){this.data=e,this.fieldMask=t,this.fieldTransforms=s}toMutation(e,t){return new ki(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function $v(r){switch(r){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw pe(40011,{dataSource:r})}}class Rf{constructor(e,t,s,o,u,h){this.settings=e,this.databaseId=t,this.serializer=s,this.ignoreUndefinedProperties=o,u===void 0&&this.Ac(),this.fieldTransforms=u||[],this.fieldMask=h||[]}get path(){return this.settings.path}get dataSource(){return this.settings.dataSource}i(e){return new Rf({...this.settings,...e},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}dc(e){var o;const t=(o=this.path)==null?void 0:o.child(e),s=this.i({path:t,arrayElement:!1});return s.mc(e),s}fc(e){var o;const t=(o=this.path)==null?void 0:o.child(e),s=this.i({path:t,arrayElement:!1});return s.Ac(),s}gc(e){return this.i({path:void 0,arrayElement:!0})}yc(e){return lc(e,this.settings.methodName,this.settings.hasConverter||!1,this.path,this.settings.targetDoc)}contains(e){return this.fieldMask.find((t=>e.isPrefixOf(t)))!==void 0||this.fieldTransforms.find((t=>e.isPrefixOf(t.field)))!==void 0}Ac(){if(this.path)for(let e=0;e<this.path.length;e++)this.mc(this.path.get(e))}mc(e){if(e.length===0)throw this.yc("Document fields must not be empty");if($v(this.dataSource)&&AC.test(e))throw this.yc('Document fields cannot begin and end with "__"')}}class CC{constructor(e,t,s){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=s||Tc(e)}A(e,t,s,o=!1){return new Rf({dataSource:e,methodName:t,targetDoc:s,path:Nt.emptyPath(),arrayElement:!1,hasConverter:o},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Cf(r){const e=r._freezeSettings(),t=Tc(r._databaseId);return new CC(r._databaseId,!!e.ignoreUndefinedProperties,t)}function PC(r,e,t,s,o,u={}){const h=r.A(u.merge||u.mergeFields?2:0,e,t,o);kf("Data must be an object, but it was:",h,s);const m=Hv(s,h);let g,_;if(u.merge)g=new ln(h.fieldMask),_=h.fieldTransforms;else if(u.mergeFields){const E=[];for(const S of u.mergeFields){const V=So(e,S,t);if(!h.contains(V))throw new re(B.INVALID_ARGUMENT,`Field '${V}' is specified in your field mask but missing from your input data.`);Kv(E,V)||E.push(V)}g=new ln(E),_=h.fieldTransforms.filter((S=>g.covers(S.field)))}else g=null,_=h.fieldTransforms;return new RC(new Jt(m),g,_)}class Cc extends Rc{_toFieldTransform(e){if(e.dataSource!==2)throw e.dataSource===1?e.yc(`${this._methodName}() can only appear at the top level of your update data`):e.yc(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof Cc}}class Pf extends Rc{_toFieldTransform(e){return new dA(e.path,new Ka)}isEqual(e){return e instanceof Pf}}function kC(r,e,t,s){const o=r.A(1,e,t);kf("Data must be an object, but it was:",o,s);const u=[],h=Jt.empty();Pi(s,((g,_)=>{const E=Wv(e,g,t);_=Et(_);const S=o.fc(E);if(_ instanceof Cc)u.push(E);else{const V=ul(_,S);V!=null&&(u.push(E),h.set(E,V))}}));const m=new ln(u);return new Bv(h,m,o.fieldTransforms)}function NC(r,e,t,s,o,u){const h=r.A(1,e,t),m=[So(e,s,t)],g=[o];if(u.length%2!=0)throw new re(B.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let V=0;V<u.length;V+=2)m.push(So(e,u[V])),g.push(u[V+1]);const _=[],E=Jt.empty();for(let V=m.length-1;V>=0;--V)if(!Kv(_,m[V])){const z=m[V];let Q=g[V];Q=Et(Q);const Y=h.fc(z);if(Q instanceof Cc)_.push(z);else{const H=ul(Q,Y);H!=null&&(_.push(z),E.set(z,H))}}const S=new ln(_);return new Bv(E,S,h.fieldTransforms)}function xC(r,e,t,s=!1){return ul(t,r.A(s?4:3,e))}function ul(r,e){if(qv(r=Et(r)))return kf("Unsupported field value:",e,r),Hv(r,e);if(r instanceof Rc)return(function(s,o){if(!$v(o.dataSource))throw o.yc(`${s._methodName}() can only be used with update() and set()`);if(!o.path)throw o.yc(`${s._methodName}() is not currently supported inside arrays`);const u=s._toFieldTransform(o);u&&o.fieldTransforms.push(u)})(r,e),null;if(r===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),r instanceof Array){if(e.settings.arrayElement&&e.dataSource!==4)throw e.yc("Nested arrays are not supported");return(function(s,o){const u=[];let h=0;for(const m of s){let g=ul(m,o.gc(h));g==null&&(g={nullValue:"NULL_VALUE"}),u.push(g),h++}return{arrayValue:{values:u}}})(r,e)}return(function(s,o){if((s=Et(s))===null)return{nullValue:"NULL_VALUE"};if(typeof s=="number")return uA(o.serializer,s);if(typeof s=="boolean")return{booleanValue:s};if(typeof s=="string")return{stringValue:s};if(s instanceof Date){const u=Je.fromDate(s);return{timestampValue:rc(o.serializer,u)}}if(s instanceof Je){const u=new Je(s.seconds,1e3*Math.floor(s.nanoseconds/1e3));return{timestampValue:rc(o.serializer,u)}}if(s instanceof rr)return{geoPointValue:{latitude:s.latitude,longitude:s.longitude}};if(s instanceof _n)return{bytesValue:uv(o.serializer,s._byteString)};if(s instanceof mt){const u=o.databaseId,h=s.firestore._databaseId;if(!h.isEqual(u))throw o.yc(`Document reference is for database ${h.projectId}/${h.database} but should be for database ${u.projectId}/${u.database}`);return{referenceValue:hf(s.firestore._databaseId||o.databaseId,s._key.path)}}if(s instanceof xn)return(function(h,m){const g=h instanceof xn?h.toArray():h;return{mapValue:{fields:{[F_]:{stringValue:U_},[Zu]:{arrayValue:{values:g.map((E=>{if(typeof E!="number")throw m.yc("VectorValues must only contain numeric values.");return af(m.serializer,E)}))}}}}}})(s,o);if(gv(s))return s._toProto(o.serializer);throw o.yc(`Unsupported field value: ${fc(s)}`)})(r,e)}function Hv(r,e){const t={};return D_(r)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):Pi(r,((s,o)=>{const u=ul(o,e.dc(s));u!=null&&(t[s]=u)})),{mapValue:{fields:t}}}function qv(r){return!(typeof r!="object"||r===null||r instanceof Array||r instanceof Date||r instanceof Je||r instanceof rr||r instanceof _n||r instanceof mt||r instanceof Rc||r instanceof xn||gv(r))}function kf(r,e,t){if(!qv(t)||!N_(t)){const s=fc(t);throw s==="an object"?e.yc(r+" a custom object"):e.yc(r+" "+s)}}function So(r,e,t){if((e=Et(e))instanceof Af)return e._internalPath;if(typeof e=="string")return Wv(r,e);throw lc("Field path arguments must be of type string or ",r,!1,void 0,t)}const DC=new RegExp("[~\\*/\\[\\]]");function Wv(r,e,t){if(e.search(DC)>=0)throw lc(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,r,!1,void 0,t);try{return new Af(...e.split("."))._internalPath}catch{throw lc(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,r,!1,void 0,t)}}function lc(r,e,t,s,o){const u=s&&!s.isEmpty(),h=o!==void 0;let m=`Function ${e}() called with invalid data`;t&&(m+=" (via `toFirestore()`)"),m+=". ";let g="";return(u||h)&&(g+=" (found",u&&(g+=` in field ${s}`),h&&(g+=` in document ${o}`),g+=")"),new re(B.INVALID_ARGUMENT,m+r+g)}function Kv(r,e){return r.some((t=>t.isEqual(e)))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class VC{convertValue(e,t="none"){switch(Si(e)){case 0:return null;case 1:return e.booleanValue;case 2:return at(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(Ii(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 11:return this.convertObject(e.mapValue,t);case 10:return this.convertVectorValue(e.mapValue);default:throw pe(62114,{value:e})}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const s={};return Pi(e,((o,u)=>{s[o]=this.convertValue(u,t)})),s}convertVectorValue(e){var s,o,u;const t=(u=(o=(s=e.fields)==null?void 0:s[Zu].arrayValue)==null?void 0:o.values)==null?void 0:u.map((h=>at(h.doubleValue)));return new xn(t)}convertGeoPoint(e){return new rr(at(e.latitude),at(e.longitude))}convertArray(e,t){return(e.values||[]).map((s=>this.convertValue(s,t)))}convertServerTimestamp(e,t){switch(t){case"previous":const s=gc(e);return s==null?null:this.convertValue(s,t);case"estimate":return this.convertTimestamp(Ha(e));default:return null}}convertTimestamp(e){const t=Ti(e);return new Je(t.seconds,t.nanos)}convertDocumentKey(e,t){const s=Ke.fromString(e);Ue(mv(s),9688,{name:e});const o=new qa(s.get(1),s.get(3)),u=new ce(s.popFirst(5));return o.isEqual(t)||Pr(`Document ${u} contains a document reference within a different database (${o.projectId}/${o.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),u}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gv extends VC{constructor(e){super(),this.firestore=e}convertBytes(e){return new _n(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new mt(this.firestore,null,t)}}function OC(){return new Pf("serverTimestamp")}const wy="@firebase/firestore",Ty="4.13.0";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Iy(r){return(function(t,s){if(typeof t!="object"||t===null)return!1;const o=t;for(const u of s)if(u in o&&typeof o[u]=="function")return!0;return!1})(r,["next","error","complete"])}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qv{constructor(e,t,s,o,u){this._firestore=e,this._userDataWriter=t,this._key=s,this._document=o,this._converter=u}get id(){return this._key.path.lastSegment()}get ref(){return new mt(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new LC(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){var e;return((e=this._document)==null?void 0:e.data.clone().value.mapValue.fields)??void 0}get(e){if(this._document){const t=this._document.data.field(So("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}}class LC extends Qv{data(){return super.data()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function MC(r){if(r.limitType==="L"&&r.explicitOrderBy.length===0)throw new re(B.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class Nf{}class bC extends Nf{}function FC(r,e,...t){let s=[];e instanceof Nf&&s.push(e),s=s.concat(t),(function(u){const h=u.filter((g=>g instanceof xf)).length,m=u.filter((g=>g instanceof Pc)).length;if(h>1||h>0&&m>0)throw new re(B.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")})(s);for(const o of s)r=o._apply(r);return r}class Pc extends bC{constructor(e,t,s){super(),this._field=e,this._op=t,this._value=s,this.type="where"}static _create(e,t,s){return new Pc(e,t,s)}_apply(e){const t=this._parse(e);return Yv(e._query,t),new xo(e.firestore,e.converter,kd(e._query,t))}_parse(e){const t=Cf(e.firestore);return(function(u,h,m,g,_,E,S){let V;if(_.isKeyField()){if(E==="array-contains"||E==="array-contains-any")throw new re(B.INVALID_ARGUMENT,`Invalid Query. You can't perform '${E}' queries on documentId().`);if(E==="in"||E==="not-in"){Ay(S,E);const Q=[];for(const Y of S)Q.push(Sy(g,u,Y));V={arrayValue:{values:Q}}}else V=Sy(g,u,S)}else E!=="in"&&E!=="not-in"&&E!=="array-contains-any"||Ay(S,E),V=xC(m,h,S,E==="in"||E==="not-in");return ft.create(_,E,V)})(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}function UC(r,e,t){const s=e,o=So("where",r);return Pc._create(o,s,t)}class xf extends Nf{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new xf(e,t)}_parse(e){const t=this._queryConstraints.map((s=>s._parse(e))).filter((s=>s.getFilters().length>0));return t.length===1?t[0]:Vn.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:((function(o,u){let h=o;const m=u.getFlattenedFilters();for(const g of m)Yv(h,g),h=kd(h,g)})(e._query,t),new xo(e.firestore,e.converter,kd(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}function Sy(r,e,t){if(typeof(t=Et(t))=="string"){if(t==="")throw new re(B.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!K_(e)&&t.indexOf("/")!==-1)throw new re(B.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const s=e.path.child(Ke.fromString(t));if(!ce.isDocumentKey(s))throw new re(B.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${s}' is not because it has an odd number of segments (${s.length}).`);return bg(r,new ce(s))}if(t instanceof mt)return bg(r,t._key);throw new re(B.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${fc(t)}.`)}function Ay(r,e){if(!Array.isArray(r)||r.length===0)throw new re(B.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function Yv(r,e){const t=(function(o,u){for(const h of o)for(const m of h.getFlattenedFilters())if(u.indexOf(m.op)>=0)return m.op;return null})(r.filters,(function(o){switch(o){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}})(e.op));if(t!==null)throw t===e.op?new re(B.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new re(B.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}function jC(r,e,t){let s;return s=r?r.toFirestore(e):e,s}class Va{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class os extends Qv{constructor(e,t,s,o,u,h){super(e,t,s,o,h),this._firestore=e,this._firestoreImpl=e,this.metadata=u}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new zu(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const s=this._document.data.field(So("DocumentSnapshot.get",e));if(s!==null)return this._userDataWriter.convertValue(s,t.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new re(B.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e=this._document,t={};return t.type=os._jsonSchemaVersion,t.bundle="",t.bundleSource="DocumentSnapshot",t.bundleName=this._key.toString(),!e||!e.isValidDocument()||!e.isFoundDocument()?t:(this._userDataWriter.convertObjectMap(e.data.value.mapValue.fields,"previous"),t.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),t)}}os._jsonSchemaVersion="firestore/documentSnapshot/1.0",os._jsonSchema={type:pt("string",os._jsonSchemaVersion),bundleSource:pt("string","DocumentSnapshot"),bundleName:pt("string"),bundle:pt("string")};class zu extends os{data(e={}){return super.data(e)}}class mo{constructor(e,t,s,o){this._firestore=e,this._userDataWriter=t,this._snapshot=o,this.metadata=new Va(o.hasPendingWrites,o.fromCache),this.query=s}get docs(){const e=[];return this.forEach((t=>e.push(t))),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach((s=>{e.call(t,new zu(this._firestore,this._userDataWriter,s.key,s,new Va(this._snapshot.mutatedKeys.has(s.key),this._snapshot.fromCache),this.query.converter))}))}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new re(B.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=(function(o,u){if(o._snapshot.oldDocs.isEmpty()){let h=0;return o._snapshot.docChanges.map((m=>{const g=new zu(o._firestore,o._userDataWriter,m.doc.key,m.doc,new Va(o._snapshot.mutatedKeys.has(m.doc.key),o._snapshot.fromCache),o.query.converter);return m.doc,{type:"added",doc:g,oldIndex:-1,newIndex:h++}}))}{let h=o._snapshot.oldDocs;return o._snapshot.docChanges.filter((m=>u||m.type!==3)).map((m=>{const g=new zu(o._firestore,o._userDataWriter,m.doc.key,m.doc,new Va(o._snapshot.mutatedKeys.has(m.doc.key),o._snapshot.fromCache),o.query.converter);let _=-1,E=-1;return m.type!==0&&(_=h.indexOf(m.doc.key),h=h.delete(m.doc.key)),m.type!==1&&(h=h.add(m.doc),E=h.indexOf(m.doc.key)),{type:zC(m.type),doc:g,oldIndex:_,newIndex:E}}))}})(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new re(B.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e={};e.type=mo._jsonSchemaVersion,e.bundleSource="QuerySnapshot",e.bundleName=Zd.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const t=[],s=[],o=[];return this.docs.forEach((u=>{u._document!==null&&(t.push(u._document),s.push(this._userDataWriter.convertObjectMap(u._document.data.value.mapValue.fields,"previous")),o.push(u.ref.path))})),e.bundle=(this._firestore,this.query._query,e.bundleName,"NOT SUPPORTED"),e}}function zC(r){switch(r){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return pe(61501,{type:r})}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */mo._jsonSchemaVersion="firestore/querySnapshot/1.0",mo._jsonSchema={type:pt("string",mo._jsonSchemaVersion),bundleSource:pt("string","QuerySnapshot"),bundleName:pt("string"),bundle:pt("string")};function Jv(r,e,t,...s){r=vi(r,mt);const o=vi(r.firestore,Io),u=Cf(o);let h;return h=typeof(e=Et(e))=="string"||e instanceof Af?NC(u,"updateDoc",r._key,e,t,s):kC(u,"updateDoc",r._key,e),Df(o,[h.toMutation(r._key,Nn.exists(!0))])}function BC(r){return Df(vi(r.firestore,Io),[new lf(r._key,Nn.none())])}function $C(r,e){const t=vi(r.firestore,Io),s=ac(r),o=jC(r.converter,e),u=Cf(r.firestore);return Df(t,[PC(u,"addDoc",s._key,o,r.converter!==null,{}).toMutation(s._key,Nn.exists(!1))]).then((()=>s))}function HC(r,...e){var _,E,S;r=Et(r);let t={includeMetadataChanges:!1,source:"default"},s=0;typeof e[s]!="object"||Iy(e[s])||(t=e[s++]);const o={includeMetadataChanges:t.includeMetadataChanges,source:t.source};if(Iy(e[s])){const V=e[s];e[s]=(_=V.next)==null?void 0:_.bind(V),e[s+1]=(E=V.error)==null?void 0:E.bind(V),e[s+2]=(S=V.complete)==null?void 0:S.bind(V)}let u,h,m;if(r instanceof mt)h=vi(r.firestore,Io),m=of(r._key.path),u={next:V=>{e[s]&&e[s](qC(h,r,V))},error:e[s+1],complete:e[s+2]};else{const V=vi(r,xo);h=vi(V.firestore,Io),m=V._query;const z=new Gv(h);u={next:Q=>{e[s]&&e[s](new mo(h,z,V,Q))},error:e[s+1],complete:e[s+2]},MC(r._query)}const g=zv(h);return _C(g,m,o,u)}function Df(r,e){const t=zv(r);return vC(t,e)}function qC(r,e,t){const s=t.docs.get(e._key),o=new Gv(r);return new os(r,o,e._key,s,new Va(t.hasPendingWrites,t.fromCache),e.converter)}(function(e,t=!0){gS(Ao),yo(new ls("firestore",((s,{instanceIdentifier:o,options:u})=>{const h=s.getProvider("app").getImmediate(),m=new Io(new vS(s.getProvider("auth-internal")),new TS(h,s.getProvider("app-check-internal")),US(h,o),h);return u={useFetchStreams:t,...u},m._setSettings(u),m}),"PUBLIC").setMultipleInstances(!0)),yi(wy,Ty,e),yi(wy,Ty,"esm2020")})();const WC={apiKey:"AIzaSyCjC2FETl-H_Cq07Ql8Cx2h8KYOh9T-GjM",authDomain:"landvms.firebaseapp.com",projectId:"landvms",storageBucket:"landvms.firebasestorage.app",messagingSenderId:"750813754088",appId:"1:750813754088:web:016b3f063f9a5d98df8f5d",measurementId:"G-PHR8DJEBFG"},Xv=by(WC),go=pS(Xv),Ua=IC(Xv);function KC(){const[r,e]=ze.useState(null),[t,s]=ze.useState(!1),[o,u]=ze.useState(!1),[h,m]=ze.useState(!1);return ze.useEffect(()=>{if(window.matchMedia("(display-mode: standalone)").matches||window.navigator.standalone===!0){m(!0);return}localStorage.getItem("pwa_install_dismissed");const E=window.navigator.userAgent,S=/iphone|ipad|ipod/i.test(E);if(u(S),S){s(!0);return}const V=z=>{z.preventDefault(),e(z),s(!0)};return window.addEventListener("beforeinstallprompt",V),window.addEventListener("appinstalled",()=>{s(!1),e(null)}),()=>window.removeEventListener("beforeinstallprompt",V)},[]),{showBanner:t,isIOS:o,isInstalled:h,install:async()=>{if(!r){alert(`To install the app: 
On Android: Tap the 3-dots Menu ⋮ and select "Install app". 
On iPhone: Tap Share ⬆ and select "Add to Home Screen".`);return}r.prompt();const{outcome:E}=await r.userChoice;E==="accepted"&&s(!1),e(null)},dismiss:()=>{s(!1),localStorage.setItem("pwa_install_dismissed",Date.now().toString())}}}function GC({isIOS:r,onInstall:e,onDismiss:t}){const[s,o]=ze.useState(!1);return P.jsxs(P.Fragment,{children:[P.jsxs("div",{className:"install-banner glass-panel animate-slide-up",children:[P.jsx("div",{className:"install-banner-icon",children:"📱"}),P.jsxs("div",{className:"install-banner-text",children:[P.jsx("strong",{children:"Install LandVMS"}),P.jsx("span",{children:"Add to home screen for the best experience"})]}),P.jsxs("div",{className:"install-banner-actions",children:[r?P.jsx("button",{className:"btn-install",onClick:()=>o(!0),children:"How to Install"}):P.jsx("button",{className:"btn-install",onClick:e,children:"Install"}),P.jsx("button",{className:"btn-dismiss",onClick:t,children:"✕"})]})]}),s&&P.jsx("div",{className:"ios-modal-overlay",onClick:()=>o(!1),children:P.jsxs("div",{className:"ios-modal glass-panel",onClick:u=>u.stopPropagation(),children:[P.jsx("h3",{children:"Install on iPhone / iPad"}),P.jsxs("ol",{className:"ios-steps",children:[P.jsxs("li",{children:["Tap the ",P.jsx("strong",{children:"Share"})," button ",P.jsx("span",{className:"ios-icon",children:"⬆"})," at the bottom of Safari"]}),P.jsxs("li",{children:["Scroll down and tap ",P.jsx("strong",{children:'"Add to Home Screen"'})]}),P.jsxs("li",{children:["Tap ",P.jsx("strong",{children:'"Add"'})," in the top right"]})]}),P.jsx("button",{className:"btn-primary mt-md",style:{width:"100%"},onClick:()=>{o(!1),t()},children:"Got it!"})]})})]})}function QC(r,e,t){if(!("speechSynthesis"in window))return null;let s=!1,o=null;function u(g){try{const[_,E]=g.split(":").map(Number),S=_>=12?"PM":"AM";return`${_%12||12}:${E.toString().padStart(2,"0")} ${S}`}catch{return g}}const h=`Your meeting with ${r} is scheduled at ${u(e)} in ${t}`;function m(){if(s)return;const g=new SpeechSynthesisUtterance(h);g.rate=.9,g.pitch=1,g.volume=1,g.lang="en-US";const E=window.speechSynthesis.getVoices().find(S=>S.name.includes("Female")||S.name.includes("Zira")||S.name.includes("Samantha")||S.name.includes("Victoria")||S.name.includes("Google")&&S.name.includes("US English")||S.gender==="female");E&&(g.voice=E),g.onend=()=>{s||(o=setTimeout(m,5e3))},window.speechSynthesis.cancel(),window.speechSynthesis.speak(g)}return m(),{stop(){s=!0,clearTimeout(o),window.speechSynthesis.cancel()}}}function YC(){var ke;const[r,e]=ze.useState(null),[t,s]=ze.useState("home"),[o,u]=ze.useState([]),[h,m]=ze.useState(null),g=ze.useRef(new Set),[_,E]=ze.useState(null),S=ze.useRef(null),{showBanner:V,isIOS:z,isInstalled:Q,install:Y,dismiss:H}=KC();ze.useEffect(()=>{"Notification"in window&&Notification.permission!=="granted"&&Notification.requestPermission();const C=n0(go,T=>{T?e(T):(e(null),u([]))});return()=>C()},[]),ze.useEffect(()=>{if(!r)return;const C=FC(jv(Ua,"visits"),UC("userId","==",r.uid)),T=HC(C,R=>{const D=R.docs.map(N=>({id:N.id,...N.data()}));u(D)},R=>{console.error("Firestore read error:",R),alert("Error reading appointments: "+R.message)});return()=>T()},[r]);const ie=async()=>{await r0(go),s("home"),g.current=new Set},ge=C=>{m(C),s("edit_visit")},Te=async C=>{if(window.confirm("Delete this appointment?"))try{await BC(ac(Ua,"visits",C))}catch(T){console.error("Error deleting",T)}},De=async(C,T)=>{try{await Jv(ac(Ua,"visits",C),{status:T})}catch(R){console.error("Error updating",R)}};if(ze.useEffect(()=>{_?S.current||(S.current=QC(_.customerName,_.time,_.location)):S.current&&(S.current.stop(),S.current=null)},[_]),ze.useEffect(()=>{if(!r)return;const C=setInterval(()=>{const T=new Date,R=T.getFullYear(),D=String(T.getMonth()+1).padStart(2,"0"),N=String(T.getDate()).padStart(2,"0"),L=`${R}-${D}-${N}`;o.forEach(A=>{if(A.date===L&&A.status==="pending"){const[Be,lt]=A.time.split(":").map(Number),gt=new Date;gt.setHours(Be,lt,0,0);const $e=(gt-T)/(1e3*60),X=A.reminderMinutes||60;$e>0&&$e<=X&&!g.current.has(A.id)&&(E(A),g.current.add(A.id),Notification.permission==="granted"&&navigator.serviceWorker&&navigator.serviceWorker.ready.then(ue=>{const te=X>=60?`${X/60} hour${X>60?"s":""}`:`${X} minutes`;ue.showNotification(`🚨 NOTIFY: ${_.customerName}`,{body:`MEETING ALERT: Starting in ${te} at ${_.location}! TAP TO OPEN.`,icon:"/logo.png",badge:"/logo.png",tag:`alarm-${_.id}`,renotify:!0,requireInteraction:!0,vibrate:[1e3,500,1e3,500,1e3,500,1e3,500,1e3,500],data:{visitId:_.id},actions:[{action:"view",title:"Open & Speak Alarm",icon:"📢"},{action:"close",title:"I Got It",icon:"✅"}]})}))}})},3e4);return()=>clearInterval(C)},[o,r]),!r)return P.jsx(eP,{onInstall:Y,isInstalled:Q,showBanner:V,isIOS:z,onDismissBanner:H});const be=()=>{switch(t){case"home":return P.jsx(Ry,{visits:o,onUpdateStatus:De,onEditVisit:ge,onDeleteVisit:Te,username:r==null?void 0:r.email.split("@")[0]});case"visits":return P.jsx(JC,{visits:o,onUpdateStatus:De,onEditVisit:ge,onDeleteVisit:Te});case"customers":return P.jsx(XC,{visits:o});case"add_visit":return P.jsx(Cy,{onSave:()=>s("home")},"add");case"edit_visit":return P.jsx(Cy,{onSave:()=>{s("home"),m(null)},visitToEdit:o.find(C=>C.id===h)},`edit-${h}`);case"reports":return P.jsx(ZC,{visits:o});default:return P.jsx(Ry,{visits:o,onUpdateStatus:De,onEditVisit:ge,onDeleteVisit:Te})}};return P.jsxs("div",{className:"app-container",children:[V&&P.jsx(GC,{isIOS:z,onInstall:Y,onDismiss:H}),P.jsxs("header",{className:"app-header glass-panel",children:[P.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"10px"},children:[P.jsx("img",{src:"/logo.png",alt:"Notify Logo",style:{width:"40px",height:"40px",borderRadius:"50%"}}),P.jsx("h1",{style:{margin:0},children:"Notify"})]}),P.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"10px"},children:[P.jsx("button",{onClick:ie,style:{background:"none",border:"1px solid var(--danger, #f87171)",borderRadius:"8px",color:"var(--danger, #f87171)",padding:"4px 10px",cursor:"pointer",fontSize:"0.8rem",fontWeight:"bold"},children:"Logout"}),P.jsx("div",{className:"user-avatar",title:r==null?void 0:r.email,children:P.jsx("span",{children:(ke=r==null?void 0:r.email)==null?void 0:ke.charAt(0).toUpperCase()})})]})]}),P.jsx("main",{className:"main-content animate-fade-in",children:be()}),_&&(()=>{const C=_.reminderMinutes||60,T=C>=60?`${C/60} hour${C>60?"s":""}`:`${C} minutes`;return P.jsx("div",{className:"alarm-modal-overlay",children:P.jsxs("div",{className:"alarm-modal glass-panel animate-pulse-border",children:[P.jsx("h2",{children:"🚨 Upcoming Visit Alert 🚨"}),P.jsxs("p",{className:"alarm-time",children:["Starting in ",T,"!"]}),P.jsx("h3",{className:"customer-name",children:_.customerName}),P.jsxs("p",{className:"visit-location",children:["📍 ",_.location]}),P.jsxs("p",{className:"visit-time",children:["🕒 ",_.time]}),P.jsx("p",{className:"text-muted",style:{fontSize:"0.85rem",marginBottom:"8px"},children:"🔊 Speaking alarm. Please dismiss to stop."}),P.jsx("button",{className:"btn-primary mt-md",style:{width:"100%",cursor:"pointer",padding:"12px",fontSize:"1.1rem"},onClick:()=>{g.current.add(_.id),E(null)},children:"Dismiss Alarm"})]})})})(),P.jsxs("nav",{className:"bottom-nav glass-panel",children:[P.jsxs("button",{className:`nav-item ${t==="home"?"active":""}`,onClick:()=>s("home"),children:[P.jsx("span",{className:"icon",children:"🏠"}),P.jsx("span",{className:"label",children:"Home"})]}),P.jsxs("button",{className:`nav-item ${t==="visits"?"active":""}`,onClick:()=>s("visits"),children:[P.jsx("span",{className:"icon",children:"📅"}),P.jsx("span",{className:"label",children:"Visits"})]}),P.jsx("button",{className:"nav-fab",onClick:()=>s("add_visit"),children:P.jsx("span",{className:"icon",children:"+"})}),P.jsxs("button",{className:`nav-item ${t==="customers"?"active":""}`,onClick:()=>s("customers"),children:[P.jsx("span",{className:"icon",children:"👥"}),P.jsx("span",{className:"label",children:"Clients"})]}),P.jsxs("button",{className:`nav-item ${t==="reports"?"active":""}`,onClick:()=>s("reports"),children:[P.jsx("span",{className:"icon",children:"📊"}),P.jsx("span",{className:"label",children:"Reports"})]})]})]})}function Ry({visits:r,onUpdateStatus:e,onEditVisit:t,onDeleteVisit:s,username:o}){const[u,h]=ze.useState(null),[m,g]=ze.useState(!1),_=new Date,E=_.getFullYear(),S=String(_.getMonth()+1).padStart(2,"0"),V=String(_.getDate()).padStart(2,"0"),z=`${E}-${S}-${V}`,Q=(r||[]).filter(ie=>ie.date===z),Y=Q.filter(ie=>ie.status==="pending"),H=Q.filter(ie=>ie.status==="completed");return P.jsxs("div",{className:"dashboard",children:[P.jsxs("h2",{className:"section-title",children:["Hello, ",o?o.charAt(0).toUpperCase()+o.slice(1):"there"," 👋"]}),P.jsx("p",{className:"section-subtitle",children:"Here's your schedule for today"}),P.jsxs("div",{className:"metrics-grid",children:[P.jsxs("div",{className:"metric-card glass-panel",children:[P.jsx("div",{className:"metric-icon pending",children:"⏳"}),P.jsx("div",{className:"metric-value",children:Y.length}),P.jsx("div",{className:"metric-label",children:"Pending Today"})]}),P.jsxs("div",{className:"metric-card glass-panel",children:[P.jsx("div",{className:"metric-icon completed",children:"✅"}),P.jsx("div",{className:"metric-value",children:H.length}),P.jsx("div",{className:"metric-label",children:"Completed"})]})]}),P.jsxs("div",{className:"upcoming-section",children:[P.jsx("div",{className:"flex-row justify-between items-center mb-sm",children:P.jsx("h3",{children:"Upcoming Visits"})}),P.jsx("div",{className:"visit-list",children:Y.length>0?Y.map(ie=>P.jsxs("div",{className:"visit-card glass-panel",children:[P.jsxs("div",{className:"visit-header",children:[P.jsx("span",{className:"badge warning",children:"Upcoming"}),P.jsx("span",{className:"visit-time",children:ie.time})]}),P.jsx("h4",{className:"customer-name",children:ie.customerName}),P.jsxs("p",{className:"visit-location",children:["📍 ",ie.location]}),P.jsx(Zv,{location:ie.location}),P.jsxs("div",{className:"visit-actions",children:[P.jsx("button",{className:"btn-icon",onClick:()=>t(ie.id),title:"Edit",children:"✏️"}),P.jsx("button",{className:"btn-icon",onClick:()=>{ie.phone&&(window.location.href=`tel:${ie.phone.replace(/\D/g,"")}`)},title:"Call",children:"📞"}),P.jsx("button",{className:"btn-icon",onClick:()=>{const ge=`Hello ${ie.customerName}! This is a reminder for our meeting today at ${ie.time} at ${ie.location}. See you there!`;window.open(`https://wa.me/${ie.phone?ie.phone.replace(/\D/g,""):""}?text=${encodeURIComponent(ge)}`,"_blank")},title:"WhatsApp",children:"💬"}),P.jsx("button",{className:"btn-primary small",onClick:()=>e(ie.id,"completed"),children:"Complete"}),P.jsx("button",{className:"btn-icon btn-delete",onClick:()=>s(ie.id),title:"Delete",children:"🗑️"})]})]},ie.id)):P.jsx("div",{className:"empty-state glass-panel",children:P.jsx("p",{children:"No more visits scheduled for today."})})})]})]})}function JC({visits:r,onUpdateStatus:e,onEditVisit:t,onDeleteVisit:s}){return P.jsxs("div",{className:"visits-page",children:[P.jsx("h2",{children:"All Visits"}),P.jsxs("div",{className:"visit-list",children:[r.length===0&&P.jsx("div",{className:"empty-state glass-panel",children:P.jsx("p",{children:"No visits scheduled yet."})}),r.map(o=>P.jsxs("div",{className:"visit-card glass-panel",children:[P.jsxs("div",{className:"flex-row justify-between items-center mb-sm",children:[P.jsx("div",{className:"visit-header",style:{marginBottom:0},children:P.jsx("span",{className:`badge ${o.status==="completed"?"success":"warning"}`,children:o.status.charAt(0).toUpperCase()+o.status.slice(1)})}),P.jsxs("button",{className:`btn-text ${o.status==="pending"?"success-text":"warning-text"}`,onClick:()=>e(o.id,o.status==="pending"?"completed":"pending"),style:{fontSize:"0.8rem",cursor:"pointer",marginRight:"var(--spacing-sm)"},children:["Mark ",o.status==="pending"?"Completed":"Pending"]}),P.jsxs("div",{className:"flex-row gap-xs",style:{marginLeft:"auto"},children:[P.jsx("button",{className:"btn-icon",onClick:()=>{const u=`Hello ${o.customerName}! This is a reminder for our meeting on ${o.date} at ${o.time} at ${o.location}.`;window.open(`https://wa.me/${o.phone?o.phone.replace(/\D/g,""):""}?text=${encodeURIComponent(u)}`,"_blank")},title:"WhatsApp",children:"💬"}),P.jsx("button",{className:"btn-icon",onClick:()=>t(o.id),title:"Edit",children:"✏️"}),P.jsx("button",{className:"btn-icon btn-delete",onClick:()=>s(o.id),title:"Delete",children:"🗑️"})]})]}),P.jsxs("span",{className:"visit-time d-block mb-sm",children:[o.date," ",o.time]}),P.jsx("h4",{className:"customer-name",children:o.customerName}),P.jsxs("p",{className:"visit-location",children:["📍 ",o.location]}),P.jsx(Zv,{location:o.location}),o.notes&&P.jsxs("p",{className:"text-muted mt-sm",style:{fontStyle:"italic",fontSize:"0.85rem"},children:['"',o.notes,'"']})]},o.id))]})]})}function XC({visits:r}){const[e,t]=ze.useState(""),o=Array.from(new Set(r.map(u=>u.customerName))).map(u=>({name:u,visitsCount:r.filter(h=>h.customerName===u).length})).filter(u=>u.name.toLowerCase().includes(e.toLowerCase()));return P.jsxs("div",{className:"customers-page",children:[P.jsx("h2",{children:"Customers"}),P.jsx("div",{className:"search-bar mb-md mt-sm",children:P.jsx("input",{type:"text",className:"input-field",placeholder:"Search customers...",value:e,onChange:u=>t(u.target.value)})}),P.jsx("div",{className:"customer-list",children:o.length>0?o.map((u,h)=>P.jsx("div",{className:"customer-card glass-panel flex-row justify-between items-center",children:P.jsxs("div",{className:"flex-row items-center gap-md",children:[P.jsx("div",{className:"avatar",children:u.name.charAt(0)}),P.jsxs("div",{children:[P.jsx("h4",{children:u.name}),P.jsxs("p",{className:"text-muted",children:[u.visitsCount," visits"]})]})]})},h)):P.jsx("div",{className:"empty-state glass-panel",children:P.jsx("p",{children:"No customers found."})})})]})}function Cy({onSave:r,visitToEdit:e}){const[t,s]=ze.useState({customerName:e?e.customerName:"",phone:e?e.phone:"",date:e?e.date:new Date().toISOString().split("T")[0],time:e?e.time:"10:00",location:e?e.location:"",notes:e?e.notes:"",reminderMinutes:e&&e.reminderMinutes||60}),[o,u]=ze.useState(!1),[h,m]=ze.useState(!1),g=async E=>{E.preventDefault(),m(!0);const S={...t,reminderMinutes:Number(t.reminderMinutes),userId:go.currentUser.uid,timestamp:OC()};try{e?await Jv(ac(Ua,"visits",e.id),S):await $C(jv(Ua,"visits"),{...S,status:"pending"}),r()}catch(V){console.error("Error saving visit",V),alert("Error saving: "+V.message+`

Make sure your Firestore Rules are set to 'allow read, write: if request.auth != null;'`)}finally{m(!1)}},_=()=>{if(!("webkitSpeechRecognition"in window)){alert("Speech recognition not supported.");return}const E=new window.webkitSpeechRecognition;E.onstart=()=>u(!0),E.onresult=S=>{const V=S.results[0][0].transcript;s({...t,notes:t.notes?t.notes+" "+V:V}),u(!1)},E.onerror=()=>u(!1),E.onend=()=>u(!1),E.start()};return P.jsxs("div",{className:"add-visit-page animate-fade-in",children:[P.jsxs("div",{className:"flex-row justify-between items-center mb-md",children:[P.jsx("h2",{children:e?"Edit Visit":"Schedule Visit"}),P.jsx("button",{className:"btn-text",onClick:r,children:"Cancel"})]}),P.jsxs("form",{className:"glass-panel form-container flex-col gap-md",onSubmit:g,children:[P.jsxs("div",{className:"input-group",children:[P.jsx("label",{children:"Customer Name"}),P.jsx("input",{type:"text",required:!0,placeholder:"E.g. John Doe",value:t.customerName,onChange:E=>s({...t,customerName:E.target.value}),className:"input-field"})]}),P.jsxs("div",{className:"input-group",children:[P.jsx("label",{children:"Phone Number"}),P.jsx("input",{type:"tel",placeholder:"+91 1234567890",value:t.phone,onChange:E=>s({...t,phone:E.target.value}),className:"input-field"})]}),P.jsxs("div",{className:"flex-row gap-md",children:[P.jsxs("div",{className:"input-group flex-1",children:[P.jsx("label",{children:"Date"}),P.jsx("input",{type:"date",required:!0,value:t.date,onChange:E=>s({...t,date:E.target.value}),className:"input-field"})]}),P.jsxs("div",{className:"input-group flex-1",children:[P.jsx("label",{children:"Time"}),P.jsx("input",{type:"time",required:!0,value:t.time,onChange:E=>s({...t,time:E.target.value}),className:"input-field"})]})]}),P.jsxs("div",{className:"input-group",children:[P.jsx("label",{children:"Location / Plot Details"}),P.jsx("input",{type:"text",placeholder:"Enter location",value:t.location,onChange:E=>s({...t,location:E.target.value}),className:"input-field"})]}),P.jsxs("div",{className:"input-group",children:[P.jsx("label",{children:"Notes (Voice Input Supported)"}),P.jsxs("div",{className:"textarea-wrapper",children:[P.jsx("textarea",{rows:"3",placeholder:"Add details...",value:t.notes,onChange:E=>s({...t,notes:E.target.value}),className:"input-field"}),P.jsx("button",{type:"button",className:`mic-btn ${o?"recording":""}`,onClick:_,children:"🎤"})]})]}),P.jsxs("div",{className:"reminder-row",children:[P.jsx("span",{className:"reminder-icon",children:"⏰"}),P.jsx("label",{children:"Remind me before"}),P.jsxs("select",{value:t.reminderMinutes,onChange:E=>s({...t,reminderMinutes:E.target.value}),children:[P.jsx("option",{value:15,children:"15 minutes before"}),P.jsx("option",{value:30,children:"30 minutes before"}),P.jsx("option",{value:60,children:"1 hour before"}),P.jsx("option",{value:120,children:"2 hours before"}),P.jsx("option",{value:180,children:"3 hours before"}),P.jsx("option",{value:240,children:"4 hours before"}),P.jsx("option",{value:300,children:"5 hours before"}),P.jsx("option",{value:360,children:"6 hours before"}),P.jsx("option",{value:420,children:"7 hours before"}),P.jsx("option",{value:480,children:"8 hours before"}),P.jsx("option",{value:1440,children:"1 day before"}),P.jsx("option",{value:2880,children:"2 days before"})]})]}),P.jsx("button",{type:"submit",className:"btn-primary mt-sm",disabled:h,children:h?"Saving...":e?"Save Changes":"Save Appointment"})]})]})}function ZC({visits:r}){const e=new Date,t=e.getFullYear(),s=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0"),u=`${t}-${s}-${o}`,h=r.filter(m=>m.date===u);return r.filter(m=>m.status==="completed").length,P.jsxs("div",{className:"reports-page",children:[P.jsx("h2",{children:"Business Insights"}),P.jsxs("div",{className:"glass-panel mb-md p-md",children:[P.jsx("h3",{children:"Today's Performance"}),P.jsx("div",{className:"flex-row justify-between items-center mt-sm",children:P.jsxs("div",{className:"text-center flex-1",children:[P.jsx("div",{className:"metric-value",children:h.length}),P.jsx("div",{className:"text-muted",children:"Total Scheduled"})]})})]})]})}function eP({onInstall:r,isInstalled:e,showBanner:t,isIOS:s,onDismissBanner:o}){const[u,h]=ze.useState("login"),[m,g]=ze.useState(""),[_,E]=ze.useState(""),[S,V]=ze.useState(""),[z,Q]=ze.useState(""),Y=async H=>{H.preventDefault(),V(""),Q("");try{u==="login"?await ZI(go,m,_):u==="signup"?(await XI(go,m,_),Q("Account created! Logging in...")):u==="forgot"&&(await JI(go,m),Q(`Password reset instructions sent to ${m}`),setTimeout(()=>h("login"),3500))}catch(ie){V(ie.message)}};return P.jsxs("div",{className:"app-container",style:{justifyContent:"center",alignItems:"center",padding:"10px"},children:[t&&!e&&P.jsxs("div",{className:"glass-panel",style:{width:"100%",maxWidth:"400px",padding:"24px 16px",marginBottom:"20px",textAlign:"center"},onClick:r,children:[P.jsx("h3",{style:{color:"#fef08a"},children:"✨ INSTALL AS REAL APP"}),P.jsx("button",{className:"btn-primary",style:{width:"100%",marginTop:"10px"},children:"INSTALL NOW"})]}),P.jsxs("div",{className:"glass-panel animate-fade-in",style:{width:"100%",maxWidth:"400px",padding:"2rem"},children:[P.jsxs("div",{className:"text-center mb-xl",children:[P.jsx("div",{style:{width:"110px",height:"110px",borderRadius:"50%",margin:"0 auto 16px",overflow:"hidden",boxShadow:"0 8px 32px rgba(0,0,0,0.5), 0 0 0 3px rgba(255,255,255,0.15)",border:"2px solid rgba(255,255,255,0.2)"},children:P.jsx("img",{src:"/logo.png",alt:"Notify Logo",style:{width:"100%",height:"100%",objectFit:"cover"}})}),P.jsx("h1",{style:{fontSize:"2rem",letterSpacing:"2px",marginBottom:"4px"},children:"NOTIFY"}),P.jsx("p",{style:{fontSize:"0.75rem",letterSpacing:"2px",textTransform:"uppercase",opacity:.6},children:"ALERTS & NOTIFICATIONS"})]}),S&&P.jsx("div",{className:"badge warning",style:{display:"block",textAlign:"center",marginBottom:"1rem"},children:S}),z&&P.jsx("div",{className:"badge success",style:{display:"block",textAlign:"center",marginBottom:"1rem"},children:z}),P.jsxs("form",{onSubmit:Y,className:"flex-col gap-md",children:[P.jsxs("div",{className:"input-group",children:[P.jsx("label",{children:"Email Address"}),P.jsx("input",{type:"email",className:"input-field",placeholder:"your@email.com",value:m,onChange:H=>g(H.target.value),required:!0})]}),u!=="forgot"&&P.jsxs("div",{className:"input-group",children:[P.jsx("label",{children:"Password"}),P.jsx("input",{type:"password",className:"input-field",placeholder:"••••••••",value:_,onChange:H=>E(H.target.value),required:!0})]}),P.jsx("button",{type:"submit",className:"btn-primary mt-sm",style:{width:"100%"},children:u==="login"?"ACCESS APP":u==="signup"?"CREATE ACCOUNT":"SEND RESET LINK"}),P.jsx("div",{style:{textAlign:"center",marginTop:"1rem"},children:u==="login"?P.jsxs(P.Fragment,{children:[P.jsx("a",{href:"#",onClick:H=>{H.preventDefault(),h("signup")},style:{display:"block",marginBottom:"0.5rem"},children:"New user? Sign up"}),P.jsx("a",{href:"#",onClick:H=>{H.preventDefault(),h("forgot")},children:"Forgot password?"})]}):P.jsx("a",{href:"#",onClick:H=>{H.preventDefault(),h("login")},children:"← Back to Login"})})]})]})]})}function Zv({location:r}){return r?P.jsx("div",{className:"map-preview",style:{marginTop:"var(--spacing-xs)",marginBottom:"var(--spacing-sm)",borderRadius:"var(--border-radius-sm)",overflow:"hidden",height:"140px",border:"1px solid var(--glass-border)"},children:P.jsx("iframe",{width:"100%",height:"100%",frameBorder:"0",style:{border:0,filter:"invert(90%) hue-rotate(180deg) contrast(1.1) opacity(0.8)"},src:`https://maps.google.com/maps?q=${encodeURIComponent(r)}&t=&z=14&ie=UTF8&iwloc=&output=embed`,allowFullScreen:!0,title:`Map for ${r}`})}):null}pw.createRoot(document.getElementById("root")).render(P.jsx(ze.StrictMode,{children:P.jsx(YC,{})}));
